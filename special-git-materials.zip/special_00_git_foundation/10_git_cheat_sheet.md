# 10 — Git Cheat Sheet by Situation

## ฉันอยู่ที่ไหนและมีอะไรเปลี่ยน

```powershell
git rev-parse --show-toplevel
git branch --show-current
git status --short --branch
```

## ดูการเปลี่ยนแปลง

```powershell
git diff
git diff --staged
git diff HEAD
```

## Stage อย่างตั้งใจ

```powershell
git add path/to/file
git add -p
git restore --staged path/to/file
```

## Commit

```powershell
git commit -m "feat: add payment validation"
git show --stat HEAD
```

## History

```powershell
git log --oneline --decorate --graph --all
git show <commit>
git log -p -- path/to/file
```

## Branch

```powershell
git switch -c feature/name
git switch main
git branch -vv
git branch -d feature/name
```

## Merge

```powershell
git switch main
git merge feature/name
git merge --abort
```

หลัง merge รัน tests และดู graph

## Remote

```powershell
git remote -v
git fetch origin
git branch -vv
git push -u origin feature/name
```

## Undo/Recovery

```powershell
# unstage แต่เก็บ content
git restore --staged path/to/file

# ทิ้ง unstaged tracked change หลังอ่าน diff
git restore path/to/file

# เอา file version จาก commit มาเป็น working change
git restore --source=<commit> -- path/to/file

# shared bad commit
git revert <commit>

# หา local commit ที่ดูเหมือนหาย
git reflog
git branch rescue/name <commit>
```

## Ignore

```powershell
git check-ignore -v path/to/file
git status --ignored
git rm --cached .env
```

## Conflict Checklist

```text
status
อ่าน requirement ทั้งสองฝั่ง
แก้ markers/semantic result
test
add resolved files
status
commit/continue
inspect graph
```

## ก่อน Push/PR

```text
status
diff/staged diff
tests
secret/private file check
commit history
PR summary + risks + evidence
```

## หยุดก่อนใช้

คำสั่งเหล่านี้ต้องเข้าใจและใช้เฉพาะ sandbox/กรณีจำเป็น:

```text
git reset --hard
git clean -fd
git push --force
git branch -D
```

หากไม่แน่ใจ ให้สร้าง rescue branch/copy และตรวจ state ก่อน

