# 06 — Remotes, GitHub, Pull and Push

## 1. Remote คือชื่ออ้างอิง URL

ดู remotes:

```powershell
git remote -v
```

`origin` เป็น convention ไม่ใช่ keyword พิเศษ

```powershell
git remote add origin <url>
```

Repository หนึ่งมีหลาย remotes ได้ เช่น `origin` และ `upstream`

---

## 2. Clone ทำอะไร

```powershell
git clone <url>
```

โดยทั่วไป:

- สร้าง folder
- ดาวน์โหลด objects/history
- ตั้ง `origin`
- สร้าง local branch ที่ track default remote branch
- checkout working tree

Clone ไม่ใช่การ download ZIP เพราะได้ history และ remote relationships

---

## 3. Fetch

```powershell
git fetch origin
```

ดาวน์โหลด commits/refs ใหม่ แต่ไม่ merge เข้า branch ปัจจุบันโดยอัตโนมัติ

หลัง fetch ตรวจ:

```powershell
git log --oneline --graph --decorate --all
git diff main..origin/main
```

Fetch เหมาะเมื่ออยาก “ดูก่อนรวม”

---

## 4. Pull

`git pull` คือ fetch แล้ว integrate ตาม config (merge/rebase)

เพราะ pull เปลี่ยน branch/working state จึงควร:

```text
status clean
→ รู้ current branch
→ fetch/inspect เมื่อเสี่ยง
→ pull ตาม team policy
→ test
```

อย่าใช้ pull เป็นคำสั่งแก้ทุกปัญหา เพราะอาจเพิ่ม merge/rebase ที่ยังไม่เข้าใจ

---

## 5. Push

```powershell
git push -u origin feature/report
```

`-u` ตั้ง upstream ให้ครั้งถัดไปใช้ `git push`/`git pull` สั้นได้

Push อาจถูก reject หาก remote branch มี commits ที่ local ไม่มี เป็น safety เพื่อป้องกัน history หาย

เมื่อ reject:

1. fetch
2. inspect divergence
3. integrate ตาม team workflow
4. resolve/test
5. push ใหม่

อย่า force push ทันที

---

## 6. Tracking Branch

ดู:

```powershell
git branch -vv
```

ข้อความ ahead/behind เทียบ upstream:

- ahead 2: local มี 2 commits ที่ remote tracking ref ไม่มี
- behind 1: remote tracking ref มี 1 commitที่ local ไม่มี
- diverged: ทั้งสองมี commits ของตัวเอง

ต้อง fetch ก่อนเพื่อให้ข้อมูล remote tracking สด

---

## 7. Authentication

Git host สมัยใหม่มักใช้:

- credential manager/token สำหรับ HTTPS
- SSH keys
- enterprise SSO policies

ห้ามใส่ token ใน remote URL ที่ commit/log/shared output อาจเผยแพร่

ทำตามระบบของบริษัทเมื่อเริ่มฝึกงาน ไม่สร้าง workaround ข้าม policy

---

## 8. Force Push

Force push rewrite remote branch และอาจลบ commits ของคนอื่น

ถ้าจำเป็นบน private feature branch ทีมอาจใช้:

```powershell
git push --force-with-lease
```

`--force-with-lease` ปลอดภัยกว่า `--force` เพราะตรวจว่าปลายทางยังอยู่จุดที่คาด แต่ยังเป็น operation rewrite history

สำหรับ Track นี้ไม่ต้องใช้เพื่อผ่าน

---

## 9. Offline Remote Lab

เรียน remote โดยไม่ต้อง GitHub ด้วย bare repository local:

```text
remote.git     ← จำลอง server
alice/         ← clone 1
bob/           ← clone 2
```

ใช้ฝึก:

- push
- fetch
- remote change
- non-fast-forward rejection
- conflict

Repository generator ใน Challenge จะสร้าง environment นี้ให้

---

## 10. Checkpoint

- [ ] แยก remote กับ remote-tracking ref
- [ ] อธิบาย fetch/pull/push
- [ ] ตรวจ ahead/behind
- [ ] ไม่ force push เมื่อ push rejected
- [ ] ไม่เผย token ใน URL/log
- [ ] ใช้ local bare remote ฝึกได้

