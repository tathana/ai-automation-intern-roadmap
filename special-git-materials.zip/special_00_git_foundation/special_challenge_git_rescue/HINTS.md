# Git Rescue — Progressive Hints

## Level 1 — Observe

- อ่าน `status`, `branch -vv`, graph และ reflog ก่อน
- ถามว่า state ใด local และ state ใด remote-tracking
- ตรวจ staged กับ unstaged แยกกัน

## Level 2 — Safety

- ปกป้อง commit ที่ดูเหมือนหายด้วย branch ใหม่
- shared bad commit ควรสร้าง reversal commit
- untracked secret ต้อง ignore ก่อน broad add

## Level 3 — Conflict

- อ่าน common base/ours/theirs
- อย่าเลือกทั้งไฟล์ฝั่งเดียว
- `check_app.py` คือ acceptance evidence

## Level 4 — Remote

- fetch ทำให้เห็น remote stateโดยยังไม่รวม
- push reject ไม่ได้แปลว่าต้อง force
- integrate แล้ว test ก่อน push

ไม่มี command sequence เฉลยเต็ม เพราะการให้คะแนนวัดการอ่าน state และเลือกคำสั่ง

