# Git Rescue — Safe Runbook

## สร้าง Lab

จาก directory ที่เก็บ Track:

```powershell
& .\special_challenge_git_rescue\setup_lab.ps1 `
  -TargetPath "$env:TEMP\git-rescue-lab-01"
```

Target ต้องยังไม่มี

## เริ่มสำรวจ

```powershell
Set-Location "$env:TEMP\git-rescue-lab-01\alice"
git rev-parse --show-toplevel
git status --short --branch
git remote -v
git branch -vv
git log --oneline --decorate --graph --all
```

## Verification Command

```powershell
python check_app.py
```

หาก Python command ต่างในเครื่อง ให้ใช้ interpreter ที่ environment กำหนด

## Reset Lab

อย่าลบ target จาก script หรือ command ที่ประกอบ path แบบเสี่ยง ให้สร้าง lab ใหม่ด้วยชื่อใหม่ เช่น `git-rescue-lab-02`

## Evidence

เก็บเฉพาะ:

- status/log snippets
- hashes สั้นใน lab
- decisions
- verification result

ไม่เก็บ user tokens, credentials หรือ paths ที่มีข้อมูลส่วนตัวเกินจำเป็น

