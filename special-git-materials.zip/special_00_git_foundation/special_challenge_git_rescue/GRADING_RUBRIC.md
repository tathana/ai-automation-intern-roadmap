# Git Rescue — Grading Rubric

## คะแนนรวม 100

| หมวด | คะแนน |
|---|---:|
| Mental model และ reconnaissance | 15 |
| Status/diff/staging accuracy | 15 |
| Atomic commit quality | 15 |
| Branch/merge workflow | 15 |
| Conflict resolution + verification | 15 |
| Undo/recovery/reflog | 10 |
| Secrets/repository hygiene | 10 |
| PR/handoff communication | 5 |

## Pass

- 75/100 ขึ้นไป
- ไม่มี Critical Failure

## Critical Failures

- commit `.env`/credential
- force push shared main
- rewrite shared bad commit แทน revert โดยไม่มี requirement
- ทำ recovered work สูญหาย
- ใช้ destructive command โดยไม่ตรวจ target/state
- แก้ conflict โดยทิ้ง requirement ฝั่งหนึ่งและไม่ test
- รายงาน success ทั้งที่ check fail

## Oral Review

ต้องตอบได้:

1. HEAD และ branches ชี้อะไร?
2. ทำไมใช้ revert กับ bad shared commit?
3. staged diff ต่างจาก working diff อย่างไร?
4. recovered commit หาเจอได้อย่างไร?
5. conflict decision รักษา requirements ใด?
6. หาก push rejected จะทำอย่างไร?

