# Special Challenge — Git Rescue Mission

## Repair a Broken Team Repository

ข้อสอบนี้จำลอง repository ทีมที่มี history, branches, remote และ mistakes หลายชนิด คุณต้องตรวจและซ่อมโดยรักษาหลักฐานและไม่ทำงานหาย

## เอกสาร

- [Mission Brief](MISSION.md)
- [Runbook](RUNBOOK.md)
- [Grading Rubric](GRADING_RUBRIC.md)
- [Progressive Hints](HINTS.md)
- [`setup_lab.ps1`](setup_lab.ps1) สร้าง lab ใหม่ใน directory ที่ระบุ

## Safety

- Script ปฏิเสธ target ที่มีอยู่แล้ว
- ใช้ target ใหม่เฉพาะสำหรับ lab
- ห้ามชี้ target ไป `D:\COOP`, `Pre-coop`, `short_course`, home หรือ root drive
- Lab ใช้ local bare remote ไม่ต้องเชื่อมอินเทอร์เน็ต
- หาก lab พัง สร้าง target ใหม่ ไม่แก้ script ให้ลบ directory กว้าง ๆ

## Recommended Flow

1. อ่าน Mission โดยยังไม่เปิด Hints
2. รัน setup script ไปยัง temp/lab directory ใหม่
3. สำรวจอย่าง read-only ก่อน
4. เขียน rescue plan
5. ทำทีละ mission พร้อม evidence
6. ส่ง Handoff Summary

