# Git Rescue Mission — Mission Brief

## Scenario

ทีม Automation มี repository จำลองสอง working copies (`alice`, `bob`) และ bare remote (`remote.git`) สถานการณ์ประกอบด้วย:

- feature branch ที่ยังไม่รวม
- remote main เดินหน้ากว่า local บางตัว
- conflict ที่ต้องแก้เชิงความหมาย
- `.env` ที่ต้องถูก ignore และห้าม commit
- change หลายเรื่องปนกันใน Working Tree
- bad commit บน shared main ที่ต้อง revert
- branch ที่ถูกลบแต่ commit ยังหาได้ผ่าน reflog
- README ที่ต้องเขียน handoff ให้ทีม

## Mission 1 — Reconnaissance

ใน `alice`:

- ระบุ repo root/current branch
- ตรวจ working/staged/untracked/ignored state
- แสดง graph ทุก refs
- ตรวจ remotes และ tracking branches
- ห้ามเปลี่ยน state ในขั้นนี้

Deliverable: `recon.md`

## Mission 2 — Secret and Hygiene

- ตรวจว่า `.env` ไม่ tracked/staged
- เพิ่ม ignore rules ที่เหมาะสม
- เก็บ `.env.example` แบบ placeholder
- ตรวจ runtime log/cache
- commit hygiene change อย่างเป็นเรื่องเดียว

หากพบ secret จริง ให้ปฏิบัติเป็น incident และไม่ copy ลง report

## Mission 3 — Atomic History

Working Tree มี source/docs changes ปนกัน:

- แบ่ง commits ด้วย explicit/patch staging
- ตรวจ staged diff
- messages ต้องบอก intention

## Mission 4 — Recover Lost Work

- หา commit จาก branch ที่ถูกลบด้วย reflog
- สร้าง `rescue/recovered-notes`
- ตรวจ content ก่อนตัดสินใจ merge/cherry-pick

เป้าหมายคือรักษา commit ให้ reachable ก่อน ไม่ใช่รีบรวม

## Mission 5 — Shared Bad Commit

บน remote/main มี commit ที่ทำ config ผิดและถือว่า shared แล้ว:

- อัปเดตข้อมูล remote อย่างปลอดภัย
- ตรวจ bad commit
- ใช้ history-preserving reversal
- เพิ่ม/รัน check ที่พิสูจน์ fix
- push โดยไม่ force

## Mission 6 — Feature Integration

- ตรวจ `feature/resume-summary`
- sync กับ main ตาม merge-based workflow
- แก้ conflict โดยรักษาทั้ง validation และ report requirement
- run `python check_app.py`
- push feature และเตรียม PR summary

## Mission 7 — Handoff

สร้าง `HANDOFF.md`:

```markdown
## Status
## Changes Made
## Commits/Branches
## Verification
## Conflicts and Decisions
## Risks/Remaining Work
## Commands That Were Intentionally Avoided
```

## Completion Conditions

- working tree clean เว้นไฟล์ evidence ที่ตั้งใจ commit
- checks ผ่าน
- ไม่มี secret tracked
- shared bad commit ถูก revert ไม่ rewrite
- recovered commit มี branch ปกป้อง
- feature history review ได้
- push ไม่มี force

