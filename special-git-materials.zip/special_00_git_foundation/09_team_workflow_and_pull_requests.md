# 09 — Team Workflow and Pull Requests

## 1. Pull Request ไม่ใช่ Git Command หลัก

PR เป็น collaboration feature ของ hosting platform เพื่อ:

- review diff
- discussion
- checks/CI
- approvals
- merge policy

Git จัด commits/branches ส่วน platform จัด review workflow

---

## 2. Typical Flow

```text
รับ task/issue
→ ทวน requirement
→ update local base
→ create branch
→ implement in small commits
→ test
→ push branch
→ open PR
→ address review
→ merge
→ cleanup
```

รายละเอียด merge/rebase/squash ขึ้นกับทีม อย่าบังคับ preference ส่วนตัว

---

## 3. Before Coding

- อ่าน acceptance criteria
- ยืนยัน branch base
- ดู related code/tests
- ระบุ out of scope
- แจ้ง assumption ที่มีผล

Git history ที่ดีเริ่มจาก scope ที่ดี

---

## 4. PR Description

Template:

```markdown
## What
- เปลี่ยนอะไร

## Why
- ปัญหา/requirement คืออะไร

## How
- design decision สำคัญ

## Testing
- tests/commands/results

## Risks
- ผลกระทบและ rollback

## Screenshots/Samples
- ถ้าจำเป็น
```

อย่าเขียนเพียง “please review” แล้วให้ reviewerสืบทุกอย่างเอง

---

## 5. Commit Series สำหรับ Review

ตัวอย่าง:

```text
feat: add normalized resume schema
feat: validate extracted resume evidence
test: cover missing and fabricated evidence
docs: explain human review states
```

Reviewer อ่าน intention ทีละขั้นได้ แต่ไม่จำเป็นต้องแยก source/test ทุกครั้งหากทำให้ commit หนึ่งไม่สมบูรณ์

---

## 6. รับ Feedback

เมื่อได้ comment:

1. ทำความเข้าใจปัญหา
2. ถ้าไม่ชัด ถามพร้อม evidence
3. แก้และเพิ่ม test เมื่อเป็น bug
4. ตอบว่าเปลี่ยนตรงไหน
5. ไม่ resolve comment ก่อนจัดการจริง

ไม่ต้องเห็นด้วยทุกข้อ แต่ต้องอธิบาย trade-off อย่างมืออาชีพ

---

## 7. Review คนอื่น

ตรวจ:

- correctness
- edge cases
- security/privacy
- tests
- readability
- compatibility
- docs/operations

เขียน comment เฉพาะเจาะจง:

```text
กรณี event ID เดิมแต่ payload ต่าง code path นี้จะ overwrite original หรือไม่?
ขอเพิ่ม conflict test เพื่อยืนยัน behavior นี้ครับ
```

ดีกว่า “โค้ดไม่ดี”

---

## 8. Keeping Branch Updated

ใช้วิธีทีมกำหนด:

- merge base branch เข้า feature
- rebase private feature branch

ก่อน integrate:

- working tree clean
- fetch
- inspect divergence
- backup/rescue หากไม่มั่นใจ

หลัง integrate ต้อง test

---

## 9. Handoff

ก่อนหยุดงานหรือส่งต่อ:

```text
Status
Completed
Remaining
How to run/test
Known failures
Branch/commit/PR
Config needed (no secret values)
Next recommended action
```

Handoff ที่ดีช่วยให้ทีมไม่ต้อง reverse-engineerงานครึ่งวัน

---

## 10. Checkpoint

- [ ] อธิบาย Git vs PR platform
- [ ] สร้าง branch จาก base ที่ถูก
- [ ] เขียน PR What/Why/How/Testing/Risks
- [ ] รับและตอบ review พร้อม evidence
- [ ] review โดยเน้น behavior/risks
- [ ] ทำ handoff ที่คนอื่นทำต่อได้

