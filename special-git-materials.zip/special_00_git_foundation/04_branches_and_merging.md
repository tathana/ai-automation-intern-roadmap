# 04 — Branches and Merging

## 1. Branch คือ Pointer ราคาถูก

การสร้าง branch ไม่ได้ copy ทุกไฟล์ แต่สร้างชื่อชี้ commit:

```powershell
git switch -c feature/report
```

ตรวจ:

```powershell
git branch --show-current
git log --oneline --decorate --graph --all
```

---

## 2. ตั้งชื่อ Branch

ตัวอย่าง:

```text
feature/resume-parser
fix/currency-validation
docs/setup-guide
test/idempotency-cases
```

ตาม convention ของทีม และหลีกเลี่ยงชื่อกว้าง เช่น `mybranch`, `new`, `test2`

---

## 3. Switch อย่างปลอดภัย

```powershell
git status
git switch main
```

Git อาจไม่ยอม switch หาก uncommitted changes จะถูกทับ นี่เป็น safety feature

ตัวเลือก:

- commit งานบน branch ปัจจุบัน
- เก็บการแก้ไว้และ switch หากไม่ชน
- stash อย่างเข้าใจ (ไม่ใช้เป็นโกดังถาวร)
- สร้าง branch ใหม่จาก current state

---

## 4. Fast-forward Merge

ถ้า main ไม่มี commit ใหม่หลังแตก branch:

```text
A ── B   main
      └── C ── D   feature
```

merge สามารถเลื่อน main ไป D:

```text
A ── B ── C ── D   main, feature
```

ไม่มี merge commit ใหม่

---

## 5. Three-way Merge

ถ้าทั้งสองฝั่งเดินต่อ:

```text
      C ── D   feature
     /
A ── B ── E   main
```

Git รวมเป็น:

```text
      C ── D
     /      \
A ── B ── E ── M   main
```

`M` มี parents สองตัว

---

## 6. Merge Workflow

```powershell
git switch main
git status
git merge feature/report
```

หลัง merge:

```powershell
git log --oneline --decorate --graph --all
```

รัน tests แม้ Git บอก merge สำเร็จ เพราะ syntactic merge ไม่รับประกัน behavior

---

## 7. Delete Branch

หลัง merge และตรวจแล้ว:

```powershell
git branch -d feature/report
```

`-d` ป้องกันลบ branch ที่ยังไม่ merge ส่วน `-D` บังคับและเสี่ยงกว่า

ลบชื่อ branch ไม่ได้ลบ commits ที่ยัง reachable จาก main

---

## 8. Merge หรือ Rebase

Track นี้ใช้ merge เป็นฐานก่อน

Rebase ย้าย/สร้าง commits ใหม่บนฐานใหม่ ทำ history เส้นตรงได้แต่เปลี่ยน hashes ไม่ควร rebase shared commits โดยไม่มีข้อตกลง

เรียน mental model ของ merge ให้แน่นก่อนใช้ rebase

---

## 9. Exercise

1. จาก main สร้าง `feature/report`
2. ทำสอง atomic commits
3. กลับ main และทำ docs commit ที่ไม่ชน
4. merge feature
5. วาด graph ก่อน/หลัง
6. รัน tests
7. ลบ branch ด้วย `-d`

---

## 10. Checkpoint

- [ ] branch เป็น pointer ไม่ใช่ copy folder
- [ ] ตรวจ current branch/working tree ก่อน switch
- [ ] แยก fast-forward กับ merge commit
- [ ] รัน tests หลัง merge
- [ ] ใช้ `-d` ก่อน `-D`
- [ ] รู้ว่า rebase rewrite commits

