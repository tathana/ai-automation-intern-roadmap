# 05 — Merge Conflicts

## 1. Conflict ไม่ใช่ Git พัง

Conflict หมายถึง Git ไม่มีข้อมูลพอจะตัดสินใจว่าผลลัพธ์ที่ถูกต้องคืออะไร จึงหยุดให้มนุษย์เลือก

เกิดได้เมื่อ:

- แก้บรรทัดใกล้กันคนละ branch
- branch หนึ่งลบไฟล์ อีก branch แก้ไฟล์
- rename/delete/modify ซับซ้อน
- binary files ต่างกัน

---

## 2. เริ่มจาก Status

หลัง conflict:

```powershell
git status
```

Git บอก:

- กำลัง merge อะไร
- files ใด unmerged
- วิธี continue/abort

อย่าเริ่มลบ marker แบบสุ่มก่อนอ่าน context

---

## 3. Conflict Markers

```text
<<<<<<< HEAD
ข้อความจาก branch ปัจจุบัน
=======
ข้อความจาก branch ที่กำลัง merge
>>>>>>> feature/report
```

ผลลัพธ์ต้อง:

- เลือกฝั่งหนึ่ง
- ผสมทั้งสองอย่างมีเหตุผล
- หรือเขียนคำตอบใหม่
- ลบ markers ทุกตัว

คำว่า ours/theirs ขึ้นกับ operation/context จึงควรอ่านชื่อ branches และ diff ไม่เดา

---

## 4. Resolution Workflow

```text
1. git status
2. อ่าน requirement ของทั้งสองฝั่ง
3. เปิด conflicted file
4. เลือก semantic result
5. ลบ markers
6. syntax/lint/test
7. git add resolved files
8. git status
9. git commit/continue
10. inspect final diff/log
```

Git รู้ว่า resolved เมื่อ stage file แล้ว แต่ stage ไม่ได้พิสูจน์ว่าคำตอบถูก จึงต้อง test ก่อนจบ

---

## 5. ดูแต่ละฝั่ง

ระหว่าง merge สามารถใช้:

```powershell
git diff
git show :1:path/to/file
git show :2:path/to/file
git show :3:path/to/file
```

แนวคิด stages:

- 1: common base
- 2: ours
- 3: theirs

ใช้เมื่อ marker ใหญ่หรือเครื่องมือ editor ทำให้สับสน

---

## 6. Abort

หากเริ่ม merge ผิด branch หรือยังไม่พร้อม:

```powershell
git merge --abort
```

เป้าหมายคือกลับ state ก่อน merge แต่ควรตรวจ status/diff และไม่ควรมี unrelated uncommitted work ก่อนเริ่ม merge

Abort ไม่ใช่ความล้มเหลว เป็นการหยุดเพื่อจัดสถานการณ์ให้ถูก

---

## 7. Semantic Conflict

Git อาจ merge ได้โดยไม่มี marker แต่ระบบผิด เช่น:

- branch A เปลี่ยนชื่อ function
- branch B เพิ่ม call ด้วยชื่อเดิมในไฟล์อื่น
- files ไม่ชน แต่ tests fail

เรียกว่า semantic conflict จึงต้องรัน tests หลัง merge ทุกครั้ง

---

## 8. ป้องกัน Conflict

- branches อายุสั้น
- sync บ่อยตาม workflow ทีม
- commits เล็ก
- แบ่ง ownership/ไฟล์อย่างชัด
- คุยก่อน refactor ใหญ่
- format changes แยกจาก behavior changes
- ไม่แก้ generated/binary files พร้อมกันโดยไม่จำเป็น

ไม่สามารถและไม่จำเป็นต้องกำจัด conflict ทั้งหมด เป้าหมายคือแก้อย่างมั่นใจ

---

## 9. Exercise

สร้าง conflict โดยตั้งใจ:

1. main แก้ข้อความ config หนึ่งแบบ
2. feature แก้บรรทัดเดียวกันอีกแบบ
3. merge
4. อ่าน status และ marker
5. เขียนผลลัพธ์ที่รักษาความตั้งใจทั้งสองฝั่ง
6. รัน test/check
7. stage และจบ merge
8. แสดง graph

เพิ่มรอบที่สองแล้วใช้ abort

---

## 10. Checkpoint

- [ ] อธิบายว่าทำไม conflict เกิด
- [ ] อ่าน marker ได้
- [ ] ตรวจ base/ours/theirs ได้
- [ ] test ก่อนจบ merge
- [ ] abort merge ได้
- [ ] รู้จัก semantic conflict

