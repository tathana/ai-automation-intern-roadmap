# 02 — Working Tree, Staging and Commit

## 1. `git status` คือ Dashboard

ใช้แบบเต็มเมื่อเรียน:

```powershell
git status
```

ใช้แบบย่อเมื่อคุ้น:

```powershell
git status --short --branch
```

ตัวอย่าง short status:

```text
 M app.py
M  README.md
MM config.py
?? notes.txt
```

สองคอลัมน์คือ index/staging และ working tree:

- ` M`: modified แต่ unstaged
- `M `: staged
- `MM`: staged version แล้วแก้ต่ออีก
- `??`: untracked

---

## 2. `git add` ไม่ได้แปลว่า Add File อย่างเดียว

`git add` นำ content ปัจจุบันไปใส่ staging area:

```powershell
git add app.py
```

หากแก้ app.py ต่อ ต้อง add ใหม่หากต้องการ version ล่าสุดใน commit

ดู staged:

```powershell
git diff --staged
```

ดู unstaged:

```powershell
git diff
```

---

## 3. Stage อย่างตั้งใจ

แนะนำ:

```powershell
git add path/to/file
git add -p
```

ระวัง:

```powershell
git add .
```

ไม่ใช่คำสั่งผิด แต่ควรใช้หลังตรวจ status และรู้ว่าทุกการเปลี่ยนแปลงควรอยู่ commit เดียวกัน

---

## 4. Interactive Patch

```powershell
git add -p
```

Git แบ่ง diff เป็น hunks ให้เลือก เช่น:

- `y`: stage hunk
- `n`: ไม่ stage
- `s`: split hunk
- `e`: edit hunk อย่างระวัง
- `q`: quit
- `?`: help

เหมาะเมื่อไฟล์เดียวมีทั้ง feature และ typo fix

---

## 5. Atomic Commit

Commit หนึ่งควรตอบคำถามได้ว่า “ทำเรื่องอะไรหนึ่งเรื่อง”

ตัวอย่างดี:

```text
feat: validate payment currency
test: cover unsupported currency cases
docs: document environment setup
```

ตัวอย่างกว้างเกิน:

```text
update files
fix stuff
final
```

Atomic ไม่ได้แปลว่าหนึ่งไฟล์ต่อ commit บาง feature ต้องมี source + tests + docs ใน commit เดียวเพื่อให้ snapshot ใช้งานได้

---

## 6. Commit Message

รูปแบบง่าย:

```text
<type>: <imperative summary>
```

Types ที่ใช้ได้:

- `feat`: ความสามารถใหม่
- `fix`: แก้ bug
- `test`: tests
- `docs`: documentation
- `refactor`: เปลี่ยนโครงโดยไม่เปลี่ยน behavior
- `chore`: maintenance

Body ใช้อธิบาย “ทำไม” และผลกระทบเมื่อจำเป็น

อย่าฝืน Conventional Commits หากทีมใช้มาตรฐานอื่น ให้ตามทีม

---

## 7. Pre-commit Ritual

ก่อน commit:

```text
1. git status
2. git diff
3. run relevant tests
4. git add อย่างตั้งใจ
5. git diff --staged
6. ตรวจ secrets/debug output
7. git commit
8. git status
```

หลัง commit working tree ไม่จำเป็นต้อง clean เสมอ ถ้าตั้งใจเหลืองานสำหรับ commit ถัดไป แต่ต้องรู้ว่าค้างอะไร

---

## 8. Partial Work

หาก feature ยังไม่เสร็จ:

- commit บน private feature branch พร้อม message ชัดได้
- หรือเก็บโดยยังไม่ commitหากระยะสั้นและปลอดภัย
- อย่าฝืนสร้าง “fake complete” commit บน main

ทีมต่างกันเรื่อง WIP commits ให้เรียน workflow ของทีม

---

## 9. Exercise — Three Changes, Three Commits

แก้ไฟล์จำลองให้มี:

1. เพิ่ม validation
2. เพิ่ม test
3. แก้ README ที่ไม่เกี่ยว

แบ่งเป็น commits อย่างมีเหตุผล ใช้ `git add -p` อย่างน้อยหนึ่งครั้ง และบันทึก staged diff ก่อน commit

---

## 10. Checkpoint

- [ ] อ่าน short status สองคอลัมน์ได้
- [ ] แยก `diff` กับ `diff --staged`
- [ ] รู้ว่า add เก็บ content version ปัจจุบัน
- [ ] ใช้ patch staging ได้
- [ ] อธิบาย atomic commit
- [ ] ตรวจ staged diff และ tests ก่อน commit

