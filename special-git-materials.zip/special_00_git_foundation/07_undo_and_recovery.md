# 07 — Undo and Recovery

## 1. ก่อน Undo ต้องจำแนก State

ถามตามลำดับ:

1. งานอยู่ใน Working Tree หรือไม่?
2. Staged แล้วหรือยัง?
3. Commit แล้วหรือยัง?
4. Push/shared แล้วหรือยัง?
5. ต้องการเก็บ content หรือทิ้งจริง?

คำว่า “ย้อนกลับ” อาจหมายถึงหลายอย่าง จึงไม่มีคำสั่งเดียวสำหรับทุกกรณี

---

## 2. ยังไม่ Staged

ดูก่อน:

```powershell
git diff -- path/to/file
```

หากตั้งใจทิ้งการแก้ tracked file:

```powershell
git restore path/to/file
```

คำสั่งนี้ทำ uncommitted changes ในไฟล์นั้นหาย ใช้หลังอ่าน diff เท่านั้น

Untracked file ไม่ได้รับผลจาก restore และ Git อาจกู้ไม่ได้หากลบ

---

## 3. Staged ผิด แต่ต้องการเก็บไฟล์

```powershell
git restore --staged path/to/file
```

เอาออกจาก index แต่ Working Tree content ยังอยู่

ตรวจ:

```powershell
git status
git diff
git diff --staged
```

---

## 4. กู้ไฟล์จาก Commit

นำเวอร์ชันจาก commit มาใส่ Working Tree:

```powershell
git restore --source=<commit> -- path/to/file
```

นี่สร้าง uncommitted change ให้ตรวจ/commit ไม่ได้ย้าย branch ไป commit เก่า

---

## 5. แก้ Commit ล่าสุดก่อน Share

หากลืมไฟล์หรือ message ผิด:

```powershell
git commit --amend
```

Amend สร้าง commit ใหม่ hash ใหม่

ใช้ได้ดีเมื่อ commit ยังไม่ shared หาก push แล้ว amend จะทำ history diverge และอาจต้อง rewrite remote

---

## 6. Revert สำหรับ Shared History

```powershell
git revert <bad-commit>
```

สร้าง commit ใหม่ที่ย้อนผลของ commit เป้าหมาย ประวัติยังโปร่งใส เหมาะกับ commits ที่ push/shared แล้ว

Revert อาจ conflict หาก code ภายหลังพึ่ง change นั้น ต้องแก้และ test

---

## 7. Reset Mental Model

`git reset` เลื่อน branch pointer และอาจเปลี่ยน index/working treeตาม mode:

- `--soft`: เลื่อน pointer, เก็บ changes staged
- default/`--mixed`: เลื่อน pointer, เก็บ changes unstaged
- `--hard`: เลื่อน pointerและทิ้ง tracked working changes

Track นี้ไม่ใช้ `reset --hard` ในงานจริง เพราะความเสี่ยงสูง ใช้ sandbox เท่านั้นหากต้องศึกษา

ก่อน reset ต้องรู้ commit target และตรวจว่า commits/changes ต้องเก็บหรือไม่

---

## 8. Reflog

Reflog เก็บการเคลื่อนของ local refs/HEAD ชั่วระยะหนึ่ง:

```powershell
git reflog
```

หาก branch ถูกลบหรือ reset ผิด อาจหา commit แล้วสร้าง rescue branch:

```powershell
git branch rescue/recovered-work <commit>
```

สร้าง branch ก่อนสำรวจต่อเพื่อให้ commit reachable ชัดเจน

Reflog เป็น local ไม่ได้ push ไป remote และไม่ใช่ backup ถาวร

---

## 9. Detached HEAD

เมื่อ checkout/switch ไป commit โดยตรง HEAD ไม่ได้อยู่บน branch:

```text
HEAD → commit X
```

สามารถอ่าน/test ได้ หากสร้าง commits ใหม่และต้องการเก็บ:

```powershell
git switch -c rescue/my-work
```

อย่าตื่นตกใจ อ่าน status/log ก่อน

---

## 10. Stash

```powershell
git stash push -m "WIP validation"
git stash list
git stash show -p stash@{0}
```

ใช้พัก tracked changes ชั่วคราว แต่:

- ไม่ใช่ replacement สำหรับ commits
- untracked files ไม่รวมโดย default
- stash conflict ได้ตอน apply/pop
- stash เก่าลืมง่าย

Prefer `apply` ก่อน `pop` เมื่ออยากตรวจแล้วค่อย drop

---

## 11. Decision Table

| สถานการณ์ | แนวทางเริ่มต้น |
|---|---|
| unstaged tracked change ต้องทิ้ง | diff แล้ว `restore` |
| staged ผิดแต่เก็บ content | `restore --staged` |
| ต้องการไฟล์จาก commit เก่า | `restore --source` |
| commit ล่าสุดยังไม่ share | amend ตามกรณี |
| bad commit shared แล้ว | revert |
| commit ดูเหมือนหาย | reflog + rescue branch |
| ต้องพักงานชั่วคราว | commit branch หรือ stash อย่างมีชื่อ |

---

## 12. Checkpoint

- [ ] จำแนก working/staged/committed/shared
- [ ] unstage โดยไม่ลบ content
- [ ] restore file จาก commit
- [ ] รู้ว่า amend เปลี่ยน hash
- [ ] ใช้ revert กับ shared history
- [ ] อธิบาย reset modes โดยไม่รีบใช้ hard
- [ ] กู้ commitผ่าน reflog/rescue branch
- [ ] ใช้ stashอย่างจำกัด

