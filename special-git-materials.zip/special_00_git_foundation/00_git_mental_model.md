# 00 — Git Mental Model

## 1. Git ไม่ใช่ GitHub

### Git

โปรแกรม version control ที่ทำงานในเครื่อง เก็บประวัติใน directory `.git`

### GitHub/GitLab/Bitbucket

บริการเก็บ Git repository บน server พร้อม collaboration เช่น Pull Request, Issue และ CI

คุณใช้ Git ได้โดยไม่มีอินเทอร์เน็ตหรือ GitHub แต่ใช้ GitHub โดยไม่เข้าใจ Git จะสับสนทันทีเมื่อ conflict หรือ undo

---

## 2. Git เก็บ Snapshot ไม่ใช่คำสั่ง Undo ต่อกัน

Commit เปรียบเหมือน snapshot ของไฟล์ tracked ณ เวลาหนึ่ง ถ้าไฟล์ไม่เปลี่ยน Git เชื่อมกลับไปใช้ content เดิมอย่างมีประสิทธิภาพ

```text
Commit A ──> Commit B ──> Commit C
  files        files        files
```

แต่ละ commit มี:

- snapshot/tree
- parent commit
- author/committer
- timestamp
- message
- hash identifier

Commit hash เปลี่ยนหาก content หรือ metadata สำคัญเปลี่ยน

---

## 3. พื้นที่สำคัญสามส่วน

```text
Working Tree
    │ git add
    ▼
Staging Area / Index
    │ git commit
    ▼
Local Repository (.git)
```

### Working Tree

ไฟล์ที่คุณกำลังแก้ใน folder

### Staging Area

รายการ snapshot ที่ตั้งใจจะใส่ commit ถัดไป ไม่ใช่เพียง “ไฟล์ที่ Git รู้จัก”

### Local Repository

commits, branches, tags และ metadata ใน `.git`

ความเข้าใจ staging สำคัญที่สุด เพราะทำให้แยกงานที่แก้ปนกันเป็น commits ที่อ่านง่ายได้

---

## 4. สถานะไฟล์

### Untracked

ไฟล์มีใน Working Tree แต่ยังไม่เคยถูก Git track

### Tracked + Unmodified

ตรงกับ snapshot ที่ checkout

### Modified

ไฟล์ tracked ถูกแก้ แต่ยังไม่ได้ stage การแก้ล่าสุด

### Staged

content version หนึ่งถูกใส่ใน index เพื่อ commit

ไฟล์หนึ่งสามารถเป็น staged และ modified พร้อมกันได้:

```text
แก้ version A → git add → staged A
แก้อีกเป็น version B → working tree B
```

Commit ตอนนี้จะเก็บ A ไม่ใช่ B

---

## 5. HEAD และ Branch

Branch เป็นชื่อที่ชี้ commit ไม่ใช่สำเนา folder ทั้งก้อน

```text
A ── B ── C   main
          ▲
         HEAD
```

โดยทั่วไป HEAD ชี้ branch ปัจจุบัน และ branch ชี้ commit ล่าสุด

สร้าง feature branch:

```text
A ── B ── C   main
          └── D ── E   feature/report
                    ▲
                   HEAD
```

Commit ใหม่เลื่อน pointer ของ branch ปัจจุบัน

---

## 6. Commit Graph

Git history เป็น directed acyclic graph ไม่ใช่เส้นเดียวเสมอ:

```text
          D ── E   feature
         /      \
A ── B ── C ───── M   main
```

`M` เป็น merge commit มี parents มากกว่าหนึ่ง

การเห็น graph ช่วยเข้าใจ merge, rebase และ recovery มากกว่าจำคำสั่ง

---

## 7. Object Identity แบบพอใช้งาน

Git ใช้ content-addressed objects เช่น blob, tree, commit และ tag คุณไม่จำเป็นต้องใช้ plumbing commands แต่ควรรู้ว่า:

- hash ระบุ object/content
- branch เป็น movable reference
- tag มักเป็นชื่อคงที่สำหรับจุดสำคัญ
- commit ไม่ถูกแก้ “ภายใน”; การ amend สร้าง commit ใหม่

นี่อธิบายว่าทำไม rewriting history เปลี่ยน hashes ของ commit ต่อเนื่อง

---

## 8. Local กับ Remote

```text
Working Tree / Index / Local Commits
                 │ push
                 ▼
            Remote Repository
                 │ fetch
                 ▼
       Remote-tracking References
```

`origin/main` เป็น reference ในเครื่องที่บอกว่า “ครั้งล่าสุดที่ fetch มา remote main อยู่ตรงไหน” ไม่ใช่ server ที่อัปเดตสดตลอดเวลา

---

## 9. Git ไม่ได้ปกป้องทุกอย่าง

Git ปกป้องได้ดีเมื่อ:

- ไฟล์ tracked
- การเปลี่ยนแปลงถูก commit
- commit ยัง reachable หรือหาได้ด้วย reflog

Git อาจช่วยไม่ได้เมื่อ:

- untracked file ถูกลบ
- ignored file ถูกลบ
- secret ถูกเผยแพร่แล้ว
- destructive command ลบ uncommitted work

ดังนั้น “เดี๋ยว Git กู้ได้” ไม่ใช่ใบอนุญาตให้ใช้คำสั่งเสี่ยง

---

## 10. Checkpoint

อธิบายด้วยภาษาตัวเอง:

1. Git ต่างจาก GitHub อย่างไร?
2. Staging Area มีประโยชน์อะไร?
3. ไฟล์เป็น staged และ modified พร้อมกันได้อย่างไร?
4. Branch ชี้ไปที่อะไร?
5. HEAD คืออะไร?
6. `origin/main` อัปเดตเมื่อใด?
7. ทำไม amend จึงสร้าง commit ใหม่?
8. Untracked file ได้รับการปกป้องจาก Git แล้วหรือยัง?

