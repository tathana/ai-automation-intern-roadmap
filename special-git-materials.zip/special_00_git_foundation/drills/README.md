# Git Drills

ทำทุก Drill ใน repository จำลองเท่านั้น ไม่ใช้ `Pre-coop`, `short_course` หรือ repository งานจริงเป็นสนามทดลอง

## ลำดับ

1. [Status Detective](drill_01_status_detective.md)
2. [Atomic Commits](drill_02_atomic_commits.md)
3. [Branch and Merge](drill_03_branch_and_merge.md)
4. [Conflict Resolution](drill_04_conflict_resolution.md)
5. [Safe Recovery](drill_05_safe_recovery.md)

## Evidence ที่ต้องเก็บ

- คำสั่งสำคัญที่ใช้
- `git status --short --branch`
- `git log --oneline --decorate --graph --all`
- เหตุผลที่เลือกคำสั่ง
- test/check หลัง merge หรือ recovery

อย่าเก็บ token, absolute private paths หรือ secret ใน evidence

