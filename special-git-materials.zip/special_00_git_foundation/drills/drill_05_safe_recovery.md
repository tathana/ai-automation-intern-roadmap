# Drill 05 — Safe Recovery

ทำใน sandbox repo เท่านั้น

## Cases

1. Stage file ผิด แต่ต้องเก็บ content
2. แก้ tracked file ผิดและตั้งใจทิ้งหลังอ่าน diff
3. ลบ tracked file แล้วกู้
4. Commit ล่าสุด message ผิดและยังไม่ share
5. Bad commit ถูกถือว่า shared แล้ว ต้อง revert
6. Branch ถูกลบ แต่หา commit ผ่าน reflog
7. Detached HEAD มี commit ใหม่ที่ต้องเก็บ

## Required Output

แต่ละ case เขียน:

```text
Initial state
Desired final state
Command chosen
Why safer than alternatives
Verification
```

## Critical Failure

- ใช้ hard reset แล้วทำ uncommitted work ที่โจทย์กำหนดให้เก็บหาย
- กู้ด้วยการเดา hash โดยไม่ตรวจ log/reflog
- rewrite shared history แทน revert

