# Drill 01 — Status Detective

สร้าง repo ทดลองที่มี:

- tracked unmodified file
- tracked modified unstaged file
- staged file
- staged แล้วแก้ต่อ (`MM`)
- untracked file
- ignored `.env`

## Tasks

1. อ่าน full status และ short status
2. บอกว่า commit ถัดไปจะมี content version ใด
3. แสดง unstaged diff
4. แสดง staged diff
5. ใช้ `git check-ignore -v .env`
6. unstage หนึ่งไฟล์โดยรักษา content

## Pass

- ไม่ commit `.env`
- อธิบาย short status สองคอลัมน์ได้
- แยก staged/unstaged content ได้ถูก

