# Drill 04 — Conflict Resolution

## Scenario

สร้าง branches สองฝั่งแก้ config/ข้อความเดียวกัน โดยแต่ละฝั่งมี requirement ที่ต้องรักษา

## Tasks

1. ทำให้เกิด conflict
2. หยุดและบันทึก `git status`
3. อ่าน base/ours/theirs
4. แก้เป็น semantic result ที่รวม requirement
5. รัน test/check
6. stage และจบ merge
7. ตรวจ final file และ graph
8. สร้าง conflict รอบใหม่แล้วทดลอง `git merge --abort`

## ห้าม

- เลือก ours/theirs ทั้งไฟล์โดยไม่อ่าน
- ลบ markers แล้วถือว่าเสร็จโดยไม่ test

