# Drill 03 — Branch and Merge

## Scenario

```text
main
├── feature/report
└── fix/validation
```

## Tasks

1. สร้าง branches จากฐานที่ถูกต้อง
2. ทำ atomic commits แต่ละ branch
3. merge `fix/validation` แบบ fast-forward ถ้า graph อนุญาต
4. ทำ commit บน main แล้ว merge `feature/report` เพื่อเห็น three-way merge
5. รัน tests/check
6. ลบ merged branches ด้วย `-d`
7. วาด graph ก่อนและหลัง

## Questions

- ทำไม merge หนึ่งเป็น fast-forward แต่อีกอันสร้าง merge commit?
- ถ้าลบชื่อ feature branch commits ยังอยู่หรือไม่?

