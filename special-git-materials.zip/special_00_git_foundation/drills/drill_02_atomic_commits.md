# Drill 02 — Atomic Commits

ให้ไฟล์ `processor.py` มี changes ปนกัน:

- เพิ่ม validation
- เปลี่ยนข้อความ log ที่ไม่เกี่ยว
- แก้ typo ใน comment

และมี `README.md` ที่เพิ่ม setup instructions

## Tasks

1. ตรวจ diff
2. ใช้ `git add -p` แบ่ง hunks
3. สร้าง commits ที่ review ได้
4. แต่ละ commit ต้องมี message บอก intention
5. แสดง final graph และ `git show` ของแต่ละ commit

## Review

- Commit แต่ละตัว build/test ได้หรือไม่?
- Validation test อยู่กับ behavior หรือแยกอย่างมีเหตุผล?
- README change เกี่ยวกับ feature หรือควรเป็น docs commit?

