# 01 — Setup and First Repository

## 1. ตรวจ Git

```powershell
git --version
```

ดู config พร้อมแหล่งที่มา:

```powershell
git config --list --show-origin
```

ตั้ง identity:

```powershell
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

Identity อยู่ใน commit metadata ไม่ใช่ GitHub login/password

---

## 2. Config Levels

- system: ทั้งเครื่อง
- global: ผู้ใช้ปัจจุบัน
- local: repository นี้

ค่าที่ specific กว่าทับค่ากว้างกว่า

ดูเฉพาะ repo:

```powershell
git config --local --list
```

สำหรับอีเมลบริษัท/ส่วนตัวอาจใช้ local config แยก repo

---

## 3. สร้าง Repository

ใน folder ทดลอง:

```powershell
git init
git status
```

กำหนดชื่อ branch เริ่มต้นหากต้องการ:

```powershell
git branch -M main
```

`.git` คือฐานข้อมูล repository อย่าแก้ไฟล์ภายในด้วยมือโดยไม่รู้จริง

---

## 4. ตรวจว่าตอนนี้อยู่ Repo ใด

```powershell
git rev-parse --show-toplevel
git status --short --branch
```

หากคำสั่งบอก `not a git repository` ให้ตรวจ CWD

สำคัญมาก: Git เดินหา `.git` ขึ้นไปยัง parent directories จึงอาจทำงานกับ repo ใหญ่กว่าที่คิด

---

## 5. Nested Repository Trap

โครงสร้างนี้อาจเกิดโดยไม่ตั้งใจ:

```text
course/.git
course/week1/project/.git
```

parent repo จะมอง child repo ต่างจาก folder ปกติ และอาจเกิด embedded repository warning

ก่อน `git init` ถาม:

- มี `.git` ใน parent แล้วหรือไม่?
- ต้องการ repo แยกจริงไหม?
- folder นี้ควรเป็นส่วนหนึ่งของ course repo หรือ standalone project?

ใช้:

```powershell
git rev-parse --show-toplevel
```

ก่อน init เสมอเมื่อไม่แน่ใจ

---

## 6. First Commit

สร้าง `README.md`, ตรวจสถานะ แล้ว:

```powershell
git add README.md
git diff --staged
git commit -m "docs: add project overview"
```

ตรวจ:

```powershell
git log --oneline --decorate --graph --all
```

ลำดับสำคัญ:

```text
status → diff → add → diff --staged → commit → log
```

---

## 7. Clone กับ Init

### `git init`

สร้าง repo จาก folder local ที่มี/ไม่มีไฟล์อยู่แล้ว

### `git clone`

ดาวน์โหลด repository พร้อม history และตั้ง remote โดยปกติชื่อ `origin`

อย่า `git init` ภายใน folder ที่เพิ่ง clone โดยไม่ตั้งใจ

---

## 8. Repository Baseline

ก่อนเขียน feature ควรมี:

- README เบื้องต้น
- `.gitignore`
- dependency/config samples
- initial commit ที่สะอาด

แต่ไม่ต้องรอ README สมบูรณ์จึงเริ่ม เพราะ documentation พัฒนาตามโปรเจกต์ได้

---

## 9. Exercise

สร้าง repo ทดลองแยกจากงานจริง:

1. ตรวจว่า parent ไม่ใช่ repo
2. init และตั้ง main
3. สร้าง README
4. ตรวจ untracked state
5. stage เฉพาะ README
6. อ่าน staged diff
7. commit
8. แสดง graph
9. อธิบายว่า HEAD/main ชี้ที่ใด

---

## 10. Checkpoint

- [ ] รู้ config system/global/local
- [ ] ตรวจ repo root ได้
- [ ] ป้องกัน nested repo โดยไม่ตั้งใจ
- [ ] แยก init กับ clone
- [ ] ทำ first commit หลังตรวจ staged diff
- [ ] อ่าน log graph พื้นฐานได้

