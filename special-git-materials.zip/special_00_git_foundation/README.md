# Special Track 00 — Git Foundation & Safe Workflow

## ทำไมเรียน Git ก่อน Week 5

Git ไม่ใช่วิชาสำหรับตกแต่งโปรเจกต์ตอนส่งงาน แต่เป็นระบบบันทึกการเปลี่ยนแปลงที่ควรใช้ตั้งแต่วันแรก หากเริ่มตอนนี้ งานทุก Week จะกลายเป็นหลักฐานว่าเราคิด แก้ bug และพัฒนาอย่างไร

Track นี้แยกเฉพาะ Git ออกจาก Week 5 เพื่อสอนตั้งแต่ mental model จนถึง team workflow ส่วน Docker, Clean Code, Documentation และ Capstone Delivery ยังคงเรียนใน Week 5

> เป้าหมายไม่ใช่จำคำสั่งจำนวนมาก แต่ต้องตรวจสถานะก่อนทำ เข้าใจผลของคำสั่ง และกู้สถานการณ์โดยไม่ทำงานหาย

---

## Learning Outcomes

เมื่อจบ Track คุณควรสามารถ:

1. อธิบาย Working Tree, Staging Area, Commit, HEAD และ Branch ได้
2. สร้าง repository และ commit แบบเป็นเรื่องเดียวกันได้
3. อ่าน `status`, `diff`, `log` และ `show` ก่อนตัดสินใจ
4. แบ่งการเปลี่ยนแปลงด้วย `git add -p` ได้
5. สร้าง branch และ merge ได้
6. แก้ merge conflict โดยไม่ลบงานอีกฝั่งโดยไม่ตั้งใจ
7. แยก fetch, pull และ push ได้
8. เลือก undo/recovery method ตามสถานะของงานได้
9. ใช้ `.gitignore` และป้องกัน secrets ได้
10. เขียน commit/PR/handoff ที่ทีมอ่านรู้เรื่องได้

---

## แผนที่บทเรียน

| ลำดับ | บทเรียน | ผลลัพธ์ |
|---|---|---|
| 00 | [Git Mental Model](00_git_mental_model.md) | เห็นภาพฐานข้อมูล snapshot และ pointers |
| 01 | [Setup and First Repository](01_setup_and_first_repository.md) | ตั้งค่าและสร้าง repo อย่างปลอดภัย |
| 02 | [Working Tree, Staging and Commit](02_working_tree_staging_commit.md) | แบ่งการเปลี่ยนแปลงเป็น atomic commits |
| 03 | [Inspect History and Changes](03_inspect_history_and_changes.md) | อ่านสถานะ, diff และ history |
| 04 | [Branches and Merging](04_branches_and_merging.md) | ทำงานแยก branch และรวมกลับ |
| 05 | [Merge Conflicts](05_merge_conflicts.md) | เข้าใจและแก้ conflict อย่างมีหลักฐาน |
| 06 | [Remotes, GitHub, Pull and Push](06_remotes_github_pull_push.md) | แยก local/remote และ sync อย่างปลอดภัย |
| 07 | [Undo and Recovery](07_undo_and_recovery.md) | เลือก restore/revert/reflog ตามสถานการณ์ |
| 08 | [Gitignore, Secrets and Hygiene](08_gitignore_secrets_and_repo_hygiene.md) | ป้องกันไฟล์ขยะและ credential |
| 09 | [Team Workflow and Pull Requests](09_team_workflow_and_pull_requests.md) | ส่งงานให้ review และรับ feedback |
| 10 | [Git Cheat Sheet](10_git_cheat_sheet.md) | คู่มือเลือกคำสั่งตามสถานการณ์ |

แบบฝึกอยู่ใน [`drills/`](drills/) และข้อสอบจบ Track อยู่ใน [`special_challenge_git_rescue/`](special_challenge_git_rescue/)

---

## เส้นทางเรียนแบบละเอียดสำหรับคนที่ยังไม่มั่นใจ

Track นี้อ่านได้สองรอบ โดยไม่ต้องพยายามจำทุกคำสั่งในครั้งแรก:

### รอบที่ 1 — สร้างภาพในหัว

1. อ่านบท 00–01 เพื่อแยก Git, GitHub, working tree, staging และ commit
2. ทดลองเฉพาะ repository ฝึก
3. ทุกครั้งก่อนใช้คำสั่ง ให้พูดออกมาว่า “คำสั่งนี้ย้ายหรือเปลี่ยนอะไร”
4. ถ้าอธิบายไม่ได้ ให้กลับไปดู state map ก่อนรัน

### รอบที่ 2 — ฝึก workflow จริง

1. อ่านบท 02–10 พร้อมทำ drills
2. ใช้ [`11_real_project_practical_playbook.md`](11_real_project_practical_playbook.md) เป็นคู่มือประกอบ
3. หลังแต่ละ session เขียน learning log สั้น ๆ: ก่อนทำอยู่ state ไหน, ทำอะไร, ผลเป็นอย่างไร, กู้ได้อย่างไร
4. ทำ Git Rescue Mission เมื่ออ่าน status/diff/log ได้ ไม่ใช่เมื่อจำ command ครบ

### รูปแบบการเรียนในแต่ละบท

```text
อ่านแนวคิด → ทายผลคำสั่ง → รันใน repo ฝึก → อ่าน output
→ อธิบายด้วยภาษาตัวเอง → ทำให้ผิดอย่างควบคุม → ฝึกกู้
```

หากกำลังทำโปรเจกต์จริงและไม่แน่ใจ ให้หยุดที่คำสั่ง read-only ก่อน ได้แก่ `status`, `diff`, `log`, `show`, `branch -vv` และ `remote -v` แล้วค่อยตัดสินใจ

---

## คู่มือสถานการณ์จริง

บท [`11 — Real Project Practical Playbook`](11_real_project_practical_playbook.md) เพิ่มคำอธิบายและตัวอย่างใช้งานแบบ end-to-end:

- วิธีอ่านคำว่า `working tree clean` อย่างถูกต้อง
- local repo ที่ต้องเชื่อมกับ GitHub repo ใหม่
- วิธีสำรวจ remote ด้วย `fetch` ก่อนรวม history
- daily workflow ตั้งแต่เริ่มงานจน handoff
- วิธีอ่าน short status และ diff
- atomic commit กับ `git add -p`
- non-fast-forward, conflict และ recovery decision table
- `.gitignore`/secret hygiene สำหรับ Python และ AI projects
- วิธีใช้ AI ช่วยวิเคราะห์ Git อย่างปลอดภัย
- diagnostic templates สำหรับส่งข้อมูลให้แชทช่วยตรวจ

---

## ลำดับเรียนแนะนำ

| Session | เนื้อหา | เวลา |
|---|---|---:|
| 1 | บท 00–01 + สร้าง repo ทดลอง | 1.5–2 ชม. |
| 2 | บท 02–03 + Atomic Commit Drill | 2–3 ชม. |
| 3 | บท 04–05 + Branch/Conflict Drills | 2–3 ชม. |
| 4 | บท 07–08 + Safe Recovery Drill | 2–3 ชม. |
| 5 | บท 06, 09–10 + Rescue Mission | 3–5 ชม. |

บท 06 เรื่อง remote สามารถเรียนหลังบท 07 ได้ เพราะการกู้ local repository สำคัญกว่าการรีบ push

---

## Safety Rules

- ใช้ repository จำลองของ Track นี้ในการทดลอง destructive-looking operations
- ก่อน undo ให้รัน `git status` และ `git diff`
- อย่าใช้ `git reset --hard`, `git clean -fd` หรือ force push เป็นคำตอบแรก
- อย่าคัดลอกคำสั่งที่ไม่เข้าใจผลกระทบ
- หากมี uncommitted work ที่สำคัญ ให้ทำสำเนาหรือ commit บน rescue branch ก่อน
- ถ้า secret เคย commit แล้ว การเพิ่ม `.gitignore` ไม่ทำให้ secret ปลอดภัย ต้อง rotate
- ห้ามทดลอง rewrite history กับ shared repository โดยไม่มีข้อตกลง

---

## Definition of Done

- [ ] อธิบาย state ของไฟล์จาก `git status` ได้
- [ ] แยก unstaged diff กับ staged diff ได้
- [ ] สร้าง atomic commits อย่างน้อย 3 commits
- [ ] ใช้ branch และ merge ได้
- [ ] แก้ conflict พร้อมทดสอบผลลัพธ์ได้
- [ ] undo staged/committed change โดยเลือกวิธีถูกสถานการณ์
- [ ] กู้ commit/file ด้วย `reflog` หรือ `restore --source`
- [ ] ป้องกัน `.env`, runtime DB, cache และ logs
- [ ] แยก fetch/pull/push ได้
- [ ] เขียน PR summary และ test evidence ได้
- [ ] Git Rescue Mission ได้อย่างน้อย 75/100 และไม่มี Critical Failure

---

## ใช้ Track นี้ร่วมกับ Week 1 อย่างไร

```text
Session 1–2 ของ Git
        ↓
สร้าง repo สำหรับงาน Week 1
        ↓
Commit หลัง milestone เล็ก ๆ
        ↓
Session 3–4 ก่อน OpsGuard
        ↓
ทำ OpsGuard ด้วย branch + tests
        ↓
Session 5 และ Rescue Mission
```

เมื่อถึง Week 5 จะเรียนต่อในระดับ production/team delivery ไม่ย้อนสอน `git add` ใหม่
