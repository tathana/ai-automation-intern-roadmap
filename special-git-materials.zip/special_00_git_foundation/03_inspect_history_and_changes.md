# 03 — Inspect History and Changes

## 1. อ่านก่อนแก้

Git workflow ที่ปลอดภัยเริ่มจาก observation:

```powershell
git status --short --branch
git diff
git diff --staged
git log --oneline --decorate --graph --all
```

หากไม่รู้ current state อย่ารีบ undo/merge/pull

---

## 2. Diff Anatomy

Diff แสดง:

- old/new file
- hunk header เช่น `@@ -3,4 +3,5 @@`
- บรรทัดลบ `-`
- บรรทัดเพิ่ม `+`
- context

`-` และ `+` ไม่ได้หมายถึง error แต่เป็นมุมมอง old/new

---

## 3. Diff หลายขอบเขต

```powershell
git diff
```

Working Tree เทียบ Staging Area

```powershell
git diff --staged
```

Staging Area เทียบ HEAD

```powershell
git diff HEAD
```

ทุกการเปลี่ยนแปลงเทียบ commit ปัจจุบัน

```powershell
git diff main...feature/report
```

การเปลี่ยนแปลงบน feature เทียบจุดร่วม เหมาะ review PR

---

## 4. Log

```powershell
git log --oneline --decorate --graph --all
```

ละเอียด:

```powershell
git log --stat
git log -p -- path/to/file
git log --author="Name"
git log --since="1 week ago"
```

หยุด pager ด้วย `q`

---

## 5. Show Commit

```powershell
git show <commit>
git show --stat <commit>
git show <commit>:path/to/file
```

ใช้ตรวจว่า commit ทำอะไรจริง ไม่เชื่อ message อย่างเดียว

---

## 6. Compare File Across Commits

```powershell
git diff <old> <new> -- path/to/file
```

ดูไฟล์เวอร์ชันเก่าโดยไม่เปลี่ยน working tree:

```powershell
git show <commit>:path/to/file
```

ปลอดภัยกว่าการ checkout ไปมาเมื่อเพียงต้องการอ่าน

---

## 7. Blame ใช้อย่างไรไม่ให้เป็นการโทษคน

```powershell
git blame path/to/file
```

ใช้หา commit/context ที่เพิ่มบรรทัด ไม่ใช่หา “คนผิด” จากนั้นอ่าน commit/PR เพื่อเข้าใจเหตุผล

`blame` อาจเข้าใจผิดหลัง refactor หรือ move จึงไม่ใช่คำตอบสุดท้าย

---

## 8. Search History

หา commit message:

```powershell
git log --grep="validation"
```

หา commit ที่เพิ่ม/ลบ string:

```powershell
git log -S "DISCORD_WEBHOOK_URL" -p
```

หา diff ตรง regex:

```powershell
git log -G "password|token" -p
```

มีประโยชน์ตอนตรวจ secret history แต่หากเคยรั่วต้อง rotate

---

## 9. Exercise — History Investigation

เลือก commit สามตัวใน repo ทดลองแล้วตอบ:

1. parent คือ commit ใด?
2. files ใดเปลี่ยน?
3. message ตรงกับ patch หรือไม่?
4. test เปลี่ยนพร้อม behavior หรือไม่?
5. หาก bug เริ่มตรงนี้ มีหลักฐานอะไร?

---

## 10. Checkpoint

- [ ] เลือก diff scope ถูก
- [ ] อ่าน patch ได้
- [ ] ดู graph/branches ได้
- [ ] inspect commit โดยไม่เปลี่ยน working tree
- [ ] ค้น history ด้วย message/content
- [ ] ใช้ blame เพื่อหา context ไม่ใช่กล่าวโทษ

