# 11 — Real Project Practical Playbook

บทนี้ทำหน้าที่เชื่อมความรู้ Git ทุกบทเข้ากับการทำโปรเจกต์จริง เหมาะสำหรับกลับมาเปิดอ่านเมื่อจำคำสั่งได้บ้าง แต่ยังไม่แน่ใจว่า **ต้องใช้คำสั่งใด เมื่อไร และเพราะอะไร**

ตัวอย่างหลักใช้โปรเจกต์สมมติชื่อ `dentalAI` ซึ่งมี local repository อยู่แล้ว และมี GitHub repository ใหม่ชื่อ `dental-caries-ai`

> หลักสำคัญ: Git ที่ปลอดภัยไม่เริ่มจากการพิมพ์คำสั่งแก้ไข แต่เริ่มจากการอ่านสถานะและสร้างภาพในหัวก่อน

---

## 1. วิธีคิดก่อนใช้ Git ทุกครั้ง

ก่อนพิมพ์คำสั่ง ให้ตอบ 5 คำถามนี้:

1. **ฉันอยู่ repository ไหน?** — อย่าสันนิษฐานจากชื่อหน้าต่าง Terminal
2. **ฉันอยู่ branch ไหน?** — งานควรลง `main` หรือ feature branch
3. **มีไฟล์อะไรเปลี่ยนอยู่?** — tracked, untracked, staged หรือ unstaged
4. **local กับ remote ใครอยู่ข้างหน้า?** — อาจมี commit บน GitHub ที่ local ยังไม่มี
5. **คำสั่งถัดไปเปลี่ยน state ใด?** — working tree, staging, local history หรือ remote history

ชุดคำสั่งตรวจสุขภาพที่ใช้ได้เกือบทุกครั้ง:

```bash
git rev-parse --show-toplevel
git status
git branch -vv
git remote -v
git log --oneline --decorate --graph --all -n 15
```

แต่ละคำสั่งตอบคนละคำถาม:

| คำสั่ง | สิ่งที่ต้องดู | ความหมาย |
|---|---|---|
| `git rev-parse --show-toplevel` | absolute path | root ของ repo ที่ Git กำลังควบคุม |
| `git status` | branch และ file states | งานที่ยังไม่ commit และสถานะโดยรวม |
| `git branch -vv` | `*`, upstream, ahead/behind | branch ปัจจุบันและ branch ที่ติดตาม |
| `git remote -v` | remote name + URL | local repo เชื่อมไปที่ใด |
| `git log ... --all` | commit graph | ประวัติทุก ref ที่ local มองเห็น |

คำว่า `working tree clean` แปลเพียงว่าไม่มี tracked change/untracked file ที่ Git ต้องรายงานใน checkout ปัจจุบัน **ไม่ได้แปลว่า**:

- เชื่อม GitHub แล้ว
- local และ GitHub มี commit เท่ากัน
- push สำเร็จแล้ว
- branch มี upstream แล้ว
- repository มีไฟล์หรือ commit อยู่จริง

---

## 2. State Map: คำสั่งหนึ่งย้ายข้อมูลไปไหน

```text
ไฟล์ที่เราแก้
Working Tree
     │ git add
     ▼
Staging Area / Index
     │ git commit
     ▼
Local Repository
     │ git push
     ▼
Remote Repository เช่น GitHub
```

ทิศทางกลับที่ใช้บ่อย:

```text
Remote ──git fetch──> remote-tracking refs ใน Local
Staging ──git restore --staged──> เอาออกจาก staged แต่ไฟล์ยังอยู่
Commit ──git restore --source──> นำเนื้อหาเก่ามาวางใน working tree
Shared bad commit ──git revert──> สร้าง commit ใหม่ที่หักล้างของเดิม
```

ข้อสังเกตสำคัญ:

- `git add` ไม่ได้ส่งอะไรขึ้น GitHub
- `git commit` ไม่ได้ส่งอะไรขึ้น GitHub
- `git fetch` ไม่แก้ไฟล์งานปัจจุบัน
- `git push` เปลี่ยน remote จึงต้องตรวจให้มากกว่าคำสั่ง local
- `git pull` เป็นคำสั่งผสม โดยทั่วไปคือ fetch แล้ว integrate จึงมีผลต่อ branch ปัจจุบัน

---

## 3. Case A — มี Local Repo แล้ว แต่ GitHub Repo เพิ่งสร้าง

### 3.1 ตรวจ local ก่อน

```bash
git rev-parse --show-toplevel
git status
git log --oneline --decorate --graph --all -n 10
git remote -v
```

แยกได้เป็น 3 กรณี:

#### กรณี A: `git remote -v` ไม่มี output

แปลว่ายังไม่มี remote ที่ตั้งชื่อไว้ ไม่ใช่ error และไม่ใช่หลักฐานว่า GitHub repo ไม่มีอยู่

```bash
git remote add origin https://github.com/tathana/dental-caries-ai.git
git remote -v
```

`origin` เป็นเพียงชื่อเล่นที่นิยมใช้ จะตั้งชื่ออื่นก็ได้ แต่ในทีมควรใช้ convention เดียวกัน

#### กรณี B: มี `origin` แต่ URL ผิด

อย่า `add` ซ้ำ ให้ตรวจและแก้:

```bash
git remote get-url origin
git remote set-url origin https://github.com/tathana/dental-caries-ai.git
git remote -v
```

#### กรณี C: มี URL ถูกแล้ว

ไม่ต้อง add ใหม่ ให้ไปขั้น fetch เพื่อขอข้อมูลจาก remote

### 3.2 ตรวจ GitHub โดยไม่รีบรวม history

```bash
git fetch origin
git branch -a
git log --oneline --decorate --graph --all -n 20
```

เหตุผลที่ใช้ `fetch` ก่อน `pull`: เราต้องการรู้ว่า GitHub มี commit เริ่มต้น เช่น README, LICENSE หรือ `.gitignore` หรือไม่ โดยยังไม่ให้ Gitแก้ branch ปัจจุบันอัตโนมัติ

### 3.3 ตัดสินใจจาก history

**Remote ว่าง และ local มี commit:**

```bash
git push -u origin main
```

`-u` หรือ `--set-upstream` ผูก local `main` ให้ติดตาม `origin/main` หลังจากนั้นมักใช้ `git push` และ `git pull` แบบไม่ระบุชื่อได้

**Remote มี commit และ local เริ่มจาก history เดียวกัน:**

```bash
git branch -vv
git log --oneline --left-right main...origin/main
```

หาก local เพียง behind และไม่มีงานชนกัน อาจใช้:

```bash
git pull --ff-only
```

`--ff-only` ยอมให้เลื่อน pointer ไปข้างหน้าอย่างเดียว หากต้องสร้าง merge commit คำสั่งจะหยุดให้เราตรวจแทน

**Local และ remote ถูกสร้างแยกกันคนละ root commit:**

อย่า force push เพื่อให้ “ผ่าน” ทันที นี่คือ unrelated histories ต้องเลือกอย่างมีสติว่าจะ:

- เก็บทั้งสอง history แล้ว integrate
- clone remote ใหม่ แล้วนำไฟล์ local เข้ามาเป็น commit
- ลบ/สร้าง remote ใหม่ หากแน่ใจว่า remote ไม่มีข้อมูลสำคัญและเป็น repo ส่วนตัว

ทางเลือกมีผลต่อประวัติ จึงควรสำรองและตรวจ graph ก่อนเสมอ

---

## 4. Case B — เริ่มวันทำงานใหม่ในโปรเจกต์จริง

Routine ที่แนะนำ:

```bash
git status
git branch -vv
git fetch origin
git log --oneline --decorate --graph --all -n 12
```

จากนั้น:

1. ถ้ามีงานค้าง ให้เข้าใจก่อนว่าเป็นงานอะไร
2. ถ้า `main` behind และ clean ให้อัปเดตอย่างปลอดภัย
3. สร้าง branch สำหรับงานใหม่

```bash
git switch main
git pull --ff-only
git switch -c feat/resume-parser
```

ทำไมไม่เขียน feature ยาว ๆ บน `main`:

- แยกขอบเขตงานได้
- เปรียบเทียบกับ baseline ง่าย
- ทิ้ง branch ได้โดยไม่รบกวน main
- เปิด PR และขอ review ได้
- สลับไปแก้ urgent bug ได้สะดวกกว่า

ตัวอย่างชื่อ branch:

```text
feat/resume-parser
fix/pdf-empty-page
docs/setup-guide
test/extraction-edge-cases
chore/update-gitignore
```

ชื่อควรบอกชนิดและเจตนา ไม่ต้องใส่รายละเอียดทุกอย่างลงชื่อ branch

---

## 5. Case C — แก้หลายอย่าง แต่ต้องการ commit ให้อ่านง่าย

สมมติแก้ `parser.py`, เพิ่ม test, แก้ README และมี debug print ปนอยู่

### 5.1 อ่านภาพรวม

```bash
git status --short
git diff --stat
git diff
```

ตัวอักษรสองคอลัมน์ใน `git status --short`:

```text
 M parser.py      # working tree modified แต่ยังไม่ staged
M  README.md      # staged แล้ว
MM config.py      # staged เวอร์ชันหนึ่ง แล้วแก้เพิ่มอีก
?? test_parser.py # untracked
```

คอลัมน์ซ้ายคือ index/staging ส่วนคอลัมน์ขวาคือ working tree

### 5.2 แบ่ง commit ตามเหตุผล

```bash
git add -p parser.py
git add test_parser.py
git diff --staged
git commit -m "feat: parse candidate skills from resume text"
```

แล้วจึงทำ documentation เป็นอีก commit:

```bash
git add README.md
git diff --staged
git commit -m "docs: explain resume parser usage"
```

`git add -p` ให้เลือกทีละ hunk คำตอบหลัก:

| ปุ่ม | ความหมาย |
|---|---|
| `y` | stage hunk นี้ |
| `n` | ยังไม่ stage hunk นี้ |
| `s` | แบ่ง hunk ให้เล็กลง |
| `e` | แก้ patch ด้วยตนเอง; ใช้เมื่อเข้าใจแล้ว |
| `q` | หยุด |
| `?` | ดูความช่วยเหลือ |

Atomic commit ไม่ได้แปลว่า commit ต้องเล็กที่สุด แต่หมายถึงมี “เหตุผลเดียวที่สอดคล้องกัน” และสามารถ review/revert ได้เป็นหน่วย

---

## 6. วิธีอ่าน Diff ให้รู้ว่ากำลังจะ commit อะไร

```diff
diff --git a/parser.py b/parser.py
index 91ab123..73cd456 100644
--- a/parser.py
+++ b/parser.py
@@ -10,3 +10,5 @@ def parse_resume(text):
-    return {}
+    skills = extract_skills(text)
+    return {"skills": skills}
```

- `--- a/...` คือเวอร์ชันก่อน
- `+++ b/...` คือเวอร์ชันหลัง
- บรรทัดขึ้นต้น `-` ถูกนำออก
- บรรทัดขึ้นต้น `+` ถูกเพิ่ม
- `@@` บอกตำแหน่งโดยประมาณของ hunk

คำสั่งที่คนเริ่มต้นมักสลับกัน:

```bash
git diff           # working tree เทียบ staging
git diff --staged  # staging เทียบ HEAD; สิ่งที่จะเข้า commit
git diff HEAD      # working tree + staged เทียบ commit ปัจจุบัน
```

ก่อน commit ให้ยึด `git diff --staged` เป็นหลัก เพราะมันคือเนื้อหาที่ Git กำลังจะบันทึกจริง

---

## 7. Commit Message ที่ช่วยตัวเราในอนาคต

รูปแบบง่าย:

```text
<type>: <สิ่งที่เปลี่ยนและเจตนา>
```

ตัวอย่าง:

```text
feat: add structured output for resume extraction
fix: handle PDF pages with missing text
test: cover duplicate candidate identifiers
docs: add local setup instructions
refactor: separate parsing from scoring logic
chore: ignore local model cache
```

หลีกเลี่ยงข้อความแบบ:

```text
update
fix bug
ล่าสุด
final final
งานวันนี้
```

คำถามทดสอบคุณภาพ: หากอ่าน message นี้อีก 3 เดือนโดยไม่เปิด diff จะพอรู้หรือไม่ว่า commit ทำอะไรและทำไม

Pre-commit ritual:

```bash
git status
git diff
git diff --staged
# รัน tests/linter ที่เกี่ยวข้อง
git commit -m "..."
git show --stat --oneline HEAD
```

---

## 8. Case D — Push แล้วถูกปฏิเสธ

ข้อความ non-fast-forward มักแปลว่า remote มี commit ที่ local ยังไม่มี ไม่ได้แปลว่า Git พัง

หยุดก่อน แล้วตรวจ:

```bash
git status
git fetch origin
git branch -vv
git log --oneline --decorate --graph --all -n 20
```

หากทำงานบน feature branch และต้องการรวม remote changes ให้ทำตาม policy ทีม เช่น merge หรือ rebase ส่วนถ้าเป็น `main` ให้หลีกเลี่ยงการ force push

หลักการ:

- `fetch` ก่อน เพื่อดูข้อเท็จจริง
- อ่าน graph ว่าแตกแขนงตรงไหน
- ตรวจว่า remote commit เป็นของใคร/ทำอะไร
- integrate และ test
- push หลัง history ถูกต้อง

อย่าแก้ non-fast-forward ด้วย `git push --force` แบบอัตโนมัติ เพราะอาจทำให้ commit ของคนอื่นหายจาก branch ที่แชร์กัน

---

## 9. Case E — ทำผิด แต่ยังไม่รู้ว่าควร Undo แบบไหน

เริ่มจากจำแนก state:

| เหตุการณ์ | วิธีคิด | คำสั่งที่มักเหมาะ |
|---|---|---|
| แก้ tracked file แต่ยังไม่ stage | ทิ้ง working change | `git restore <file>` |
| stage ผิด แต่ต้องเก็บเนื้อหา | เอาออกจาก index | `git restore --staged <file>` |
| commit ล่าสุดผิดและยังไม่ share | แก้ local history | `git commit --amend` หรือ reset ตามกรณี |
| bad commit ถูก push/share แล้ว | เพิ่มประวัติหักล้าง | `git revert <commit>` |
| branch/commit ดูเหมือนหาย | หา pointer เก่า | `git reflog` แล้วสร้าง rescue branch |
| merge ยังไม่เสร็จและต้องย้อน | กลับก่อนเริ่ม merge | `git merge --abort` |

ก่อนใช้ `restore` กับ working tree ให้ดู `git diff` เพราะเนื้อหาที่ทิ้งอาจกู้ยากหากไม่เคย commit

Safe rescue pattern เมื่อไม่มั่นใจ:

```bash
git status
git diff
git diff --staged
git switch -c rescue/before-recovery
git add -A
git commit -m "wip: preserve state before recovery"
```

WIP commit บน rescue branch ไม่จำเป็นต้อง push หรือ merge จุดประสงค์คือทำให้ข้อมูลมี object ใน Git ก่อนทดลองกู้

---

## 10. Case F — Merge Conflict แบบไม่เดาสุ่ม

เมื่อ merge แล้ว conflict:

```bash
git status
git diff --name-only --diff-filter=U
```

เปิดไฟล์จะเห็น:

```text
<<<<<<< HEAD
เนื้อหาจาก branch ปัจจุบัน
=======
เนื้อหาจากอีกฝั่ง
>>>>>>> feat/example
```

อย่าเลือก ours/theirs เพียงเพราะอยากให้ marker หาย ขั้นตอนที่ถูกต้อง:

1. เข้าใจเจตนาทั้งสองฝั่ง
2. เขียนผลลัพธ์สุดท้าย ซึ่งอาจรวมทั้งสองฝั่งหรือเขียนใหม่
3. ลบ marker ทุกตัว
4. รัน test
5. stage เฉพาะไฟล์ที่แก้เสร็จ
6. ตรวจ status/diff แล้วจบ merge

```bash
git add path/to/resolved_file
git diff --check
git status
git commit
```

ถ้าพบว่าเริ่ม merge ผิด branch หรือยังไม่พร้อม:

```bash
git merge --abort
```

Abort ไม่ใช่ความล้มเหลว แต่เป็นการกลับไปเก็บข้อมูลก่อนตัดสินใจใหม่

---

## 11. `.gitignore` และ Secrets ในโปรเจกต์ AI/Python

ตัวอย่าง baseline ซึ่งต้องปรับตามโปรเจกต์:

```gitignore
# Python
__pycache__/
*.py[cod]
.pytest_cache/
.mypy_cache/
.ruff_cache/

# Virtual environments
.venv/
venv/

# Secrets and local config
.env
.env.*
!.env.example

# IDE / OS
.vscode/
.idea/
.DS_Store
Thumbs.db

# Runtime artifacts
*.log
tmp/
outputs/

# Models/data: ตัดสินตาม policy ไม่ใช่ ignore ทุกอย่างอัตโนมัติ
models/local/
data/private/
```

ตรวจว่าไฟล์ถูก ignore เพราะ rule ใด:

```bash
git check-ignore -v .env
```

ถ้าไฟล์เคย tracked แล้ว การเพิ่ม `.gitignore` อย่างเดียวไม่ทำให้ Git เลิกติดตาม:

```bash
git rm --cached .env
```

แต่ถ้า secret เคย commit หรือ push แล้ว ต้องถือว่า secret รั่ว:

1. revoke/rotate credential ก่อน
2. ประเมินว่าอยู่ใน remote/history/log ที่ใดบ้าง
3. แจ้งผู้รับผิดชอบตาม incident process
4. ค่อยจัดการ history ตามข้อตกลงทีม

การลบข้อความจากไฟล์ล่าสุดไม่ทำให้ credential เดิมปลอดภัย

---

## 12. End-of-Day Workflow

ก่อนเลิกงาน:

```bash
git status
git diff
git diff --staged
```

เลือกอย่างใดอย่างหนึ่ง:

- งานเป็นหน่วยสมบูรณ์: test แล้ว commit
- งานยังไม่สมบูรณ์แต่ต้องเก็บ: WIP commit บน feature branch ตาม policy ทีม
- ต้องย้าย branch ชั่วคราว: ใช้ stash เมื่อเข้าใจและตั้ง message ชัดเจน
- มีไฟล์ขยะ/secret: แก้ hygiene ก่อน push

ตรวจ history และ upstream:

```bash
git log --oneline --decorate -n 8
git branch -vv
git status
```

ถ้า push feature branch:

```bash
git push -u origin feat/resume-parser
```

Handoff ที่ดีควรบอก:

- ทำอะไรเสร็จแล้ว
- branch/commit/PR ใด
- รัน test อะไรและผลเป็นอย่างไร
- ยังมีข้อจำกัดหรือ TODO อะไร
- ผู้รับควรทำอะไรต่อ

---

## 13. วิธีใช้ AI ช่วย Git โดยไม่มอบพวงมาลัยให้ AI

AI เหมาะกับ:

- อธิบาย `git status`, `diff`, `log` ที่เราส่งให้
- เสนอ commit grouping จากรายชื่อไฟล์/diff
- ช่วยเขียน commit message หรือ PR description
- อธิบาย conflict ทั้งสองฝั่ง
- เสนอ recovery options พร้อมผลกระทบ

ก่อนให้ AI แนะนำ ควรส่งข้อมูล read-only:

```bash
git status
git branch -vv
git remote -v
git log --oneline --decorate --graph --all -n 20
git diff
git diff --staged
```

อย่าส่ง `.env`, token, private key หรือข้อมูลลูกค้า และอย่ารันคำสั่ง destructive ที่ AI เสนอจนกว่าจะอธิบายได้ว่า:

1. คำสั่งเปลี่ยน state ใด
2. ข้อมูลใดอาจหาย
3. มี backup/recovery path หรือไม่
4. กระทบ remote/shared history หรือไม่

Prompt ที่ใช้ถามได้ดี:

```text
นี่คือ git status, branch -vv และ commit graph ของผม
ช่วยอธิบาย current state ก่อน โดยยังไม่เสนอคำสั่งแก้ไข
จากนั้นเสนอทางเลือกที่ปลอดภัย 2 วิธี พร้อมผลกระทบและวิธีกู้คืน
ห้ามใช้ force push หรือ reset --hard
```

---

## 14. Diagnostic Templates — ส่งอะไรมาให้คนช่วยดู

### ปัญหา local/remote sync

```bash
git status
git branch -vv
git remote -v
git log --oneline --decorate --graph --all -n 25
```

### ปัญหา staged ผิดหรือ commit ปนกัน

```bash
git status --short
git diff
git diff --staged
git show --stat --oneline HEAD
```

### ปัญหา merge conflict

```bash
git status
git diff --name-only --diff-filter=U
git log --oneline --decorate --graph --all -n 15
```

### ปัญหา commit/branch หาย

```bash
git status
git branch -avv
git reflog -n 30
git log --oneline --decorate --graph --all -n 30
```

ก่อนส่ง output ให้ผู้อื่น ตรวจ URL, username, path และข้อมูลลับที่อาจปรากฏก่อนทุกครั้ง

---

## 15. Practice Scenario — จากโปรเจกต์ว่างถึง Pull Request

ทำใน repository ทดลอง ไม่ใช่ repo งานสำคัญ:

1. สร้าง repo และ baseline commit
2. สร้าง bare/local remote หรือ GitHub test repo
3. ผูก `origin` และ push `main`
4. สร้าง `feat/input-validation`
5. แก้ code + test + docs โดยตั้งใจให้มีหลาย concerns
6. ใช้ `git add -p` แบ่งเป็น 2–3 atomic commits
7. push feature branch
8. เขียน PR description แม้ไม่ได้เปิด PR จริง
9. จำลอง remote ahead แล้ว fetch/read graph
10. สร้าง conflict เล็ก ๆ และแก้พร้อม test
11. สร้าง bad commit แล้วฝึก `revert`
12. สร้าง branch ชั่วคราว ลบ แล้วกู้ด้วย reflog

หลักฐานที่ควรเก็บ:

```text
git status ตอนสำคัญ
commit graph ก่อน/หลัง merge
commit messages
diff ที่แบ่งด้วย add -p
test output
PR description
recovery notes: เกิดอะไร เลือกวิธีไหน เพราะอะไร
```

---

## 16. Checkpoint แบบอธิบายด้วยภาษาตัวเอง

หากตอบไม่ได้ ให้ย้อนอ่านบทที่เกี่ยวข้องก่อนจำ command เพิ่ม:

1. ทำไม `working tree clean` ยังไม่ยืนยันว่า sync กับ GitHub
2. `git diff` และ `git diff --staged` ต่างกันอย่างไร
3. ทำไม fetch ปลอดภัยกว่าการ pull ทันทีเมื่อต้องการสำรวจ
4. upstream/tracking branch ช่วยอะไร
5. เมื่อ commit ถูก share แล้ว ทำไม revert มักเหมาะกว่า reset
6. ทำไม `.gitignore` ไม่ช่วย secret ที่เคย commit แล้ว
7. conflict marker บอกอะไร และเหตุใดไม่ควรเลือกฝั่งใดฝั่งหนึ่งแบบสุ่ม
8. `git add -p` ช่วย code review และ recovery อย่างไร
9. reflog ช่วยกู้สถานการณ์ประเภทใด
10. ก่อน push ควรตรวจอะไรอย่างน้อย 5 อย่าง

เมื่ออธิบายได้โดยไม่ท่องจำ คุณจะเริ่มใช้ Git เป็นระบบคิด ไม่ใช่ชุดคาถาครับ
