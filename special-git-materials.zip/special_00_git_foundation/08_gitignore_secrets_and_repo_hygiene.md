# 08 — Gitignore, Secrets and Repository Hygiene

## 1. `.gitignore` ใช้กับ Untracked Files

ตัวอย่าง Python:

```gitignore
__pycache__/
*.py[cod]
.pytest_cache/
.coverage
htmlcov/
.venv/
.env
*.log
*.db
*.db-journal
dist/
build/
```

Pattern ต้องตรงกับสิ่งที่โปรเจกต์สร้างจริง อย่า copy template ขนาดใหญ่จนซ่อนไฟล์ที่ควรเก็บ

---

## 2. Ignore ไม่ได้ Untrack ของเดิม

หาก `.env` ถูก track แล้ว การเพิ่ม `.env` ลง `.gitignore` ไม่เอาออกจาก index/history

หยุด track แต่เก็บ local file:

```powershell
git rm --cached .env
```

จากนั้น commit การลบจาก repository

แต่ถ้ามี secret จริงเคย commit ต้อง rotate/revoke เพราะยังอยู่ใน history/clone อื่น

---

## 3. ตรวจว่า Rule ไหน Ignore

```powershell
git check-ignore -v path/to/file
```

ช่วยหา pattern ที่ซ่อนไฟล์โดยไม่ตั้งใจ

ดู ignored files:

```powershell
git status --ignored
```

---

## 4. Secret Hygiene

ถือเป็น secret:

- API keys
- passwords
- access/refresh tokens
- private keys
- webhook URLs ที่มี credential
- connection strings
- session cookies

ใช้:

```text
.env              ← local, ignored
.env.example      ← committed, placeholders only
```

อย่าใส่ค่าจริงใน test fixtures, screenshots, logs หรือ README

---

## 5. Secret Incident Response

ถ้า secret ถูก commit:

1. หยุดใช้/rotate/revoke ทันที
2. ประเมินว่า push/shared หรือยัง
3. ลบจาก current files
4. ป้องกันด้วย ignore/config
5. ถ้าต้อง rewrite history ให้ทำตามผู้ดูแล repoและประสานผู้ร่วมงาน
6. ตรวจ logs/actions/artifacts
7. บันทึก incident ตาม policy

การลบ commit local ไม่เพียงพอหาก secret ถูกส่งไปแล้ว

---

## 6. Runtime Artifacts

โดยทั่วไปไม่ commit:

- virtual environment
- cache
- generated logs
- local runtime DB
- downloaded private resumes
- temporary exports
- coverage output

อาจ commit:

- schema/migrations
- small synthetic sample data
- `.env.example`
- deterministic fixtures
- lock/dependency filesตาม tooling

ตัดสินตาม reproducibility และ privacy

---

## 7. Large/Binary Files

Git ไม่เหมาะกับ binary ที่เปลี่ยนบ่อย เช่น model weights, datasets, office filesขนาดใหญ่

พิจารณา:

- artifact storage
- object storage
- Git LFS ตาม policy
- download scripts/checksums

อย่า commit Resume จริงของผู้สมัครใน training repository

---

## 8. Pre-push Hygiene Checklist

```text
git status
git diff
git diff --staged
ตรวจ .env/token/password/webhook
รัน tests
ตรวจ generated/private files
อ่าน commit history
```

ใช้ secret scanning ของทีมเมื่อมี แต่ไม่แทนการรับผิดชอบของผู้พัฒนา

---

## 9. Exercise

สร้างไฟล์จำลอง:

- `.env`
- `.env.example`
- `app.db`
- `debug.log`
- `tests/fixtures/sample.json`

เขียน `.gitignore` ให้ ignore เฉพาะ runtime/private files แล้วใช้ `git check-ignore -v` พิสูจน์

---

## 10. Checkpoint

- [ ] รู้ว่า ignore ไม่กระทบ tracked file
- [ ] untrack โดยเก็บ local content ได้
- [ ] ตรวจ ignore rule ได้
- [ ] แยก secret/config sample
- [ ] rotate secret เมื่อเคยเผยแพร่
- [ ] ไม่ commit private resumes/runtime artifacts

