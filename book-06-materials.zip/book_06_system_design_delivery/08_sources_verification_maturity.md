# 08 — Sources, Verification และ Maturity Model

ตรวจแหล่งอ้างอิงเมื่อ 12 กันยายน 2026 รูปแบบ architecture ในเล่มเป็นแนวทางการออกแบบ ไม่ใช่มาตรฐานบังคับของทุกบริษัท

## Sources

- [Python Packaging: src vs flat layout](https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/)
- [FastAPI Dependencies](https://fastapi.tiangolo.com/tutorial/dependencies/)
- [FastAPI Response Models](https://fastapi.tiangolo.com/tutorial/response-model/)
- [Docker Compose Specification](https://docs.docker.com/reference/compose-file/)
- [The Twelve-Factor App: Config](https://12factor.net/config)
- [C4 Model](https://c4model.com/)
- [OWASP API Security Top 10](https://owasp.org/API-Security/)
- [OWASP GenAI Security: Prompt Injection](https://genai.owasp.org/llmrisk/llm01-prompt-injection/)
- [OWASP GenAI Security: Excessive Agency](https://genai.owasp.org/llmrisk/llm062025-excessive-agency/)
- [OpenTelemetry Concepts](https://opentelemetry.io/docs/concepts/)
- [GitHub Actions Documentation](https://docs.github.com/actions)

## Maturity Model สำหรับโปรเจกต์ฝึกงาน

| Level | หลักฐาน |
|---|---|
| 0 Prototype | happy path synthetic demo; limitations ชัด |
| 1 Tested | contracts + negative unit/API tests |
| 2 Integrated | staging dependencies/network/config ผ่าน |
| 3 Recoverable | durable state, retry/idempotency, restart/replay tests |
| 4 Operable | logs/metrics/runbook/alerts/owner/rollback |
| 5 Governed | privacy/security/evaluation/change approval ตามองค์กร |

ไม่ต้องเริ่ม Level 5 ในวันแรก แต่ห้ามนำ Level 0 ไปอ้างว่า production-ready ระบุ level ต่อ component ได้ เพราะ API อาจ Level 3 แต่ AI eval ยัง Level 1

## Verification ของหนังสือ

- ตรวจ Markdown links/HTML anchors/ZIP integrity
- parse Python code blocks ที่เป็นตัวอย่างสมบูรณ์
- architecture cases ใช้ synthetic data และระบุ high-impact boundary
- ไม่อ้างว่าทดสอบ cloud/provider/production runtime
- เชื่อมกลับ Books 00–05 โดยไม่เปลี่ยน URL เดิม

## Definition of Done ของ Design Pack

ผู้อ่านใหม่ตอบได้ว่าแก้ปัญหาอะไร, component ไหนรับผิดชอบอะไร, source of truth อยู่ไหน, failure/replay ทำอย่างไร, ใครมีสิทธิ์ทำ side effect, วัดผลอย่างไร และ rollback/ส่งต่ออย่างไร
