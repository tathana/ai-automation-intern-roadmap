# 03 — Data Model, State, Queue และ Idempotency

## Data Model เริ่มจาก Identity

แยก identifiers:

```text
candidate_id  ตัวบุคคลในระบบธุรกิจ
document_id   เอกสารหนึ่งฉบับ
document_hash snapshot เนื้อหา
task_id       งานประมวลผลหนึ่งงาน
execution_id  รอบที่ workflow/worker รัน
review_id     งานตรวจโดยคน
```

การใช้ ID เดียวแทนทุกอย่างทำให้ upload ใหม่/retry/review ผูกกันผิด

## State Machine

```text
queued → processing → succeeded
   │         │          └→ review (ถ้าผลต้องคนยืนยัน)
   │         ├→ retry_pending → queued
   │         └→ failed
   └→ cancelled
```

กำหนด allowed transitions, actor, timestamp และ invariant เช่น succeeded ต้องมี result reference; decided review ต้องมี reviewer/decision time

## Transaction Boundary

```text
BEGIN
  insert task
  insert audit event
COMMIT
ตอบ 202
```

หากตอบก่อน commit แล้ว process ตาย caller เชื่อว่ารับงานแต่ task หาย Transaction ควรครอบการเปลี่ยน state ที่ต้องเกิดร่วมกัน แต่ไม่ถือ lock ข้าม network call ยาวโดยไม่จำเป็น

## Worker Claim และ Lease

```text
worker A: atomically claim queued task + lease_until
          ↓ process
heartbeat/extend ตาม policy
          ↓ complete หรือ retry

worker A ตาย → lease หมด → worker B reclaim
```

claim ต้อง atomic มิฉะนั้น worker สองตัวอาจทำ task เดียวพร้อมกัน Lease ไม่แทน idempotency ของ side effects

## Retry Policy

```text
retryable: timeout, 429, selected 5xx
non-retryable: invalid input, auth failure, policy rejection
```

ใช้ attempt ceiling, exponential backoff + jitter, deadline และ dead-letter/manual review เมื่อเกินเพดาน เก็บ last error แบบปลอดภัย

## Idempotency Scope

```text
request key: create-task:EVENT-1
analysis key: document_hash + prompt/model/schema version
notification key: notify:TASK-7:needs-review:v1
```

key หนึ่งจุดไม่ทำให้ pipeline exactly-once ทุก side effect ต้องมี identity/constraint ของตัวเอง

## Outbox Pattern Mental Model

```text
DB transaction: update task + insert outbox event
                         ↓ commit
publisher อ่าน outbox → ส่ง → mark sent
```

ช่วยไม่ให้ DB state เปลี่ยนแต่ event หาย อย่างไรก็ตาม downstream ยังต้องรับ duplicate ได้เพราะส่งแล้วแต่ mark sent อาจล้ม

## Schema Migration

การแก้ model code ไม่เปลี่ยน production DB อัตโนมัติ Migration ต้อง versioned, review, backup/rollback/forward-fix plan และทดสอบกับข้อมูลรูปแบบใกล้จริง การย้อน Git ไม่ได้ย้อนข้อมูลที่ถูก transform เสมอ

## Data Design Checklist

- business identity และ unique constraints
- state transitions/invariants
- timestamps/timezone และ audit history
- transaction/locking/concurrency
- retention/deletion/privacy
- migration/backup/recovery
- indexes จาก query pattern ไม่ใช่เดา
