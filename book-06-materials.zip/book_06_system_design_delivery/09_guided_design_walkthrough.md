# 09 — Guided Design Walkthrough: จากโจทย์หนึ่งประโยคสู่ระบบที่อธิบายได้

ใช้ตัวอย่าง “ช่วย HR หา evidence ใน resume” เพื่อเชื่อม requirement, layout, contract, state, security, tests และ delivery โดยไม่สมมติว่า AI เป็นแกนของทุกปัญหา

## Step 1: อย่าเริ่มวาดกล่องจากชื่อเครื่องมือ

โจทย์แรก:

```text
ใช้ AI ช่วยอ่าน resume เป็นพันไฟล์
```

ยังตอบ architecture ไม่ได้ เพราะไม่รู้ว่า output ใช้ทำอะไร ต้องถามจนได้ workflow:

```text
HR เปิดเอกสาร → หาหลักฐาน skill/experience → จด quote
→ reviewer ตรวจจากต้นฉบับ → ใช้ประกอบงานคัดกรอง
```

จุดออกแบบสำคัญเปลี่ยนทันที: ระบบควรช่วยสร้าง **evidence draft** ไม่ใช่ตัดสินผู้สมัคร และ output ต้องย้อนกลับไป source ได้

## Step 2: Requirement เปลี่ยนเป็น Component อย่างไร

```text
REQ รับงานและคืน ID โดยไม่รอนาน
        ↓
API intake + durable task store

REQ extraction อาจช้า/ล้มเหลว
        ↓
worker + bounded retry + explicit state

REQ ทุก claim มีหลักฐาน
        ↓
schema validator + evidence validator

REQ คนต้องตรวจและ action ถูก audit
        ↓
review boundary + authorization + audit record
```

Component ไม่ได้เกิดเพราะ “best practice บอกให้มี” แต่เกิดจาก responsibility/risk ที่ชัด

## Step 3: เริ่มโครงสร้างเล็กก่อน

Prototype แรกอาจเป็น:

```text
prototype.py
fixtures/
tests/
README.md
```

เมื่อมี HTTP, state และ provider ซึ่งเปลี่ยนคนละเหตุผลจึงโตเป็น:

```text
src/app/
├── api/       # request/response/auth boundary
├── domain/    # evidence and transition rules
├── services/  # intake/process/review use cases
├── adapters/  # DB/file/model provider
└── models/    # contracts/config
```

กฎง่าย: ถ้าไฟล์เดียวต้อง import FastAPI, SQL, provider SDK และ business rule พร้อมกัน มันมีหลายเหตุผลให้แก้ ควรแยก boundary

## Step 4: Contract ต้องมี Semantics

```json
{"event_id":"evt-01","document_ref":"fixture://resume-01.pdf"}
```

Schema บอก type แต่ design ต้องตอบเพิ่ม:

- event ID unique ต่อ source หรือต่อวัน
- duplicate payload ต่างกันใช้ ID เดิมทำอย่างไร
- scheme/path ใดอนุญาต
- response 202 รับประกันว่า state commit แล้วหรือยัง
- caller poll/retry จาก status/error ใด

นี่คือสาเหตุที่ contract test ไม่ควรตรวจแค่ JSON shape

## Step 5: State เป็นภาษากลางของ Recovery

```text
queued → processing → retry_wait → queued
            ↓
       needs_review → approved/rejected
            ↓
      failed_terminal
```

หากมีเพียง boolean `done` เราแยกไม่ได้ว่ากำลังทำ, รอ retry, ต้องใช้คน หรือหมดสิทธิ์ retry แล้ว State machine ทำให้ API, worker, UI, metrics และ runbook ใช้ความหมายเดียวกัน

สำหรับ transition หนึ่งรายการให้ตอบ:

```text
processing → retry_wait
actor: worker
precondition: owns unexpired lease
write atomically: status, attempt, error_category, next_attempt_at, audit
side effect: none
```

## Step 6: Transaction Boundary ป้องกัน “ตอบสำเร็จแต่ไม่มีงาน”

```text
BEGIN
  insert task(event_id unique)
  insert audit(task_created)
COMMIT
return 202 task_id
```

ถ้าตอบ `202` ก่อน commit แล้ว process ตาย caller เชื่อว่ารับงานแล้วแต่ไม่มี state ถ้า insert task กับ audit แยก transaction อาจมี task ที่ตรวจย้อนหลังไม่ได้

## Step 7: Idempotency ไม่ใช่แค่ Retry

Retry คือ “ลองอีกครั้ง”; idempotency คือ “ลองซ้ำแล้วผลเชิงธุรกิจไม่ถูกทำซ้ำ”

```text
same event_id
  ↓ unique constraint + transaction
same logical task_id
  ↓ attempts may be many
one approved/export side effect
```

ต้องกำหนด scope/key/payload conflict/retention ไม่ใช่เพิ่ม header แล้วหวังว่า framework จัดการ

## Step 8: Trust Boundary เปลี่ยน Validation

```text
resume text (untrusted) → model prompt
model JSON (untrusted) → schema validator
claim + quote → source evidence validator
validated draft → authorized human
approved record → future export adapter
```

แม้ model ตอบ JSON ถูก schema ก็อาจอ้าง quote ที่ไม่มีจริง และแม้ quote ถูกก็ยังไม่ควรมีสิทธิ์ approve/export เอง Validation, authorization และ human review แก้คนละความเสี่ยง

## Step 9: Tests สะท้อน Boundary

```text
domain: quote matching/state transitions → unit
DB unique/lease/transaction → integration
API auth/schema/errors → API integration
provider adapter → contract tests with controlled fake
end-to-end: submit → worker → review
AI quality: versioned dataset/eval, not one demo
operations: crash/restart/replay drills
```

การ mock database ใน test idempotency อาจพลาด behavior ของ unique constraint จริง จึงเลือก test level ตามสิ่งที่ต้องพิสูจน์

## Step 10: Observability เดินตาม Identity

```text
request_id → task_id → attempt_id → review_id
```

Log เหตุการณ์เชิงโครงสร้างโดยไม่ใส่ raw resume; metric ดู queue age/retry/review correction; trace ช่วย latency ข้าม component Identity ทำให้รวมหลักฐานของงานเดียวโดยไม่ค้นจากชื่อผู้สมัคร

## Step 11: Architecture ที่ “ใหญ่พอ” แต่ไม่ใหญ่เกิน

สำหรับ synthetic prototype อาจยังใช้ process เดียว + SQLite และ worker command แยกได้ ไม่จำเป็น Kubernetes/message broker แต่ contract/state boundary ควรชัดเพื่อย้าย adapter ภายหลัง

เพิ่มระบบเมื่อมี evidence:

| Evidence | Possible change |
|---|---|
| concurrent load สูง | stronger DB/worker scaling |
| OCR cases มากและคุ้ม | approved OCR pipeline |
| review queue bottleneck | UI/batching/prioritization |
| multiple downstream side effects | outbox/delivery state |

## Step 12: Delivery คือส่วนหนึ่งของ Design

ก่อนเรียก pilot ต้องมี config/secret ownership, migration, health/readiness, logs/metrics, rollback/stop control, runbook และผู้รับมอบทดลอง recovery ถ้ากู้ไม่ได้โดยไม่มีผู้เขียน architecture ยังไม่จบ

## Mini Design Exercise

เปลี่ยนตัวอย่างเป็น Daily Report Automation แล้วตัด component ที่ไม่จำเป็น คำตอบที่สมเหตุผลอาจเหลือ:

```text
approved CSV → Python CLI validation → pure aggregation
→ atomic Markdown output → human review/send
```

ไม่มี AI, API, queue หรือ database เพราะ volume/actor/failure policy ยังไม่ต้องการ การ “ตัดของออกพร้อมเหตุผล” เป็นทักษะ system design เช่นเดียวกับการเพิ่มของ

## ไปต่อ

เมื่อเข้าใจเส้นนี้แล้ว เปิด **Book 07 — Project Delivery Template Book** เพื่อคัดลอก intake, requirements, data/risk, architecture, test, release และ handoff templates พร้อมตัวอย่างกรอกครบวงจร

