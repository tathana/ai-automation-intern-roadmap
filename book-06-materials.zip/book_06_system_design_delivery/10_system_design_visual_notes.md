# 10 — Visual Notes: Architecture, State และ Delivery Boundary

## Context → Components → Code

<div class="visual-board"><div class="visual-lane"><strong>Context</strong><div class="visual-track">User ↔ Our System ↔ External Systems</div></div><div class="visual-lane"><strong>Components</strong><div class="visual-track">API · n8n · worker · DB · AI adapter · review</div></div><div class="visual-lane"><strong>Code</strong><div class="visual-track">api/ · domain/ · services/ · adapters/ · models/</div></div></div>

## Requirement สร้าง Architecture

<div class="visual-board"><div class="visual-flow"><div class="visual-box">งานช้าและต้องรอด restart</div><span class="visual-arrow">→</span><div class="visual-box">durable task + worker</div><span class="visual-arrow">→</span><div class="visual-box">state machine + lease</div></div><div class="visual-flow"><div class="visual-box">AI claim ต้องมีหลักฐาน</div><span class="visual-arrow">→</span><div class="visual-box">evidence validator</div><span class="visual-arrow">→</span><div class="visual-box">human review</div></div></div>

## State Machine

<div class="visual-board"><div class="visual-flow"><div class="visual-box">queued</div><span class="visual-arrow">→</span><div class="visual-box">processing</div><span class="visual-arrow">→</span><div class="visual-box">needs_review</div><span class="visual-arrow">→</span><div class="visual-box">approved</div></div><div class="visual-flow"><div class="visual-box">retry_wait</div><span class="visual-arrow">↗ bounded retry</span><div class="visual-box">failed_terminal</div></div></div>

## Trust Boundary

<div class="visual-board"><div class="visual-flow"><div class="visual-box">External input</div><span class="visual-arrow">auth + validate →</span><div class="visual-box">API</div><span class="visual-arrow">contract →</span><div class="visual-box">Provider output</div><span class="visual-arrow">schema + evidence →</span><div class="visual-box">Authorized review</div><span class="visual-arrow">audit →</span><div class="visual-box">Side effect</div></div></div>

