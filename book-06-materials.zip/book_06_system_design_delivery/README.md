# Book 06 — System Design & Delivery Playbook

เล่มนี้ใช้หลังรู้เครื่องมือพื้นฐานแล้ว เพื่อเปลี่ยน requirement ที่ยังคลุมเครือให้เป็นระบบที่มีขอบเขต, contracts, state, failure policy, tests และผู้รับผิดชอบ เหมาะกลับมาเปิดก่อนเริ่มโปรเจกต์หรือส่ง design ให้ทีมตรวจ

## เป้าหมาย

```text
ปัญหาธุรกิจ → scope/metrics → data + contracts → components
          → failures/security → tests/observability → rollout/handoff
```

## บทเรียน

| บท | เนื้อหา |
|---|---|
| 00 | Requirement, scope และ acceptance criteria |
| 01 | Project layouts สำหรับ script/API/worker/n8n/AI |
| 02 | Layers, dependencies และ API contracts |
| 03 | Data model, state machine, queue และ idempotency |
| 04 | Configuration, security, privacy และ trust boundaries |
| 05 | Testing, observability, CI/CD และ rollout |
| 06 | Architecture gallery: HR, report, ticket, transaction, RAG |
| 07 | ADR, design review, documentation และ handoff |
| 08 | Sources, verification และ maturity model |
| 09 | Guided Design Walkthrough: อธิบายทุก boundary ผ่านโปรเจกต์เดียว |

## วิธีใช้

อ่านบท 00 แล้วสร้าง design pack ของโปรเจกต์หนึ่งชิ้น จากนั้นเปิดเฉพาะบทที่สัมพันธ์กับความเสี่ยง เช่นมี webhook ให้อ่าน state/idempotency, มี AI ให้อ่าน trust boundary/evaluation และมี side effect ให้เพิ่ม authorization/human approval

เล่มนี้ไม่บังคับทุกโปรเจกต์ใช้โครงสร้างใหญ่ เริ่ม architecture ที่เล็กที่สุดซึ่งรองรับ risk/ทีม แล้วเพิ่มความซับซ้อนเมื่อมีเหตุผลและหลักฐาน

ถ้าหัวข้อ architecture/state/security ดูเป็นคำศัพท์แยกส่วน ให้เปิดบท 09 บทนี้เดินโปรเจกต์เดียวจาก requirement ไปถึง release และชี้ว่าทฤษฎีแต่ละส่วนเปลี่ยนการออกแบบจริงอย่างไร
