# 00 — Requirement, Scope และ Acceptance Criteria

## เริ่มจากปัญหา ไม่ใช่เทคโนโลยี

Requirement ที่ว่า “ใช้ AI ช่วยอ่าน resume” ยังไม่พอ ต้องถามว่าใครทำงานอะไร ใช้เวลาตรงไหน output ถูกใช้ตัดสินใจอะไร และความผิดพลาดแบบใดรับไม่ได้

```text
ปัจจุบัน HR เปิดไฟล์ → ค้น skill → คัดลอก quote → สร้าง note
ปัญหา: เวลาเฉลี่ย/งานซ้ำ/ตามหลักฐานยาก
เป้าหมาย: สร้าง evidence draft ให้ตรวจเร็วขึ้น
ไม่ทำ: auto-rank, auto-reject, auto-hire
```

## Problem Statement Template

```text
ผู้ใช้หลัก:
งานปัจจุบัน:
pain/เวลา/ข้อผิดพลาด:
ผลลัพธ์ที่ต้องการ:
สิ่งที่ระบบไม่ทำ:
ข้อมูลที่เกี่ยวข้อง:
ข้อจำกัดเวลา/นโยบาย/ระบบเดิม:
```

## Functional vs Non-functional Requirements

**Functional** บอกระบบทำอะไร เช่นรับ resume reference, สร้าง task, แสดง evidence

**Non-functional** บอกคุณภาพ/ข้อจำกัด เช่น response ภายใน 300 ms สำหรับ intake, ไม่ log raw resume, กู้ queued tasks หลัง restart, จำกัด file size

## Acceptance Criteria ที่ตรวจได้

ไม่ใช้ “ระบบรวดเร็วและแม่น” ให้เขียน Given/When/Then:

```text
Given event_id เดิมและ payload เดิมเคยสร้าง task แล้ว
When caller ส่งซ้ำ
Then คืน task_id เดิม, duplicate=true และไม่มี task ใหม่
```

```text
Given AI claim อ้าง quote ที่ไม่มีใน source segment
When validator ตรวจผล
Then status=needs_review และ validated_profile ไม่มีค่า
```

## Success Metrics และ Guardrails

| ประเภท | ตัวอย่าง |
|---|---|
| Outcome | เวลาที่ HR ใช้ค้นหลักฐานต่อเอกสารลดลง |
| Quality | unsupported-claim rate บนชุดประเมิน |
| Reliability | task loss หลัง restart = 0 ใน crash test ที่กำหนด |
| Capacity | review queue age ไม่เกิน SLA |
| Guardrail | ไม่มี auto-reject/hire; PII access ถูก audit |

การลดเวลารวมต้องรวมเวลาตรวจ/แก้ output AI ไม่วัดเฉพาะ latency API

## Constraint และ Assumption Log

แยกสิ่งที่รู้กับสิ่งที่สมมติ เช่น “ไฟล์ทั้งหมดเป็น searchable PDF” เป็น assumption ที่อาจผิดและเปลี่ยน architecture ไปสู่ OCR เก็บ owner/วันที่ที่จะพิสูจน์

## Scope Ladder

```text
V0 manual baseline + วัดเวลา
V1 intake + queue + human-only review
V2 extraction mock + validators
V3 real model synthetic eval
V4 staging integration
V5 limited production rollout
```

แต่ละขั้นต้องมี exit criteria ไม่สร้างระบบใหญ่ทั้งหมดก่อนเรียนรู้จากผู้ใช้

## Design Exercise

เขียน one-page brief ของโปรเจกต์ลดเวลาหนึ่งงาน: problem, current flow, target flow, out-of-scope, metrics, five acceptance cases, privacy risk และ owner จากนั้นให้คนที่ไม่รู้โปรเจกต์อ่านแล้วทวนกลับ
