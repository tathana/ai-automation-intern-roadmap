# 02 — Layers, Dependencies และ Contracts

## Dependency Direction

```text
API/n8n/CLI adapters
        ↓ เรียก
Application services/use cases
        ↓ ใช้ interface
Domain rules/models
        ↑ implemented by
DB/provider/email adapters
```

เป้าหมายไม่ใช่ทำ Clean Architecture เต็มรูปทุกโปรเจกต์ แต่ป้องกัน business rule ผูกกับ FastAPI, SQL หรือ SDK จน test/เปลี่ยนไม่ได้

## Thin Route

```python
@router.post("/tasks", response_model=TaskAccepted, status_code=202)
def create_task(request: TaskCreate, service: ServiceDep) -> TaskAccepted:
    try:
        return service.create(request)
    except IdempotencyConflict as exc:
        raise HTTPException(status_code=409, detail={"code": exc.code}) from exc
```

route จัด HTTP/model/error mapping; service จัด use case; repository จัด transaction/persistence

## Port/Adapter Interface

```python
from typing import Protocol


class AnalysisProvider(Protocol):
    def analyze(self, prompt: str) -> str: ...
```

service พึ่งพาความสามารถ `analyze` ไม่พึ่ง SDK class เฉพาะ Mock/real adapter จึงสลับได้ แต่ interface ต้องสะท้อน errors/timeouts/metadata ที่งานต้องใช้จริง

## Contract มีหลายระดับ

- **Function contract:** parameters, return, exceptions
- **API contract:** method/path/headers/body/status
- **Event contract:** event type/key/schema/version/order expectations
- **Database contract:** schema/constraints/transaction semantics
- **Workflow contract:** node/sub-workflow input/output/status
- **AI contract:** prompt scope/output schema/evidence/fallback

## Versioning

เปลี่ยนชื่อ field/meaning/status อาจกระทบ caller แม้ endpoint เดิม ใช้ backward-compatible additive change เมื่อเหมาะ กำหนด deprecation/consumer tests และ version event/prompt/schema ตามความหมาย

## Boundary Validation

```text
external input → parse/schema → business rules → authorization
external output ← response schema ← safe error mapping
```

ตรวจที่ boundary แต่ไม่ duplicate rule แบบขัดกันทุกชั้น Pydantic ตรวจ shape, service ตรวจ state/policy, DB constraint เป็น safety net สำหรับ concurrency

## Error Taxonomy

| Error | ตัวอย่าง | เจ้าของการตัดสินใจ |
|---|---|---|
| Input | missing/invalid field | caller แก้ |
| Domain | duplicate conflict/invalid transition | service policy |
| Dependency | DB/provider unavailable | retry/recovery policy |
| Authorization | ไม่มีสิทธิ์ resource | security boundary |
| Unexpected | bug/invariant broken | incident/engineering |

อย่า map ทุก exception เป็น 500 ข้อความเดียวภายใน logs และอย่าส่ง internal stack/SQL/secrets ให้ client

## Dependency Review

สำหรับ component ทุกตัวให้เขียน:

```text
name/purpose
owner
input/output contract
timeout/retry/idempotency
authentication/authorization
data classification
health/monitoring
failure fallback
```

ถ้าตอบไม่ได้ architecture diagram ยังเป็นเพียงกล่องและลูกศร
