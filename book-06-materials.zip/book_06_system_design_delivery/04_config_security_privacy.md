# 04 — Configuration, Security, Privacy และ Trust Boundaries

## Configuration แยกจาก Code

ค่าที่เปลี่ยนตาม environment เช่น database URL, provider endpoint, timeout และ feature flag อยู่ configuration layer พร้อม validation ตอน startup Secret ไม่ควรมี default ที่ดูเหมือนใช้งานจริง

```text
environment/secret store
        ↓ load + parse + validate
Settings object
        ↓ inject
API/service/worker/provider
```

`.env.example` บอกชื่อและตัวอย่างที่ไม่ลับ; `.env` local ถูก ignore; production ใช้ mechanism ของ platform/องค์กร

## Authentication กับ Authorization

- **Authentication:** ผู้เรียกคือใคร
- **Authorization:** identity นี้ทำ action นี้กับ resource นี้ได้หรือไม่

token ถูกต้องไม่ได้แปลว่าอ่าน candidate/task ทุกตัวได้ Downstream service ต้องตรวจ authorization ทุก request ไม่ให้ LLM/n8n flag เป็นผู้ตัดสินสิทธิ์

## Trust Boundary Diagram

```text
Internet/user document (untrusted)
        ↓ validate/size/type/auth
API boundary
        ↓ authorized normalized data
internal service
        ├→ DB (sensitive state)
        ├→ provider (external data processor)
        └→ n8n/tool output (untrusted response)
```

ทุกลูกศรข้าม boundary ต้องมี contract, identity, minimization, timeout และ safe logging

## AI-specific Boundary

```text
trusted application policy
       + untrusted resume/web/tool data
                    ↓
                  LLM
                    ↓ untrusted candidate output
parse/schema/evidence/policy/authorization
                    ↓
draft/review; restricted side effect
```

Prompt ไม่ใช่ security boundary ระบบต้องจำกัด functionality, permissions และ autonomy จริง

## Data Classification

| ระดับตัวอย่าง | ข้อมูล | แนวทาง |
|---|---|---|
| Public | docs เผยแพร่แล้ว | integrity/version ยังสำคัญ |
| Internal | workflow/config ที่ไม่ลับ | จำกัดตามทีม |
| Confidential | resume, transaction details | minimization/access/audit/retention |
| Secret | keys/password/private key | secret store/rotation/no logs |

ใช้ classification policy ของบริษัทจริง ไม่คิดเองจากตารางตัวอย่างนี้

## File/URL Safety

อย่ารับ local path หรือ URL ใดก็ได้แล้วให้ server เปิดทันที ต้องจำกัด scheme/host/storage scope, ป้องกัน path traversal/SSRF, จำกัด size/pages/time และแยก parser ที่รับไฟล์ไม่เชื่อถือ

## Logging Privacy

เก็บ trace/task/reason/version/duration แทน raw payload ไม่ log authorization header, resume text หรือ provider response ทั้งก้อนเพื่อความสะดวก กำหนด retention/access และ redaction tests

## Threat Modeling Questions

- ใครส่ง input ปลอม/ซ้ำ/ใหญ่มากได้
- ถ้า credential รั่วเข้าถึงอะไรได้บ้าง
- LLM/tool ถูกชักนำให้ทำอะไรได้บ้าง
- ข้อมูลข้ามผู้ใช้/tenant ได้อย่างไร
- replay side effect ใดเสียหาย
- dependency ถูกยึด/ล่มแล้ว fallback เป็นอย่างไร
- audit พิสูจน์ actor/action/time/resource ได้หรือไม่

## Security Review Gate

ก่อนข้อมูลจริง: owner/data policy, consent/legal basis ตามองค์กร, provider retention/training terms, access scopes, incident procedure, deletion request และ human review สำหรับ high-impact decisions
