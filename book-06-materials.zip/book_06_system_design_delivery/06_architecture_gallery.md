# 06 — Architecture Gallery

ตัวอย่างเหล่านี้เป็น starting points ต้องปรับตามระบบ/นโยบายจริง

## A. Daily Operations Report

```text
Schedule → Fetch paginated data → Python/SQL compute facts
        → validate counts/totals → LLM draft narrative (optional)
        → human review → idempotent publish
```

Key design: report business key ต่อวัน/timezone, pagination guard, source counts, no AI arithmetic, publish key และ rerun policy

## B. HR Resume Evidence Assistant

```text
Upload reference → intake API → durable task → parser segments
→ LLM extraction → schema/evidence validators → review UI
→ HR decision in authorized system
```

ไม่ทำ auto-rank/reject/hire Data model แยก candidate/document/version/task/review; privacy/access/retention และ parser isolation เป็น production gates

## C. Support Ticket Triage

```text
Webhook → auth/normalize/redact → rules → classifier
       ├→ known low-risk queue
       ├→ ambiguous/urgent review
       └→ unsafe/invalid quarantine
```

AI แนะนำ category/draft; external reply ผ่าน approval ในรุ่นแรก Metrics แยก category และตรวจ false urgent downgrade

## D. Transaction Review Explanation

```text
transaction facts → deterministic rule engine → flags/reason codes
→ LLM draft explanation → number/fact validation → reviewer
```

การ freeze/refund/approval อยู่ใน policy service ที่ authenticate/authorize แล้ว ไม่ให้ model tool มีสิทธิ์กว้าง

## E. Internal Knowledge Assistant

```text
identity + question → authorized retrieval → current chunks
→ LLM answer from evidence → citation validation
→ not found/escalate owner
```

แยก indexing/query pipeline, document versions, ACL filtering, deletion/re-index และ retrieval evaluation

## Component Allocation Table

| ความรับผิดชอบ | เครื่องมือที่เหมาะเริ่มต้น |
|---|---|
| deterministic calculation/rules | Python/SQL |
| HTTP contract/auth | FastAPI/service |
| trigger/integration/routing | n8n |
| language extraction/draft | LLM ผ่าน adapter/validator |
| durable state/concurrency | DB/repository/worker |
| high-impact decision | authorized human/policy system |

## Unified Capstone

```text
Client
  ↓ POST /intakes (idempotency key)
FastAPI ──transaction──> SQLite/Postgres task+audit
  ↓ 202 task_id
n8n monitors/coordinates        Worker claims task
        │                            ↓
        └──────────────→ parser → AI service
                                     ↓ schema/evidence
                              result or review task
                                     ↓
                            HR/ops UI + audited decision
```

## Architecture Review Questions

1. Source of truth อยู่ที่ไหน
2. queued/succeeded/approved หมายถึงอะไรต่างกัน
3. failure จุดใด retry ได้และ side effect ซ้ำอย่างไร
4. ใครมีสิทธิ์อ่าน/เขียนข้อมูลใด
5. restart แล้วงาน/state อยู่หรือไม่
6. ตรวจ version ของ code/schema/prompt/model อย่างไร
7. วัด outcome และ guardrails อย่างไร
8. disable/rollback โดยไม่ทำข้อมูลเสียอย่างไร
