# 05 — Testing, Observability, CI/CD และ Rollout

## Test Strategy ตาม Boundary

```text
Unit           pure rule/service; เร็วและ deterministic
Integration    DB/parser/provider adapter กับ controlled dependency
Contract       API/event/schema ระหว่าง producer-consumer
End-to-end     topology/config/network สำคัญใน staging
Evaluation     model quality/retrieval/security cases
Chaos/recovery restart/crash/timeout/replay ตามความเสี่ยง
```

test เยอะที่ชั้นเดียวไม่แทนชั้นอื่น MockProvider ผ่านไม่พิสูจน์โมเดลจริง; TestClient ผ่านไม่พิสูจน์ container network

## Acceptance Matrix

| Case | Expected state | Side effect | Evidence |
|---|---|---|---|
| happy path | succeeded/review | ตาม policy 1 ครั้ง | response + DB + audit |
| invalid | rejected | 0 | 422/reason |
| duplicate same | task เดิม | 0 เพิ่ม | duplicate=true |
| duplicate conflict | needs review/409 | 0 | payload hash mismatch |
| timeout | retry/unknown | dedup | attempts/log |
| crash after claim | reclaim หลัง lease | dedup | restart test |

## Logs, Metrics, Traces

- **Logs:** เหตุการณ์ที่มี fields/บริบท
- **Metrics:** จำนวน/อัตรา/latency/backlog แนวโน้ม
- **Trace:** เส้นทาง request/task ข้าม components

```text
trace_id=T1
API received → task_id=Q7 queued → worker attempt=2
→ provider latency=820ms → review_id=R3 created
```

อย่าใช้ candidate email เป็น correlation key ใน logs ใช้ opaque IDs และควบคุม lookup

## Useful Metrics

API request/status/latency; queue depth/oldest age; worker throughput/retry/dead-letter; provider latency/error/cost; validation/review rate; human review age/outcome โดยระวัง privacy/fairness ของ metric

## CI Pipeline

```text
checkout
  → install locked dependencies
  → format check/lint/type check
  → unit/integration/contract tests
  → build image/artifact
  → scan/policy gates
  → publish immutable artifact
```

CI ควรใช้ commands เดียวกับ local และคืน non-zero เมื่อ gate fail ไม่เก็บ production secrets ใน pull-request jobs ที่ไม่ไว้ใจ

## CD และ Environment Promotion

```text
commit SHA → artifact/image digest
     dev → staging → limited production → broader rollout
```

โปรโมต artifact เดิมแทน rebuild ต่าง environment ถ้า workflow รองรับ แยก config/secrets และบันทึก version ที่ deploy

## Rollout Patterns

- shadow/dry-run: คำนวณแต่ไม่ทำ side effect
- feature flag: เปิดเฉพาะกลุ่ม/งาน
- canary: traffic ส่วนน้อย
- human approval: ก่อน external/high-impact action
- rollback/forward fix: มี criteria และ data migration consideration

## Release Evidence

commit/image/prompt/schema/migration versions, test/eval reports, config diff, owner, monitoring dashboard, rollback steps และ known limitations

## Incident Debug Order

```text
impact/scope → stop unsafe side effects
→ preserve IDs/logs/state → dependency health
→ recent changes → reproduce synthetic/staging
→ recover state → fix/test → rollout → post-incident actions
```
