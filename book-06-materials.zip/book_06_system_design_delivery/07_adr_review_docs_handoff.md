# 07 — ADR, Design Review, Documentation และ Handoff

## Architecture Decision Record (ADR)

ADR บันทึกเหตุผลและ trade-offs ไม่ใช่แค่ผลลัพธ์:

```text
Title: Use durable task table before returning 202
Status: Accepted
Context: Resume analysis takes longer than request timeout
Decision: Persist task+audit in one transaction, worker processes later
Alternatives: synchronous request; in-process background task
Consequences: adds worker/state/monitoring; survives API restart
Validation: crash/restart and duplicate tests
```

เมื่อเปลี่ยน decision ให้สร้าง ADR ใหม่ที่ supersede เดิม ไม่แก้ประวัติจนไม่รู้เหตุผล ณ เวลานั้น

## Design Pack ขั้นต่ำ

- one-page problem/scope/out-of-scope/metrics
- context/component/data-flow diagrams
- API/event/data contracts
- state machine และ failure matrix
- threat/privacy notes
- test/evaluation strategy
- rollout/monitoring/rollback
- open questions/assumptions/owners

## Diagram ระดับต่าง ๆ

```text
Context: User/System A → ระบบเรา → Provider/System B
Container/Component: API, n8n, worker, DB, AI service
Sequence: request หนึ่งรอบเรียกอะไรก่อนหลัง
State: queued → processing → ...
Deployment: process/container/network/volume อยู่ที่ไหน
```

เลือก diagram ที่ตอบคำถาม ไม่ใส่กล่องละเอียดทุก class ลงภาพ context

## README สำหรับผู้พัฒนา

```text
What/why/scope
architecture summary
prerequisites/setup
commands: run/test/lint/build
configuration names (no secrets)
sample requests/expected responses
failure drills
known limitations
links to runbook/ADR/eval
```

## Runbook สำหรับผู้ operate

health/readiness, normal start/stop, dashboards/alerts, common incidents, safe replay, backup/restore, migration/rollback, escalation owner และ evidence ที่ต้องเก็บ

## Handoff Rehearsal

ให้เพื่อนเริ่มจาก clone/empty environment โดยไม่ใช้คำบอกปาก ทดลอง setup, tests, API probe, one failure case และ recovery ถ้าเขาต้องถาม path/secret/command ที่ควรอยู่ใน docs ให้แก้ docs แล้วลองใหม่

## Demo Script

```text
1 ปัญหาและ baseline เวลา
2 architecture และขอบเขต AI
3 happy path พร้อม trace/task ID
4 failure + retry/review
5 replay/idempotency หรือ restart recovery
6 metrics/tests/eval evidence
7 limitations และ next safe step
```

ไม่สาธิตด้วยข้อมูลจริงถ้าไม่จำเป็น และไม่กล่าว “production-ready” หาก environment/runtime/security gates ยังไม่ผ่าน

## Review Checklist

- requirement/acceptance cases ตรวจได้
- responsibilities/dependencies ชัด
- status/identity/source of truth ไม่กำกวม
- failure/concurrency/replay ครบ
- privacy/auth/secrets/trust boundaries ครบ
- tests/eval/observability วัดสิ่งสำคัญ
- deploy/migration/rollback/handoff มี owner
- complexity ทุกชิ้นมีเหตุผล
