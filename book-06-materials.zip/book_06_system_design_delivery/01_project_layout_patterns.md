# 01 — Project Layout Patterns

โครงสร้างโฟลเดอร์คือเครื่องมือสื่อ ownership/dependencies ไม่ใช่คะแนนความเป็นมืออาชีพ เลือกให้เหมาะกับขนาดงานและทีม

## Pattern A: Automation Script

```text
report_job/
├── README.md
├── pyproject.toml
├── src/report_job/
│   ├── __init__.py
│   ├── main.py          # orchestration/CLI entry
│   ├── config.py
│   ├── extract.py
│   ├── transform.py
│   └── load.py
├── tests/
└── fixtures/
```

เหมาะกับ scheduled/batch job ที่ไม่เปิด HTTP API แยก pure transforms ออกจาก file/network side effects เพื่อทดสอบง่าย

## Pattern B: FastAPI Service

```text
resume_api/
├── pyproject.toml
├── src/resume_api/
│   ├── main.py
│   ├── api/
│   │   ├── dependencies.py
│   │   └── routes/
│   ├── schemas/
│   ├── services/
│   ├── repositories/
│   └── core/
│       ├── config.py
│       └── logging.py
├── tests/
│   ├── unit/
│   ├── integration/
│   └── contract/
└── migrations/
```

`main.py` ประกอบ app/lifecycle ไม่ควรมี business logic ทั้งระบบ routes map HTTP, services ทำ use cases, repositories จัด persistence

## Pattern C: API + Durable Worker

```text
automation_service/
├── src/automation_service/
│   ├── api/
│   ├── worker/
│   ├── domain/
│   ├── repositories/
│   └── shared/
├── tests/
├── migrations/
├── Dockerfile
├── compose.yaml
└── docs/
```

API persist task แล้วตอบ 202; worker claim/process/complete ด้วย transaction/lease ทั้งคู่แชร์ domain contracts แต่มี entry point และ process lifecycle แยก

## Pattern D: n8n + Backend

```text
hr_automation/
├── backend/
├── workflows/
│   ├── native/
│   └── compose/
├── fixtures/
├── docs/
│   ├── workflow-contracts.md
│   └── runbook.md
└── compose.yaml
```

n8n จัด trigger/integration/routing ส่วนกฎธุรกิจที่ซับซ้อนและต้อง unit test อยู่ backend เก็บ workflow JSON ใน Gitโดยไม่มี credentials

## Pattern E: AI Integration

```text
ai_service/
├── src/ai_service/
│   ├── prompts/
│   ├── schemas/
│   ├── providers/
│   ├── validators/
│   ├── services/
│   └── tools/
├── evaluations/
│   ├── datasets/
│   └── reports/
├── fixtures/
├── tests/
└── docs/
    ├── threat-model.md
    └── model-change-log.md
```

แยก prompt/schema/provider/eval เพื่อเปลี่ยนและวัดผลได้ ไม่วาง API call, parsing, policy และ side effect ใน function เดียว

## Monorepo หรือหลาย Repo

เริ่มหนึ่ง repo เมื่อ component เปลี่ยนพร้อมกัน ทีม/permissions/release cycle เดียว แยก repo เมื่อ ownership, security boundary หรือ deployment lifecycle แยกจริง Monorepo ไม่ได้หมายถึงทุก code import กันได้ ต้องรักษา module boundaries

## Files ที่ควรมีตามเหตุผล

| File | หน้าที่ |
|---|---|
| README | setup/run/test/architecture/limitations |
| pyproject.toml | package/dependencies/tool config |
| `.env.example` | ชื่อ config ที่ต้องใช้ ไม่มี secret |
| `.gitignore` | generated/local/secret patterns |
| Dockerfile | วิธีสร้าง image |
| compose.yaml | local multi-service topology |
| migrations | schema changes ที่ versioned |
| RUNBOOK | operate/recover/rollback |

อย่าสร้างโฟลเดอร์ว่างสิบชั้นล่วงหน้า เริ่มจาก module ที่มี responsibility จริง เมื่อไฟล์โตหรือมี dependency boundary จึง split พร้อม tests

## Decision Questions

```text
มี HTTP caller?       → API entry point
งานนาน/ต้องกู้หลังตาย? → durable queue + worker
หลาย integrations?    → orchestrator/n8n
มี probabilistic output? → provider + schema + validator + eval
มี DB schema เปลี่ยน?  → migration workflow
หลายทีม/สิทธิ์ต่างกัน? → explicit service/repo boundary
```
