# Technical Glossary — ศัพท์ที่ใช้คุยกับทีม

## A–C

**Acceptance criteria** — เงื่อนไขตรวจได้ว่างานตอบ requirement เช่น Given/When/Then

**Adapter** — ชั้นแปลง interface ของเราไปหา DB/SDK/provider ภายนอก

**API contract** — method/path/input/output/status/error ที่ producer และ consumer ตกลง

**Artifact** — ผล build ที่นำไปใช้/เผยแพร่ เช่น wheel, Docker image, HTML, ZIP

**ASGI** — interface มาตรฐานของ Python async web application ที่ FastAPI/Uvicorn ใช้

**Audit trail** — ประวัติ actor/action/time/resource/result ที่ย้อนตรวจได้

**Backoff** — เพิ่มช่วงรอก่อน retry รอบถัดไป; มักใช้ jitter ลดการยิงพร้อมกัน

**Backpressure** — กลไกชะลอ input เมื่อ downstream รับไม่ทัน

**Business key** — identity ของเหตุการณ์/งานในความหมายธุรกิจ ไม่ใช่ execution ID

**CI/CD** — automation สำหรับตรวจ/build และนำ artifact ไป environment ต่าง ๆ

**Correlation ID / Trace ID** — รหัสเชื่อม logs/events ข้าม component

## D–I

**Dependency injection** — ส่ง dependency ให้ component แทนสร้าง/หา global ภายใน ช่วย test/สลับ implementation

**Deterministic** — input/state เดิมภายใต้เงื่อนไขเดียวให้ผลเดิม เหมาะกับ rules/tests

**Durable state** — state ที่ยังอยู่หลัง process/container restart ตาม guarantee ที่ระบุ

**Embedding** — vector representation สำหรับเปรียบเทียบความใกล้เชิงความหมาย ไม่ใช่ข้อเท็จจริงหรือสิทธิ์เข้าถึง

**Evaluation (Eval)** — ชุดข้อมูล/เกณฑ์/metric สำหรับวัดคุณภาพ AI system

**Evidence validation** — ตรวจว่า claim/output มีหลักฐานจาก source ที่กำหนด

**Execution** — รอบการทำงานหนึ่งรอบของ workflow/process; อาจมีหลาย business items

**Exit code** — เลขที่ process คืนให้ caller; 0 มักสำเร็จ non-zero มัก failure

**Health vs Readiness** — health บอก process ยังทำงาน; readiness บอกพร้อมรับ traffic ตาม dependencies/policy

**Human-in-the-loop** — จุดที่คนตรวจ/ตัดสินพร้อมข้อมูล สิทธิ์ state และ audit ไม่ใช่แค่ส่งแจ้งเตือน

**Idempotency** — การเรียกซ้ำใน scope/key เดิมไม่สร้างผลธุรกิจซ้ำที่ไม่ตั้งใจ

**Invariant** — เงื่อนไขที่ต้องจริงเสมอ เช่น succeeded ต้องมี result reference

## L–R

**Lease** — สิทธิ์ครอบครองงานชั่วคราวที่หมดอายุเพื่อให้ worker อื่นกู้ได้

**LLM** — โมเดลภาษาที่สร้าง output ตามบริบทแบบ probabilistic; output ยังต้องตรวจ

**Migration** — การเปลี่ยน schema/data แบบ versioned และ deployable

**Mock** — ตัวแทน dependency ที่ควบคุม output/failure ได้ ไม่พิสูจน์ dependency จริง

**Node contract** — input/process/output/failure ของ node ใน workflow

**Observability** — ความสามารถเข้าใจ state ภายในจาก logs/metrics/traces และ domain signals

**Orchestration** — การประสานหลายขั้นตอน/services ให้เป็น flow เดียว

**PII** — ข้อมูลที่ระบุหรือเชื่อมโยงบุคคล ต้องจัดการตามนโยบาย/กฎหมายองค์กร

**Prompt injection** — input ภายนอกพยายามเปลี่ยนพฤติกรรม/อำนาจของ LLM application

**RAG** — retrieval-augmented generation: ค้น evidence แล้วให้โมเดลตอบจากบริบทนั้น

**Repository pattern** — abstraction สำหรับ persistence/query ไม่ใช่ชื่อ Git repository ในบริบทนี้

**Retry** — ลอง operation ใหม่ตาม policy; ไม่เท่ากับ recovery และอาจทำ side effect ซ้ำ

**Rollback** — กลับ deployment/config เมื่อทำได้; database/data change อาจต้อง forward fix/restore

## S–Z

**Schema validation** — ตรวจ shape/type/constraints ไม่พิสูจน์ความจริงหรือ authorization

**Side effect** — การเปลี่ยนสิ่งภายนอก function เช่นเขียน DB ส่งอีเมล เรียก payment

**Source of truth** — แหล่ง state ที่ระบบถือเป็นหลักเมื่อข้อมูลหลายสำเนาขัดกัน

**Structured output** — output ที่มี schema/fields ให้ parse/validate ได้

**Synthetic data** — ข้อมูลสร้างเพื่อทดสอบที่ไม่ใช่ข้อมูลบุคคล/ธุรกิจจริง

**Throughput** — จำนวนงานต่อหน่วยเวลา; ต่างจาก latency ของงานหนึ่งชิ้น

**Timeout** — เพดานเวลารอ; เมื่อหมดเวลา outcome ของ remote side effect อาจยังไม่รู้

**Transaction** — กลุ่ม database operations ที่ commit/rollback ตาม atomic boundary

**Trust boundary** — จุดที่ข้อมูล/identity/authority ข้ามขอบเขตและต้องตรวจ

**Webhook** — HTTP callback ที่ระบบต้นทางส่งเมื่อ event เกิด; อาจถูกส่งซ้ำ/สลับลำดับ

**Worker** — process ที่หยิบ queued task มาประมวลผล แยกจาก API intake ได้

## คำที่มักพูดผิด

```text
HTTP 200             ≠ business succeeded เสมอ
queued               ≠ processed
schema valid         ≠ factually correct
quote exists         ≠ claim supported
confidence 0.9       ≠ ถูก 90% หากไม่ calibration
mock tests pass      ≠ integration/production pass
container running    ≠ service ready
Git revert code      ≠ database rollback
human notified       ≠ human review workflow สมบูรณ์
AI agent             ≠ ควรมีสิทธิ์ทำทุก action
```
