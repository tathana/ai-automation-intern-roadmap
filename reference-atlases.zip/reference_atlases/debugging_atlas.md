# Debugging Atlas — จากอาการไปหาชั้นที่ผิด

## กฎแรก

```text
บันทึกอาการจริง + command + directory + version + input + expected
       ↓
หา failure ชั้นแรก
       ↓
เปลี่ยนตัวแปรเดียว
       ↓
รันกรณีเล็กและเก็บ evidence
```

อย่าเปลี่ยน code/config/dependency/network พร้อมกัน

## Command Not Found

ตรวจ:

```powershell
Get-Command <name> -All
$env:PATH
```

สาเหตุ: ยังไม่ติดตั้ง, PATH ไม่รวม executable, ใช้ shell คนละแบบ หรือเปิด terminal ก่อนติดตั้งแล้ว environment ยังไม่ refresh

## Python Import Error

```powershell
Get-Location
python -c "import sys; print(sys.executable); print(*sys.path, sep='\n')"
python -m pip show <package>
```

- `ModuleNotFoundError`: environment/path/package ไม่พบ
- `ImportError`: module พบแต่ object/import cycle/version อาจผิด
- local file ชื่อชน package เช่น `fastapi.py`, `json.py` ทำให้ import ผิดตัว

## File Not Found

ตรวจ current directory และ absolute target:

```powershell
Get-Location
Test-Path -LiteralPath '.\data\input.json'
Resolve-Path -LiteralPath '.\data' -ErrorAction SilentlyContinue
```

อย่าแก้ด้วย hardcode path ส่วนตัวทันที ให้ตัดสินว่า path ควรสัมพันธ์กับ CWD, project root หรือไฟล์ module

## Port/Connection

```powershell
Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
curl.exe -i http://127.0.0.1:8000/health
```

| อาการ | ชั้นที่น่าตรวจ |
|---|---|
| connection refused | process/listener/host/port |
| DNS failure | hostname/resolver/network |
| TLS/certificate | scheme/certificate/trust/proxy |
| timeout | network/service/dependency; outcome อาจ unknown |
| 404 | ถึง HTTP server แต่ path/prefix ผิด |
| 405 | method ผิด |
| 422 | request schema/type/field |
| 500 | application bug/unhandled dependency error |
| 502/503 | gateway/upstream/readiness/capacity |

## FastAPI 422

อ่าน `detail[].loc`, `type`, `msg`, `input` แล้วเทียบ path/query/header/body กับ model อย่าแก้ service เพราะ route ยังไม่ถูกเรียก

## Async/Timeout

แยก client timeout, SDK timeout, reverse-proxy timeout และ task deadline การ timeout หลังส่ง request ไม่บอกว่า server ไม่ทำ side effect ตรวจ business/idempotency state ก่อน retry

## Pytest

```powershell
python -m pytest tests\test_file.py::test_name -vv
python -m pytest -x
```

- 0 collected: naming/config/path
- import error: environment/project install
- flaky: เวลา/network/shared state/order/randomness
- mock ผ่าน real fail: boundary/contract/config/network ไม่ได้ถูกทดสอบ

## SQL/SQLite

- database locked: transaction นาน/concurrent writers/connection lifecycle
- no such table: database path ผิดหรือ migration ไม่รัน
- data ไม่คง: commit/transaction/ใช้ DB คนละไฟล์
- duplicate race: check-then-insert ไม่มี unique constraint/atomic transaction

พิมพ์ resolved database path และ environment ก่อนแก้ schema

## n8n

```text
ไม่มี execution → trigger/active/test URL
execution มี     → เปิด node แรกที่ output ต่าง expected
0 items          → filter/route/array-vs-items
expression undefined → field path/type/item linking
HTTP เขียวแต่ธุรกิจ fail → statusCode + body.status
replay ส่งซ้ำ → side-effect idempotency
```

ดู Input/Parameters/Output ของ node ไม่สรุปจากสีเขียว

## LLM/AI Pipeline

```text
input schema → prompt/context → provider call
→ JSON parse → schema → evidence → policy → downstream
```

reason codes: `invalid_request`, `provider_timeout`, `invalid_json`, `invalid_schema`, `unsupported_claim`, `blocked`, `needs_review` แก้ชั้นแรกที่ fail ไม่เปลี่ยน prompt ทุกกรณี

## Docker

```powershell
docker version
docker compose config
docker compose ps
docker compose logs --tail 200 api
docker inspect <container>
```

- client มี/server error: Engine ไม่พร้อม
- build context ใหญ่/ไฟล์หาไม่พบ: `Dockerfile`, context, `.dockerignore`, COPY paths
- container ออกทันที: process exit/logs/entrypoint/config
- localhost ผิด: network namespace/service name/port mapping
- permission denied volume: UID/GID/host mount permissions
- unhealthy: healthcheck command/dependency/readiness

## Git

```powershell
git status
git diff
git diff --staged
git log --oneline --decorate --graph --all -15
git reflog
```

- detached HEAD: ตรวจ commit/branch ก่อนสร้างงาน
- rejected push: fetch แล้วอ่าน divergence ไม่ force ทันที
- conflict: แก้ markers, test, stage resolution
- file ดูหาย: หยุด mutation ตรวจ status/log/reflog/tracked-untracked

## Production Incident Minimum

1. ลดผลกระทบ/หยุด side effect อันตราย
2. เก็บ trace/task/execution/deployment IDs และ timestamps
3. ตรวจ dependency health/recent changes
4. ห้ามทดลอง destructive บน production เพื่อหาเหตุ
5. recovery ก่อน permanent fix เมื่อเหมาะ
6. verify state และสื่อสาร limitation
