# Command Atlas — คำสั่งที่ใช้ตลอดหลักสูตร

เปิดหน้านี้เพื่อค้นเร็ว แล้วอ่านคำอธิบายเต็มใน Book 00 ก่อนใช้คำสั่งที่เปลี่ยน state

## Context ก่อนทุกคำสั่ง

```powershell
Get-Location
Get-ChildItem
Get-Command python -All
python -c "import sys, os; print(sys.executable); print(os.getcwd())"
```

## Files และ Paths

| งาน | PowerShell |
|---|---|
| ดูตำแหน่ง | `Get-Location` |
| เปลี่ยนโฟลเดอร์ | `Set-Location -LiteralPath 'D:\Work\project'` |
| แสดงไฟล์ | `Get-ChildItem -Force` |
| ตรวจ path | `Test-Path -LiteralPath '.\pyproject.toml'` |
| resolve absolute | `Resolve-Path -LiteralPath '.\src'` |
| อ่านต้นไฟล์ | `Get-Content -LiteralPath '.\README.md' -First 40` |
| ค้นข้อความ | `rg -n "pattern" .` |
| ค้นรายชื่อไฟล์ | `rg --files` |

`Move-Item`, `Copy-Item -Recurse` และ `Remove-Item` เปลี่ยน state ตรวจ exact target ก่อน โดยเฉพาะ recursive/wildcard

## Python Environment

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip --version
python -m pip install -e .
python -m pip list
python -m pip check
```

ตรวจ environment:

```powershell
python -c "import sys; print(sys.executable)"
python -c "import package_name; print(package_name.__file__)"
```

## Run และ Test

```powershell
python script.py
python -m package.module
python -m pytest -q
python -m pytest tests\test_api.py::test_case -vv
python -m pytest -x
python -m pytest -k "timeout or duplicate"
python -m ruff check .
python -m ruff format --check .
python -m mypy src
```

## FastAPI และ HTTP

```powershell
python -m uvicorn package.main:app --reload --port 8000
curl.exe -i http://127.0.0.1:8000/health
Invoke-RestMethod -Method Get -Uri 'http://127.0.0.1:8000/openapi.json'
$body = @{event_id='E1'; amount_minor=1200} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8000/events' -ContentType 'application/json' -Body $body
```

## Process และ Port

```powershell
Get-Process python -ErrorAction SilentlyContinue
Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
Get-Process -Id 12345
Stop-Process -Id 12345
```

หยุดเฉพาะ PID ที่ตรวจแล้วว่าเป็น process ของงานคุณ

## Environment Variables

```powershell
$env:APP_ENV = 'development'
Get-ChildItem Env:APP_ENV
Remove-Item Env:APP_ENV
```

ตัวแปร process นี้ถูกส่งต่อให้ child process และเป็น string ไม่ commit secret ลง `.env`

## Git Read-only

```powershell
git status
git diff
git diff --staged
git log --oneline --decorate --graph -10
git branch --show-current
git remote -v
```

## Git Change/Share

```powershell
git switch -c feature/intake-validation
git add -- path\to\file.py
git diff --staged
git commit -m "Validate resume intake payload"
git fetch origin
git pull --ff-only
git push -u origin feature/intake-validation
git revert <commit>
git reflog
```

อ่าน Git Special Track ก่อน reset/force push/clean

## Docker

```powershell
docker version
docker build -t app:dev .
docker image ls
docker run --rm -p 8000:8000 app:dev
docker ps
docker logs <container>
docker inspect <container>
```

## Docker Compose

```powershell
docker compose config
docker compose build
docker compose up
docker compose up -d
docker compose ps
docker compose logs --follow api
docker compose stop
docker compose down
```

`docker compose down -v` อาจลบข้อมูลใน named volumes ไม่ใช้เป็น cleanup ปกติโดยไม่ตรวจ

## n8n

```powershell
n8n --version
n8n start
n8n --help
n8n import:workflow --help
n8n export:workflow --help
```

ทดลอง import/export ด้วย user folder/instance แยกจากงานจริง

## SQLite และ JSON Quick Probes

```powershell
python -c "import sqlite3; print(sqlite3.sqlite_version)"
python -m json.tool .\fixture.json
```

## GitHub/Vercel Verification

```powershell
git status
git log -1 --oneline
git remote -v
```

การ push/deploy เป็น external side effect ตรวจ repository, branch, identity และ diff ก่อนเสมอ

## Help เป็นส่วนหนึ่งของงาน

```powershell
python --help
python -m pytest --help
git help status
docker compose --help
n8n --help
Get-Help Get-ChildItem -Full
```

flags เปลี่ยนตาม version ให้ใช้ help ของ executable ใน environment นั้นเป็นหลัก
