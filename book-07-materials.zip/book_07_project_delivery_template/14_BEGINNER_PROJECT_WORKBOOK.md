# 14 — Beginner Project Workbook: สมุดงานไฟล์เดียว

Workbook นี้ลดภาระการเลือก Template หลายไฟล์ ให้คัดลอกหัวข้อต่อไปนี้ไปไว้ใน `docs/PROJECT_WORKBOOK.md` แล้วเติมทีละส่วน ข้อใดยังไม่รู้ให้เขียน `UNKNOWN — ถามใคร / เมื่อไร` แทนการเดา

## 1. Project Snapshot

```markdown
# Project: <ชื่อที่สื่อปัญหา>

## โจทย์ต้นฉบับ
<ข้อความจากผู้มอบหมาย>

## ความเข้าใจของเรา
ระบบนี้ช่วย <ผู้ใช้> ทำ <งาน> โดยลด <เวลา/ข้อผิดพลาด/ขั้นตอน>

## Success metric
- ก่อนทำ: ...
- เป้าหมายทดลอง: ...
- วิธีวัด: ...

## Owner และผู้ตัดสิน
- ผู้ใช้จริง:
- ผู้ให้ requirement:
- ผู้อนุมัติผลลัพธ์:
```

ถ้ายังไม่มี baseline ให้จดวิธีเก็บ ไม่ต้องสร้างตัวเลขขึ้นเอง เช่น “จับเวลาการอ่าน Resume 30 ไฟล์จากตัวอย่างสังเคราะห์หรือข้อมูลที่ได้รับอนุญาต”

## 2. Current Flow

```text
ใครส่งอะไร
  ↓
ใครเปิด/อ่าน/คัดลอก
  ↓
ใช้กฎอะไรตัดสิน
  ↓
บันทึกผลไว้ที่ไหน
  ↓
ใครรับงานต่อ
```

ใต้ Flow ให้จดจุดช้า จุดผิดบ่อย และจุดที่ต้องใช้วิจารณญาณมนุษย์ อย่ารีบทำ automation ในขั้นที่ยังไม่เข้าใจกฎ

## 3. Scope Box

```markdown
## In scope รอบนี้
- รับไฟล์ข้อความ/PDF ที่ระบบรองรับ
- สกัดข้อมูลตาม schema
- แสดงหลักฐานและส่งให้คนตรวจ

## Out of scope รอบนี้
- ตัดสินรับหรือปฏิเสธผู้สมัครอัตโนมัติ
- OCR เอกสารทุกชนิด
- เชื่อม production HR system ก่อนผ่าน pilot

## ข้อห้าม
- ห้าม log เนื้อหา Resume เต็ม
- ห้ามให้ model ทำ side effect โดยไม่มี approval
```

Out of scope ไม่ได้แปลว่าเรื่องนั้นไม่สำคัญ แต่แปลว่า “ยังไม่รับปากในรอบนี้”

## 4. Acceptance Examples

เขียนตัวอย่างก่อนเขียนโค้ด:

| ID | Given | When | Then |
|---|---|---|---|
| AC-01 | Resume มี skill Python จริง | วิเคราะห์ | คืน skill พร้อม quote ที่ค้นพบในต้นฉบับ |
| AC-02 | Provider คืน quote ที่ไม่มีจริง | ตรวจ evidence | ระบุ `needs_review` และไม่ยืนยันข้อมูลนั้น |
| AC-03 | ส่ง event เดิมซ้ำ | รับข้อมูล | คืน task เดิมและไม่สร้างงานซ้ำ |

`Given–When–Then` แปลแบบง่ายว่า “กำหนดสถานการณ์ → ทำบางอย่าง → คาดหวังผล” และสามารถเปลี่ยนเป็น test ภายหลังได้ตรง ๆ

## 5. Data and Risk Notes

```markdown
| Data | Source | Sensitive? | Store where? | Keep how long? |
|---|---|---|---|---|
| resume_text | upload | PII | approved storage | ตาม policy |

| Risk | What can happen? | Control | How to test? | Owner |
|---|---|---|---|---|
| RISK-01 | PII ปรากฏใน log | redact และ log เฉพาะ ID | ตรวจ captured logs | backend |
```

## 6. Simple System Map

```text
[Input] → [Validate] → [Save Task] → [Process] → [Review] → [Output]
               │             │            │
               └─ error      └─ retry     └─ audit
```

ทุกกล่องควรบอกได้ว่า “รับอะไร คืนอะไร เก็บ state หรือไม่ และล้มเหลวอย่างไร” หากกล่องหนึ่งทำหลายหน้าที่จนตอบยาก ให้แยกกล่อง

## 7. Work Slices

| Slice | Demo ที่เห็นได้ | Code | Test | Done เมื่อ |
|---|---|---|---|---|
| S1 | input ถูกต้องสร้าง task ได้ | model + validation + repository | valid/invalid input | query task กลับมาได้ |
| S2 | worker สร้าง evidence | provider + service | supported/unsupported quote | result ถูกบันทึก |
| S3 | คนกด approve/reject | review API + audit | valid/duplicate decision | audit ค้นย้อนหลังได้ |

หนึ่ง Slice ควรวิ่งจาก input ไปถึงผลที่มองเห็น ไม่ใช่ “ทำ database ทั้งหมด” โดยยังสาธิตอะไรไม่ได้

## 8. Daily Log

```markdown
## วันที่ ...
- เป้าหมายชิ้นเล็ก:
- ก่อนแก้ tests เป็นอย่างไร:
- ไฟล์ที่ตั้งใจแก้:
- สิ่งที่ทดลอง:
- หลักฐานหลังแก้:
- คำถาม/ความเสี่ยงที่ยังเหลือ:
- commit:
```

## 9. Release and Handoff

```markdown
- [ ] รันจาก clean setup ตาม README ได้
- [ ] ไม่มี secret หรือข้อมูลจริงใน Git/log/test fixture
- [ ] happy path และ failure สำคัญผ่าน
- [ ] มีวิธีตรวจ health และงานค้าง
- [ ] มี rollback/disable switch
- [ ] ระบุ limitation ตรงไปตรงมา
- [ ] คนอื่นทดลองตาม runbook ได้
```

Workbook นี้เป็นเส้นหลัก ส่วน Template Pack ใช้เมื่อเรื่องใดซับซ้อนพอที่จะต้องแยกเอกสาร เช่น ADR หลายรายการ, risk register ใหญ่ หรือ release ที่มี migration

