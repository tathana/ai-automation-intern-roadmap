# 04 — Architecture, Boundaries, State และ ADR

## เริ่มจากความรับผิดชอบ ไม่ใช่ชื่อเทคโนโลยี

ถามก่อนว่าใครรับ request, ใคร validate, ใครเก็บ state, ใครทำงานช้า, ใครอนุมัติ และใครส่งผลต่อ จากนั้นค่อยเลือก FastAPI, n8n, worker หรือ provider

## Diagram สี่ภาพที่คุ้มที่สุด

1. **Context:** คนและระบบภายนอกใดคุยกับระบบเรา
2. **Component:** ส่วนหลักและ responsibility
3. **Sequence:** request หนึ่งเส้นทางเดินอย่างไร
4. **State:** task เปลี่ยนสถานะได้แบบใด

```text
[HR] → [Web/API] → [Task DB] ← [Worker] → [Approved AI provider]
                           ↓
                    [Review queue] → [Reviewer]
```

```text
HR        API        DB        Worker      Provider
 | submit  |          |           |            |
 |-------->| validate |           |            |
 |         |--insert->| queued    |            |
 |<--202 task_id------|           |            |
 |                    |<-claim----|            |
 |                    |           |---request->|
 |                    |<-result---|<--output---|
```

## State Machine ก่อนเขียน Worker

```text
queued → processing → needs_review → approved → exported
            │              │
            ├→ retry_wait ─┘
            └→ failed_terminal
```

กำหนดว่า actor ใดเปลี่ยน state, precondition คืออะไร, เขียนข้อมูลใดใน transaction เดียว และ retry ได้หรือไม่ สถานะ `failed` เดียวมักกว้างเกินไปสำหรับ recovery

## Sync หรือ Async

ใช้ synchronous เมื่อเร็ว คาดการณ์ได้ และ caller รอได้ ใช้ durable async เมื่อเวลานาน มี provider/retry, ต้องรอด restart หรือมี human review อย่าใช้ in-process background task แทน queue โดยไม่เข้าใจว่าถ้า process ตาย state อยู่ที่ไหน

## Architecture Decision Record

ADR เก็บ context, decision, alternatives, consequences และ validation:

```text
ADR-01: Persist task before returning 202
Context: processing may exceed request timeout
Decision: API writes task+audit atomically; worker claims later
Alternative: synchronous; in-memory task
Consequence: DB/worker complexity, but restart-safe
Validate: crash-after-202 and duplicate-event tests
```

## Architecture Review Walkthrough

ไล่หนึ่ง request ด้วยนิ้วตั้งแต่ต้นจนจบ แล้วถามทุก boundary:

- identity/authorization มาจากไหน
- invalid/duplicate input ไปไหน
- state ถูก commit ก่อนตอบหรือไม่
- process ตายตรงนี้แล้วกู้จากอะไร
- trace/task ID เดินครบหรือไม่
- ข้อมูลลับปรากฏใน log ตรงใด

### Gate B ตรวจผ่านเมื่อ

ทีมอธิบาย happy path, failure path, state owner, source of truth, trust boundaries และเหตุผลของ component ทุกชิ้นได้โดยไม่อาศัย “framework จัดการให้”

