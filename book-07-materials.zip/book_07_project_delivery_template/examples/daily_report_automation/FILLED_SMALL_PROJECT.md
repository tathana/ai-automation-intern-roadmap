# Filled Small Project — Daily Report Automation

Status: internal script pilot  
Owner/user: Operations analyst  
Technical owner: Data automation team  
Current gate: C, manual send only

## Intake and baseline

ทุกเช้า analyst ดาวน์โหลด approved CSV สามไฟล์ ตรวจคอลัมน์ รวมยอดตามทีม และคัดลอกลงข้อความ ใช้ active time median 24 นาทีจากตัวอย่าง 10 วัน ความผิดพลาดหลักคือไฟล์วันผิดและคอลัมน์หาย

Target: สร้าง **draft report** พร้อม validation summary ภายใน active timeไม่เกิน 8 นาที โดย analyst ตรวจและกดส่งเอง

Out of scope: automatic email/send, real-time dashboard, AI narrative, arbitrary input directory

## Requirements

| ID | Requirement | Acceptance |
|---|---|---|
| REQ-F-01 | รับไฟล์สามประเภทของ business date เดียวกัน | missing/mixed date fails before output |
| REQ-F-02 | validate required columns/types before aggregate | invalid rows reported with source/row |
| REQ-F-03 | render deterministic Markdown draft | totals match golden fixture |
| REQ-NF-01 | rerun same input does not create ambiguous copies | output path includes date + content hash |

```text
approved input folder
   ↓ discover exact filenames/date
validate schema + business date
   ↓ invalid → error report, no final draft
aggregate pure functions
   ↓
render report.tmp
   ↓ atomic rename
report_2026-09-12_<hash>.md
   ↓ analyst reviews and sends manually
```

## Why this architecture is small

หนึ่ง user, run วันละครั้ง, input อยู่เครื่องมือ approved, ไม่มี concurrent requests และ send เป็น manual จึงใช้ Python CLI + pure domain functions + filesystem output ไม่ต้องมี FastAPI, queue, worker, Docker หรือ LLM

```text
src/report_tool/
├── cli.py          # arguments and exit code
├── validation.py   # schemas/date checks
├── aggregate.py    # pure calculations
└── render.py       # Markdown template
tests/
├── fixtures/
├── test_validation.py
└── test_aggregate.py
```

## Task plan

- TASK-01 create synthetic normal/missing-column/mixed-date fixtures
- TASK-02 validation with clear exit code and error report
- TASK-03 pure aggregation with golden expected totals
- TASK-04 atomic output and rerun behavior
- TASK-05 README/runbook + analyst rehearsal

## Tests and failures

| Case | Expected |
|---|---|
| normal three files | exit 0; deterministic draft |
| required column missing | non-zero; names file/column; no final draft |
| mixed business dates | non-zero; no aggregate |
| same content rerun | same identifiable output; no conflicting result |
| interrupted before rename | temp can be cleaned; prior final unchanged |

## Release and handoff

Pilot runs manually in approved directory. README contains supported Python version, setup, command, input naming/schema and expected output. Runbook explains error report, temp cleanup, rerun and escalation. Analyst performs one normal and one missing-column case from docs.

## Impact measurement

Compare the same file mix for 10 pilot days. Record tool run time separately from analyst review/correction. Stop/adjust if validation misses schema errors or active time does not improve. Automatic send remains a new requirement/risk review, not an implicit next step.

