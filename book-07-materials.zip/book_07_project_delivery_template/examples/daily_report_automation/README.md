# Filled Example — Daily Report Automation

ตัวอย่างงานขนาดเล็กที่ใช้ template แบบย่อและเลือก architecture พอดีกับความเสี่ยง ดู `FILLED_SMALL_PROJECT.md`

