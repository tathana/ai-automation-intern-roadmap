# Filled Project Pack — HR Resume Evidence Assistant

> Training example • synthetic data only • prototype • no auto-rank/reject/hire

Version: `0.3-design-example`  
Decision owner: HR Operations Lead (fictional role)  
Users/SME: HR screening specialists  
Technical owner: Automation Engineering team  
Current gate: C — synthetic verification; Gate D not requested

## 1. Intake and Current State

### Request received

“ช่วยใช้ AI อ่าน resume จำนวนมากและสรุปให้ HR”

### Observable problem

HR ต้องเปิด PDF ค้นหลักฐานของ skill/experience คัดลอก quote และสร้าง note สำหรับ reviewer งานช้าเมื่อรูปแบบเอกสารต่างกัน และ reviewer ย้อนหาที่มาของสรุปยาก

### Current-state sample

```text
mailbox → download PDF (0.5m active)
        → find evidence (5m active median)
        → copy note (1m active)
        → reviewer checks quote (2m active)
```

Baseline training sample: synthetic searchable PDFs 30 ไฟล์, median 8.5 active minutes/file, p90 13 minutes; scanned PDFs ไม่รวมและถูกบันทึกเป็น assumption gap

### Stakeholders and decisions

| Role | Needs | Decides |
|---|---|---|
| HR user | evidence หาเร็วและแก้ได้ | usability feedback |
| HR owner | scope/metric/pilot | accept business outcome |
| HR SME | rubric/ground truth | extraction correctness |
| Technical owner | operability | architecture/release |
| Privacy/Security | allowed data/provider | real-data gate |

### Out of scope

- ไม่ rank, score, reject หรือ hire
- ไม่อ่าน scanned PDF/OCR ใน V1
- ไม่เชื่อม ATS จริงใน prototype
- ไม่ใช้ resume จริงก่อน privacy/security approval

## 2. Project Brief

### Target outcome

ลด active time ในการสร้าง evidence draft โดย HR ยังตรวจและอนุมัติทุกผล และ unsupported evidence ต้องไม่ถูก export

### Metrics

- median human active time รวม review/correction เทียบ baseline
- quote support rate และ unsupported-claim rate บน dataset รุ่นคงที่
- unprocessable/needs-review count แยกเหตุผล
- duplicate task count และ task loss หลัง restart

### Guardrails

- auto-employment decision = 0
- unsupported quote exported = 0 ใน acceptance set
- raw resume in application logs = 0 จาก log inspection
- real data/provider connection = blocked จนมี owner approval

### Constraints and assumptions

| ID | Type | Statement | Validation |
|---|---|---|---|
| ASM-01 | assumption | PDF ส่วนใหญ่มี text layer | HR owner samples approved aggregate, date TBD |
| CON-01 | constraint | provider ต้องอยู่ใน approved list | Security owner before real-data pilot |
| CON-02 | constraint | retention follows HR policy | Data owner supplies period before Gate D |

## 3. Requirements and Acceptance

| ID | Requirement | Acceptance |
|---|---|---|
| REQ-F-01 | รับ PDF reference ที่อนุญาตและคืน durable task ID | AC-01, AC-02 |
| REQ-F-02 | สร้าง evidence draft ที่แต่ละ claim มี quote/location | AC-04, AC-05 |
| REQ-F-03 | reviewer approve/edit/reject พร้อม audit | AC-06 |
| REQ-NF-01 | application logs ไม่มี raw resume text | AC-07 |
| REQ-NF-02 | event เดิมไม่สร้าง task ใหม่ | AC-03 |
| REQ-NF-03 | accepted task รอด API/worker restart | AC-08 |

### Selected acceptance cases

```text
AC-01 Given valid synthetic searchable PDF <= allowed size
When authorized caller submits a new event_id
Then API returns 202 + stable task_id and persisted state=queued
```

```text
AC-02 Given PDF has no text layer
When submitted
Then state=needs_review reason=TEXT_NOT_FOUND
And model is not called and response is not marked extracted
```

```text
AC-03 Given event_id evt-001 already created task t-001
When same event is replayed concurrently
Then all successful responses identify t-001 and database has one task
```

```text
AC-05 Given model returns a quote not present in normalized source
When evidence validator runs
Then claim is removed/flagged and task cannot become approved automatically
```

## 4. Data and Risk

### Data flow

```text
approved reference → file/text adapter → task store
                  → model adapter → untrusted structured output
                  → schema/evidence/policy validators → review queue
                  → authorized HR reviewer → approved draft/export (future)
```

### Selected risks

| ID | Risk | Controls | Residual/action |
|---|---|---|---|
| RISK-01 | malicious/invalid file | type/size/path allowlist; parser isolation | parser threat review before real data |
| RISK-02 | hallucinated evidence | quote/location required; source validator; eval | human review remains required |
| RISK-03 | unauthorized approval | authenticated role + audit + transition guard | external identity integration TBD |
| RISK-04 | PII leakage via logs/provider | structured redacted logs; approved provider | privacy approval blocks pilot |
| RISK-05 | duplicate event/task | unique key + transaction + concurrency test | monitor conflict/replay count |
| RISK-06 | task lost on crash | durable state + lease/reclaim | backup/restore plan before pilot |

### AI trust rule

Document content and model output are both untrusted. Text inside resume cannot grant tool permission. Only validated fields with source evidence enter the review draft; no model output directly calls ATS/email.

## 5. Architecture and ADR

```text
[HR client]
     ↓ authorized submit/status/review
[FastAPI intake] ──atomic write──> [Task + Audit DB]
                                      ↑ claim/lease/result
                                  [Worker]
                                  /      \
                         [File adapter] [Approved model adapter]
                                  \      /
                              [Validators]
                                      ↓
                               [Review queue]
```

### State machine

```text
queued → processing → needs_review → approved
            │              └──────→ rejected
            ├→ retry_wait → queued
            └→ failed_terminal
```

No transition from raw model output directly to `approved`.

### ADR-01 — Persist before 202

- Context: extraction time/provider latency exceeds reliable HTTP wait
- Decision: insert task + audit in one transaction before returning `202`
- Alternatives: synchronous request; in-memory background task
- Consequence: needs DB/worker, but accepted work survives API restart
- Validate: TEST-05 + DRILL-01

### ADR-02 — Evidence draft, not ranking

- Context: requested outcome is faster evidence gathering; employment decision has higher fairness/governance risk
- Decision: return editable evidence with source location; prohibit rank/reject/hire
- Revisit only with explicit business, legal/privacy, fairness and evaluation review

## 6. Contracts

### Intake request

```json
{
  "event_id": "evt-syn-001",
  "document_ref": "fixture://synthetic/resume-001.pdf"
}
```

`event_id` is unique per intake source. Allowed reference schemes are environment-configured; arbitrary URL/local path is rejected.

### Draft result

```json
{
  "task_id": "task-001",
  "status": "needs_review",
  "candidate_profile": {
    "skills": [
      {
        "name": "Python",
        "quote": "Built Python data validation tools",
        "source_page": 1,
        "supported": true
      }
    ]
  },
  "flags": []
}
```

Missing evidence is not invented; the field is absent/flagged according to schema. `confidence` alone never bypasses evidence validation.

## 7. Implementation Plan

| Task | Outcome | Links | Verification |
|---|---|---|---|
| TASK-01 | synthetic fixtures + baseline | brief | fixture review |
| TASK-02 | validated intake | REQ-F-01/RISK-01 | TEST-01/02 |
| TASK-03 | idempotent transaction | REQ-NF-02/RISK-05 | TEST-03/04 |
| TASK-04 | worker lease/reclaim | REQ-NF-03/RISK-06 | TEST-05/DRILL-01 |
| TASK-05 | model adapter/mock then approved provider | REQ-F-02/RISK-04 | contract tests |
| TASK-06 | schema + evidence validator | REQ-F-02/RISK-02 | TEST-06/09 |
| TASK-07 | review/audit transitions | REQ-F-03/RISK-03 | TEST-10/11 |
| TASK-08 | correlated redacted logs | REQ-NF-01 | TEST-12/log inspect |

First vertical slice uses mock extraction: submit → persist → worker → deterministic draft → review state. It proves state/review before model quality.

## 8. Test and Evaluation Plan

Deterministic tests cover type/size/path, duplicate/concurrent intake, state transitions, lease expiry, crash/restart, authorization and log redaction.

AI evaluation dataset: synthetic versioned resumes with labeled fields/quotes, including missing skill, conflicting dates, long document, Thai/English slices and injection-like text. Metrics: schema pass, field precision/recall, evidence support, abstention and unsupported-claim rate. Prompt/model/dataset/evaluator versions are recorded together.

```text
TEST-09 invented quote
source does not contain “Kubernetes administrator”
model fixture returns that claim
expected: supported=false, flag=UNSUPPORTED_EVIDENCE, no approval/export
```

## 9. Failure and Recovery

| Failure | Safe behavior | Recovery |
|---|---|---|
| provider 429/timeout | retry_wait; no success | bounded backoff, then needs_review |
| worker crashes after claim | lease expires; task visible | another worker reclaims idempotently |
| malformed model JSON | validation failure | retry within budget or review |
| duplicate webhook | same task ID | return duplicate marker |
| no text layer | explicit needs_review | manual/OCR future path |

DRILL-01: kill worker after persisted claim, restart, advance/expire lease safely, verify one logical result and audit attempts.

## 10. Release Readiness Status

This example is **not Gate D ready**. Missing: real identity/authorization integration, approved provider/data processing decision, retention/delete policy, production store backup/restore, load profile, monitoring owner and limited-pilot approval.

Prototype local smoke path:

```text
synthetic fixture → API 202 → durable queued task → worker mock
→ validated draft → needs_review → reviewer transition (planned UI)
```

## 11. Demo and Impact Plan

Demo shows baseline, a supported quote, an invented quote being blocked, duplicate intake returning same task, and restart recovery. It labels model as mock or approved-test provider explicitly.

Impact pilot would compare the same sampled mix. New time includes submit, wait excluded/separated, human review, correction and failure handling. No annual savings claim until representative volume and behavior are observed.

## 12. Handoff

Handoff pack must contain repository/version, setup, config names without secrets, fixtures, test/eval commands, state diagram, log lookup by task ID, replay rules, known limitations, provider/DB owners and runbook. Recipient must complete setup + one failure drill from docs.

### Current decision

Gate C may be claimed only for synthetic/local behaviors with linked evidence. Continue to real-data pilot only after data/privacy/security and operational gaps above receive named approvals.

