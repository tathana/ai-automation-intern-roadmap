# 10 — ตัวอย่างครบวงจร วิธีนำไปใช้ และแหล่งอ่านต่อ

## ตัวอย่าง A: HR Resume Evidence Assistant

เปิด `examples/hr_resume_assistant/FILLED_PROJECT_PACK.md` เพื่อดู artifact ที่กรอกแล้วในเอกสารเดียว และ `TRACEABILITY.csv` เพื่อเห็นการเชื่อม:

```text
pain: HR ใช้เวลาค้น evidence
→ REQ-F-02: extract draft with source quote/location
→ design: worker + approved model adapter + validator
→ TASK-06: evidence validation
→ TEST-09: invented quote must be rejected
→ EVID-04: eval report version v1
```

ตัวอย่างนี้จงใจไม่ auto-rank/reject/hire และใช้ข้อมูลสังเคราะห์ เพราะเป้าหมายคือ decision support ที่ตรวจสอบได้

## ตัวอย่าง B: Daily Report Automation

เปิด `examples/daily_report_automation/FILLED_SMALL_PROJECT.md` เพื่อดูงานที่ใช้ script/scheduler อย่างพอดี ไม่ใช้ queue, microservices หรือ LLM โดยไม่มีเหตุผล

```text
approved CSV → validate → aggregate → render draft → human sends
```

บทเรียนสำคัญคือ Template เดียวกันต้อง **ย่อได้** ตามความเสี่ยง ไม่ใช่บังคับ architecture แบบเดียว

## วิธี Copy ไปใช้

```powershell
Copy-Item -Recurse '.\template_pack' '.\docs\delivery'
```

จากนั้นลบเฉพาะ template ที่ตัดสินใจแล้วว่าไม่จำเป็น และบันทึกเหตุผลสั้น ๆ ใน Master Checklist อย่า copy filled example แล้วเปลี่ยนชื่อโดยไม่ตรวจ assumptions

## แหล่งอ่านต่อที่คัดตามงาน

| เมื่อกำลังทำ | แหล่งหลัก | อ่านเรื่อง |
|---|---|---|
| Requirement/API | [OpenAPI Specification](https://spec.openapis.org/oas/latest.html) | contract ที่เครื่องมืออ่านได้ |
| Architecture diagram | [C4 Model](https://c4model.com/) | context/container/component/code |
| Python packaging | [Python Packaging User Guide](https://packaging.python.org/) | environment, dependency, project layout |
| FastAPI/Pydantic | [FastAPI](https://fastapi.tiangolo.com/) / [Pydantic](https://docs.pydantic.dev/) | validation และ API contracts |
| Workflow | [n8n Documentation](https://docs.n8n.io/) | executions, error handling, credentials |
| Container | [Docker Documentation](https://docs.docker.com/) | images, Compose, networking, storage |
| Tests | [pytest Documentation](https://docs.pytest.org/) | fixtures, parametrization, test discovery |
| Web/API security | [OWASP API Security](https://owasp.org/www-project-api-security/) | authorization, input, resources |
| AI risk | [NIST AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) | govern/map/measure/manage |
| LLM threats | [OWASP GenAI Security](https://genai.owasp.org/) | prompt injection, output handling, data risks |
| Observability | [OpenTelemetry Documentation](https://opentelemetry.io/docs/) | traces, metrics, logs, context propagation |
| Reliability/incident | [Google SRE Books](https://sre.google/books/) | SLO, monitoring, incident/postmortem |
| Git collaboration | [GitHub Docs](https://docs.github.com/en/pull-requests) | branches, pull requests, reviews |

ลิงก์เหล่านี้เป็นจุดเริ่มจากเอกสารทางการ แต่ policy, deployment, security และ data retention ของบริษัทมีลำดับสูงกว่า textbook เสมอ

## Definition of Done ของ Project Pack

- ไม่มี placeholder สำคัญที่ไม่ระบุ owner/date
- requirement สำคัญเชื่อมกับ design/task/test/evidence
- diagrams และ contracts ตรงกับ version ที่ส่ง
- risk/privacy/security มีผู้อนุมัติตามบริบท
- verification commands ทำซ้ำได้
- rollback/recovery ไม่อาศัยผู้เขียนคนเดียว
- filled example/test data ไม่มีข้อมูลจริงหรือ secret

