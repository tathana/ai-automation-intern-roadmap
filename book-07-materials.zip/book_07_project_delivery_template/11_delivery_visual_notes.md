# 11 — Visual Notes: รับงานจนถึง Handoff

## Phase Gates

<div class="visual-board"><div class="visual-flow"><div class="visual-box">A Problem<br><small>baseline/scope</small></div><span class="visual-arrow">→</span><div class="visual-box">B Design<br><small>contract/risk</small></div><span class="visual-arrow">→</span><div class="visual-box">C Verified<br><small>test/eval</small></div><span class="visual-arrow">→</span><div class="visual-box">D Release<br><small>monitor/rollback</small></div><span class="visual-arrow">→</span><div class="visual-box">E Transfer<br><small>runbook/rehearsal</small></div></div></div>

## Traceability

<div class="visual-board"><div class="visual-flow"><div class="visual-box"><code>REQ-F-02</code></div><span class="visual-arrow">→</span><div class="visual-box"><code>ADR-01</code></div><span class="visual-arrow">→</span><div class="visual-box"><code>TASK-06</code></div><span class="visual-arrow">→</span><div class="visual-box"><code>TEST-09</code></div><span class="visual-arrow">→</span><div class="visual-box"><code>EVID-04</code></div></div></div>

## Before / After ที่วัดอย่างตรงไปตรงมา

<div class="visual-board"><div class="visual-grid"><div class="visual-pane"><div class="visual-label">BEFORE</div><p>read + copy + verify + rework</p></div><div class="visual-pane"><div class="visual-label">AFTER</div><p>submit + review + correct + recover failures</p></div><div class="visual-pane"><div class="visual-label">COMPARE</div><p>same case mix · median/p90 · quality guardrails</p></div></div></div>

## Handoff

<div class="visual-board"><div class="visual-grid"><div class="visual-pane"><div class="visual-label">README</div><p>developer setup/run/test</p></div><div class="visual-pane"><div class="visual-label">RUNBOOK</div><p>operator health/replay/rollback</p></div><div class="visual-pane"><div class="visual-label">REHEARSAL</div><p>ผู้รับมอบทำได้จาก docs จริง</p></div></div></div>

