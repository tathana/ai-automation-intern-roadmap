# 15 — From Requirement to Code: เปิด Editor แล้วทำอะไรก่อน

บทนี้เชื่อม “สิ่งที่ผู้ใช้ต้องการ” ไปยัง “ไฟล์และฟังก์ชันที่ต้องเขียน” โดยไม่กระโดดไปสร้างระบบทั้งก้อน

## เริ่มจาก Contract ไม่ใช่ Framework

สมมติ requirement คือ:

> เมื่อรับข้อความ Resume ระบบต้องคืน candidate ID, skills และ evidence quote โดย quote ต้องพบในข้อความต้นฉบับ

ก่อนเปิด FastAPI หรือ n8n ให้เขียนรูปร่างข้อมูลก่อน:

```python
from pydantic import BaseModel


class ResumeInput(BaseModel):
    candidate_id: str
    text: str


class Evidence(BaseModel):
    skill: str
    quote: str
    supported: bool
```

นี่คือ **data contract**: ข้อตกลงว่าข้อมูลเข้าและออกมี field/type อะไร ทำให้คนและระบบส่วนอื่นคุยกันด้วยรูปแบบเดียวกัน

## ลำดับการเขียนที่ลดความงง

```text
1. ตัวอย่าง input/output
2. Model และ validation
3. Pure function ของกฎหลัก
4. Unit test ของกฎหลัก
5. Repository หรือ database
6. Service/use case ที่ประสานงาน
7. API/CLI/worker เป็นทางเข้า
8. Integration test
```

เริ่มแก่นกลางก่อนเพราะแก้และ test ง่ายกว่าเริ่มจากหน้า API ที่ผูกหลายอย่างพร้อมกัน

## Pure Function แรก

ฟังก์ชันตรวจ quote ไม่จำเป็นต้องรู้จัก HTTP, database หรือ AI provider:

```python
def is_supported_quote(source_text: str, quote: str) -> bool:
    normalized_source = " ".join(source_text.lower().split())
    normalized_quote = " ".join(quote.lower().split())
    return bool(normalized_quote) and normalized_quote in normalized_source
```

อ่านทีละขั้น:

```text
รับ source_text + quote
        ↓
ลดตัวพิมพ์และช่องว่างที่ต่างกัน
        ↓
quote ว่างหรือไม่
        ↓
ค้น quote ใน source
        ↓
คืน True / False
```

เพราะไม่มี side effect เราจึงเรียกด้วย input เดิมแล้วคาดผลเดิมได้ ทำให้ unit test ง่าย

## Function Design Card

ก่อนสร้างฟังก์ชันที่เริ่มซับซ้อน ให้ตอบ:

```markdown
Function: validate_evidence
Responsibility: ตรวจ evidence หนึ่งรายการเท่านั้น
Input: source_text: str, evidence: Evidence
Output: Evidence ที่กำหนด supported แล้ว
Side effect: ไม่มี
Failure: input ไม่ตรง model ถูกปฏิเสธก่อนถึงฟังก์ชัน
Example: source="Used Python" + quote="Python" → supported=True
```

หากช่อง Responsibility มีคำว่า “และ” หลายครั้ง เช่น “อ่านไฟล์ และเรียก AI และบันทึก DB และส่งอีเมล” นั่นเป็นสัญญาณว่าควรแบ่งฟังก์ชัน

## โครงสร้างโปรเจกต์เริ่มต้น

```text
project/
├─ README.md
├─ pyproject.toml
├─ .env.example
├─ src/
│  └─ app/
│     ├─ models.py       # รูปร่างข้อมูล
│     ├─ rules.py        # pure business rules
│     ├─ repository.py   # อ่าน/เขียน state
│     ├─ services.py     # ลำดับ use case
│     ├─ api.py          # HTTP boundary
│     └─ settings.py     # config จาก environment
└─ tests/
   ├─ test_rules.py
   ├─ test_services.py
   └─ test_api.py
```

นี่เป็นจุดเริ่ม ไม่ใช่กฎตายตัว โปรเจกต์เล็กมากอาจรวมไฟล์ได้ แต่ควรแยกเมื่อเหตุผลในการเปลี่ยนต่างกัน เช่น business rule ไม่ควรต้องแก้เพราะเปลี่ยน database

## Service ทำหน้าที่ประสาน ไม่ทำทุกอย่างเอง

```python
def create_evidence_task(payload, repository, provider):
    existing = repository.find_by_event_id(payload.event_id)
    if existing:
        return existing

    draft = provider.extract(payload.text)
    checked = validate_all(payload.text, draft)
    return repository.save(payload.event_id, checked)
```

ตัวแปร `repository` และ `provider` ถูกส่งเข้ามา ทำให้ test สามารถใช้ fake/mock แทน database และ external AI จริงได้ แนวคิดนี้เรียกว่า **dependency injection**

## แบ่งงานเป็น Vertical Slice

แทนที่จะทำ models ทั้งหมดก่อนสามวัน ให้เลือก flow เล็ก:

```text
POST /tasks
  → validate payload
  → save task
  → GET /tasks/{id} เห็นสถานะ queued
```

เมื่อผ่านจึงเพิ่ม worker/provider ใน Slice ถัดไป วิธีนี้ทำให้มีของสาธิตเร็วและพบปัญหาระหว่าง layer ตั้งแต่ต้น

## เมื่อใดถือว่าฟังก์ชันหนึ่งเสร็จ

- ชื่อสื่อหน้าที่เดียว
- input/output ชัด
- จัดการกรณีผิดตาม contract
- มี test ของอย่างน้อย happy path และ edge/failure สำคัญ
- ไม่มี secret/PII ใน log
- ผู้อ่านอธิบายได้ว่าทำไมโค้ดจึงอยู่ layer นี้

