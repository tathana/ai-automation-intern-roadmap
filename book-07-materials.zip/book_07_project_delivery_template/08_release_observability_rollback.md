# 08 — Release, Migration, Observability และ Rollback

## “Container เปิด” ไม่เท่ากับ “ระบบพร้อม”

```text
process running → liveness
dependencies/config ready → readiness
user journey works → smoke test
quality/risk gates pass → release ready
```

Release checklist ต้องระบุ environment, version/commit, config names, secret source, migrations, backup, health/smoke, dashboards/alerts, rollback และ owner

## Configuration และ Secrets

validate config ตอน startup; `.env.example` มีชื่อ/ตัวอย่างที่ไม่ลับ; production secrets มาจากช่องทางที่ทีมอนุญาต ไม่ log token และไม่ฝังค่า environment-specific ใน image

## Migration

ทุก schema change ต้องตอบ forward, backward compatibility, data backfill, lock/downtime, verification และ rollback/roll-forward บาง migration rollback ไม่ปลอดภัย จึงต้องทดสอบ restore หรือใช้ expand-contract

## Observability จาก User Journey

ใช้ correlation/task ID เชื่อม:

```text
request_id → task_id → attempt_id → review_id → export_id
```

Log เป็น event ที่ค้นสาเหตุได้, metric บอกแนวโน้ม/alert, trace แสดง latency ข้าม component ห้ามใส่ raw resume/prompt โดยไม่จำเป็น

Metrics ตัวอย่าง:

- intake success/error by category
- queue depth และ oldest age
- attempt/retry/exhausted count
- review turnaround และ correction rate
- unsupported-claim rate จาก sample
- export failures/duplicates

## Rollout

เริ่ม synthetic/local → staging → shadow/dry-run → limited pilot → wider rollout การใช้ feature flag หรือปิด side effect ช่วยแยก “เห็นผล” ออกจาก “ส่งผลจริง”

## Rollback

เขียน trigger, authority, exact steps, data consequence และ verification ห้ามใช้ “redeploy เวอร์ชันก่อน” หาก schema/event side effect ไม่ย้อนตาม

## Incident Flow

```text
detect → contain → preserve evidence → communicate → recover
      → verify → learn/postmortem → follow-up owner/date
```

### Gate D ตรวจผ่านเมื่อ

คนที่ on-call/รับมอบรู้วิธีดูสถานะ หยุดผลกระทบ ตรวจ version/config/state และ rollback/roll-forward โดยไม่ต้องเดาจากความจำผู้พัฒนา

