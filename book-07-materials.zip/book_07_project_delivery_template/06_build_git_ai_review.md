# 06 — Build, Git Workflow และตรวจงานที่ AI ช่วยสร้าง

## วงจรงานย่อย

```text
เลือก TASK → อ่าน linked requirement/test → ทำ change เล็ก
→ รัน focused test → inspect diff → self-review → commit/PR → feedback
```

เริ่มจาก expected behavior ก่อน prompt AI มิฉะนั้นเราจะตรวจเพียงว่า code “ดูสมเหตุผล” ไม่ใช่ตรง contract

## ก่อนแก้

```powershell
git status
git branch --show-current
python -m pytest tests/unit -q
```

บันทึก baseline ถ้า test เดิมเสีย เพื่อไม่อ้างว่า change ใหม่เป็นสาเหตุทั้งหมด

## หลังแก้

```powershell
git diff --check
git diff
python -m pytest -q
git status
```

อ่าน diff ทีละไฟล์: ทำไมเปลี่ยน, มี unrelated change หรือ secret หรือไม่, error path/test/docs ถูกเปลี่ยนตาม contract หรือยัง

## AI-assisted Coding Contract

ให้ AI ได้เฉพาะ context ที่ได้รับอนุญาต ระบุ constraints/test/output และขอ change เล็ก อย่า paste secrets, PII หรือ proprietary code ไปยังบริการที่ทีมไม่อนุญาต

ตรวจสิ่งที่ AI มักเดา:

- package/API version
- file/path/function ที่ไม่มีจริง
- happy path โดยไม่มี timeout/error/idempotency
- permission กว้างเกินจำเป็น
- test ที่ mock จนไม่ตรวจ behavior
- log raw payload

## Pull Request ที่ Reviewer ใช้งานได้

```text
Why: linked problem/requirement
What: behavior changed and not changed
How to verify: exact commands + expected result
Risk: data/state/security/compatibility
Evidence: test/eval/demo link
Rollback: safe reversal path
```

## Definition of Done

Done ไม่ใช่ “code รันได้ในเครื่องผม” อย่างน้อยต้องผ่าน acceptance ที่เกี่ยวข้อง, tests, lint/type ตามทีม, docs/config example, observability, review และไม่มี secret

### Gate C ตรวจผ่านเมื่อ

ผู้เขียนอธิบาย diff ได้เอง รัน verification จาก clean setup ได้ และ reviewer เชื่อม change กลับไปยัง requirement/risk ได้

