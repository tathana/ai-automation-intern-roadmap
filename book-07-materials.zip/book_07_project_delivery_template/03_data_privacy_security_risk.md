# 03 — Data Inventory, Privacy, Security และ Risk Register

## วาด Data Journey ก่อนเลือกเครื่องมือ

```text
Source → ingest → temporary storage → processing/provider
      → result → human review → downstream/export → retention/delete
```

ทุกลูกศรคือ boundary ที่ข้อมูลอาจถูกเปิดเผย เปลี่ยนรูป สูญหาย หรือถูกใช้เกินวัตถุประสงค์

## Data Inventory

สำหรับแต่ละ field/ไฟล์ บันทึก source, owner, classification, purpose, storage, retention, access, export และ deletion ไม่ใช้คำว่า “ข้อมูลผู้ใช้” กว้าง ๆ

| Data | Class | Need | Stored where | Retention | Access |
|---|---|---|---|---|---|
| synthetic resume | test | eval | repo fixture | project | developers |
| real resume | restricted/PII | pilot | approved store | policy | HR role |
| extracted evidence | sensitive derived | review | task DB | policy | HR/reviewer |

Derived data อาจยัง sensitive แม้ไม่ใช่ไฟล์ต้นฉบับ

## Trust Boundary

ผู้ใช้, browser, API, workflow, database, model provider และ downstream system ไม่ควรถูกถือว่าไว้ใจกันโดยอัตโนมัติ ที่ boundary ให้ถาม authentication, authorization, validation, encryption, audit และ failure behavior

## AI-specific Risks

- prompt injection จากเอกสารไม่ใช่คำสั่งที่เชื่อถือได้
- hallucinated field/quote ต้องถูก validate กับ source
- model output เป็น untrusted input ก่อนผ่าน schema/business rules
- ranking/explanation อาจมี bias และไม่ควรกลายเป็นการตัดสินอัตโนมัติโดยไม่อนุมัติ
- prompt/log อาจเปิดเผย PII

```text
Document text (untrusted)
  ↓ delimit + instruct as data
LLM output (untrusted)
  ↓ schema + evidence + policy validation
Draft
  ↓ authorized human review
Approved result
```

## Risk Register ที่ใช้งานได้

Risk ไม่ใช่รายการความกลัว แต่ต้องมี trigger, likelihood, impact, control, residual risk, owner และ review date

```text
RISK-02: unsupported evidence ถูก reviewer เชื่อ
Prevent: require verbatim quote + source location
Detect: validator + sampled eval
Respond: needs_review; disable export
Owner: AI engineer + HR SME
```

## Security Questions ก่อน Build

- ใครเรียก endpoint/เปิด workflow ได้
- ใครดู task ของคนอื่นได้
- URL/file path ถูกจำกัดอย่างไร
- secrets มาจากไหนและ rotate อย่างไร
- logs, backups และ exports มี PII หรือไม่
- side effect ไหนต้อง approval/idempotency
- dependency/provider failure ทำให้ข้อมูลค้างที่ไหน

### Gate B ตรวจผ่านเมื่อ

มี data owner, classification, allowed environment, retention, access control, risk owner และ stop condition สำหรับความเสี่ยงสำคัญ ห้ามใช้ข้อมูลจริงเพื่อ “ลองก่อน” หากยังไม่ผ่าน

