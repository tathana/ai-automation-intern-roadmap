# Book 07 — Project Delivery Template Book

เล่มนี้คือชุดทำงานสำเร็จรูปสำหรับเปลี่ยนโจทย์ที่ยังคลุมเครือให้เป็นงานที่ตรวจสอบและส่งมอบได้ ตั้งแต่รับงาน วิเคราะห์กระบวนการ เขียน requirement ออกแบบระบบ แบ่งงาน พัฒนา ทดสอบ เปิดใช้ วัดผล จนถึง handoff

> เป้าหมายไม่ใช่สร้างเอกสารให้เยอะ แต่ทำให้การตัดสินใจสำคัญไม่หาย และให้ Requirement → Design → Code → Test → Evidence เชื่อมถึงกัน

## เลือกทางอ่าน

**ทางลัด 45 นาที:** อ่านบท 00 → เปิด `template_pack/00_master_checklist.md` → ดู `examples/hr_resume_assistant/FILLED_PROJECT_PACK.md` → คัดลอกเฉพาะ template ที่ต้องใช้

**ทางทำงานจริง:** เดินบท 00–10 ตาม phase gate และเติมเอกสารทีละชิ้น อย่ากรอกทุกไฟล์ล่วงหน้าโดยยังไม่ได้คุยกับผู้ใช้

```text
รับโจทย์ → เข้าใจงานเดิม → ตกลง scope/criteria → สำรวจ data/risk
       → ออกแบบ contracts/system → แบ่ง vertical slice → build/review
       → verify/evaluate → release/observe → demo/measure/handoff
```

## บทเรียน

| บท | สิ่งที่ทำเสร็จ |
|---|---|
| 00 | เลือก workflow และระดับเอกสารให้พอดีกับความเสี่ยง |
| 01 | Intake, stakeholder questions และ current-state map |
| 02 | Scope, requirements, acceptance criteria และ traceability |
| 03 | Data inventory, privacy, security และ risk register |
| 04 | Architecture diagrams, boundaries, state และ ADR |
| 05 | Project structure, contracts และ implementation plan |
| 06 | Git/AI-assisted build, review และ Definition of Done |
| 07 | Tests, failure matrix และ AI evaluation |
| 08 | Release, migration, rollback และ observability |
| 09 | Demo, impact measurement, runbook และ handoff |
| 10 | ตัวอย่างครบวงจรและแหล่งอ่านต่อ |

## สิ่งที่ดาวน์โหลดได้

ZIP ของเล่มมี `template_pack/` สำหรับคัดลอกไปโปรเจกต์ และ `examples/` สองแบบ:

- **HR Resume Evidence Assistant:** งาน AI ที่มี PII, human review และข้อห้าม auto-reject
- **Daily Report Automation:** งาน automation ขนาดเล็กที่แสดงว่ากระบวนการนี้ใช้ได้โดยไม่ต้องสร้าง architecture ใหญ่

ข้อมูลตัวอย่างทั้งหมดเป็นข้อมูลสังเคราะห์ ห้ามนำชื่อ บุคคล เอกสาร หรือ secrets ของบริษัทไปใส่ในเครื่องมือที่ยังไม่ได้รับอนุญาต

## กติกา Traceability

ใช้รหัสคงที่ เช่น `REQ-01`, `RISK-02`, `ADR-01`, `TEST-03` และเชื่อมไว้ในตาราง:

```text
REQ-01 → component: intake API → TASK-02 → TEST-04 → EVIDENCE-03
```

ถ้าหาความเชื่อมโยงนี้ไม่ได้ งานอาจถูกสร้างโดยไม่มีเหตุผล หรือ requirement อาจยังไม่มีหลักฐานว่าผ่าน

