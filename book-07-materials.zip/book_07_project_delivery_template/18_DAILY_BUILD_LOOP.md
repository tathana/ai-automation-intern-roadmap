# 18 — Daily Build Loop: วงจรทำงานหนึ่งก้อนต่อวัน

เมื่อโปรเจกต์ใหญ่ ให้ลดมุมมองเหลือ “วันนี้จะทำ behavior เล็กใดให้พิสูจน์ได้” แล้วใช้วงจรเดิมซ้ำ

## วงจร 10 ขั้น

```text
1 อ่าน task + acceptance
2 เลือก behavior เดียว
3 เขียน/แก้ test ให้แสดงสิ่งที่ต้องการ
4 ออกแบบ function contract
5 เขียน implementation เล็กสุด
6 รัน focused test
7 รัน test ที่เกี่ยวข้องทั้งหมด
8 อ่าน diff และตรวจ secret/PII
9 อัปเดต docs/decision ถ้าจำเป็น
10 commit ที่อธิบายเหตุผลได้
```

## ตัวอย่างหนึ่งรอบ

เป้าหมาย: event เดิมต้องไม่สร้าง task ซ้ำ

```text
AC-03 duplicate event → same task ID
        ↓
เขียน integration test ที่ส่ง event เดิม 2 รอบ
        ↓
เพิ่ม unique constraint + find-before-create
        ↓
รัน test_idempotency.py
        ↓
ตรวจ DB count = 1
        ↓
commit: feat: make intake idempotent
```

งานก้อนนี้มี requirement, code, test และ evidence เชื่อมกัน จึง review ง่ายกว่า commit “update backend” ที่เปลี่ยนหลาย behavior

## จุดที่ให้ AI ช่วยในวงจร

- ก่อนเขียน: ช่วยหาคำถามหรือ edge cases ที่เราลืม
- ระหว่างออกแบบ: เปรียบเทียบสองทางเลือกและ trade-off
- ระหว่างเขียน: ร่างฟังก์ชัน/fixture/test ก้อนเล็ก
- เมื่อติด: ช่วยตั้งสมมติฐานจาก error และหลักฐาน
- ก่อน commit: review diff เทียบ acceptance criteria

AI ไม่ควรเป็นคนตัดสินว่า requirement ถูกต้องแทน stakeholder หรือกดข้าม test เพราะคำตอบ “ดูน่าจะใช้ได้”

## คำสั่งขั้นต่ำที่ใช้บ่อย

```powershell
git status
git diff
pytest tests/test_idempotency.py -q
pytest -q
git diff --check
git add <เฉพาะไฟล์ที่ตรวจแล้ว>
git commit -m "feat: make intake idempotent"
```

`focused test` ให้ feedback เร็วระหว่างทำ ส่วน `full relevant suite` ช่วยตรวจว่าไม่ได้ทำ behavior อื่นพัง ทั้งสองมีหน้าที่ต่างกัน

## End-of-day Note

ก่อนหยุด ให้เขียนสั้น ๆ:

```markdown
Done: AC-03 duplicate event ผ่านบน SQLite test DB
Evidence: pytest tests/test_idempotency.py -q → 3 passed
Decision: ใช้ event_id เป็น business idempotency key
Next: ทดลอง crash หลัง provider สำเร็จแต่ก่อน save result
Blocked: ต้องถาม retention policy ของ raw document
```

ข้อความนี้ช่วยให้วันถัดไปเริ่มต่อได้ทันที และทำให้หัวหน้ามองเห็นความคืบหน้า ความเสี่ยง และคำถามโดยไม่ต้องอ่านโค้ดทั้งหมด

