# 01 — รับโจทย์, Discovery และ Baseline

## แปลคำขอให้เป็นปัญหาที่ตรวจได้

ผู้ใช้อาจเริ่มว่า “อยากใช้ AI อ่าน resume” นี่คือ solution idea ไม่ใช่ problem definition ให้ถามต่อว่าใครทำอะไร ช่วงไหนช้า output ถูกใช้ต่ออย่างไร และผิดแบบไหนอันตราย

```text
คำขอ: ใช้ AI อ่าน resume
  ↓ ถามงานปัจจุบัน
HR เปิด PDF → หา evidence → จดลง sheet → ส่ง reviewer
  ↓ วัด
เฉลี่ย 7 นาที/ไฟล์, 1,000 ไฟล์, ต้องย้อนหา quote บ่อย
  ↓ เป้าหมายที่ปลอดภัย
สร้าง evidence draft พร้อมตำแหน่งอ้างอิง ให้คนตรวจเร็วขึ้น
```

## Stakeholder Map

แยกบทบาทให้ชัด:

- **User:** คนทำงานกับระบบทุกวัน
- **Sponsor/Owner:** คนตัดสิน scope/priority
- **Subject-matter expert:** คนตัดสินว่าผลถูกทางธุรกิจหรือไม่
- **Technical owner:** คนรับระบบหลังส่งมอบ
- **Risk approver:** Security, Legal, Privacy หรือผู้มีอำนาจตามบริบท

คนเดียวอาจมีหลายบทบาท แต่ชื่อ “ทีม HR” กว้างเกินไปสำหรับ decision log

## คำถาม Discovery ที่ให้หลักฐาน

แทนที่จะถาม “อยากได้ feature อะไร” ให้ถาม:

- ช่วยทำรายการจริงหนึ่งรายการให้ดูตั้งแต่ต้นจนจบได้ไหม
- จุดใดใช้เวลาคนลงมือ จุดใดเป็นเวลารอ
- input ที่แย่ที่สุดหน้าตาอย่างไร
- output ถูกนำไปตัดสินใจหรือส่งระบบใดต่อ
- วันนี้เมื่อข้อมูลขาด/ซ้ำ/อ่านไม่ได้ทำอย่างไร
- ใครตรวจว่าผลถูก และตรวจจากหลักฐานอะไร
- ถ้าระบบหยุดหนึ่งวัน ผลกระทบคืออะไร

## Current-State Map

บันทึก actor, action, system, data และเวลาคร่าว ๆ:

| Step | Actor | Input → Output | Active/Wait time | Failure |
|---|---|---|---|---|
| 1 | HR | mailbox → PDF | 30s | attachment หาย |
| 2 | HR | PDF → notes | 5m | scanned PDF |
| 3 | Reviewer | notes → decision support | 2m | quote ตามไม่พบ |

การแยก **active time** กับ **wait time** ป้องกันการอ้างว่าลดเวลาคนทั้งที่ลดเพียง latency ระบบ

## Baseline ที่เทียบได้

กำหนดจุดเริ่ม/จบ ชุดตัวอย่าง และเงื่อนไขเดียวกัน:

```text
Start: HR เปิดไฟล์
End: evidence note พร้อมให้ reviewer ตรวจ
Sample: synthetic/searchable 30 ไฟล์ แบ่งสั้น/ยาว/ข้อมูลขาด
Measure: median, p90, correction count, unprocessable count
```

ค่าเฉลี่ยอย่างเดียวซ่อนงานยาก จึงเก็บ distribution หรืออย่างน้อย median/p90 และแบ่งประเภทเอกสาร

## Output ของบทนี้

- `01_project_intake.md`
- `02_stakeholder_questions.md`
- `03_current_state_and_baseline.md`
- รายการ unknown พร้อม owner/date ที่จะตอบ

### Gate A ตรวจผ่านเมื่อ

ผู้ใช้และ owner ทวนกลับได้ตรงกันว่า pain อยู่ที่ใด เป้าหมายคืออะไร จะวัดจากอะไร และข้อใดไม่ใช่งานรอบนี้

