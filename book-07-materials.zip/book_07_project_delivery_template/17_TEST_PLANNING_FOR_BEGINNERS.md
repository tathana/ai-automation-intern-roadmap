# 17 — Test Planning for Beginners: ต้องทดสอบอะไรบ้าง

Test ไม่ได้มีไว้พิสูจน์ว่า “โค้ดไม่มี bug” แต่เป็นหลักฐานว่า behavior สำคัญที่เราระบุไว้ยังทำงาน และช่วยเตือนเมื่อการแก้ครั้งใหม่ทำของเดิมเสีย

## เปลี่ยน Acceptance Criteria เป็น Test

```text
Requirement
  ↓ เขียนตัวอย่าง Given–When–Then
Acceptance criterion
  ↓ เลือกระดับที่ตรวจได้เร็วที่สุด
Test
  ↓ เก็บผลการรัน
Evidence
```

ตัวอย่าง:

```python
def test_quote_found_in_source_is_supported():
    assert is_supported_quote("Used Python daily", "Python") is True


def test_empty_quote_is_not_supported():
    assert is_supported_quote("Used Python daily", "") is False
```

ชื่อ test ควรบอกสถานการณ์และผลที่คาด อ่านแล้วเข้าใจ contract ได้โดยไม่ต้องเปิด implementation ก่อน

## สี่ระดับที่ควรรู้

| ระดับ | ตรวจอะไร | ตัวอย่าง |
|---|---|---|
| Unit | ฟังก์ชัน/กฎเล็กแบบแยกส่วน | quote validator |
| Component | module หรือ service กับ fake dependency | service + fake provider |
| Integration | หลายส่วนจริงคุยกัน | API + SQLite |
| End-to-end | เส้นทางผู้ใช้ตั้งแต่ต้นจนจบ | upload → process → review |

ไม่จำเป็นต้องทำทุกกรณีเป็น end-to-end เพราะช้าและหาสาเหตุยาก กฎย่อยควรมี unit test ส่วน boundary สำคัญจึงเสริม integration

## ชุดคำถามสร้าง Test Matrix

สำหรับแต่ละ flow ให้ถาม:

1. **Happy path:** ข้อมูลถูกต้องแล้วได้อะไร
2. **Boundary:** ค่าว่าง เล็กสุด ใหญ่สุด หรือหมดเวลาจะเกิดอะไร
3. **Invalid input:** field หาย type ผิด format ผิดถูกปฏิเสธอย่างไร
4. **Duplicate:** request/event เดิมเข้าซ้ำแล้วข้อมูลหรือ side effect ซ้ำหรือไม่
5. **Dependency failure:** database/provider/email ล่มหรือช้าแล้ว state อยู่ไหน
6. **Crash recovery:** process หยุดหลังทำครึ่งหนึ่งแล้วเริ่มใหม่ได้หรือไม่
7. **Permission:** ผู้ใช้ที่ไม่มีสิทธิ์ทำสิ่งนี้ได้หรือไม่
8. **Privacy:** log/error/response เปิดเผยข้อมูลเกินจำเป็นหรือไม่

## ตาราง Test Plan ขนาดเล็ก

| ID | Behavior | Level | Fixture | Expected | Evidence |
|---|---|---|---|---|---|
| T-01 | quote จริงได้รับการยืนยัน | unit | source+quote | `True` | pytest report |
| T-02 | quote ปลอมถูก block | component | fake provider | `needs_review` | result record |
| T-03 | event ซ้ำไม่สร้าง task ซ้ำ | integration | SQLite temp DB | same task ID | DB count |
| T-04 | worker crash คืนงานเข้า queue | integration | short lease | task retried | state history |

## Mock อย่างไรไม่ให้ Test หลอกเรา

Mock ใช้แทน dependency ที่ช้า แพง หรือควบคุมไม่ได้ เช่น LLM API แต่ไม่ควร mock สิ่งที่ test ตั้งใจพิสูจน์

```text
ถ้าต้องพิสูจน์ business rule → ใช้ input จริงกับ rule จริง
ถ้าต้องพิสูจน์ SQL → ใช้ database test จริง
ถ้าต้องพิสูจน์ provider failure handling → fake provider ที่ตั้งให้ timeout
```

Test ที่ mock database, service และ provider ทั้งหมดอาจพิสูจน์เพียงว่า mock คืนค่าตามที่เราสั่ง

## AI System ต้องมี Evaluation เพิ่ม

Software test ตรวจ contract ที่แน่นอน ส่วน AI evaluation ตรวจคุณภาพที่อาจแปรผัน:

- evidence grounded หรือไม่
- field extraction ถูกต้องเพียงใด
- unsupported claim ถูก block เท่าไร
- human reviewer ต้องแก้มากเพียงใด
- latency/cost อยู่ในขอบเขตหรือไม่

ใช้ dataset สังเคราะห์หรือข้อมูลที่ได้รับอนุญาต เก็บ prompt/model/version/rubric เพื่อให้เปรียบเทียบรอบใหม่ได้

## ก่อนบอกว่า Test ผ่าน

- รันคำสั่งจาก clean environment ได้
- test ล้มจริงเมื่อจงใจทำ behavior ให้ผิด
- ไม่มี test ที่ขึ้นกับลำดับหรือข้อมูลค้างจากรอบก่อน
- failure สำคัญจาก risk register มี test หรือ manual procedure รองรับ
- บันทึก command, environment และผลที่ใช้เป็น evidence

