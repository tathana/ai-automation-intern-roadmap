# 17 — Test Planning for Beginners: ต้องทดสอบอะไรบ้าง

Test ไม่ได้มีไว้พิสูจน์ว่า “โค้ดไม่มี bug” แต่เป็นหลักฐานว่า behavior สำคัญที่เราระบุไว้ยังทำงาน และช่วยเตือนเมื่อการแก้ครั้งใหม่ทำของเดิมเสีย

## เปลี่ยน Acceptance Criteria เป็น Test

```text
Requirement
  ↓ เขียนตัวอย่าง Given–When–Then
Acceptance criterion
  ↓ เลือกระดับที่ตรวจได้เร็วที่สุด
Test
  ↓ เก็บผลการรัน
Evidence
```

ตัวอย่าง:

```python
def test_quote_found_in_source_is_supported():
    assert is_supported_quote("Used Python daily", "Python") is True


def test_empty_quote_is_not_supported():
    assert is_supported_quote("Used Python daily", "") is False
```

ชื่อ test ควรบอกสถานการณ์และผลที่คาด อ่านแล้วเข้าใจ contract ได้โดยไม่ต้องเปิด implementation ก่อน

## Manual Check ก่อนเขียน Pytest

ก่อนมี test file เราสามารถเรียกฟังก์ชันด้วย input เล็ก ๆ จาก Terminal เพื่อยืนยัน mental model วิธีนี้เรียกว่า **manual check** หรือการทดลองด้วยมือ ยังไม่ใช่ automated test เพราะต้องมีคนรันและอ่านผลเอง

สมมติมี `document_reader.py`:

```python
def read_txt(content: bytes) -> str:
    text = content.decode("utf-8-sig")
    if not text.strip():
        raise ValueError("NO_EXTRACTABLE_TEXT")
    return text
```

ตรวจ happy path ด้วยคำสั่งสั้น:

```powershell
python -c "from document_reader import read_txt; print(read_txt(b'Python and SQL'))"
```

`python -c` ให้ Python รันโค้ดที่อยู่ในข้อความโดยไม่ต้องสร้าง script เพิ่ม ผลที่คาดคือ `Python and SQL`

ตรวจ failure path โดยส่ง bytes ว่าง:

```powershell
python -c "from document_reader import read_txt; read_txt(b'')"
```

ผลที่ตั้งใจให้เกิด:

```text
Traceback (most recent call last):
  ...
  raise ValueError("NO_EXTRACTABLE_TEXT")
ValueError: NO_EXTRACTABLE_TEXT
```

นี่คือ **expected failure**: โปรแกรมเกิด exception ตรงตาม contract จึงถือว่าการทดลองกรณีนี้ผ่าน อ่าน traceback จากบรรทัดล่างขึ้นบนก่อน:

```text
ValueError                    → ประเภท exception
NO_EXTRACTABLE_TEXT           → รหัส/ข้อความสาเหตุ
document_reader.py, line ...  → ตำแหน่งที่ raise
<string>, line 1              → คำสั่ง python -c ที่เรียกฟังก์ชัน
```

```text
input b''
  ↓ decode เป็นข้อความว่าง
strip แล้วยังว่าง
  ↓
raise ValueError
  ↓
Terminal แสดง traceback ที่เราคาดไว้
```

อย่าสรุปว่า “เห็น traceback = test ผ่าน” ทุกกรณี ต้องกำหนด expected result ก่อนรัน หากคาดว่าจะได้ข้อความแต่กลับพบ traceback นั่นคือ failure ที่ต้องวิเคราะห์

เมื่อ manual check ตรงตามที่คิด ให้เปลี่ยนเป็น pytest เพื่อให้เครื่องตรวจ exception และรันซ้ำได้:

```python
import pytest

from document_reader import read_txt


def test_empty_bytes_raise_no_extractable_text() -> None:
    with pytest.raises(ValueError, match="NO_EXTRACTABLE_TEXT"):
        read_txt(b"")
```

`pytest.raises` ระบุว่าใน block นี้ต้องเกิด `ValueError` และ `match` ตรวจข้อความ หากไม่เกิด exception, เกิดผิดประเภท หรือข้อความไม่ตรง test จะล้ม ต่างจาก manual check ที่คนต้องตีความ traceback เอง

| วิธี | จุดเด่น | ข้อจำกัด |
|---|---|---|
| `python -c` | ทดลองเร็ว เห็นการทำงานทันที | ไม่มีผล pass/fail ที่รันซ้ำอัตโนมัติ |
| pytest | ทำซ้ำได้ ตรวจ regression และใช้ใน CI ได้ | ต้องสร้าง test และติดตั้งเครื่องมือก่อน |

หลังย้ายกรณีสำคัญเข้า pytest แล้ว manual command ยังมีประโยชน์ระหว่าง debug แต่หลักฐานส่งมอบควรมาจาก test suite และคำสั่งที่บันทึกไว้

## สี่ระดับที่ควรรู้

| ระดับ | ตรวจอะไร | ตัวอย่าง |
|---|---|---|
| Unit | ฟังก์ชัน/กฎเล็กแบบแยกส่วน | quote validator |
| Component | module หรือ service กับ fake dependency | service + fake provider |
| Integration | หลายส่วนจริงคุยกัน | API + SQLite |
| End-to-end | เส้นทางผู้ใช้ตั้งแต่ต้นจนจบ | upload → process → review |

ไม่จำเป็นต้องทำทุกกรณีเป็น end-to-end เพราะช้าและหาสาเหตุยาก กฎย่อยควรมี unit test ส่วน boundary สำคัญจึงเสริม integration

## ชุดคำถามสร้าง Test Matrix

สำหรับแต่ละ flow ให้ถาม:

1. **Happy path:** ข้อมูลถูกต้องแล้วได้อะไร
2. **Boundary:** ค่าว่าง เล็กสุด ใหญ่สุด หรือหมดเวลาจะเกิดอะไร
3. **Invalid input:** field หาย type ผิด format ผิดถูกปฏิเสธอย่างไร
4. **Duplicate:** request/event เดิมเข้าซ้ำแล้วข้อมูลหรือ side effect ซ้ำหรือไม่
5. **Dependency failure:** database/provider/email ล่มหรือช้าแล้ว state อยู่ไหน
6. **Crash recovery:** process หยุดหลังทำครึ่งหนึ่งแล้วเริ่มใหม่ได้หรือไม่
7. **Permission:** ผู้ใช้ที่ไม่มีสิทธิ์ทำสิ่งนี้ได้หรือไม่
8. **Privacy:** log/error/response เปิดเผยข้อมูลเกินจำเป็นหรือไม่

## ตาราง Test Plan ขนาดเล็ก

| ID | Behavior | Level | Fixture | Expected | Evidence |
|---|---|---|---|---|---|
| T-01 | quote จริงได้รับการยืนยัน | unit | source+quote | `True` | pytest report |
| T-02 | quote ปลอมถูก block | component | fake provider | `needs_review` | result record |
| T-03 | event ซ้ำไม่สร้าง task ซ้ำ | integration | SQLite temp DB | same task ID | DB count |
| T-04 | worker crash คืนงานเข้า queue | integration | short lease | task retried | state history |

## Mock อย่างไรไม่ให้ Test หลอกเรา

Mock ใช้แทน dependency ที่ช้า แพง หรือควบคุมไม่ได้ เช่น LLM API แต่ไม่ควร mock สิ่งที่ test ตั้งใจพิสูจน์

```text
ถ้าต้องพิสูจน์ business rule → ใช้ input จริงกับ rule จริง
ถ้าต้องพิสูจน์ SQL → ใช้ database test จริง
ถ้าต้องพิสูจน์ provider failure handling → fake provider ที่ตั้งให้ timeout
```

Test ที่ mock database, service และ provider ทั้งหมดอาจพิสูจน์เพียงว่า mock คืนค่าตามที่เราสั่ง

## AI System ต้องมี Evaluation เพิ่ม

Software test ตรวจ contract ที่แน่นอน ส่วน AI evaluation ตรวจคุณภาพที่อาจแปรผัน:

- evidence grounded หรือไม่
- field extraction ถูกต้องเพียงใด
- unsupported claim ถูก block เท่าไร
- human reviewer ต้องแก้มากเพียงใด
- latency/cost อยู่ในขอบเขตหรือไม่

ใช้ dataset สังเคราะห์หรือข้อมูลที่ได้รับอนุญาต เก็บ prompt/model/version/rubric เพื่อให้เปรียบเทียบรอบใหม่ได้

## ก่อนบอกว่า Test ผ่าน

- รันคำสั่งจาก clean environment ได้
- test ล้มจริงเมื่อจงใจทำ behavior ให้ผิด
- ไม่มี test ที่ขึ้นกับลำดับหรือข้อมูลค้างจากรอบก่อน
- failure สำคัญจาก risk register มี test หรือ manual procedure รองรับ
- บันทึก command, environment และผลที่ใช้เป็น evidence
