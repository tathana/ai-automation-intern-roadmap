# 07 — Test Strategy, Failure Matrix และ AI Evaluation

## ทดสอบตาม Boundary และ Risk

```text
Domain rules → unit tests
DB/provider/files → integration tests
User journey → end-to-end tests
LLM behavior → fixed evaluation dataset + validators + human rubric
Operational recovery → failure drills
```

จำนวน test ไม่ใช่เป้าหมาย ให้ความเสี่ยงเป็นตัวกำหนดว่าต้องพิสูจน์อะไร

## Test Matrix

| Case | Input | Expected state/output | Evidence |
|---|---|---|---|
| happy | valid PDF | needs_review + supported fields | test/report |
| invalid | unsupported type | rejected, no task side effect | API test |
| duplicate | same event twice | one task, same ID | concurrency test |
| provider timeout | valid input | retry_wait, no false success | failure drill |
| unsupported quote | model invented quote | needs_review/field removed | eval |

## Failure Matrix

สำหรับแต่ละ dependency ถาม timeout, retryable errors, retry budget, persistent state, alert, manual recovery และ safe replay

```text
Provider 429
→ record attempt/category
→ exponential backoff + jitter within budget
→ retry_wait with next_attempt_at
→ exhausted: needs_review/failed_terminal
→ never export unvalidated partial result
```

## AI Evaluation ไม่ใช่ Unit Test ธรรมดา

แยก deterministic validators ออกจาก model-quality eval:

- schema validity
- evidence quote พบใน source จริง
- field precision/recall ตาม rubric
- abstention เมื่อไม่มีหลักฐาน
- unsupported-claim rate
- latency/cost เป็น secondary metrics
- slice ผลตาม document type/language/difficulty

ห้ามปรับ prompt และตัดสินด้วยตัวอย่างเดียว สร้าง versioned dataset, expected labels, evaluator version และผล regression

## Human Review

review screen ต้องแสดง source, extracted claim, evidence/location, confidence ที่อธิบายได้, reason flags และ action approve/edit/reject พร้อม audit actor/time

## Evidence Pack

เก็บ command, environment/version, dataset version, summary, failures, known limitations และผู้ตรวจ อย่าเก็บ raw sensitive fixtures ใน artifact ที่แชร์กว้าง

### Gate C ตรวจผ่านเมื่อ

must-have acceptance cases มีหลักฐาน, critical failure drill ผ่าน, AI claims มี evidence validation และ limitation ถูกบันทึก ไม่เลือกเฉพาะตัวอย่างที่สวย

