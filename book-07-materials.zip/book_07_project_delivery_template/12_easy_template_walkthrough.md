# 12 — Easy Walkthrough: รับโจทย์หนึ่งประโยคแล้วใช้ Template อย่างไร

สมมติหัวหน้าบอกว่า:

> “ช่วยทำระบบ AI อ่าน Resume เพื่อลดเวลาทีม HR หน่อย”

ประโยคนี้ยังเริ่มเขียนโค้ดไม่ได้ เพราะยังไม่รู้ input, output, ผู้ใช้, baseline, ข้อห้าม และคำว่า “ลดเวลา” วัดอย่างไร บทนี้พาเดิน template แบบภาษาง่าย

## Phase 1 — Intake: อย่าเพิ่งเสนอเทคโนโลยี

```text
โจทย์กว้าง
  ↓ ถามว่าใครทำอะไรอยู่
Current workflow
  ↓ จับเวลา/จำนวน/error
Baseline ที่วัดได้
```

คำถามสำคัญ เช่น Resume มาจากไหน, เดือนละกี่ไฟล์, ภาษา/format อะไร, HR ต้องการผลแบบใด, จุดไหนเสียเวลาจริง และใครตัดสินสุดท้าย

**Baseline** คือค่าก่อนปรับ เช่นเฉลี่ย 8 นาที/ไฟล์ ไม่ใช่ตัวเลขที่เราคาดเองเพื่อให้โปรเจกต์ดูดี

## Phase 2 — Scope และ Requirement

```text
In scope: extract text + evidence draft + review queue
Out of scope: auto-rank/reject/hire, production OCR ทุกชนิด
```

จากนั้นเปลี่ยนความต้องการเป็นสิ่งทดสอบได้:

```text
คำกว้าง: ระบบไม่สร้างข้อมูลมั่ว
REQ-AI-03: quote ทุกชิ้นต้องตรวจพบใน normalized source
TEST-09: mock คืน quote ปลอม → result ต้อง unsupported/needs_review
```

นี่คือ **acceptance criteria** หรือเงื่อนไขที่ใช้ตัดสินว่างานผ่าน ไม่ใช่รายละเอียด implementation

## Phase 3 — Data/Risk

เขียนรายการข้อมูลและถามว่าใครเข้าถึง เก็บที่ไหน นานเท่าไร และ log อะไร:

```text
Resume text = PII สูง
candidate_id = identifier
evidence draft = derived data
review decision = business record
```

**Risk register** ไม่ใช่รายการสิ่งน่ากลัวลอย ๆ แต่ต้องมี likelihood/impact/control/owner เช่น PII หลุดใน log → redact raw text → owner backend → test log inspection

## Phase 4 — Architecture และ ADR

วาดกล่องเฉพาะที่ช่วยตัดสินใจ:

```text
n8n → Intake API → SQLite task
                      ↓
                   Worker → Provider
                      ↓
             Validator → Human Review
```

**ADR (Architecture Decision Record)** คือบันทึกว่าเลือกอะไร เพราะอะไร มี trade-off อะไร เช่น “เริ่ม text-only + Mock AI เพื่อพิสูจน์ flow ก่อน PDF/OCR” ช่วยไม่ให้ทีมย้อนถกเรื่องเดิมโดยลืมบริบท

## Phase 5 — Plan เป็น Vertical Slice

อย่าแบ่งงานเป็น “ทำ backend ทั้งหมด / ทำ database ทั้งหมด” ให้แบ่งเส้นที่ demo ได้:

```text
Slice 1: valid text → 202 + durable task
Slice 2: worker → supported evidence
Slice 3: hallucination → needs_review
Slice 4: human decision + audit
```

**Vertical slice** คือชิ้นเล็กที่ผ่านหลาย layer ตั้งแต่ input ถึง observable output

## Phase 6 — Build/Review

หนึ่ง task/commit ควรเชื่อมกับ requirement/test:

```text
REQ-IDEM-01
  ↓ TASK-04 implement unique event + hash
  ↓ commit feat: make intake idempotent
  ↓ TEST-05 replay same payload
  ↓ evidence: test report + task count
```

AI ช่วยร่างได้ แต่ต้องอ่าน diff, ตรวจ API/version, test happy/failure และเช็ก secret/PII ก่อน commit

## Phase 7 — Verify/Evaluate

- Test: software ทำตาม deterministic contract หรือไม่
- Evaluation: AI output quality บน dataset/rubric เป็นอย่างไร

สองอย่างไม่แทนกัน `pytest passed` ไม่ได้พิสูจน์ model accuracy และคะแนน eval ดีไม่ได้พิสูจน์ transaction/idempotency

## Phase 8 — Release/Rollback/Observe

**Release plan** บอกลำดับเปิดใช้และ verification **Rollback plan** บอก trigger/วิธีกลับ/ผลต่อข้อมูล **Observability** บอกจะเห็นอย่างไรว่างานค้าง ผิด หรือช้าลง

เริ่ม shadow/manual-assist ก่อน side effect จริงในงานเสี่ยง วัด false result และ correction time ไม่ดูเพียงจำนวน workflow executions

## Phase 9 — Demo/Impact/Handoff

Demo ที่ดีมี normal + failure + recovery + limitation:

```text
valid input → task → evidence
hallucination → blocked
duplicate → same task
review → audit
```

Impact เปรียบเทียบ baseline กับผลทดลองพร้อมจำนวน sample และข้อจำกัด Handoff ต้องให้คนอื่นรันจาก clean start โดยไม่พึ่งความจำของผู้สร้าง

## เลือก Template เท่าที่จำเป็น

งานเล็กหนึ่งวันอาจใช้ Project Brief + Acceptance/Test + README ก็พอ งานที่มี PII/AI/หลายระบบจึงค่อยเพิ่ม Data Risk, ADR, Eval, Runbook และ Release Plan เป้าหมายคือช่วยตัดสินใจ ไม่ใช่กรอกเอกสารครบเพื่อความสวยงาม

## ศัพท์สรุป

| ศัพท์ | คำถามที่มันช่วยตอบ |
|---|---|
| Stakeholder | ใครได้ผล/ได้รับผลกระทบ/ตัดสินใจ |
| Baseline | ก่อนทำระบบใช้เวลา/ผิดพลาดเท่าไร |
| Scope | รอบนี้ทำและไม่ทำอะไร |
| Acceptance criteria | หลักฐานแบบใดจึงเรียกว่าผ่าน |
| Traceability | requirement เชื่อม design/code/test ไหน |
| Risk control | ลดโอกาสหรือผลกระทบอย่างไร |
| ADR | ทำไมเลือก design นี้ |
| Rollback | ถ้า release มีปัญหากลับอย่างปลอดภัยอย่างไร |
| Runbook | คนดูแลตรวจ/recover ระบบอย่างไร |
| Handoff | คนอื่นรับช่วงต่อได้จริงหรือยัง |
