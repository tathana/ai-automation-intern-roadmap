# 19 — Filled Guided Example: Resume Evidence Assistant

ตัวอย่างนี้แสดงกระบวนการย่อหนึ่งรอบ ไม่ใช่ requirement สำหรับ production และใช้ข้อมูลสังเคราะห์ทั้งหมด

## 1. โจทย์ต้นฉบับ

> HR อ่าน Resume จำนวนมากและต้องการ AI ช่วยลดเวลาหาข้อมูลที่เกี่ยวข้อง

## 2. แปลเป็นปัญหาที่ตรวจได้

HR ยังเป็นผู้ตัดสิน ระบบช่วยสร้าง evidence draft โดยทุกข้ออ้างต้องมี quote ที่ค้นพบในข้อความต้นฉบับ เป้าหมาย pilot คือเปรียบเทียบเวลาต่อไฟล์และ correction rate กับวิธีเดิม

คำถามที่ยังต้องถาม:

- ปริมาณ/ภาษา/ชนิดไฟล์จริงเป็นอย่างไร
- field ใดที่ HR ต้องใช้ในขั้นถัดไป
- retention และสิทธิ์เข้าถึงเป็นอย่างไร
- ใครอนุมัติผลลัพธ์ก่อนใช้ต่อ

## 3. Scope รอบแรก

```text
ทำ: text input → structured evidence → validation → human review
ไม่ทำ: auto-rank/reject, production OCR, ส่งผลเข้า HRIS อัตโนมัติ
```

เหตุผลที่เริ่ม text-only คือพิสูจน์ business flow และ evidence validation ก่อนรับความซับซ้อนจากเอกสารหลายรูปแบบ

## 4. Acceptance

| ID | เงื่อนไขผ่าน |
|---|---|
| AC-01 | payload ไม่ครบถูกปฏิเสธพร้อม error ที่อ่านได้ |
| AC-02 | evidence quote ทุกชิ้นค้นพบใน normalized source หรือถูกระบุ unsupported |
| AC-03 | event เดิมส่งซ้ำแล้วไม่สร้าง task ใหม่ |
| AC-04 | model/provider ล้มเหลวแล้ว task ไม่หายและ retry ได้ตาม policy |
| AC-05 | การ approve/reject มีผู้ทำ เวลา เหตุผล และประวัติ |

## 5. System Flow

```text
Synthetic Resume
      ↓
Intake API ──validate──→ reject 4xx
      ↓ valid
SQLite Task Queue ← duplicate returns existing
      ↓ lease
Worker → Mock/Approved AI Provider
      ↓
Evidence Validator → unsupported? → needs_review
      ↓
Human Review → decision + audit
```

## 6. Project Structure

```text
src/app/
├─ models.py       # request/result contracts
├─ rules.py        # evidence validation
├─ repository.py   # durable task state
├─ services.py     # intake/process/review use cases
├─ provider.py     # Mock และ approved provider boundary
├─ api.py          # HTTP endpoints
└─ worker.py       # claim/process/retry loop
tests/
├─ test_rules.py
├─ test_intake.py
├─ test_worker.py
└─ test_review.py
```

## 7. Work Breakdown

### Slice 1 — Intake ที่ทน duplicate

- Code: input model, repository, `POST /tasks`, `GET /tasks/{id}`
- Tests: valid, missing field, duplicate event, DB persistence
- Demo: ส่ง payload สองครั้งแล้วได้ task ID เดียว

### Slice 2 — Evidence ที่มีหลักฐาน

- Code: mock provider, quote validator, process service
- Tests: supported quote, invented quote, provider invalid schema
- Demo: claim ที่ไม่มีหลักฐานถูกส่ง `needs_review`

### Slice 3 — Recovery

- Code: lease, attempts, retry/backoff, terminal failure
- Tests: timeout, crash, lease expiry, max attempts
- Demo: หยุด worker กลางทางแล้วเริ่มใหม่โดย task ไม่หาย

### Slice 4 — Human decision

- Code: review endpoint, role/permission boundary, audit record
- Tests: approve, reject, duplicate decision, unauthorized user
- Demo: ค้นย้อนหลังได้ว่าใครตัดสินอะไรและเพราะอะไร

## 8. Function Card ตัวอย่าง

```text
Function: claim_next_task
Responsibility: จอง task พร้อมทำหนึ่งรายการให้ worker
Input: worker_id, now, lease_seconds
Output: claimed task หรือ None
Side effect: เปลี่ยน status/lease owner ใน transaction เดียว
Failure: DB busy → retry ตาม policy
Important test: worker สองตัวต้อง claim task เดียวกันไม่ได้
```

## 9. Prompt ให้ AI ช่วยก้อนแรก

```text
ช่วยออกแบบ tests สำหรับ claim_next_task บน SQLite
ต้องพิสูจน์ว่า worker สองตัว claim task เดียวไม่ได้ และ lease หมดอายุแล้ว reclaim ได้
ยังไม่เขียน production code ขอ test cases, fixture state และ expected transition ก่อน
ห้ามใช้ sleep จริงใน test ให้ส่ง clock/now เข้า function
```

การส่ง `now` เข้าไปทำให้ test ควบคุมเวลาได้ ไม่ต้องรอจริง แนวคิดนี้ทำให้ failure/recovery test เร็วและไม่ flaky

## 10. Test และ Evidence

```text
AC-03 → test_duplicate_event_returns_existing_task → DB count = 1
AC-04 → test_expired_lease_can_be_reclaimed → status returns processing
AC-05 → test_review_writes_audit_record → actor/reason/timestamp exist
```

## 11. Demo และ Handoff

Demo ตามลำดับ normal → failure → recovery → limitation:

1. ส่ง Resume สังเคราะห์และดู task
2. แสดง evidence ที่รองรับ
3. ให้ mock provider สร้าง quote ปลอมและเห็นว่า validator block
4. ส่ง event ซ้ำและเห็นว่า task ไม่ซ้ำ
5. review และเปิด audit
6. บอกตรง ๆ ว่า pilot ยังไม่รองรับอะไร

ก่อนส่งมอบ ให้เพื่อนหรือคนในทีม clone ใหม่ ทำตาม README และ runbook โดยเราไม่บอกขั้นตอนปากเปล่า จุดที่เขาติดคือ documentation gap ที่ต้องแก้

