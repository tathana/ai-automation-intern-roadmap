# 02 — Scope, Requirements, Acceptance Criteria และ Traceability

## จากปัญหาไปสู่สัญญาที่ทดสอบได้

```text
Problem → Outcome → Scope → Requirement → Acceptance case → Test/Evidence
```

แต่ละชั้นตอบคนละคำถาม: outcome บอกผลต่อผู้ใช้, requirement บอกพฤติกรรมระบบ, acceptance case บอกตัวอย่างที่ใช้ตัดสินว่ายอมรับได้

## Project Brief หนึ่งหน้า

ควรมี problem, users, target outcome, in/out of scope, constraints, assumptions, baseline, success/guardrail metrics, owner และ milestone แรก ถ้า brief ยังอธิบายไม่ได้ในหนึ่งหน้า อย่าเพิ่งแตก task จำนวนมาก

## Functional และ Non-functional Requirements

```text
REQ-F-01 ระบบรับ PDF ไม่เกินขนาดที่กำหนดและสร้าง task ID
REQ-NF-01 ระบบไม่บันทึก raw resume ใน application log
REQ-NF-02 duplicate event เดิมต้องไม่สร้าง task ใหม่
```

Functional คือ “ทำอะไร”; non-functional คือคุณภาพ ขีดจำกัด ความปลอดภัย ความทนทาน และการดูแล

## Acceptance Criteria

ใช้ Given/When/Then หรือ Input/Action/Expected แต่ต้องมีตัวอย่าง failure ด้วย:

```text
AC-03
Given PDF ไม่มี text layer
When ส่งเข้าระบบรุ่นที่ยังไม่มี OCR
Then task เป็น needs_review reason=TEXT_NOT_FOUND
And ไม่เรียก LLM และไม่แสดงว่า extract สำเร็จ
```

จุดสำคัญคือ “อะไรต้องไม่เกิด” เช่นไม่ส่งซ้ำ ไม่ log PII ไม่ auto-reject

## Assumption, Constraint และ Decision

- **Assumption:** เชื่อชั่วคราวและต้องพิสูจน์ เช่นไฟล์ส่วนใหญ่ searchable
- **Constraint:** ข้อจำกัดที่ต้องยอมรับ เช่นใช้เฉพาะ provider ที่บริษัทอนุญาต
- **Decision:** ทางเลือกที่ตกลงแล้วพร้อมเหตุผล เช่นเก็บ evidence location แทน raw prompt log

อย่าปนสามคำนี้ เพราะ assumption ที่ถูกเขียนเหมือน fact ทำให้ design พังเงียบ ๆ

## Traceability Matrix

| Requirement | Design | Task | Verification | Status |
|---|---|---|---|---|
| REQ-F-01 | API intake | TASK-02 | TEST-01, EVID-01 | verified |
| REQ-NF-02 | unique event key | TASK-05 | TEST-06 | planned |

Matrix ช่วยหา orphan สองแบบ: requirement ไม่มี test และ feature ไม่มี requirement

## Change Control แบบเบา

เมื่อ requirement เปลี่ยน ให้บันทึก:

```text
CHANGE-04: เพิ่ม OCR
Reason: baseline พบ scanned PDF 28%
Impact: provider/cost/privacy/eval + 3 วัน
Decision: defer V1; return explicit TEXT_NOT_FOUND
Owner/date: ...
```

ไม่ต้องจัดประชุมใหญ่ทุกครั้ง แต่ห้ามให้ change ซ่อนอยู่ใน chat แล้วไม่มีผลต่อ plan

### Gate A ตรวจผ่านเมื่อ

ทุก must-have requirement มี acceptance case, owner ยืนยัน scope/out-of-scope และ unknown สำคัญมีวิธีพิสูจน์

