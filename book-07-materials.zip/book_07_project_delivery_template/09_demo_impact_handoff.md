# 09 — Demo, Impact Measurement, Runbook และ Handoff

## Demo คือการพิสูจน์ ไม่ใช่โชว์เฉพาะ Happy Path

สคริปต์ห้านาที:

1. ปัญหา ผู้ใช้ และ baseline
2. scope และสิ่งที่ระบบไม่ทำ
3. input → output → human review
4. failure หนึ่งกรณีและ recovery
5. tests/eval/metrics evidence
6. limitation, decision ที่ต้องการ และ next step

ติดป้าย mock, synthetic, staging และ production ให้ชัด

## วัด Impact อย่างซื่อสัตย์

```text
old active time = read + copy + verify
new active time = submit + review + correct + recover failures
time saved = comparable old - comparable new
```

รายงาน sample size, mix, median/p90, correction/failure rate, wait time และ learning effect ไม่คูณผลทดลองเล็กเป็น savings รายปีโดยไม่บอก assumption

## README, Runbook และ Handoff ต่างกัน

- **README:** developer เข้าใจ/ติดตั้ง/รัน/test
- **Runbook:** operator ตรวจ health, incident, replay, backup, rollback
- **Handoff:** owner, status, access, limitations, evidence และการถ่ายโอนความรู้

## Handoff Rehearsal

ให้ผู้รับมอบเริ่มจาก repository/สภาพแวดล้อมที่ตกลง แล้วทำ:

1. setup ด้วย docs เท่านั้น
2. รัน tests และ smoke case
3. หา log ของ task หนึ่งรายการ
4. ทำ failure drill ที่ปลอดภัย
5. อธิบาย safe replay/rollback/escalation

ทุกคำถามที่ควรตอบได้จาก docs คือ bug ของ handoff pack ให้แก้แล้วลองซ้ำ

## Ownership หลังส่ง

ระบุ business owner, technical owner, data/risk owner, support channel, SLA/expectation, known debt, expiry/review date ของ prototype และสิ่งที่ยังไม่ production-ready

### Gate E ตรวจผ่านเมื่อ

ผู้รับมอบปฏิบัติงานพื้นฐานและ recovery drill ได้, owner ยอมรับ limitation, metrics มี baseline/วิธีวัด และหลักฐาน release เชื่อมถึง version ที่ส่งจริง

