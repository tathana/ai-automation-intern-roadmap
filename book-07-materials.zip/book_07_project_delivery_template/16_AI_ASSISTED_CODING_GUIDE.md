# 16 — AI-assisted Coding: ให้ AI ช่วยโดยเรายังคุมงานได้

AI เหมาะกับการช่วยคิดทางเลือก ร่างฟังก์ชันเล็ก เขียน test อธิบาย error และ review diff แต่ผู้พัฒนายังต้องรับผิดชอบ requirement, ความถูกต้อง, security และผลที่ส่งให้ผู้ใช้

## Prompt ที่ตรวจงานได้

Prompt สำหรับงานโค้ดควรมีหกส่วน:

```text
Context      โปรเจกต์แก้ปัญหาอะไร ใช้ stack/version ใด
Task         ให้ทำงานก้อนเดียวอะไร
Contract     input/output/error behavior
Constraints  ไฟล์ที่แก้ได้ ข้อห้าม security/style
Examples     ตัวอย่างผ่านและไม่ผ่าน
Verification ขอ tests และคำสั่งที่ใช้ตรวจ
```

ตัวอย่าง:

```text
บริบท: Python 3.12, Pydantic v2 ระบบตรวจ evidence จาก Resume

งาน: เขียน pure function is_supported_quote ใน src/app/rules.py

Contract:
- รับ source_text และ quote เป็น str
- ไม่สนตัวพิมพ์และช่องว่างซ้ำ
- quote ว่างต้องได้ False
- คืน bool และไม่มี side effect

ข้อจำกัด:
- ยังไม่เพิ่ม dependency
- ห้ามแก้ไฟล์อื่น
- ไม่ log ข้อความ Resume

ตัวอย่าง:
"Used Python daily", "python" → True
"Used Python daily", "Java" → False

ขอให้:
1. อธิบายวิธีคิดสั้น ๆ
2. เสนอ implementation
3. เขียน pytest ทั้ง happy path และ edge cases
4. บอก assumption ที่ใช้
```

ขอบเขตแคบทำให้เราอ่านและพิสูจน์คำตอบได้ หากขอ “สร้างระบบ HR AI production-ready ทั้งหมด” เราจะได้โค้ดจำนวนมากที่ไม่รู้ว่า requirement ใดรองรับอยู่

## วงจรใช้ AI ต่อหนึ่งงาน

```text
เราเขียน contract/example
        ↓
ให้ AI เสนอ pseudocode หรือทางเลือก
        ↓
เลือกแนวทางและขอ patch เล็ก
        ↓
อ่าน diff ทีละไฟล์
        ↓
รัน test + ทดลอง failure
        ↓
อธิบายโค้ดกลับด้วยคำของเรา
        ↓
commit เมื่อหลักฐานครบ
```

หากอธิบายไม่ได้ว่าแต่ละฟังก์ชันรับอะไร คืนอะไร และล้มเหลวอย่างไร ยังไม่ควรส่งโค้ดนั้นให้ทีมตรวจ

## Prompt สำหรับแบ่งงาน

```text
ช่วยแปลง requirement ต่อไปนี้เป็น vertical slices ขนาดเล็ก
แต่ละ slice ต้องมี:
- observable demo
- files/modules ที่คาดว่าจะเปลี่ยน
- acceptance criteria
- unit/integration tests
- dependency กับ slice อื่น

อย่าเขียน implementation และอย่าเพิ่ม requirement ที่ไม่มีในโจทย์
ระบุคำถามที่ต้องถาม stakeholder แยกต่างหาก
```

## Prompt สำหรับ Debug

แนบข้อมูลที่ช่วยวิเคราะห์ ไม่ใช่เพียงคำว่า “ใช้ไม่ได้”:

```text
Expected: ส่ง event เดิมซ้ำแล้วได้ task_id เดิม
Actual: ได้ task ใหม่ทุกครั้ง
Command: pytest tests/test_idempotency.py -q
Error/output: <ตัดเฉพาะส่วนเกี่ยวข้องและลบ secret/PII>
Relevant code: <ฟังก์ชันสั้น ๆ>
Already tried: ตรวจ event_id แล้ว

ช่วยเสนอสมมติฐานสาเหตุเรียงตามความเป็นไปได้
จากนั้นบอกการตรวจเพื่อยืนยันแต่ละข้อ ยังไม่ต้องแก้หลายไฟล์พร้อมกัน
```

## Prompt สำหรับ Review

```text
Review diff นี้เทียบกับ AC-01, AC-02 และ AC-03
มองหา correctness, duplicate side effect, transaction boundary,
PII leakage, missing failure tests และการเปลี่ยน contract โดยไม่ตั้งใจ

รายงานเป็น:
- finding พร้อม severity
- หลักฐานจากบรรทัดที่เกี่ยวข้อง
- failure scenario
- วิธีแก้ที่เล็กที่สุด
หากไม่พบให้บอกสิ่งที่ยังพิสูจน์ไม่ได้จาก diff
```

## สิ่งที่ไม่ควรส่งให้ AI ที่ยังไม่ได้รับอนุญาต

- Resume หรือข้อมูลลูกค้าจริง
- API key, token, `.env`, private key
- Source code หรือ architecture ที่ policy บริษัทห้ามนำออก
- Production logs ที่มี identifier/PII
- Prompt/system instruction ภายในที่เป็นความลับ

ใช้ข้อมูลสังเคราะห์และ placeholder เช่น `candidate-001` เมื่อเรียนหรือทดลอง

## Checklist ก่อนรับโค้ด AI

- โค้ดแก้เฉพาะ scope ที่ขอหรือไม่
- library/API ตรงกับ version จริงหรือไม่
- test ตรวจ behavior จริง ไม่ได้ mock ทุกอย่างจนไม่เหลือสิ่งให้พิสูจน์หรือไม่
- failure, retry และ duplicate ทำให้เกิด side effect ซ้ำหรือไม่
- secret/PII ปรากฏใน source, fixture หรือ log หรือไม่
- มี assumption ใดที่ AI เดาแทน stakeholder หรือไม่
- เราอธิบายและดูแลโค้ดนี้ต่อได้หรือไม่

