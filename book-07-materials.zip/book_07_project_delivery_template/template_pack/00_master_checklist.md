# Master Project Delivery Checklist

Project / version / date:
Business owner / technical owner / users:
Level: experiment / internal script / team service / sensitive-production
Current gate: A Problem / B Design / C Verified / D Release / E Transfer

## Artifact Status

| Artifact | Required? | Owner | Status | Link/evidence | Review date |
|---|---|---|---|---|---|
| Intake + baseline | yes | | draft | | |
| Brief + requirements | yes | | | | |
| Data/risk | depends on data | | | | |
| Architecture + ADR | depends on complexity | | | | |
| Contracts + plan | yes | | | | |
| Test/eval evidence | yes | | | | |
| Release/rollback | if deployed | | | | |
| Runbook/handoff | if another person operates | | | | |

## Gate Decision Log

| Gate/date | Decision: pass/change/stop | Evidence | Approver | Follow-up owner/date |
|---|---|---|---|---|
| | | | | |

## Open Critical Items

- [ ] owner and users named
- [ ] scope/out-of-scope confirmed
- [ ] data permission and environment confirmed
- [ ] must-have requirements have tests/evidence
- [ ] known limitations and rollback/handoff accepted

Ready when: คนใหม่เปิดไฟล์นี้แล้วรู้สถานะ ลิงก์หลัก เจ้าของ และสิ่งที่กีดขวางการส่งมอบโดยไม่ต้องถามผู้เขียน

