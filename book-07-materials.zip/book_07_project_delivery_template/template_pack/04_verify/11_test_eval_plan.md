# Test and AI Evaluation Plan

Version/environment/commit:
Linked requirements and top risks:

## Deterministic tests

| ID | Level | Setup/input | Expected behavior/state | Command/evidence | Result |
|---|---|---|---|---|---|
| TEST-01 | unit/integration/e2e/drill | | | | |

## AI evaluation (if applicable)

Dataset/version/source/permission:
Slices and difficult cases:
Expected labels/rubric/reviewer agreement:
Metrics + thresholds + guardrails:
Schema/evidence/abstention validators:
Prompt/model/evaluator versions:
Regression comparison:

Failures and limitations (include, do not hide):
Approver / rerun date:
Ready when: result ทำซ้ำได้, sample ไม่เลือกเฉพาะเคสสวย, thresholds ตกลงก่อนดูผล และ failure เชื่อม action

