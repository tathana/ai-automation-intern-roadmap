# Failure and Recovery Matrix

| Dependency/step | Failure/timeout | Detect | Safe state | Retry/budget | User signal | Manual recovery | Owner |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

## Failure drills

| Drill | Safe setup | Expected transition/log/metric | Recovery | Evidence |
|---|---|---|---|---|
| process restart | | | | |
| duplicate/replay | | | | |
| dependency timeout | | | | |
| invalid/corrupt input | | | | |

Side effects that must not repeat:
Dead-letter/needs-review handling:
Escalation trigger/contact:
Ready when: failure สำคัญไม่กลายเป็น false success, state รอดตาม requirement และ safe replay ถูกทดลอง

