# One-page Project Brief

Problem / affected users:
Current baseline:
Target outcome:

## Scope

In scope:
Out of scope:
Constraints:
Assumptions + validation owner/date:

## Success

Outcome metrics:
Quality/reliability metrics:
Safety/business guardrails:

## Delivery

Owner / contributors / approvers:
First vertical slice:
Milestones and decision dates:
Top risks / unknowns:

Ready when: อ่านหนึ่งหน้าแล้วคนที่ไม่รู้โปรเจกต์อธิบาย why/what/not-what/how-measured/who ได้

