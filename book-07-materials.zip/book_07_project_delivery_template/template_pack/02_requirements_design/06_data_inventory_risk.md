# Data Inventory, Privacy and Risk

## Data Inventory

| Data/field | Source/owner | Class | Purpose | Storage/processor | Access | Retention/delete | Export |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Approved environments/providers:
Prohibited data/actions:
Legal/privacy/security approver if required:

## Risk Register

| ID | Event/cause/impact | Likelihood | Prevent/detect/respond | Residual | Owner/review |
|---|---|---|---|---|---|
| RISK-01 | | | | | |

## Trust Boundaries

Untrusted inputs:
Authentication/authorization boundaries:
Secrets and key rotation owner:
Logging/redaction/audit rules:
Stop/escalation conditions:

Ready when: data ทุกกลุ่มมี purpose/owner/access/retention และ critical risk มี control กับ owner ไม่ใช่เพียงคำว่า “ระวัง”

