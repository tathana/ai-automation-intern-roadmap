# Architecture Design and ADR

## Context

Users/external systems:
System boundary and responsibilities:
Context diagram:

## Components and flow

| Component | Responsibility | Input/output contract | State/dependency | Owner |
|---|---|---|---|---|
| | | | | |

Sequence for happy path:
State machine and invalid transitions:
Failure/retry/idempotency summary:
Trust boundaries and data flow:
Deployment/runtime assumptions:

## ADR-[NN] — [Decision]

Status/date/owner:
Context and decision drivers:
Decision:
Alternatives considered:
Positive/negative consequences:
How to validate / revisit trigger:

Ready when: ทุก component มีเหตุผล, source of truth/state owner ชัด, และคน review ไล่ request/failure/restart ได้

