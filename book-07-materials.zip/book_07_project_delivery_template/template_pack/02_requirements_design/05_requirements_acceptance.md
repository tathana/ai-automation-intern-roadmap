# Requirements and Acceptance Criteria

## Requirements

| ID | Type F/NF | Requirement (must/shall) | Priority | Owner/source | Acceptance IDs | Status |
|---|---|---|---|---|---|---|
| REQ-F-01 | F | | must | | AC-01 | draft |

## Acceptance cases

### AC-01 — [behavior]

Given:
When:
Then:
And must not:
Test data/reference:
Evidence expected:

## Change Log

| Change/date | Reason/evidence | Scope/time/risk impact | Decision/owner |
|---|---|---|---|
| | | | |

Ready when: must-have ทุกข้อวัดได้ มี failure/negative cases และคำว่าเร็ว/แม่น/ปลอดภัยถูกแปลงเป็นเกณฑ์

