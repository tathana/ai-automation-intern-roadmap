# Pull Request and AI-assisted Code Review

PR / commit / linked TASK:
Why / user behavior changed:
What changed / explicitly not changed:
Architecture/data/schema/config impact:
How to verify + expected output:
Test/eval evidence:
Risk/security/privacy considerations:
Migration/rollback:

## Self-review

- [ ] diff เฉพาะ scope และ `git diff --check` ผ่าน
- [ ] เข้าใจ code ทุกส่วนที่ AI ช่วยสร้าง
- [ ] dependency/API version ตรวจจากแหล่งจริง
- [ ] validation, error, timeout, retry/idempotency เหมาะกับ boundary
- [ ] ไม่มี secret/PII/raw sensitive log
- [ ] tests ตรวจ behavior ไม่ได้ mock จุดสำคัญทิ้ง
- [ ] docs/config/contract อัปเดต

Open questions / reviewer requested:
Ready when: reviewer reproduce result และชี้ requirement/risk ของทุก material change ได้

