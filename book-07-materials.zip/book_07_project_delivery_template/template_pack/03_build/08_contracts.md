# API, Event, Data and AI Contracts

Contract/version/owner/consumers:

## Request or Event

Schema/example:
Required/optional/null semantics:
Identity and idempotency scope:
Authentication/authorization:
Size/rate constraints:

## Response or Result

Schema/example:
Status/error taxonomy:
Retry guidance:
Backward compatibility/versioning:

## AI-specific

Model/provider/version policy:
Structured output schema:
Evidence requirements:
Validator/abstention/human-review rule:
Prohibited autonomous action:

Consumer/producer contract tests:
Ready when: producer และ consumer เข้าใจค่าเดียวกัน รวม missing/null/duplicate/error/version—not just happy JSON

