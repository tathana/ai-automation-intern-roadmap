# Project Delivery Template Pack

คัดลอกโฟลเดอร์นี้ไปไว้ใน `docs/delivery/` ของโปรเจกต์ แล้วเริ่มจาก `00_master_checklist.md` ใช้รหัส `REQ-*`, `RISK-*`, `ADR-*`, `TASK-*`, `TEST-*`, `EVID-*` อย่างสม่ำเสมอ

แต่ละ template มี **Required**, **Guiding questions** และ **Ready when** ลบไฟล์ที่ไม่จำเป็นได้ แต่บันทึกเหตุผลใน Master Checklist ห้ามใส่ secrets หรือข้อมูลจริงใน repository ที่ไม่ได้รับอนุญาต

