# Operations Runbook

System/status/owners/support channel:
Architecture/data/state summary:
Prerequisites and access (no secret values):

## Normal operation

Start/stop/restart commands:
Health/readiness/smoke expected results:
Scheduled jobs/queue/state locations:
Log/metric/trace lookup by task ID:

## Recovery

Common symptoms → checks → actions:
Safe replay/idempotency rules:
Backup/restore/migration/rollback:
Actions requiring approval:

Known limitations and expiry/review date:
Last rehearsal / participant / evidence:
Ready when: technical owner ทำ normal operation และ failure drill ที่ตกลงได้จาก runbook เท่านั้น

