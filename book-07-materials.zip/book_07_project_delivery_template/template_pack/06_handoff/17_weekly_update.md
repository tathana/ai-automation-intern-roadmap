# Weekly Project Update

Week/project/owner:
Outcome users can do now:
Evidence: demo/test/eval/metric/commit:
Feedback received and resulting change:
Completed vs planned:
Blocker, attempted actions and impact:
Decision/help needed from whom by when:
Risks/assumptions changed:
Next vertical slice and demo date:
Learning/skill to revisit (maximum two):

Ready when: ผู้อ่านรู้ progress จาก evidence ไม่ใช่เปอร์เซ็นต์ลอย ๆ และรู้คำตัดสินที่ต้องช่วย

