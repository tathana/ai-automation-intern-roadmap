# Handoff and Retrospective

System/version/status: experiment / prototype / pilot / production
Business/technical/data owners:
Repository/deployment/docs/evidence locations:
What it does / does not do:
Setup/config names (no secrets):
Contracts/state/dependencies:
Tests/eval/security checks last run:
Known limitations/debt/expiry:
Support/escalation/access transfer:

## Rehearsal

Recipient/date/environment:
Setup/test/smoke/failure drill attempted:
Questions or undocumented knowledge found:
Docs fixed and rechecked:
Acceptance/sign-off:

## Retrospective

Expected vs actual outcome/effort:
What helped / what created rework:
Requirement/design/test assumptions disproved:
Follow-up improvement with owner/date/evidence:

Ready when: ownership/access/knowledge ถูกโอนและผู้รับมอบยืนยันจากการลงมือ ไม่ใช่เพียงรับลิงก์

