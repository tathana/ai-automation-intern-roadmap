# Demo and Impact Record

Audience/date/version/environment:

## Five-minute demo

Problem/baseline:
Scope and prohibited behavior:
Happy path input → output → review:
Failure/recovery case:
Test/eval/observability evidence:
Limitations and decision requested:

## Before / After

Comparable sample and period:
Old active/wait time median/p90:
New active/wait time including review/correction/recovery:
Quality/correction/failure/escalation:
Tool/API cost in measured scope:
Calculation and assumptions:
Reviewer/owner interpretation:

Ready when: claim ทุกข้อมี sample/method/evidence และ mock/synthetic/staging ถูกติดป้ายชัด

