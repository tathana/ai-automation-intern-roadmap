# Current State and Baseline

Process name / population / measurement period:
Start event / end event:

| Step | Actor/system | Input → output | Active time | Wait time | Error/rework |
|---|---|---|---:|---:|---|
| | | | | | |

Sample definition and size:
Case mix (normal/hard/invalid):
Median / p90 total time:
Correction, failure, escalation counts:
Cost or capacity constraints:
Measurement caveats:

## Target hypothesis

Step to remove/assist:
Expected new human work:
Metric + target + guardrail:
How/when/who will compare:

Ready when: baseline มีนิยามเริ่ม–จบ ชุดตัวอย่าง และข้อจำกัดที่ทำให้คนอื่นวัดซ้ำได้

