# Project Intake

## Required

Request/date/source:
Decision owner / daily users / SME / technical owner:
Requested solution in their words:
Problem in observable terms:
Current process summary:
Desired outcome and why now:
Input / output / connected systems:
Deadline, constraints, policy/tool restrictions:
Explicit out-of-scope:
First safe demo date and sample data owner:

## Guiding questions

- ขอให้ผู้ใช้ทำเคสจริงหนึ่งเคสให้ดูได้หรือไม่
- จุดที่เสีย active time และ wait time อยู่ตรงไหน
- error แบบไหนแก้ได้/รับไม่ได้ และวันนี้รับมืออย่างไร
- ใครตัดสินว่าผลถูกและอ้างจากหลักฐานใด
- ถ้าหยุดระบบได้เมื่อใด ใครมีอำนาจตัดสิน

Ready when: owner ทวนปัญหา outcome และสิ่งที่ไม่ทำได้ตรงกัน พร้อมมี next interview/demo ที่ระบุวัน

