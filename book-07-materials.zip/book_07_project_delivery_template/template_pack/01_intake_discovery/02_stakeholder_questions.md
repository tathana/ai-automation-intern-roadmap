# Stakeholder Interview Notes

Interview / date / facilitator / participants:
Role of each participant:

## Observe the work

Trigger → steps → result:
Tools/data used:
Decision points and exceptions:
What is copied/rechecked/reworked:
Worst/rare cases:

## Definition of useful

What result saves effort:
What must remain human-controlled:
What evidence builds trust:
What would make users stop using it:

## Agreements

Confirmed facts:
Assumptions to validate (owner/date):
Conflicting needs / decision owner:
Artifacts or samples promised (approved channel only):
Next checkpoint:

Ready when: notes separate facts, quotes/observations, assumptions and decisions; sensitive details are stored only where approved

