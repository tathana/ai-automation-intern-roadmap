# Release Readiness and Rollback

Release/version/commit/environment/date/owner:

- [ ] scope and accepted limitations confirmed
- [ ] test/eval/security/privacy gates passed
- [ ] config validated; secrets provided by approved mechanism
- [ ] migration/backfill/backup/restore considered and rehearsed as required
- [ ] health/readiness/smoke checks documented
- [ ] dashboards/log queries/alerts available
- [ ] feature flag/dry-run/limited rollout selected
- [ ] support, incident and communication owners named

## Rollout

Stages / population / duration:
Success and abort thresholds:
Who authorizes expansion:

## Rollback or roll-forward

Trigger and decision authority:
Exact steps:
Data/schema/event consequences:
Verification after recovery:
Maximum tolerable impact/time:

Ready when: ผู้มีสิทธิ์ deploy/rollback ทำตามเอกสารได้ และ abort criteria ไม่ถูกคิดหลังเกิดเหตุ

