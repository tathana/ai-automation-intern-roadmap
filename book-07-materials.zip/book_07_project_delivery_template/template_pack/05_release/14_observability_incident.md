# Observability and Incident Plan

User journey and correlation IDs:
Key logs (event, fields, redaction):
Metrics/SLO or service expectations:
Trace boundaries if used:
Dashboard and alert links/owners:

| Symptom/alert | First checks | Containment | Recovery | Escalate to |
|---|---|---|---|---|
| | | | | |

## Incident Record

Start/detect/contain/recover times:
Impact and affected scope:
Timeline with evidence:
Root/contributing causes (after investigation):
What worked/failed in detection and response:
Follow-ups with owner/date/verification:

Ready when: operator ตอบ “เสียตรงไหน กระทบใคร หยุดอย่างไร หา task อย่างไร” โดยไม่ log ข้อมูลเกินจำเป็น

