# 05 — Project Structure, Contracts และ Implementation Plan

## โครงสร้างตาม Responsibility

โครงสร้างเริ่มเล็กแล้วโตตาม boundary:

```text
project/
├── README.md
├── pyproject.toml
├── .env.example
├── src/app/
│   ├── api/          # HTTP boundary
│   ├── domain/       # business rules, no framework knowledge
│   ├── services/     # use cases/orchestration
│   ├── adapters/     # DB/provider/email/n8n integration
│   ├── models/       # validated contracts
│   └── config.py
├── tests/
│   ├── unit/
│   ├── integration/
│   └── fixtures/
├── scripts/
└── docs/
```

ไม่ต้องสร้างโฟลเดอร์ว่างทุกชื่อ หากมีไฟล์เดียวเริ่ม `main.py` ได้ แต่เมื่อ HTTP, rule และ provider ถูกแก้คนละเหตุผล ให้แยก responsibility

## Contract คือข้อตกลงที่ Boundary

Contract ระบุ schema, semantics, errors, versioning, idempotency และตัวอย่าง ไม่ใช่แค่ชื่อ field

```json
{
  "event_id": "evt-001",
  "document_ref": "approved-store://synthetic/r-01.pdf"
}
```

ต้องตอบเพิ่มว่า `event_id` unique ใน scope ใด, `document_ref` scheme ไหนอนุญาต, missing/duplicate คืนอะไร และ caller retry ได้เมื่อใด

## Vertical Slice

แทนที่จะทำ database ทั้งหมด แล้ว API ทั้งหมด แล้ว UI ทั้งหมด ให้ส่งเส้นทางบางที่สุดที่ผู้ใช้ทดลองได้:

```text
synthetic input → validated intake → persisted task
                → mock extraction → review screen/export draft
```

Slice แรกใช้ mock provider ได้ แต่ต้องติดป้ายชัด เพื่อทดสอบ flow/state/review ก่อนเสียเวลากับ model quality

## Task Breakdown ที่ดี

Task ควรมี outcome, scope, files/components, acceptance cases, dependencies, risk, verification command และ evidence

```text
TASK-04 Persist intake idempotently
Linked: REQ-F-01, REQ-NF-02, ADR-01
Done when: duplicate event returns same task; concurrency test passes
Verify: python -m pytest tests/integration/test_intake.py -q
```

## Milestone

- M0: baseline + synthetic fixtures
- M1: thin vertical slice + demo
- M2: failure/retry/review + eval
- M3: staging integration + readiness review
- M4: limited pilot + measured impact

แต่ละ milestone มี evidence และ decision: continue, change, defer หรือ stop

### Gate B ตรวจผ่านเมื่อ

สามารถสร้าง first slice โดยไม่เดา contract สำคัญ มี task ขนาด review ได้ และความซับซ้อนใหม่ทุกชิ้นเชื่อมกับ requirement/risk

