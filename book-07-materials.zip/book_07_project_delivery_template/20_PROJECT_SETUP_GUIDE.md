# 20 — เตรียมโปรเจกต์ทีละขั้น: จากโฟลเดอร์ว่างจนพร้อมเขียน

หน้านี้รวมขั้นตอนที่ต้องพิมพ์เองไว้ใน Book 7 ทำตามจากบนลงล่างได้ ส่วนลิงก์ **อ่านเพิ่ม** ใช้เมื่อต้องการเข้าใจเรื่องนั้นลึกขึ้น ไม่ต้องอ่านครบทุกเล่มก่อนเริ่ม

ตัวอย่างใช้ Windows + PowerShell และ Python 3.11 ตามเครื่องที่ใช้ฝึก ชื่อโปรเจกต์คือ `resume-evidence-assistant` ถ้าทำบางขั้นแล้วให้ตรวจผลและข้ามไปขั้นถัดไป ไม่ต้องสร้างใหม่

```text
สร้างโฟลเดอร์ → เปิด VS Code → ตรวจ Python/Git
      ↓
สร้าง .venv → เลือก interpreter → ทดลองรัน
      ↓
สร้าง README/.gitignore → เริ่ม Git → บันทึกจุดเริ่ม
      ↓
อ่าน Resume จาก TXT → PDF/DOCX → API → task → AI → review
```

## 1. สร้างโฟลเดอร์และเปิด Editor

เปิด PowerShell แล้วพิมพ์ทีละบรรทัด:

```powershell
New-Item -ItemType Directory -Path D:\COOP\practice\resume-evidence-assistant -Force
Set-Location D:\COOP\practice\resume-evidence-assistant
code .
```

- `New-Item` สร้างสิ่งใหม่ โดย `-ItemType Directory` ระบุว่าเป็นโฟลเดอร์
- `-Force` ในคำสั่งสร้าง directory นี้ใช้กับโฟลเดอร์เดิมได้ ไม่ลบเนื้อหาข้างใน อย่าเหมารวมว่า Force ของทุกคำสั่งปลอดภัยเหมือนกัน
- `Set-Location` เปลี่ยนตำแหน่งทำงานของ Terminal
- `code .` เปิดโฟลเดอร์ปัจจุบันใน VS Code จุด `.` หมายถึงตำแหน่งที่อยู่ตอนนี้

ถ้าไม่มีไดรฟ์ D ให้เลือกโฟลเดอร์ของตัวเอง และใช้ path นั้นตลอดบท ถ้า `code` ไม่พบ ให้เปิด VS Code ด้วยตนเองแล้วเลือก File → Open Folder

**ตรวจผล:** เห็นโฟลเดอร์โปรเจกต์ใน Explorer ของ VS Code

**อ่านเพิ่ม:** [Book 00 — Paths และ Navigation](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-2)

## 2. ตรวจว่าพร้อมเริ่มหรือยัง

ใน VS Code เลือก Terminal → New Terminal และใช้ PowerShell สังเกต prompt ขึ้นต้น `PS` แล้วพิมพ์:

```powershell
Get-Location
py --version
git --version
```

คำสั่งแรกบอกตำแหน่งทำงาน อีกสองคำสั่งตรวจว่าเรียกเครื่องมือได้ ตัวอย่างผลจากเครื่องฝึกคือ Python 3.11.9 และ Git 2.52.0 รุ่นไม่ต้องตรงทุกหลัก แต่เลือก Python ให้ตรงข้อกำหนดโปรเจกต์

ถ้า `py` ไม่พบแต่ `python --version` ใช้ได้ ให้ตรวจว่าเป็น Python รุ่นที่ต้องการก่อนใช้ `python -m venv .venv` แทน หากไม่มี Python/Git ให้ติดตั้งผ่านช่องทางที่เครื่องนั้นอนุญาตแล้วเปิด Terminal ใหม่

**ตรวจผล:** อยู่ในโฟลเดอร์โปรเจกต์ และคำสั่งทั้งสองแสดง version

**อ่านเพิ่ม:** [Book 00 — Terminal และ Command](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-1)

## 3. สร้าง Virtual Environment

Virtual environment คือพื้นที่แยก Python packages ของโปรเจกต์นี้ เพื่อไม่ให้การติดตั้ง package ของงานหนึ่งปะปนกับงานอื่น โฟลเดอร์นี้สร้างใหม่ได้จากรายการ dependencies จึงไม่ต้องเก็บใน Git

```powershell
py -3.11 -m venv .venv
```

`py -3.11` เลือก Python 3.11, `-m venv` เรียกโมดูลสร้าง environment และ `.venv` เป็นชื่อโฟลเดอร์ปลายทาง คำสั่งสำเร็จมักกลับมาที่ prompt โดยไม่มีข้อความพิเศษ

```text
Python ที่ติดตั้งในเครื่อง
       ↓ สร้าง environment
project/.venv
       ├─ Python สำหรับเรียกใช้งาน
       └─ packages ของโปรเจกต์นี้
```

**ตรวจผล:** เห็นโฟลเดอร์ `.venv` ในโปรเจกต์ หากมีอยู่แล้วตรวจขั้นต่อไปก่อนสร้างทับ

**อ่านเพิ่ม:** [Book 00 — Python, venv และ Dependencies](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-3)

## 4. Activate และตรวจ Python ตัวที่ใช้อยู่

```powershell
.\.venv\Scripts\Activate.ps1
python -c "import sys; print(sys.executable)"
```

Activate ปรับ environment ของ Terminal รอบนี้ให้ค้นหา Python ใน `.venv` ก่อน ไม่ได้เปลี่ยน Python ทั้งเครื่อง ส่วน `-c` ให้ Python รันโค้ดสั้นจากข้อความ `sys.executable` คือ path ของ Python ที่กำลังรันจริง

คาดหวังผล:

```text
D:\COOP\practice\resume-evidence-assistant\.venv\Scripts\python.exe
```

มักเห็น `(.venv)` หน้า prompt ด้วย แต่ path ที่ตรวจได้เป็นหลักฐานที่ชัดกว่า เมื่อเปิด Terminal ใหม่ให้ activate ใหม่ แล้วเลือก Python: Select Interpreter จาก Command Palette ของ VS Code ให้ชี้ `.venv` เดียวกัน

หาก PowerShell บล็อก Activate ยังรัน Python ของโปรเจกต์โดยตรงได้:

```powershell
.\.venv\Scripts\python.exe -c "import sys; print(sys.executable)"
```

ไม่จำเป็นต้องเปลี่ยน execution policy เพื่อทำขั้นนี้ หากใช้วิธีเรียกตรง คำสั่ง `python` ในขั้นต่อไปให้แทนด้วย `.\.venv\Scripts\python.exe`

**อ่านเพิ่ม:** [Book 00 — Environment และการเลือก executable](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-3)

## 5. ทดลองไฟล์ Python แรก

สร้างไฟล์ `hello.py` ที่ระดับเดียวกับ `.venv` ด้วย VS Code แล้วพิมพ์และบันทึก:

```python
print("Resume Evidence Assistant is ready")
```

กลับ Terminal ที่อยู่โฟลเดอร์โปรเจกต์:

```powershell
python hello.py
```

ควรเห็น `Resume Evidence Assistant is ready` นี่พิสูจน์ว่า editor บันทึกไฟล์ถูกที่และ Terminal รัน Python ได้ ขั้นนี้ยังไม่ต้องติดตั้ง FastAPI หรือ AI SDK

**อ่านเพิ่ม:** [Week 1 — Python Execution และ Functions](https://ai-automation-intern-roadmap.vercel.app/week-1#lesson-2)

## 6. สร้างไฟล์บอกทางก่อนเก็บงานใน Git

สร้าง `README.md` ที่รากโปรเจกต์ แล้วเริ่มด้วย:

```markdown
# Resume Evidence Assistant Lite

ช่วย HR อ่าน Resume สังเคราะห์และแสดงทักษะพร้อมหลักฐานให้คนตรวจ

## เป้าหมายแรก
อ่าน TXT ได้ก่อน แล้วเพิ่ม PDF/DOCX และ Mock AI

## Environment
Python 3.11, Windows PowerShell

## ทดลองรัน
python hello.py
```

สร้าง `.gitignore` ที่รากเดียวกันแล้วใส่:

```gitignore
.venv/
__pycache__/
*.py[cod]
.pytest_cache/
.env
```

`.gitignore` บอก Git ว่าไฟล์ใหม่กลุ่มไหนไม่ต้องติดตาม ไม่ได้ทำให้ไฟล์ที่ commit ไปแล้วหายจากประวัติ ตัวอย่างนี้ไม่ ignore README, source และ test เพราะเป็นสิ่งที่คนอื่นต้องใช้

```text
resume-evidence-assistant/
├─ .venv/       ← environment ไม่ commit
├─ .gitignore   ← กติกาไฟล์ที่ไม่ติดตาม
├─ README.md    ← วิธีเริ่มและรัน
└─ hello.py     ← ตรวจว่าเครื่องพร้อม
```

**อ่านเพิ่ม:** [Git Special — Gitignore และ Secrets](https://ai-automation-intern-roadmap.vercel.app/special-git#lesson-9)

## 7. เริ่ม Git และบันทึกจุดเริ่ม

ตรวจที่อยู่และ repository ก่อน:

```powershell
Get-Location
git rev-parse --show-toplevel
```

ถ้าบอก `not a git repository` และอยู่ถูกโฟลเดอร์ ให้สร้าง repo:

```powershell
git init -b main
```

ถ้าแสดง path โปรเจกต์นี้อยู่แล้วให้ข้าม init หากชี้ไปโฟลเดอร์แม่ แปลว่าอยู่ใน repo อื่น ให้แยกตำแหน่งโปรเจกต์ก่อน ไม่สร้าง repo ซ้อนโดยไม่ตั้งใจ

ตรวจผู้เขียน commit:

```powershell
git config user.name
git config user.email
```

หากว่างหรือผิด ให้ตั้งเฉพาะ repo นี้ โดยแทนค่าตัวอย่างก่อนรัน:

```powershell
git config user.name "YOUR NAME"
git config user.email "YOUR EMAIL"
```

ไม่ใช้ `--global` ในตัวอย่างนี้ จึงไม่เปลี่ยนผู้เขียนของงานอื่น ตรวจแล้วเก็บไฟล์ที่ทำเสร็จ:

```powershell
git status
git add .gitignore README.md hello.py
git diff --cached
git commit -m "chore: initialize learning project"
git status
```

`add` เลือกไฟล์เข้าพื้นที่เตรียม commit หรือ staging; `diff --cached` ให้ตรวจสิ่งที่จะบันทึก; `commit` สร้างจุดบันทึกในเครื่อง ขั้นนี้ยังไม่ต้อง push ขึ้น GitHub

**ตรวจผล:** commit สำเร็จ และ `git status` บอก working tree clean โดย `.venv` ไม่อยู่ในรายการที่จะ commit

**อ่านเพิ่ม:** [Git Special — Setup และ First Repository](https://ai-automation-intern-roadmap.vercel.app/special-git#lesson-2), [Staging และ Commit](https://ai-automation-intern-roadmap.vercel.app/special-git#lesson-3)

## 8. Package ต้องติดตั้งตอนไหน

การอ่าน TXT ด้วย Python พื้นฐานยังไม่ต้องเพิ่ม package เมื่อเริ่มเขียน test ค่อยติดตั้ง pytest ใน `.venv` ที่ตรวจแล้ว:

```powershell
python -m pip install pytest
python -m pytest --version
```

`python -m pip` ช่วยให้ติดตั้งผ่าน Python ตัวเดียวกับที่เราเลือกไว้ คำสั่งตรวจ version บอกเพียงว่ามี pytest ยังไม่ได้พิสูจน์ว่า test โปรเจกต์ผ่าน

บันทึก dependencies ที่ใช้จริงใน `pyproject.toml` หรือ requirements ตามรูปแบบที่เลือกให้ชัด และอ่านวิธีบันทึก version/lock ก่อนส่งมอบ เมื่อเพิ่ม PDF/DOCX จึงค่อยเพิ่ม reader dependencies

**อ่านเพิ่ม:** [Book 00 — Dependency Declaration](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-3), [Week 1 — Pytest](https://ai-automation-intern-roadmap.vercel.app/week-1#lesson-7)

## พร้อมไปเขียนฟังก์ชันแรกเมื่อใด

- อยู่ในโฟลเดอร์ถูกต้องและเปิดด้วย VS Code
- `sys.executable` ชี้ `.venv` ของโปรเจกต์
- `hello.py` รันและแสดงข้อความได้
- README ระบุเป้าหมายและวิธีรัน
- Git เก็บจุดเริ่มแล้ว และไม่ติดตาม `.venv` หรือ `.env`

สำหรับ Resume Assistant ต่อที่ [Project 01 — บท 08 อ่านไฟล์ Resume](https://ai-automation-intern-roadmap.vercel.app/project-01#lesson-9) โดยทำ F0: TXT → unit tests → PDF/DOCX ส่วนวิธีคิดหน้าที่ฟังก์ชันเปิด [From Requirement to Code](15_FROM_REQUIREMENT_TO_CODE.md)

## ถ้าติด ให้เปิดตรงนี้

| อาการ/คำถาม | ตรวจเบื้องต้น | อ่านลึก |
|---|---|---|
| คำสั่งหาไฟล์ไม่เจอ | Get-Location และชื่อไฟล์ที่บันทึก | [Paths](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-2) |
| ลง package แล้ว import ไม่ได้ | sys.executable และ Python interpreter | [Environment](https://ai-automation-intern-roadmap.vercel.app/book-00#lesson-3) |
| ไม่เข้าใจ print/function/import | ทดลองโค้ดเล็กทีละบรรทัด | [Python](https://ai-automation-intern-roadmap.vercel.app/week-1#lesson-2) |
| จะอ่านไฟล์และจัดการ path อย่างไร | เริ่ม pathlib และ encoding | [Files](https://ai-automation-intern-roadmap.vercel.app/week-1#lesson-4) |
| จะทดสอบฟังก์ชันอะไรบ้าง | ระบุ input, expected output, error | [Test Planning ใน Book 7](17_TEST_PLANNING_FOR_BEGINNERS.md) |
| อยากให้ AI ช่วยก้อนที่ติด | บอกเป้าหมาย command และ error | [AI-assisted Coding](16_AI_ASSISTED_CODING_GUIDE.md) |

ถ้าฝึกกับผู้ช่วย ให้ส่ง command พร้อมผลที่เห็นหลังแต่ละด่าน เพื่อให้ตรวจจากสิ่งที่เกิดจริง เมื่อจบ session จดว่าผ่านขั้นไหนและอะไรยังติดใน Workbook แล้วกลับมาเริ่มต่อได้ทันที
