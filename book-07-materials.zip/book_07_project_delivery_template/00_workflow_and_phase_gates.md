# 00 — วิธีใช้ Template โดยไม่ทำ Documentation เกินจำเป็น

## Template ไม่ใช่งานเอกสารเพิ่ม

Template คือ external memory ของทีม: เก็บสิ่งที่ตกลง เหตุผล และวิธีพิสูจน์ เพื่อไม่ให้คำพูดเปลี่ยนความหมายหลังผ่านไปหลายวัน เอกสารที่ดีช่วยตอบคำถามสามข้อ:

1. เรากำลังแก้ปัญหาอะไร และไม่ทำอะไร
2. เราเลือกวิธีนี้เพราะอะไร มีความเสี่ยงใด
3. จะรู้ได้อย่างไรว่างานใช้ได้และส่งต่อได้

ถ้าเอกสารหนึ่งไม่ช่วยตัดสินใจ สื่อสาร หรือพิสูจน์ ให้ย่อหรือไม่สร้าง

## เลือกระดับงาน

| ระดับ | ตัวอย่าง | ชุดขั้นต่ำ |
|---|---|---|
| Experiment | ทดลอง parser ด้วยข้อมูลสังเคราะห์ | brief, experiment note, result |
| Internal script | report รายวัน ใช้คนเดียว | brief, README, test cases, handoff note |
| Team service | API/n8n มีหลายผู้ใช้ | requirements, design, contracts, test/release/runbook |
| Sensitive/production | PII, money, side effects, AI decision support | ชุดเต็ม + security/privacy/eval/rollback/owner approval |

ความซับซ้อนของเอกสารตาม **blast radius และ uncertainty** ไม่ใช่จำนวนบรรทัดโค้ด

## Phase Gates

```text
Gate A — Problem understood
  ↓ owner ยืนยันปัญหา ผู้ใช้ baseline และขอบเขต
Gate B — Safe design
  ↓ contracts/state/failures/data risks มีคำตอบพอเริ่ม slice เล็ก
Gate C — Verified build
  ↓ tests/eval/review evidence ผ่านเกณฑ์ที่ตกลง
Gate D — Release ready
  ↓ config/migration/monitor/rollback/owner พร้อม
Gate E — Transfer complete
  ↓ ผู้รับมอบรันและแก้ failure drill ได้จากเอกสาร
```

Gate ไม่ใช่พิธีอนุมัติใหญ่เสมอไป สำหรับงานเล็กอาจเป็น checklist 10 นาที แต่ห้ามข้ามเพราะ “เดี๋ยวค่อยจำ”

## Stop Conditions

หยุด build และขอคำตอบเมื่อ:

- ไม่รู้ว่าใครเป็น decision owner
- ไม่มีตัวอย่าง input/output หรือผู้ตรวจความถูกต้อง
- ต้องใช้ข้อมูลจริงแต่ยังไม่รู้ policy/permission
- acceptance criteria ใช้คำว่า “ดี”, “เร็ว”, “แม่น” โดยไม่มีวิธีวัด
- AI output จะสร้าง side effect สำคัญโดยไม่มี validation/approval
- deploy target, secret owner หรือ rollback ยังไม่มีผู้รับผิดชอบ

## วิธีเริ่มใน 15 นาที

1. คัดลอก `template_pack/00_master_checklist.md`
2. เติมระดับงานและ owner
3. เปิด `01_project_intake.md` คุยกับผู้ใช้
4. สร้างรหัส requirement/risk เริ่มต้น
5. นัด checkpoint แรกที่มี demo ชิ้นเล็ก ไม่ใช่รอจน “เสร็จทั้งหมด”

## ความเข้าใจผิดที่พบบ่อย

**“Requirement เปลี่ยนแปลว่าเราเก็บไม่ดี”** — งาน discovery ทำให้เรียนรู้เพิ่มได้ การเปลี่ยนไม่ผิด แต่ต้องบันทึกว่าอะไรเปลี่ยน เหตุผล ผลต่อเวลา และใครยืนยัน

**“มี README แล้วเท่ากับ handoff ได้”** — README ช่วย developer เริ่มต้น ส่วน runbook ช่วย operator ดูแลเหตุขัดข้อง และ handoff ต้องพิสูจน์ด้วย rehearsal

**“Prototype ไม่ต้องคิดเรื่อง privacy”** — prototype อาจมีข้อมูลจริงและถูกแชร์ง่าย ความเสี่ยงข้อมูลเริ่มตั้งแต่ไฟล์แรก ไม่ใช่ตอน production

