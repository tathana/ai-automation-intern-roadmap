# 05 — Git, Docker, n8n และ Database Command Cookbook

บทนี้เป็นแผนที่สั้น รายละเอียดเต็มอยู่ใน Git Special Track, Week 3 และ Week 5

## Git: ตรวจ state ก่อนเปลี่ยน state

```powershell
git status
git diff
git diff --staged
git log --oneline --decorate --graph -10
git branch --show-current
git remote -v
```

วงจรสร้าง commit:

```powershell
git add -- path\to\file.py
git diff --staged
git commit -m "Handle duplicate intake requests"
```

การส่ง/รับ:

```powershell
git fetch origin
git pull --ff-only
git push origin main
```

อย่าใช้ `reset --hard`, force push หรือ clean เพียงเพราะ working tree ดูยุ่ง อ่าน Special Track 00 ในชุด Git Foundation เรื่อง restore/revert/reflog ก่อน

## Docker: Image, Container, Compose

```powershell
docker version
docker build -t resume-api:dev .
docker image ls
docker run --rm -p 8000:8000 resume-api:dev
docker ps
docker logs <container-name>
docker inspect <container-name>
```

Compose:

```powershell
docker compose config
docker compose build
docker compose up
docker compose up -d
docker compose ps
docker compose logs --follow api
docker compose stop
docker compose down
```

`down -v` ลบ named volumes ของ project ตาม scope และอาจลบข้อมูล จึงไม่อยู่ใน routine command

```text
Docker CLI → Docker Engine → image/container/network/volume
```

ถ้า `docker version` แสดง client แต่ server error แปลว่า CLI อยู่แต่ Engine ไม่พร้อม

## n8n

```powershell
n8n --version
n8n start
```

คำสั่ง import/export เปลี่ยนตามรุ่นและ deployment ตรวจ help ของ executable ที่ใช้:

```powershell
n8n --help
n8n import:workflow --help
n8n export:workflow --help
```

ก่อน import/export ให้ระบุ instance/user folder/credential policy อย่าทดลองกับ state งานจริงโดยไม่สำรอง รายละเอียด flow อยู่ Book 03

## SQLite ผ่าน Python

เพราะ sqlite CLI อาจไม่ได้อยู่ใน PATH ใช้ Python ตรวจอย่างปลอดภัย:

```powershell
python -c "import sqlite3; print(sqlite3.sqlite_version)"
```

ตัวอย่าง read-only query ควรเขียนเป็น script ที่ระบุ database path ชัดและไม่พิมพ์ PII ใน terminal สำหรับ mutation ให้ใช้ transaction, backup/migration plan และ environment ที่ถูกต้อง

## HTTP/API

```powershell
curl.exe -i http://127.0.0.1:8000/health
Invoke-RestMethod -Method Get -Uri 'http://127.0.0.1:8000/openapi.json'
python -m uvicorn package.main:app --reload --port 8000
```

`--reload` เหมาะ development ไม่ใช่ production process manager

## Command Selection Flow

```text
อยากรู้ state? → status/list/show/config/logs แบบ read-only ก่อน
อยากทดลอง?    → synthetic data + local/staging + exact target
อยากเปลี่ยน?  → diff/backup/rollback + command ที่ scope เล็กสุด
อยากลบ?       → resolve exact target + ตรวจ ownership + ยืนยันผลกระทบ
```
