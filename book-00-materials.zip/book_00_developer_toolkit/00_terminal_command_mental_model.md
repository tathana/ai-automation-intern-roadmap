# 00 — Terminal และ Command Mental Model

## Terminal, Shell และ Command ต่างกันอย่างไร

- **Terminal** คือหน้าต่างที่รับข้อความและแสดงผล
- **Shell** คือโปรแกรมที่ตีความสิ่งที่พิมพ์ เช่น PowerShell, CMD หรือ Bash
- **Command/Executable** คือสิ่งที่ shell เรียก เช่น `python`, `git`, `docker`

```text
คุณพิมพ์: python -m pytest -q
              ↓
PowerShell แยก command/arguments
              ↓
ค้น python จาก alias/current path/PATH
              ↓
เปิด Python process พร้อม arguments: -m pytest -q
              ↓
process เขียน stdout/stderr และคืน exit code
```

## อ่าน Prompt ก่อนพิมพ์

```text
PS D:\Work\resume-api>
│  └───────────────┘
│     current directory
└─ shell = PowerShell
```

คำสั่งที่ใช้ relative path จะเริ่มจาก current directory นี้ จึงควรตรวจทุกครั้งก่อน build, test, copy หรือ delete:

```powershell
Get-Location
Get-ChildItem
```

## Anatomy ของ command

```powershell
python -m pytest tests -q
└─┬──┘ └──┬───┘ └─┬─┘ └┬┘
 command   option   arg  flag
```

ความหมาย:

- `python`: executable ที่ shell หาเจอ
- `-m pytest`: ให้ interpreter นี้เปิด module `pytest`
- `tests`: target directory
- `-q`: quiet output

ข้อดีของ `python -m pytest` เทียบกับ `pytest` คือเห็นชัดว่าใช้ pytest จาก Python interpreter ใด

## Output สามช่องทาง

```text
stdout     ผลปกติ เช่น test summary
stderr     warning/error/diagnostic
exit code  0 มักหมายถึงสำเร็จ; non-zero หมายถึง command รายงาน failure
```

ตรวจ exit code ล่าสุดใน PowerShell:

```powershell
$LASTEXITCODE
```

อย่าดูเพียงมีข้อความออกมา บาง tool พิมพ์ warning แต่ exit 0; บาง test แสดงรายละเอียดครบแต่ exit 1

## PowerShell ไม่ใช่ CMD/Bash

| งาน | PowerShell | CMD | Bash |
|---|---|---|---|
| ดูไฟล์ | `Get-ChildItem` หรือ `dir` | `dir` | `ls` |
| ดูตำแหน่ง | `Get-Location` | `cd` | `pwd` |
| ตัวแปร env | `$env:APP_ENV` | `%APP_ENV%` | `$APP_ENV` |
| ตั้ง env ชั่วคราว | `$env:APP_ENV='dev'` | `set APP_ENV=dev` | `export APP_ENV=dev` |
| path separator | `\` | `\` | `/` |

คำสั่งจากบทความ Bash อาจใช้ `export`, `rm`, `source` ซึ่งคัดลอกมา PowerShell ตรง ๆ ไม่ได้ ให้แปลตาม shell และตรวจความหมายก่อน

## Core Practice

รันในโฟลเดอร์ฝึกที่ไม่มีข้อมูลสำคัญ:

```powershell
Get-Location
Get-Command python
python --version
python -c "import sys; print(sys.executable)"
git --version
$LASTEXITCODE
```

Expected: เห็น absolute path ของ directory, ตำแหน่ง command และ Python executable จริง หาก `python --version` กับ `sys.executable` ไม่ใช่ environment ที่ตั้งใจ ให้หยุดก่อนติดตั้ง package

## Deep Dive: Command resolution

เมื่อพิมพ์ชื่อ command, PowerShell อาจพบ alias, function, cmdlet หรือ application ตรวจด้วย:

```powershell
Get-Command python -All
Get-Command curl -All
```

นี่สำคัญเมื่อ `curl` หรือ `python` ทำงานต่างจากที่ tutorial คาด การใช้ full path ช่วยพิสูจน์ executable แต่ไม่ควร hardcode path ส่วนตัวลง project ที่ต้องส่งทีม
