# 07 — Project Bootstrap Lab จากโฟลเดอร์ว่าง

Lab นี้สร้าง Python API project เล็กเพื่อฝึก command/order ไม่เน้น business feature

## Target Structure

```text
toolkit_lab/
├── .gitignore
├── README.md
├── pyproject.toml
├── src/
│   └── toolkit_lab/
│       ├── __init__.py
│       └── main.py
└── tests/
    └── test_health.py
```

## Step 1: ตรวจจุดเริ่ม

```powershell
Get-Location
New-Item -ItemType Directory -Path '.\toolkit_lab'
Set-Location -LiteralPath '.\toolkit_lab'
Get-Location
git status
```

ถ้า `git status` บอก not a repository ให้ตัดสินใจก่อนว่าจะสร้าง repo ใหม่หรืออยู่ผิดโฟลเดอร์ อย่าสร้าง nested repo ใน repo เดิมโดยไม่ตั้งใจ

## Step 2: สร้าง Environment

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -c "import sys; print(sys.executable)"
python -m pip install fastapi uvicorn pytest httpx
python -m pip check
```

บันทึก dependency declaration ใน `pyproject.toml`; อย่าพึ่งพาเฉพาะ packages ที่บังเอิญอยู่ในเครื่อง

## Step 3: สร้างไฟล์ด้วย Editor

ใช้ editor สร้าง structure ตามต้นแบบ ไม่ใช้คำสั่งเขียนไฟล์ยาวลง shell เพราะตรวจ diff/encoding ยาก ใส่ `.venv/`, caches, `.env` ใน `.gitignore`

`main.py`:

```python
from fastapi import FastAPI

app = FastAPI()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
```

`test_health.py`:

```python
from fastapi.testclient import TestClient

from toolkit_lab.main import app

client = TestClient(app)


def test_health() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
```

สำหรับ src layout ต้องติดตั้ง project แบบ editable หลัง `pyproject.toml` ตั้ง packaging ถูก:

```powershell
python -m pip install -e .
python -m pytest -q
```

## Step 4: เปิด API และ Probe

```powershell
python -m uvicorn toolkit_lab.main:app --reload --port 8000
```

อีก terminal ต้อง activate environment เดียวกันก่อน probe/test:

```powershell
curl.exe -i http://127.0.0.1:8000/health
```

Expected: HTTP 200 และ JSON `{"status":"ok"}`

## Step 5: Quality Gate และ Git

```powershell
python -m pytest -q
git status
git diff
git add -- .gitignore README.md pyproject.toml src tests
git diff --staged
git commit -m "Bootstrap FastAPI toolkit lab"
```

ก่อน commit ต้องยืนยัน `.venv`, cache และ secret ไม่ถูก stage

## Failure Drills

1. รัน Uvicorn จาก parent directory แล้วดู import error
2. ใช้ Python นอก `.venv` แล้วเทียบ `sys.executable`
3. เปิด server สองตัว port เดียวและหา owning PID
4. เปลี่ยน test expected เป็นค่าผิดเพื่อเห็น pytest exit code
5. ส่ง GET path ผิดเพื่อแยก 404 จาก connection refused

## Definition of Done

- clone/copy source ไป directory ใหม่แล้ว recreate environment ได้
- tests ผ่านจาก project root
- API probe ผ่านและหยุด process ได้ถูกตัว
- Git มี atomic bootstrap commit ไม่มี generated/secret files
- อธิบาย current directory, interpreter, port และ import path ได้
