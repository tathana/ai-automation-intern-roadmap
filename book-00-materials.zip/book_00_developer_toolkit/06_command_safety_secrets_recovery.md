# 06 — Command Safety, Secrets และ Recovery

## Classify ก่อนกด Enter

| ระดับ | ตัวอย่าง | สิ่งที่ทำก่อน |
|---|---|---|
| Read-only | status, list, show, logs | ตรวจ scope/output privacy |
| Reversible | format, create branch, stop service | ดู diff/state และวิธีย้อน |
| Destructive | delete, overwrite, drop DB, remove volume | resolve target, backup, approval |
| External side effect | push, deploy, send email, call payment | environment, identity, idempotency |

## Safe Command Checklist

```text
ฉันอยู่ directory ไหน?
command จะหา target ด้วย exact path หรือ wildcard?
target เป็น local/dev/staging/production?
มี uncommitted/untracked data หรือไม่?
คำสั่งเปลี่ยน files, database, remote หรือคนอื่นหรือไม่?
ถ้าล้มกลางทาง state จะเป็นอย่างไร?
มี backup/revert/retry key หรือไม่?
```

## Secrets

สิ่งต่อไปนี้ไม่ควรอยู่ใน Git, screenshots, HTML, shell history หรือ shared logs:

- API keys/tokens/passwords
- private keys และ connection strings ที่มี credential
- authorization headers/cookies
- production `.env`
- resume/financial/health data จริง

ตรวจไฟล์ที่กำลัง stage:

```powershell
git status
git diff --staged
```

ถ้า secret ถูก commit/push แล้ว การลบจากไฟล์ปัจจุบันไม่พอ ต้อง revoke/rotate ก่อน ประเมิน exposure และทำ incident procedure ของทีม

## Wildcard กับ Variable Risk

คำสั่งนี้กว้างเพราะ `*`:

```powershell
Remove-Item -Path '.\output\*' -Recurse
```

ก่อนใช้ ให้ resolve directory, ยืนยันว่าอยู่ใต้ project และ list รายการ หลีกเลี่ยงตัวแปรระบบกว้างหรือ string-built commands สำหรับ delete/move

## Recovery Ladder

```text
หยุดทำ mutation เพิ่ม
      ↓
บันทึก current state: status/log/path/error
      ↓
แยกไฟล์ tracked / untracked / database / remote
      ↓
เลือก recovery ที่ scope เล็กสุด
      ↓
verify content/tests/state ก่อนทำต่อ
```

Git tracked file อาจกู้จาก commit/reflog ได้ แต่ untracked file ไม่ได้อยู่ใน Git history เสมอ Database/volume ต้องมี backup/transaction/recovery plan ของตัวเอง

## External Commands และ Idempotency

เมื่อ command ส่ง request, deploy หรือ push ผลอาจเกิดแล้วแม้ terminal timeout ก่อนเห็นคำตอบ ตรวจ remote state ก่อนรันซ้ำ เช่น deployment ID, commit SHA หรือ business idempotency key

## Practice: Safety Review

เลือก command ห้าคำสั่งจากงานจริง จัดระดับตามตาราง ระบุ exact target, expected state change, verification และ rollback หากตอบไม่ได้ ห้ามรวม command นั้นไว้ใน automation script
