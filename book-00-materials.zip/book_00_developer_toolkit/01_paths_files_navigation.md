# 01 — Paths, Files และ Navigation

## Absolute กับ Relative Path

```text
Absolute: D:\COOP\short_course\book_00_developer_toolkit
Relative: .\tests\test_api.py
```

relative path ถูก resolve จาก current directory:

```text
current = D:\Work\api
.\tests\test_api.py
        ↓
D:\Work\api\tests\test_api.py
```

ถ้าย้าย prompt ไป `D:\Work` relative path เดิมจะหมายถึงคนละที่

## คำสั่งอ่านอย่างปลอดภัย

```powershell
Get-Location
Get-ChildItem
Get-ChildItem -Force
Get-ChildItem -Recurse -File | Select-Object -First 30
Test-Path -LiteralPath '.\pyproject.toml'
Resolve-Path -LiteralPath '.\src'
Get-Content -LiteralPath '.\README.md' -First 40
```

`-LiteralPath` ให้ชื่อ path ถูกใช้ตรง ๆ ไม่ตี `*`, `?`, `[` เป็น wildcard เหมาะเมื่อ path มาจากผู้ใช้หรือมีอักขระพิเศษ

## สร้างและคัดลอก

```powershell
New-Item -ItemType Directory -Path '.\notes'
New-Item -ItemType File -Path '.\notes\experiment.md'
Copy-Item -LiteralPath '.\config.example' -Destination '.\config.local'
```

ก่อน copy แบบ recursive ให้ resolve source/destination และเช็กว่า destination อยู่ใน project ที่ตั้งใจ

```text
source exists?
    ↓
resolve absolute source/destination
    ↓
destination อยู่ใต้ project root?
    ↓
copy → list/check hash ตามความเสี่ยง
```

## Move/Delete เป็นการเปลี่ยน state

```powershell
Move-Item -LiteralPath '.\old_name.md' -Destination '.\new_name.md'
Remove-Item -LiteralPath '.\temporary.txt'
```

สำหรับ recursive delete ต้องตรวจ exact absolute target ก่อนเสมอ ไม่ใช้ broad root, unresolved variable หรือ wildcard ที่อาจขยายเกินคาด ใน Git repository ให้ดู `git status` ก่อนและหลัง เพราะไฟล์ untracked อาจไม่มีสำเนาใน history

## Path ที่มีช่องว่าง

```powershell
Set-Location -LiteralPath 'D:\COOP\short_course'
python '.\tools\build report.py'
```

single quotes ป้องกัน PowerShell ขยาย `$variable`; double quotes ใช้เมื่อต้องการ interpolation:

```powershell
$projectDir = 'D:\Work\api'
Write-Output "Project: $projectDir"
```

## Project Root กับ Working Directory

project root มักมี `pyproject.toml`, `.git`, `README.md` หรือ `compose.yaml` หลาย command สมมติว่ารันจาก root:

```text
resume_api/            ← run pytest/docker compose ที่นี่
├── pyproject.toml
├── src/resume_api/
└── tests/
```

ถ้า import/file path พัง ให้พิมพ์ `Get-Location`, `Get-ChildItem` และ `python -c "import os; print(os.getcwd())"` ก่อนแก้ code

## Practice: Path Detective

1. สร้าง sandbox directory
2. สร้าง `src`, `tests`, `docs`
3. ใช้ relative path สร้างไฟล์ในแต่ละโฟลเดอร์
4. เปลี่ยน current directory แล้วทำนายว่า relative path เดิมชี้ที่ไหน
5. ใช้ `Resolve-Path` ยืนยัน

จบแบบฝึกเมื่ออธิบายได้ว่า current directory, project root และ Python import path ไม่ใช่สิ่งเดียวกัน
