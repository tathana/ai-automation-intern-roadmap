# Book 00 — Developer Toolkit: Command Line, Environment และเครื่องมือพื้นฐาน

เล่มนี้เป็นฐานร่วมของทุก Book ใช้อ่านก่อนเริ่มและกลับมาเปิดเมื่อคำสั่ง “รันได้ในเครื่องหนึ่งแต่ไม่ได้อีกเครื่อง” เน้น PowerShell บน Windows ตามเครื่องที่ใช้ พร้อมบอกความต่างสำคัญจาก CMD/Bash

## เป้าหมาย

เมื่อจบ คุณควรอธิบายได้ว่า command รันจาก directory ใด ใช้ executable/environment ใด รับ arguments อะไร เปลี่ยน state ใด และดู exit code/output ที่ไหน

```text
prompt → current directory → command resolution → arguments
                                         ↓
                              process + environment
                                         ↓
                         stdout / stderr / exit code / files
```

## ลำดับอ่าน

| บท | เนื้อหา |
|---|---|
| 00 | Mental model ของ terminal และ command |
| 01 | Paths, files และ navigation |
| 02 | Python, virtual environment และ dependencies |
| 03 | Processes, ports, HTTP และ environment variables |
| 04 | Tests, lint, format, type checking และ task commands |
| 05 | Git, Docker, n8n และ database command cookbook |
| 06 | Command safety, secrets และการกู้สถานการณ์ |
| 07 | Project Bootstrap Lab จากโฟลเดอร์ว่าง |
| 08 | Sources, verification และขอบเขต |
| 09 | Guided Companion: อธิบายทุกบทแบบเห็นภาพและอ่าน command ทีละส่วน |

## วิธีอ่านสามชั้น

- **Core:** อ่านคำอธิบายและ flow ก่อนจำ syntax
- **Practice:** พิมพ์คำสั่งใน sandbox/project ทดลอง และทายผลก่อน Enter
- **Reference:** ใช้ตาราง “อาการ → ตรวจอะไร → คำสั่ง” ระหว่างทำงานจริง

> ทุกตัวอย่าง destructive จะระบุชัด เล่มนี้ไม่สอนให้คัดลอกคำสั่งลบ/เขียนทับโดยไม่ตรวจ target

## ความสัมพันธ์กับแผน 5 สัปดาห์

เรียนบท 00–03 ก่อน Week 1 จากนั้นอ่านบทที่เกี่ยวข้องตามงาน เช่น Git ก่อน commit, HTTP ก่อน Week 2, n8n ก่อน Week 3 และ Docker ก่อน Week 5 ไม่ต้องรอจบ Book 00 ทั้งเล่มจึงเริ่มเขียน Python ได้

ถ้าบทใดดูสั้นหรือศัพท์แน่น ให้เปิดบท 09 คู่กัน บทนี้แปล mental model ของบท 00–08 เป็นภาษาที่เห็นภาพ พร้อม “ทายก่อนรัน”, expected result และลำดับ debug
