# 10 — Visual Notes: Terminal, Environment และ Runtime

## ตอนกด Enter

<div class="visual-board"><div class="visual-flow"><div class="visual-box"><code>PS D:\project&gt;</code></div><span class="visual-arrow">→</span><div class="visual-box">PowerShell<br><small>parse + resolve</small></div><span class="visual-arrow">→</span><div class="visual-box"><code>python.exe</code></div><span class="visual-arrow">→</span><div class="visual-box">Process<br><small>cwd/env/args</small></div><span class="visual-arrow">→</span><div class="visual-box">output + exit</div></div></div>

## Path

<div class="visual-board"><div class="visual-grid"><div class="visual-pane"><div class="visual-label">CURRENT DIRECTORY</div><p><code>D:\work\api</code></p></div><div class="visual-pane"><div class="visual-label">RELATIVE PATH</div><p><code>.\config\app.json</code></p></div><div class="visual-pane"><div class="visual-label">RESOLVED TARGET</div><p><code>D:\work\api\config\app.json</code></p></div></div></div>

## Process → Port → HTTP

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Python PID</div><span class="visual-arrow">listen →</span><div class="visual-box"><code>127.0.0.1:8000</code></div><span class="visual-arrow">HTTP →</span><div class="visual-box"><code>GET /health</code></div><span class="visual-arrow">→</span><div class="visual-box"><code>200 {status}</code></div></div></div>

## Git State

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Working tree</div><span class="visual-arrow">git add →</span><div class="visual-box">Staging</div><span class="visual-arrow">git commit →</span><div class="visual-box">Local history</div><span class="visual-arrow">git push →</span><div class="visual-box">Remote</div><span class="visual-arrow">CI/CD? →</span><div class="visual-box">Deployment</div></div></div>

Commit ไม่เท่ากับ push และ push ไม่เท่ากับ deploy เว้นแต่ pipeline กำหนดไว้

