# 03 — Processes, Ports, HTTP และ Environment Variables

## Process คือโปรแกรมที่กำลังทำงาน

เมื่อรัน:

```powershell
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

terminal นี้ถูกใช้แสดง server logs จนหยุดด้วย `Ctrl+C` หากเปิด terminal ใหม่แล้วรันซ้ำ port เดิมอาจถูกใช้

```text
command → Python process → Uvicorn server → listen 127.0.0.1:8000
client  → TCP connection → HTTP request → FastAPI app → response
```

## ตรวจ Process และ Port บน Windows

```powershell
Get-Process python -ErrorAction SilentlyContinue
Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
```

ค่า `OwningProcess` เชื่อมไปยัง process ID:

```powershell
Get-Process -Id 12345
```

อย่าหยุดทุก process ชื่อ Python เพราะอาจเป็นงานอื่น ตรวจ PID, command context และ owner ก่อน `Stop-Process`

## Host ที่พบบ่อย

- `127.0.0.1`: รับจากเครื่อง/container เดียวกันเท่านั้น
- `0.0.0.0`: bind ทุก interface ที่ runtime มี ไม่ได้เป็น URL สำหรับ client
- `localhost` ใน container: container นั้นเอง ไม่ใช่ Windows host
- service name ใน Compose เช่น `http://api:8015`: ใช้ระหว่าง containers ใน network เดียวกัน

## HTTP Probe

PowerShell:

```powershell
Invoke-RestMethod -Method Get -Uri 'http://127.0.0.1:8000/health'
$body = @{transaction_id='T1'; amount_satangs=5000} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8000/transactions' -ContentType 'application/json' -Body $body
```

ใช้ curl executable โดยระบุชื่อชัดบน Windows ถ้าต้องการ syntax แบบ curl:

```powershell
curl.exe -i http://127.0.0.1:8000/health
```

## Debug ตามชั้น

```text
Connection refused → ไม่มี listener/host/port ผิด
Timeout            → network/service ช้า/firewall; server อาจยังทำงาน
404                → ถึง server แต่ path ไม่พบ
405                → path มีแต่ method ผิด
422                → request ถึง FastAPI แต่ schema ไม่ผ่าน
500                → application/dependency ล้มเหลว
```

## Environment Variables

ตั้งสำหรับ PowerShell process ปัจจุบันและ child processes:

```powershell
$env:APP_ENV = 'development'
$env:DATABASE_URL = 'sqlite:///./data/app.db'
python -c "import os; print(os.environ['APP_ENV'])"
```

ค่าคือ string เสมอ ต้อง parse boolean/int/URL ใน configuration layer และ validate ตอน startup

```python
import os

app_env = os.getenv("APP_ENV", "development")
timeout_seconds = int(os.getenv("UPSTREAM_TIMEOUT_SECONDS", "5"))
```

หากค่าเป็น `"false"`, `bool("false")` ยังเป็น `True` เพราะ string ไม่ว่าง อย่า parse boolean ด้วย `bool(text)`

## `.env` ไม่ใช่ที่เก็บลับโดยอัตโนมัติ

`.env` เป็นรูปแบบไฟล์ config ที่ tooling อาจโหลด ต้องใส่ `.env` ใน `.gitignore`, จำกัดสิทธิ์ไฟล์ และใช้ secret manager ตาม environment จริง ส่งมอบเฉพาะ `.env.example` ที่ไม่มีค่าลับ

## Practice: Port Detective

1. เปิด API ที่ port 8000
2. ตรวจ listener/PID
3. probe `/health`
4. ทดลอง path ผิดและ method ผิด
5. หยุดเฉพาะ process ที่คุณเปิด
6. ยืนยัน port ไม่มี listener

บันทึก expected/actual เพื่อแยก network failure จาก HTTP/application failure
