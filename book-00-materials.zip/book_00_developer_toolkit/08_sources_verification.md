# 08 — Sources, Verification และขอบเขต

ตรวจเอกสารทางการเมื่อ 12 กันยายน 2026 คำสั่ง/flags อาจเปลี่ยนตามรุ่น ให้ตรวจ `--help` และเอกสารของ version ที่ทีมใช้อยู่ก่อน automation หรือ production change

## Sources

- [Python `venv`](https://docs.python.org/3/library/venv.html)
- [Python tutorial: Virtual Environments and Packages](https://docs.python.org/3/tutorial/venv.html)
- [Python Packaging User Guide: `pyproject.toml`](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)
- [Python Packaging: src layout vs flat layout](https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/)
- [PowerShell Path Syntax](https://learn.microsoft.com/powershell/module/microsoft.powershell.core/about/about_path_syntax)
- [PowerShell Environment Variables](https://learn.microsoft.com/powershell/module/microsoft.powershell.core/about/about_environment_variables)
- [Docker CLI Reference](https://docs.docker.com/reference/cli/docker/)
- [Docker Compose CLI](https://docs.docker.com/reference/cli/docker/compose/)
- [n8n CLI commands](https://docs.n8n.io/hosting/cli-commands/)
- [Git Reference](https://git-scm.com/docs)
- [Pytest Documentation](https://docs.pytest.org/)
- [Ruff Documentation](https://docs.astral.sh/ruff/)
- [Mypy Documentation](https://mypy.readthedocs.io/)

## สิ่งที่ตรวจในชุดหนังสือ

- internal links/anchors และ ZIP integrity
- Python code blocks หลัก parse ได้
- ไม่มีคำสั่ง destructive ถูกนำเสนอเป็น routine step โดยไม่มี warning
- ตัวอย่างใช้ local/synthetic values
- command ระบุ shell/context และ expected result ในจุดสำคัญ

## สิ่งที่ยังต้องตรวจในเครื่อง/บริษัท

- executable versions และ PATH จริง
- PowerShell execution policy ที่องค์กรกำหนด
- package registry/proxy/certificate
- Docker Engine/permissions และ container runtime
- n8n deployment/credentials/user folder
- CI runner, cloud provider, secret manager และ production access policy

เล่มนี้ไม่แทน runbook บริษัทหรือสิทธิ์อนุมัติการเปลี่ยน production
