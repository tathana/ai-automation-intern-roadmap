# 02 — Python, Virtual Environment และ Dependencies

## ทำไม “ติดตั้งแล้วแต่ import ไม่ได้”

เครื่องหนึ่งมี Python ได้หลายตัว และแต่ละ environment มี packages ของตัวเอง:

```text
PowerShell หา python A
        ↓ python -m pip install fastapi
ติดตั้งเข้า environment ของ A

VS Code/Test ใช้ python B
        ↓ import fastapi
ModuleNotFoundError
```

ตรวจคู่กัน:

```powershell
python -c "import sys; print(sys.executable)"
python -m pip --version
```

path ทั้งสองควรชี้ environment ที่ตั้งใจ

## สร้าง Virtual Environment

จาก project root:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -c "import sys; print(sys.executable)"
```

`.venv` เป็นของสร้างใหม่ได้ ไม่ commit เข้า Git และไม่ควรย้ายไปอีกเครื่อง ให้เก็บ dependency declaration/lock แล้ว recreate

ถ้า activation ถูก policy บล็อก คุณยังเรียก interpreter โดยตรงได้:

```powershell
.\.venv\Scripts\python.exe -m pip install -U pip
.\.venv\Scripts\python.exe -m pytest -q
```

อย่าเปลี่ยน execution policy ระดับเครื่องโดยไม่เข้าใจผลเพียงเพื่อแก้ activation

## ติดตั้งและตรวจ package

```powershell
python -m pip install fastapi uvicorn pytest httpx
python -m pip show fastapi
python -m pip list
python -m pip check
```

`pip check` ตรวจ dependency conflicts ที่ติดตั้งอยู่ ไม่ได้รัน application tests

## Dependency Declaration

สำหรับโปรเจกต์สมัยใหม่ `pyproject.toml` เป็นศูนย์กลาง metadata/build/tool configuration ตัวอย่างย่อ:

```toml
[project]
name = "resume-api"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
  "fastapi>=0.110,<1",
  "uvicorn>=0.29,<1",
]

[project.optional-dependencies]
dev = ["pytest>=8,<9", "httpx>=0.27,<1", "ruff>=0.6,<1"]
```

ช่วง version เป็น policy ตัวอย่าง ต้องเลือกจาก compatibility/security policy ของทีมและ lock resolution จริง ไม่คัดลอกเลขนี้เป็นมาตรฐานบริษัท

## `pip freeze` ไม่เท่ากับออกแบบ dependencies

```powershell
python -m pip freeze
```

แสดงทุก package ที่ติดตั้งรวม transitive dependencies เหมาะกับ snapshot บาง workflow แต่ไฟล์จาก environment ที่ปนงานอื่นอาจมีของไม่เกี่ยวข้อง แยก direct dependencies, lock file และ environment purpose ให้ชัดตาม tool ที่ทีมใช้

## `python -m` Mental Model

```powershell
python -m pytest
python -m uvicorn resume_api.main:app
python -m pip
```

หมายถึงให้ interpreter ที่เลือกค้นและเปิด module นั้น ลดความสับสนจาก executable wrapper ที่ชี้คนละ environment

## Src Layout และ Editable Install

```text
project/
├── pyproject.toml
├── src/resume_api/
│   └── __init__.py
└── tests/
```

เมื่อ packaging configuration ถูกต้อง:

```powershell
python -m pip install -e .
```

editable install ทำให้ import package จาก source ที่กำลังแก้ได้ แต่ไม่ได้แก้ circular import หรือ project structure ที่ผิดโดยอัตโนมัติ

## Reproducibility Checklist

- ระบุ supported Python version
- มี dependency declaration และ lock ตาม workflow ทีม
- `.venv`, cache, secrets ไม่อยู่ใน Git
- setup ใหม่จาก clone เปล่าได้
- `python -m pip check` และ tests ผ่าน
- บันทึก OS/native dependencies ที่ pip จัดการไม่ได้

## Practice

สร้าง project ว่าง, สร้าง `.venv`, ติดตั้ง pytest, พิมพ์ executable และสร้าง test หนึ่งไฟล์ จากนั้นปิด terminal เปิดใหม่และพิสูจน์ว่าต้องเลือก/activate environment ก่อนรัน
