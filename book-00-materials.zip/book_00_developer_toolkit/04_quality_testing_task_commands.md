# 04 — Tests, Lint, Format, Type Checking และ Task Commands

เครื่องมือเหล่านี้ตอบคนละคำถาม จึงไม่ใช้แทนกัน

| Tool category | คำถาม |
|---|---|
| Tests | พฤติกรรมที่คาดยังถูกหรือไม่ |
| Linter | มีรูปแบบ/ข้อผิดพลาดที่ตรวจจาก source ได้หรือไม่ |
| Formatter | จัดรูปแบบ code ให้สม่ำเสมอหรือยัง |
| Type checker | การใช้ชนิดข้อมูลสอดคล้องกับ annotations หรือไม่ |
| Coverage | test วิ่งผ่าน code ส่วนใด ไม่ได้บอก assertion ดีแค่ไหน |

## Pytest Commands

```powershell
python -m pytest
python -m pytest -q
python -m pytest tests\test_api.py -q
python -m pytest tests\test_api.py::test_create_transaction -vv
python -m pytest -x
python -m pytest -k "duplicate or timeout"
```

- `-q`: output ย่อ
- `-vv`: รายละเอียดเพิ่ม
- `-x`: หยุด failure แรก
- `-k`: เลือกจากชื่อ expression

ก่อนสรุปว่า test ผ่าน ให้ดูจำนวน collected/passed/skipped และ exit code การเห็น `0 tests collected` ไม่ใช่หลักฐาน feature ผ่าน

## Ruff และ Type Checker

หากโปรเจกต์เลือกใช้ Ruff:

```powershell
python -m ruff check .
python -m ruff format --check .
python -m ruff format .
```

คำสั่ง format ตัวสุดท้ายแก้ไฟล์ จึงควรดู `git diff` หลังรัน ส่วน type checker ใช้ตาม config ทีม เช่น:

```powershell
python -m mypy src
```

อย่าเพิ่ม tool เพราะดูเป็นมาตรฐานโดยไม่กำหนด config/ownership เริ่มชุดเล็กที่ทีมรันเหมือนกัน local และ CI

## Coverage อย่างมีความหมาย

```powershell
python -m pytest --cov=src --cov-report=term-missing
```

ต้องติดตั้ง plugin ที่รองรับก่อน Coverage สูงแต่ไม่ assert outcome สำคัญยังเป็น test อ่อน ให้ใช้ missing lines เพื่อหา risk gaps แล้วเขียน behavior cases

## Pre-commit Ritual

```text
git status
  ↓
ตรวจ diff ที่จะส่ง
  ↓
format/lint/type check ตาม project
  ↓
targeted tests
  ↓
full tests ตามความเสี่ยง
  ↓
ตรวจ diff อีกครั้ง → commit
```

## Task Runner ทำไมมีประโยชน์

README ที่มี command ยาวหลายชุดอาจ drift ทีมอาจใช้ Makefile, scripts, tox/nox หรือ package manager scripts เพื่อให้ command มาตรฐาน เช่น `task test` แต่ต้องอ่านไฟล์ task ก่อนรัน เพราะชื่อสั้นอาจซ่อนการเปลี่ยน state

ตัวอย่าง PowerShell script ที่ตั้งใจให้สร้างภายหลัง:

```powershell
.\scripts\verify.ps1
```

ควรพิมพ์ขั้นตอนที่จะรัน, หยุดเมื่อ command สำคัญ fail และคืน exit code non-zero ให้ CI เข้าใจ

## Practice

สร้าง failure test หนึ่งข้อ รัน targeted จนเห็น fail แก้ code ให้ผ่าน แล้วรัน full suite + lint ดู `git diff` และอธิบายว่าแต่ละ command พิสูจน์อะไรและยังไม่พิสูจน์อะไร
