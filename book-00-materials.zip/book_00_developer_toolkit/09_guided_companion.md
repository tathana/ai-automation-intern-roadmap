# 09 — Guided Companion: จาก Command หนึ่งบรรทัดไปสู่ภาพทั้งระบบ

บทนี้ไม่ได้แทนบท 00–08 แต่ใช้เปิดคู่กันเมื่อคำว่า shell, PATH, process, environment, port, image หรือ state ยังดูเป็นนามธรรม

## 1. ตอนกด Enter เกิดอะไรขึ้น

สมมติ prompt แสดง:

```text
PS D:\work\resume-api>
```

แล้วพิมพ์:

```powershell
python -m pytest tests -q
```

ให้แยกภาพเป็นห้าชั้น:

```text
1 current directory = D:\work\resume-api
2 PowerShell แยก python | -m | pytest | tests | -q
3 PowerShell หา executable ที่ชื่อ python
4 Python process หา module pytest ใน environment ของมัน
5 pytest หา target tests จาก current directory แล้วคืน output + exit code
```

ดังนั้น error แต่ละชั้นคนละเรื่อง:

- `python is not recognized` — shell หา executable ไม่เจอ
- `No module named pytest` — พบ Python แต่ environment นี้ไม่มี pytest
- `file or directory not found: tests` — pytest เปิดได้ แต่ path target ไม่ตรง
- tests failed — เครื่องมือครบและพบ test แล้ว แต่ behavior ไม่ผ่าน

อย่าแก้ทุกอาการด้วย `pip install` เพราะอาจอยู่คนละชั้น

## 2. Path คือคำตอบของ “เริ่มจากที่ไหน ไปหาอะไร”

```powershell
Get-Content '.\config\settings.json'
```

อ่านทีละส่วน:

```text
.                 current directory
\config           เข้าโฟลเดอร์ config
\settings.json    เลือกไฟล์
```

ถ้าปัจจุบันอยู่ `D:\work\resume-api` path ที่ resolve คือ `D:\work\resume-api\config\settings.json` แต่ถ้าอยู่ `D:\work` คำสั่งเดิมจะมองคนละที่

### Flow ตรวจ path ก่อนสรุปว่าไฟล์หาย

```text
Get-Location
  ↓ อยู่ project root หรือไม่
Test-Path '.\config\settings.json'
  ↓ false
Get-ChildItem
  ↓ ดูชื่อจริง/ระดับโฟลเดอร์/นามสกุล
Resolve-Path <existing path>
```

ข้อความ “หาไฟล์ไม่เจอ” ไม่ได้แปลว่าไม่มีไฟล์เสมอไป อาจเริ่มจาก directory ผิด สะกด/case/extension ผิด หรือโปรแกรม resolve path จากตำแหน่งอื่น

## 3. Environment คือกระเป๋าเครื่องมือของ Python แต่ละชุด

```text
machine
├── system Python + packages ชุด A
└── project .venv Python + packages ชุด B
```

การ activate ช่วยให้ชื่อ `python` ชี้ไป `.venv` ก่อน แต่หลักฐานที่ชัดกว่าคือ:

```powershell
python -c "import sys; print(sys.executable)"
python -m pip --version
```

สองบรรทัดควรชี้ environment เดียวกัน การใช้ `python -m pip install ...` จึงชัดกว่า `pip install ...`: เราระบุว่าให้ **Python ตัวนี้** เปิด module pip

### Debug `import` แบบไม่เดา

```text
ตรวจ sys.executable
  ↓
ตรวจ python -m pip show <package>
  ↓
ตรวจชื่อ module ที่ import (อาจไม่เท่าชื่อ package)
  ↓
ตรวจ local file ชื่อชน เช่น fastapi.py
  ↓
ตรวจ project install/src layout
```

อย่า install ซ้ำจนกว่าจะรู้ว่า install เข้า interpreter ใด

## 4. Process, Port และ HTTP เป็นคนละชั้น

เมื่อเปิด server:

```powershell
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

```text
Python process
  ↓ imports app.main and reads variable app
Uvicorn process listens TCP 127.0.0.1:8000
  ↓ receives HTTP GET /health
FastAPI matches route/method
  ↓ validates and runs handler
response status/body
```

แปลอาการตามระยะที่ request ไปถึง:

| อาการ | หลักฐานว่าไปถึงไหน | ตรวจต่อ |
|---|---|---|
| connection refused | ยังไม่ถึง HTTP app | listener, process log, host/port |
| 404 | ถึง HTTP server | path/prefix/trailing slash |
| 405 | พบ path | method ที่ route รองรับ |
| 422 | พบ route และ validator | request schema/body/header |
| 500 | เข้า application แล้ว | traceback, dependency/state |

### `0.0.0.0` ทำไมเปิด browser ตรง ๆ ไม่ใช่แนวคิดที่ดี

`0.0.0.0` คือ bind instruction ให้ server ฟังทุก interface ที่มี ไม่ใช่ปลายทางเฉพาะสำหรับ client ในเครื่องให้ใช้ `127.0.0.1:port`; ระหว่าง Compose containers ใช้ service name/port ภายในตาม network

## 5. Environment Variable เดินทางอย่างไร

```powershell
$env:APP_ENV='development'
python -c "import os; print(os.getenv('APP_ENV'))"
```

```text
PowerShell process มี APP_ENV
        ↓ child inherits a copy
Python process อ่าน string "development"
        ↓ config layer parses + validates
application settings
```

การตั้งค่าหลัง process เปิดแล้วมักไม่เปลี่ยนค่าที่ process อ่านไป ต้อง restart ตาม design และค่าจาก environment เป็น string:

```python
raw = "false"
bool(raw)       # True เพราะเป็น string ที่ไม่ว่าง
```

จึงใช้ settings model/parser ที่นิยาม accepted values และ fail fast

## 6. Quality Commands ไม่ได้ทำงานซ้ำกัน

```text
formatter → จัดรูปแบบ
linter    → หา pattern/error บางประเภท
type check→ ตรวจสัญญาชนิดแบบ static
tests     → รัน behavior examples
```

format ผ่านไม่ได้แปลว่า function ถูก และ coverage สูงไม่ได้แปลว่า assertion ตรวจสิ่งสำคัญ ลำดับก่อน commit ที่อ่านง่าย:

```powershell
python -m ruff format --check .
python -m ruff check .
python -m pytest -q
git diff --check
git status
```

ถ้าโปรเจกต์มีคำสั่งมาตรฐานใน README/`pyproject.toml`/task runner ให้ใช้ของทีม เพราะ options และ test environment อาจต่างจากคำสั่งทั่วไป

## 7. Git เก็บ Snapshot และ History ไม่ใช่ระบบ Backup อัตโนมัติ

```text
working tree --git add--> staging area --git commit--> local history
                                                   --git push--> remote
```

`git status` บอก state, `git diff` บอก unstaged change, `git diff --staged` บอกสิ่งที่จะเข้า commit การ commit ไม่ได้ push และ push ไม่ได้ deploy เว้นแต่ pipeline ถูกออกแบบให้ทำเช่นนั้น

ก่อนคำสั่งเปลี่ยน state ให้ตอบ:

- อยู่ repo/branch ใด
- target file/commit/remote ใด
- เปลี่ยน local หรือ remote
- กู้กลับอย่างไรโดยไม่ทับงานคนอื่น

## 8. Docker Image กับ Container

```text
Dockerfile + build context --docker build--> image (template/read-only layers)
image + runtime config --docker run--> container process
container filesystem (ephemeral) + named volume (persistent by policy)
```

`COPY . .` มองเห็นเฉพาะ build context และอาจ copy secret/venv หาก `.dockerignore` ไม่ดี ส่วน environment variables/volumes/ports เป็น runtime concerns

### Port mapping

```text
browser http://127.0.0.1:8015
  ↓ host port 8015
Docker mapping 8015:8000
  ↓ container port 8000
Uvicorn must listen 0.0.0.0:8000 inside container
```

สลับ host/container port เป็นสาเหตุยอดนิยมของ “container healthy แต่เข้าไม่ได้”

## 9. n8n และ Database Commands เปลี่ยน State

การ import/activate workflow, execute migration, update rows และ replay webhook อาจมี side effect อย่าคิดว่าเป็นเพียง command line:

```text
command → credentials/config → target instance/database
        → state mutation → downstream side effects/audit
```

ตรวจ instance/environment, workflow/database identity, backup/export, dry-run และ idempotency ก่อนรัน โดยเฉพาะคำสั่งที่คัดลอกจากเครื่อง local ไป staging/production

## 10. Universal Debug Ladder

```text
1 reproduce ด้วย input เล็ก
2 capture exact command + cwd + version + output + exit code
3 classify: shell/path/env/process/network/HTTP/app/data/state
4 inspect closest evidence at failed boundary
5 change one variable
6 rerun same reproduction
7 add regression test/runbook note
```

### แบบฝึกสั้น

พบ `ModuleNotFoundError` หลัง activate `.venv` ให้เขียนหลักฐานสามบรรทัดที่จะเก็บก่อน install อะไรเพิ่ม คำตอบขั้นต่ำ:

```powershell
python -c "import sys; print(sys.executable)"
python -m pip --version
python -m pip show <package-name>
```

จากนั้นจึงเทียบกับ project dependency declaration และชื่อ import จริง

