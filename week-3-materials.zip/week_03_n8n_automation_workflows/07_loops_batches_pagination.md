# 07 — Loop, Batch และ Pagination

## หลาย items ไม่ได้แปลว่าต้องสร้าง loop เองเสมอ

หลาย node ของ n8n ประมวลผลแต่ละ item ให้ตามปกติอยู่แล้ว ส่งสาม items เข้า HTTP Request อาจเกิดสาม requests ตรวจพฤติกรรม node และ settings เช่น Execute Once ก่อนเพิ่ม Loop Over Items

Loop Over Items มีประโยชน์เมื่อต้องควบคุมเป็นชุดหรือเว้นจังหวะ ไม่ใช่เครื่องหมายที่จำเป็นสำหรับข้อมูลทุก array

## Batch คุมจังหวะของข้อมูลที่มีแล้ว

ตั้ง Batch Size = 2 กับ input 5 items แล้วดูชื่อ output บน UI: ต่อเส้น `loop` ไปงานใน batch และต่อกลับ Loop Over Items; ต่อ `done` ไปสรุปหลังครบทุกชุด

```text
5 items → Loop Over Items (2)
             ├─ loop → HTTP → Wait → กลับ Loop Over Items
             │          ชุด [1,2], [3,4], [5]
             └─ done → สรุปผลทั้งหมด
```

อย่าต่อ done กลับเข้าลูป และอย่าเปิด reset โดยไม่เข้าใจเงื่อนไข เพราะอาจทำให้เริ่มรายการเดิมใหม่ไม่จบ การตั้ง batch=2 ไม่ใช่คำรับประกันว่าเรียกพร้อมกันสอง requests: concurrency ขึ้นกับ node และการตั้งค่าด้วย

## Pagination ขอข้อมูลที่ยังไม่ได้โหลด

Batch แบ่งข้อมูลที่มีอยู่ ส่วน Pagination ขอหน้าถัดไปจาก API ตัวอย่าง mock ใช้ GET `/records?page=1` คืน `results` และ `next_page`

```text
page=1 → results=[R1,R2], next_page=2
page=2 → results=[R3,R4], next_page=3
page=3 → results=[R5],    next_page=null → หยุด
```

ตั้ง HTTP Request pagination ให้แก้ query `page` ตาม response `next_page` และหยุดเมื่อเป็น null ตรวจชื่อช่องของรุ่นที่ใช้อยู่ อาจใช้ expression `$response.body.next_page` ในบริบท pagination ซึ่งไม่ใช่ `$json` ของ input เดิม

หากยังไม่คุ้น built-in pagination ให้ทำสาม requests ด้วย page=1,2,3 เพื่อเข้าใจ contract ก่อน แล้วจึงทำ loop ที่มี state `page` และ `pages_seen` พร้อมเพดาน เช่น 20 หน้า

## Rate limit ไม่ใช่แค่เพิ่ม Wait

เมื่อได้ 429 อ่าน Retry-After หากบริการให้มา รองรับว่าค่าอาจเป็นจำนวนวินาทีหรือ HTTP date ตั้งเพดานรอและจำนวน attempts; ถ้าต้องรอนานให้เก็บงานไว้ retry ภายหลัง ไม่ค้าง flow ไม่จำกัด

สูตร backoff ตัวอย่าง: 1,2,4 วินาที พร้อม jitter เล็กน้อย เพื่อลดการที่หลายงานตื่นขึ้นยิงพร้อมกัน ตัวเลขนี้เป็น lab policy ไม่ใช่กฎของทุก API

## กรณีที่ต้องทดสอบ

0 items ต้องจบอย่างชัดเจน, 1 item ไม่หาย, 5 items ไม่มีซ้ำ, หน้าที่สองล้มเหลวไม่ทำให้หน้าที่หนึ่งถูกสร้างซ้ำ และ next_page เดิมวนกลับมาต้องถูกหยุดด้วย guard

