# Add-on — HR Resume Intake ก่อนเพิ่ม AI

เราจะช่วย HR รับและจัดคิวเอกสาร ไม่จัดอันดับหรือคัดคนออก สัปดาห์นี้ผลสำเร็จหมายถึง “ได้ processing task ที่ตรวจสอบได้” ไม่ใช่ “AI อ่าน resume แล้ว”

## Identity สามแบบที่ต้องไม่ปนกัน

| ชื่อ | หมายถึง | เปลี่ยนเมื่อไร |
|---|---|---|
| candidate_id | ผู้สมัครในระบบ | ไม่เปลี่ยนเพียงเพราะอัปเดตไฟล์ |
| file_hash | SHA-256 ของ bytes จริง | bytes เปลี่ยนจึงมีโอกาสได้ hash ใหม่ |
| task_id | งานประมวลผล | ขึ้นกับ dedup/version policy |

ใน lab ใช้ unique `(candidate_id, file_hash)` ผู้สมัครเดิมส่งไฟล์เดิมไม่สร้าง task ใหม่ คนละ candidate ส่งไฟล์เดียวกันได้คนละ task ไม่ใช้ hash ระบุตัวบุคคล ในงานหลายตำแหน่งอาจต้องเพิ่ม job_id หรือ processing_version ตามความหมายงาน

## ทางเดินข้อมูล

```text
รับ metadata + bytes สังเคราะห์
        ↓
ตรวจ extension + ขนาด decoded bytes + signature เบื้องต้น
        ├─ ผิด → rejected/review พร้อม reason
        ↓
คำนวณ SHA-256 จาก bytes (ไม่ใช่ชื่อไฟล์)
        ↓
ค้น/สร้าง task ภายใต้ UNIQUE constraint
        ├─ ซ้ำ → คืน task เดิม
        └─ ใหม่ → queued + audit
                         ↓
               Week 4 ค่อยมี worker/AI
```

## Lab ที่รันได้โดยไม่ต้องมี resume จริง

นำเข้า [03_hr_intake.json](../workflows/03_hr_intake.json) เปิด mock ก่อน แล้วรัน ตัวอย่างส่ง bytes ทดสอบที่ขึ้นต้น PDF แต่ไม่ใช่เอกสารสำหรับอ่านจริง เพื่อทดสอบ intake contract เท่านั้น

POST `/resume-intake` รับ candidate_id, filename, content_base64 API decode → ตรวจขนาด → คำนวณ hash เอง ห้ามเชื่อ file_hash จาก client โดยไม่ตรวจ bytes

Base64 เป็น encoding ไม่ใช่ encryption ใครเห็นก็ decode ได้ จึงยังเป็นข้อมูลที่ต้องปกป้อง และขนาด base64 ใหญ่กว่า binary จึงใช้เฉพาะไฟล์เล็กใน lab นี้

## ถ้ารับ binary จริงใน n8n

ไฟล์อยู่ใน binary property ซึ่งแยกจาก json ตรวจชื่อ property ใน output เช่น `data` อย่าคิดว่า `data` เป็นชื่อบังคับทุก node ถ้าปลายทางรับ multipart ให้ HTTP Request เลือก Form-Data → n8n Binary File แล้วตั้ง Input Data Field Name ตาม property จริง

endpoint ใน mock นี้รับ JSON/base64 **ไม่ใช่ multipart** ดังนั้นการฝึก binary upload ต้องสร้าง endpoint multipart เพิ่มเป็น stretch หรือแปลงด้วยวิธีที่ runtime รองรับก่อน อย่าตั้ง Form-Data แล้วยิง endpoint นี้แล้วคาดว่าจะผ่าน

## File validation ยังไม่ใช่เอกสารปลอดภัย

mock ตรวจ PDF header และโครงชื่อไฟล์หลักใน ZIP ของ DOCX แต่ไม่ได้ parse เอกสาร, ตรวจ malware, encrypted PDF, zip bomb หรือเนื้อหาภายใน ใช้ข้อมูลสังเคราะห์เท่านั้น งานจริงต้องมีขนาดจำกัดตั้งแต่ชั้นรับ request และ isolated parser/scanner ตามนโยบายบริษัท

## Test ที่ต้องทำ

1. ไฟล์เดิมชื่อใหม่ candidate เดิม → task เดิม
2. ไฟล์เดิมคนละ candidate → task ใหม่ แต่ hash เท่ากัน
3. bytes เปลี่ยน → hash ใหม่
4. เปลี่ยนชื่อ .exe เป็น .pdf แต่ bytes ไม่ใช่ PDF → 422
5. ไฟล์ใหญ่เกิน 100000 decoded bytes → 422 สำหรับ lab
6. API ล่ม → ไม่บอก HR ว่า queued ถ้ายังไม่ได้บันทึก

## Human Review และสิ่งที่ต้องทำต่อ

ให้สร้างคิว review สำหรับ invalid file หรือ intake failure โดยเก็บ reason และ reference ที่ไม่เปิดเผยเอกสารต่อสาธารณะ ตัว mock ยังไม่มี endpoint ตัดสินใจของ HR; ผู้เรียนต้องออกแบบ task state, reviewer identity และ audit เป็น deliverable ไม่สมมติว่ามีครบแล้ว

สิ่งที่ส่งท้ายบท: export ใหม่, test evidence และคำตอบ “ทำไมไฟล์ซ้ำจึงไม่เท่ากับคนเดียวกัน?” ขั้นนี้ปูทางให้ Week 4 เพิ่ม extraction, evidence validation และ human review โดยไม่ต้องรื้อ intake ใหม่

