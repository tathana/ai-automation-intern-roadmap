# Drills — ฝึกแยกทีละทักษะ

ให้ใช้ workflow ใหม่สำหรับแต่ละข้อ บันทึก input/output และประโยคสั้น ๆ ว่าเหตุใดจึงได้ผลนั้น ไม่ต้องทำทั้งระบบให้เสร็จก่อนจึงค่อยทดสอบ

## 1. Items Detective

สร้าง Code node คืน `[{json:{users:[{id:'U1'},{id:'U2'}]}}]` ทายจำนวน items ก่อนรัน จากนั้นเพิ่ม Split Out field users แล้วตรวจจำนวนใหม่

ผ่านเมื่อ: ก่อน Split Out มี 1 item หลังมี 2 และแต่ละคนยังมี ID ของตนเอง เพิ่มกรณี users=[] แล้วบันทึกว่า node ถัดไปถูกเรียกหรือไม่

คำใบ้: นับซอง `{json:...}` ชั้นนอก ไม่ใช่นับทุก object ที่อยู่ด้านใน

## 2. Expression Lab

สร้างสาม items: country ไม่มี key, country=null, country="" เพิ่ม field display_country ด้วย `??` แล้วเทียบกับ `||` จากนั้นเพิ่ม discount=0 และทายผลก่อนรัน

ผ่านเมื่อ: อธิบายได้ว่าทำไม `??` ไม่แทนข้อความว่างหรือ 0 และไม่ใช้ fallback ซ่อน event_id ที่จำเป็น

คำใบ้: ตาราง expected สำหรับ country ตามลำดับคือ UNKNOWN, UNKNOWN, ข้อความว่าง เมื่อใช้ `??`

## 3. Webhook Echo

สร้าง POST webhook รับ `{"event_id":"D3","amount_minor":100}` แล้วตอบ `{"received_event_id":"D3"}` ให้เพิ่ม Normalize คั่นกลาง ไม่อ่านจาก Webhook ย้อนหลังโดยไม่จำเป็น

ทดสอบ event_id หาย: ต้องตอบ validation error ที่ออกแบบไว้ ไม่ตอบ 200 พร้อม null โดยไม่รู้ตัว ผ่านเมื่อทดสอบทั้ง Test URL และ production URL ของ workflow lab ที่เปิดใช้งาน แล้วปิดหลังทดลอง

## 4. API Connector

ใช้ HTTP Request เรียก mock `/events` เปิด full response และ Never Error ตั้ง route 201/200 ไปผลสำเร็จ; 422 ไป rejected

ส่ง amount=-1 และ amount="100" ต้องเป็น 422 ทั้งคู่ใน mock ที่ strict ผ่านเมื่อไม่มี record ถูกสร้าง ตรวจ GET `/events/{id}` แล้วได้ 404 สำหรับ invalid cases

## 5. Batch และ Pagination

ดึง `/records` จนครบ 5 record ไม่หยุดที่หน้าแรก จากนั้นให้ Loop Over Items batch size=2 ส่งข้อมูลผ่าน Edit Fields เพิ่ม `processed=true` แล้วรวมสรุปหลัง done

ผ่านเมื่อ IDs คือ R1–R5 ครบไม่ซ้ำ และอธิบายได้ว่า pagination 3 หน้าไม่ใช่ batch 3 ชุด แม้จำนวนรอบบังเอิญเท่ากัน

## 6. Failure Recovery

ใช้ mode=transient กับ ID ใหม่ เพิ่ม retry แบบสูงสุด 3 attempts รวมครั้งแรก รออย่างน้อย 1 วินาทีต่อการลองใหม่ และใช้ ID เดิมทั้งหมด

ผ่านเมื่อเห็น 503,503,201 และ audit มี created เพียงหนึ่งครั้ง เปลี่ยนเป็น permanent แล้วต้องหยุดที่สาม ไม่วนไม่สิ้นสุด เปลี่ยนเป็น invalid amount แล้วต้องไม่ retry

## แบบบันทึกหลักฐาน

| Case | Input | Expected | Actual | Execution ID | สิ่งที่แก้ |
|---|---|---|---|---|---|
| D1 | users 2 คนใน array | 1 → 2 items | กรอกหลังรัน | กรอก | กรอก |

อย่านำ expected ไปใส่ actual โดยยังไม่ได้รัน ถ้าผิดให้บันทึกผลผิดก่อน แล้วค่อยเพิ่มผลหลังแก้ จะเห็นพัฒนาการและสาเหตุได้ชัดกว่า

