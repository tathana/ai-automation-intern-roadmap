# 03 — Items, JSON และ Expressions

## 1. Item คือหนึ่งซองข้อมูล

ลองนึกว่า node ส่งซองงานให้ node ถัดไป ในซองมีช่อง `json` เก็บข้อมูล และอาจมี `binary` สำหรับไฟล์

```json
[
  {"json": {"user_id": "U1", "amount_minor": 1200}},
  {"json": {"user_id": "U2", "amount_minor": 2500}}
]
```

นี่คือ **2 items** ไม่ใช่ 1 item เพราะ array ชั้นนอกมีสองซอง UI อาจแสดงเฉพาะข้อมูลด้านในจนมองไม่เห็นคำว่า `json` ทุกครั้ง

เปรียบเทียบกับ:

```json
[{"json": {"users": [{"user_id":"U1"}, {"user_id":"U2"}]}}]
```

นี่คือ **1 item ที่มี array อยู่ข้างใน** มีผู้ใช้สองคน แต่มีซองเดียว ถ้าจะส่งผู้ใช้ทีละคนให้ Split Out field `users` ก่อน

```text
1 item: {users: [U1, U2]}
          ↓ Split Out users
2 items: {user_id: U1}, {user_id: U2}
          ↓ node ที่ทำงานต่อ item
ดำเนินการกับ U1 และ U2
```

## 2. Expression อ่านค่าจากไหน

Expression คือค่าที่คำนวณตอนรัน ไม่ใช่ข้อความคงที่ ในช่อง expression ของ n8n เขียน:

```javascript
{{ $json.user_id }}
```

`$json` หมายถึง JSON ของ **item ปัจจุบัน** จุด `.` คือเข้าถึง field ชื่อ user_id ถ้า input เป็น `{"body":{"user_id":"U1"}}` ต้องเขียน `$json.body.user_id` เพราะมี body ครอบอีกชั้น

```text
$json                  → {body: {user_id: "U1"}}
$json.body             → {user_id: "U1"}
$json.body.user_id      → "U1"
```

ใน workflow JSON ที่ export อาจเห็น `={{ $json.user_id }}` เครื่องหมาย `=` เป็นรูปแบบที่ n8n บันทึก expression ไม่ต้องเติมลงใน JSON payload ที่ส่งให้ API

## 3. Optional field และค่าเริ่มต้น

```javascript
{{ $json.body.country ?? 'UNKNOWN' }}
```

`??` ใช้ค่าขวาเมื่อค่าซ้ายเป็น `null` หรือ `undefined` จึงต่างจาก Python `dict.get(key, default)` ที่ใช้ default เฉพาะ key ไม่มี หาก field มีค่า `""` จะยังคงเป็นข้อความว่าง ส่วน `||` ใช้ค่าขวากับ falsy values เช่น `0`, `false`, `""` ด้วย จึงอาจทำให้เลขศูนย์ที่ตั้งใจส่งมาหายไป

```javascript
{{ $json.discount ?? 10 }} // discount=0 → 0
{{ $json.discount || 10 }} // discount=0 → 10
```

สำหรับ field จำเป็น อย่าใส่ default เพื่อซ่อนปัญหา เช่น amount หายไม่ควรถูกแทนด้วย 0 แล้วส่งต่อว่าข้อมูลถูกต้อง

## 4. JavaScript ไม่ใช่ Python

Expression และ Code node ตัวอย่างในสัปดาห์นี้ใช้ JavaScript: `true`, `false`, `null` ไม่ใช่ `True`, `False`, `None`; `===` เทียบแบบไม่แปลงชนิด; `const` ประกาศตัวแปรที่ไม่ reassign; `return` ส่งผลออกจากฟังก์ชัน

```javascript
const amount = 1200;
const large = amount >= 1000;
// large เป็น boolean true ไม่ใช่ string "true"
```

ถ้า API ต้องการ integer อย่าส่ง `"1200"` โดยหวังว่าปลายทางจะแปลงให้เสมอ ตรวจ schema ของ Week 2 ประกอบ

## 5. Code node และ loop แบบอ่านง่าย

เลือก **Run Once for All Items** แล้วใส่:

```javascript
const output = [];
const inputs = $input.all();

for (let i = 0; i < inputs.length; i++) {
  const row = inputs[i].json;
  output.push({
    json: {
      ...row,
      needs_review: row.amount_minor >= 10000
    },
    pairedItem: { item: i }
  });
}

return output;
```

`inputs` เก็บทุก item; `i` เริ่ม 0; `i < inputs.length` ตรวจว่ายังมีรายการ; `i++` ขยับไปตัวถัดไป ส่วน `...row` คัดลอก field ชั้นบนมา แล้วเพิ่ม needs_review โดยไม่ทิ้ง user_id เดิม นี่เป็น shallow copy ไม่ได้ทำสำเนาวัตถุซ้อนทุกชั้น

`pairedItem` บอกว่า output นี้มาจาก input หมายเลขใด ช่วยให้ node ถัดไปอ้างข้อมูลย้อนหลังถูกคน อย่าคัดลอก index แบบนี้ไปใช้หลัง sort/filter โดยไม่คิด mapping ใหม่

## 6. อ่าน node ก่อนหน้าอย่างระมัดระวัง

```javascript
{{ $('Normalize').item.json.event_id }}
{{ $('Config').first().json.base_url }}
```

`.item` อาศัย item linking เพื่อหาข้อมูลที่สัมพันธ์กับ item ปัจจุบัน ส่วน `.first()` หยิบรายการแรกเสมอ เหมาะกับ Config ที่ตั้งใจมีหนึ่งรายการ ไม่ใช่วิธีแก้ linking error ของข้อมูลหลายผู้ใช้ เพราะอาจเอาข้อมูล U1 ไปใส่ U2

## ทดลองก่อนผ่านบท

สร้าง input สอง items ที่ user_id ต่างกัน แล้วเพิ่ม `label` ให้แต่ละคน ถ้าผลทั้งคู่เป็น U1 ให้ตรวจว่าคุณใช้ `.first()` ผิดตำแหน่งหรือไม่ ถ้า output เหลือหนึ่งรายการ ให้ตรวจว่ากำลังส่ง array ไว้ใน item เดียวหรือ return ไม่ครบ

## ชั้น Practice: อ่าน expression จากในออกนอก

expression นี้:

```javascript
{{ $json.body.amount_minor >= 10000 ? 'review' : 'auto' }}
```

ให้อ่านทีละช่วง:

```text
$json                       item ปัจจุบัน
  .body                     object ชื่อ body
    .amount_minor           ค่าที่ต้องการ
>= 10000                    คำถาม true/false
? 'review' : 'auto'         เลือกค่าตามคำตอบ
```

ถ้าผลผิด ให้ pin input เล็ก ๆ แล้วตรวจ `$json.body`, `$json.body.amount_minor` และ expression เต็มทีละขั้น อย่าแก้ expression ยาวทั้งก้อนจากการเดา

## ชั้น Deep Dive: Item กับ array ไม่เหมือนกัน

```text
กรณี A: 2 n8n items
item 0 → {user_id:"U1"}
item 1 → {user_id:"U2"}
node ส่วนมากทำงานต่อได้ 2 ครั้งตาม item

กรณี B: 1 n8n item ที่มี array
item 0 → {users:[{user_id:"U1"},{user_id:"U2"}]}
node ถัดไปเห็นเพียง 1 item จนกว่าจะ Split Out
```

นี่เป็นคำถามแรกที่ควรถามเมื่อ loop หรือ mapping ให้ผลแปลก: “เรามีกี่ n8n items และแต่ละ item มี field อะไร” ไม่ใช่เพียง “JSON มีข้อมูลกี่แถว”
