# 01 — Automation และ Orchestration

## ให้คิดว่า workflow เป็นขั้นตอนส่งต่องาน

สมมติมีคนส่งคำขอให้ทีมตรวจ transaction เราไม่ได้อยากให้เจ้าหน้าที่คัดลอก JSON ไปมา แต่ยังต้องรู้ว่ารายการใดตรวจแล้วและรายการใดรอแก้ไข

```text
เหตุการณ์เข้ามา (Trigger)
       ↓
จัดรูปข้อมูล (Transform)
       ↓
เรียกบริการตรวจ (Action)
       ↓
อ่านผลแล้วแยกทาง (Routing)
       ├─ accepted → บันทึกผล
       └─ rejected → ส่งให้แก้ข้อมูล
```

**Automation** คือให้ขั้นตอนเกิดเอง **Orchestration** คือประสานหลายขั้นตอนให้เป็นงานเดียว n8n เหมาะกับส่วนหลัง เพราะมองเห็นลำดับและจุดเชื่อมระบบได้

## Node ไม่ใช่กล่องเก็บความคิด แต่มี contract

ก่อนวาง node ให้เขียนสามบรรทัด: input คืออะไร, ทำอะไร, output คืออะไร เช่น node เรียก API รับ `event_id` และ `amount_minor` แล้วคืน `statusCode` กับ `body` ไม่ควรเดาว่า field เดิมจะติดมาด้วยเสมอ เพราะหลาย node เปลี่ยน output เป็นผลจากบริการ

**Execution** คือการทำงานหนึ่งรอบของ workflow ไม่ใช่รายการธุรกิจหนึ่งรายการเสมอ รอบหนึ่งอาจรับ 100 items หรือไม่มี item ออกมาเลยก็ได้

## อะไรควรอยู่ Python

| งาน | วางที่ไหน | เหตุผล |
|---|---|---|
| เลือกเวลาทำงาน/เรียก API | n8n | เห็น flow และแก้การเชื่อมต่อได้ง่าย |
| ตรวจข้อมูลหลายเงื่อนไข | Python API | เขียน unit tests และใช้ซ้ำได้ |
| บันทึก key ป้องกันซ้ำ | Database/API | ต้องรับมือ concurrent requests |
| แจ้งเตือนผล | n8n | เป็น integration แต่ต้องคิดเรื่องแจ้งซ้ำ |

อย่าแปลงกฎธุรกิจยาวทั้งชุดไปเป็น Code node เพียงเพราะใส่ได้ เก็บ Code node ไว้สำหรับการปรับข้อมูลสั้น ๆ ที่อ่านรู้เรื่อง

## ลองออกแบบก่อนคลิก

งาน: รับคำขอ refund แล้วส่งให้คนตรวจ **ไม่คืนเงินจริง** เขียน input เช่น `request_id`, `transaction_id`, `reason` และ output เช่น `review_task_id`, `status=pending_review` จะเห็นว่ารับคำขอสำเร็จต่างจากอนุมัติ refund แล้ว

จำหลักนี้ไว้: ชื่อสถานะต้องบอกสิ่งที่เกิดขึ้นจริง ไม่ใช่สิ่งที่เราหวังว่าจะเกิดในขั้นถัดไป

## ชั้น Core: อ่าน workflow ให้เหมือนอ่านประโยค

เมื่อเปิด workflow ที่ไม่เคยเห็น อย่าเริ่มจากไล่ดูค่าทุกช่อง ให้หาคำกริยาหลักก่อน:

```text
When?             What shape?          Do what?            Decide?          Record/notify?
Webhook      →    Normalize       →    Call API       →    Switch      →    Save result
เริ่มเมื่อไร       ข้อมูลหน้าตาใด        ทำงานอะไร            เลือกทางใด       ทิ้งหลักฐานอะไร
```

node แต่ละตัวควรตอบได้หนึ่งประโยค เช่น `Normalize Intake` คือ “รับ body จาก webhook แล้วคืน candidate_id และ file_ref ที่มีชื่อแน่นอน” หากต้องใช้คำว่า “และ” หลายครั้ง node อาจรับผิดชอบมากเกินไป

คำศัพท์ที่ควรรู้เมื่อคุยกับทีม:

- **control flow**: ลำดับและการแตกแขนงของงาน
- **data flow**: รูปร่างและค่าของข้อมูลที่เดินระหว่าง node
- **side effect**: การเปลี่ยนสิ่งภายนอก เช่นส่งอีเมลหรือสร้าง record
- **orchestrator**: ตัวประสานขั้นตอน ไม่จำเป็นต้องเป็นที่เก็บ business logic ทั้งหมด

## ชั้น Practice: เขียน contract บนกระดาษก่อนสร้าง node

ลองเขียน workflow รับ ticket โดยยังไม่เปิด n8n:

```text
Trigger input : {ticket_id, message}
Normalize     : {ticket_id, message, received_at}
Classify API  : {category, confidence, reasons}
Route         : confidence ต่ำ → review / อื่น ๆ → queue
Final record  : {ticket_id, status, category?, trace_id}
```

จากนั้นวงกลม field ที่ต้องติดตามตั้งแต่ต้นถึงท้าย เช่น `ticket_id` และ `trace_id` นี่คือ **correlation fields** หากหายกลางทาง เราจะตาม execution ได้แต่ตามรายการธุรกิจไม่ได้

## ชั้น Deep Dive: สีเขียวบอกเพียง node ไม่ throw error

node HTTP อาจได้ `200` แต่ body เป็น `{"status":"rejected"}`; node Filter อาจสำเร็จแต่ปล่อย 0 items; node ส่งอีเมลอาจสำเร็จแต่ส่งถึงผู้รับผิดคน ดังนั้น “สำเร็จ” ต้องนิยามด้วย business outcome และหลักฐาน ไม่ใช่สีบน canvas

เช็กลำดับนี้เมื่อรับช่วง workflow จากคนอื่น:

```text
เลือก execution จริงหนึ่งรอบ
        ↓
นับ input/output items ของแต่ละ node
        ↓
ตรวจ correlation field ยังอยู่หรือไม่
        ↓
ตรวจ branch ที่ไม่ได้เดินด้วย
        ↓
ระบุ side effect และจุดที่ replay แล้วอาจซ้ำ
```
