# 02 — สภาพแวดล้อมและการอ่าน Execution

## เริ่มจากของเดิมที่มีอยู่

เครื่องนี้ตรวจพบ n8n 1.115.3 แล้ว จึงไม่จำเป็นต้องติดตั้งซ้ำ เปิด instance ที่คุณใช้อยู่และสร้าง workflow ใหม่ชื่อ `W3 - Items Lab` อย่า import ทับงานเดิม และอย่าอัปเกรด instance ที่มีข้อมูลโดยยังไม่ได้สำรอง

ถ้ายังไม่ได้เปิด n8n และต้องการใช้ instance เดิม สามารถใช้ terminal:

```powershell
n8n --version
n8n start
```

คำสั่งหลังเปิดบริการและใช้ข้อมูลของบัญชีผู้ใช้ปัจจุบัน ดู URL ที่ terminal แสดง ถ้า port ถูกใช้อยู่ให้กลับไปเปิด instance เดิม ไม่ต้องลบ database เพื่อแก้

## พื้นที่ที่ควรดูทุกครั้ง

**Canvas** แสดงการต่อ node; **Parameters** เป็นค่าที่เราตั้ง; **Input/Output** เป็นข้อมูลจริงของการรัน; **Executions** เป็นประวัติรอบการทำงาน

```text
แก้ parameter
    ↓
รันด้วยข้อมูลสังเคราะห์
    ↓
ดู Input: ส่งเข้ามากี่ items?
    ↓
ดู Output: field หาย/เปลี่ยนชนิดไหม?
    ↓
ดู node ถัดไป ไม่สรุปจากสีเขียวเพียงอย่างเดียว
```

## Pinned Data คือข้อมูลทดแทนสำหรับการพัฒนา

เมื่อ API เรียกยากหรือเสียเงิน เราสามารถ pin output ตัวอย่างเพื่อพัฒนา node ถัดไปได้ แต่ผลที่ได้พิสูจน์เพียงว่า logic ทำงานกับข้อมูลที่ pin ไม่ได้พิสูจน์ว่าเชื่อม API จริงสำเร็จ

ก่อนทดสอบทั้ง flow ให้ unpin แล้วส่ง request ใหม่ การรัน production ไม่ได้ใช้ pinned data แบบการพัฒนา อย่าใช้ภาพผล pinned เป็นหลักฐาน integration test

## เปิด Mock API

ทำตาม [Lab README](lab/README.md) ใน terminal อีกหน้าหนึ่ง API ใช้ port 8013 เพื่อแยกจากงาน Week 2 ที่อาจใช้ 8000

| n8n อยู่ที่ไหน | API อยู่ที่ไหน | URL ที่ควรเริ่มตรวจ |
|---|---|---|
| บน Windows โดยตรง | Windows | `http://127.0.0.1:8013` |
| Docker Desktop | Windows | `http://host.docker.internal:8013` |
| Docker Compose เครือข่ายเดียวกัน | service ชื่อ api | `http://api:8013` |
| Cloud | เครื่องส่วนตัว | localhost ใช้ไม่ได้ ต้องมี endpoint ที่เข้าถึงได้อย่างปลอดภัย |

ใน Docker `localhost` หมายถึง container นั้นเอง ไม่ใช่ Windows host หากต้อง bind API ออกนอก loopback ให้ทำเฉพาะ lab ที่ควบคุม firewall ได้ ไม่แนะนำเปิด tunnel สาธารณะเพียงเพื่อผ่านแบบฝึก

## สมุดบันทึกทดลอง

บันทึกเวอร์ชัน n8n, workflow name, payload, expected/actual, execution ID และเวลาพร้อม timezone ใช้ metadata สังเคราะห์ ไม่แคป credentials หรือข้อมูลส่วนบุคคลติดไปด้วย

