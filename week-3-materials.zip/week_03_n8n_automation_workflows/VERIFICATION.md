# Verification — สถานะการตรวจชุดเรียน

วันที่ตรวจ: 10 กันยายน 2026

## ตรวจแล้ว

- Mock API tests: 18 tests ผ่าน รวม strict validation, duplicate/conflict, concurrent duplicate, 429/503, pagination และ resume identity/hash
- ใช้ test database แยก ไม่แตะฐานข้อมูลฝึกเดิมของผู้เรียน

## Workflow runtime

- นำเข้า workflow JSON ทั้ง 4 ไฟล์ผ่าน n8n CLI 1.115.3 สำเร็จ โดยใช้ user folder และ database สำหรับตรวจชุดนี้แยกจาก instance เดิม
- Items Lab: ได้ needs_review เป็น false และ true ตาม amounts ของสอง items
- API Probe: ได้ response succeeded จาก mock และรันซ้ำคืน duplicate โดยไม่สร้าง event ใหม่
- HR Synthetic Intake: สร้าง queued task จาก bytes สังเคราะห์ได้
- FlowGuard BROKEN: ยืนยันว่า API ตอบ 422 แต่ node สุดท้ายรายงาน succeeded จริง นี่คือ bug ที่โจทย์ต้องการให้แก้ ไม่ใช่ผลผ่านของ workflow ที่ถูกต้อง

## หนังสือและชุดดาวน์โหลด

- รวมเอกสาร Markdown 24 ไฟล์เป็น HTML; ตรวจ anchors ทุกจุด ไม่มี ID ซ้ำหรือ internal link ขาด
- มี code/flow blocks 36 ชุด และ archive source 35 ไฟล์
- ลิงก์ workflow ใช้ relative paths ไม่ใช้ file:/// ของเครื่องผู้เขียน
- ยังไม่ได้ทดสอบการคลิก UI ทุกขั้นตอนใน browser หรือ workflow บน n8n รุ่นอื่น

## สิ่งที่ผู้เรียนต้องทำเองตามโจทย์

FlowGuard starter จงใจมีข้อผิดพลาด ไม่ใช่ reference solution; bounded retry, production webhook, schedule, Error Workflow และ human review ต้องประกอบและทดสอบตาม Drills/Challenge ชุด API tests ไม่ได้พิสูจน์ว่า workflow ที่ผู้เรียนสร้างผ่านกรณีเหล่านี้แล้ว

ไฟล์ PDF bytes ตัวอย่างเป็น fixture สำหรับ intake validation ไม่ใช่ resume ที่เปิดอ่านได้ และ mock ไม่มี AI worker
