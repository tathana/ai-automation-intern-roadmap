# 08 — Error, Retry และ Recovery

## แยกความผิดพลาดก่อนตัดสินใจ retry

Retry คือการลองคำขอเดิมใหม่ ไม่ใช่วิธีแก้ทุกปัญหา ถ้า amount เป็น -1 การส่ง -1 อีกสิบครั้งก็ยังผิด schema

| สิ่งที่พบ | การตัดสินใจเริ่มต้น |
|---|---|
| 422 ข้อมูลไม่ถูก | rejected และบอก field ที่ต้องแก้ |
| 401/403 สิทธิ์ไม่ผ่าน | หยุดและตรวจ config/credentials |
| 409 key เดิม payload เปลี่ยน | review ความขัดแย้ง |
| 429 | รอตาม policy แล้วลองแบบมีขอบเขต |
| 503 | ลองใหม่แบบมีขอบเขต หาก operation ปลอดภัยต่อการทำซ้ำ |
| Timeout | ผลอาจไม่แน่นอน ตรวจสถานะหรือ retry ด้วย idempotency key เดิม |

## node สำเร็จ แต่ธุรกิจไม่สำเร็จได้

เมื่อเปิด Never Error แล้วรับ 503 node อาจจบปกติ แต่ระบบปลายทางยังทำงานไม่ได้ ต้อง inspect statusCode เอง ส่วน On Error แบบ Continue using error output ใช้ส่งข้อผิดพลาดไปเส้นทางเฉพาะ ตรวจ output จริงเพราะรูปทรง error ไม่จำเป็นต้องเหมือน HTTP response

อย่าเปิด Retry On Fail แบบเหมารวมให้ทุก error โดยไม่รู้ว่าสิ่งใดถือว่า fail โดยเฉพาะ Never Error ทำให้ HTTP 503 ที่ถูกคืนเป็นข้อมูลอาจไม่เข้า retry อัตโนมัติของ node

## วางขอบเขตให้ชัด

```text
attempt=1 → เรียก API
               ├─ สำเร็จ → succeeded
               ├─ ข้อมูลผิด → rejected
               └─ ชั่วคราว
                     ↓ attempt < 3 ?
                  ใช่ → Wait → attempt+1 → เรียกใหม่ด้วย key เดิม
                  ไม่ → retry_exhausted → review
```

คำว่า max attempts=3 ในแบบฝึกหมายถึงเรียกรวมครั้งแรกด้วยสามครั้ง ไม่ใช่ครั้งแรกบวก retry อีกสามครั้ง เก็บ counter ไว้ใน state ที่ไม่หายเมื่อ HTTP node เปลี่ยน output

## Error Workflow เป็นตาข่ายอีกชั้น

สร้าง workflow ใหม่เริ่มด้วย Error Trigger แล้วบันทึก workflow name, execution ID/URL ถ้ามี และ error message แบบไม่ใส่ payload ทั้งฉบับ จาก workflow หลักไป Settings เลือก Error Workflow นี้

ทดสอบด้วย workflow lab ที่เปิดใช้งานและล้มเหลวจาก trigger จริง เช่น Webhook → Stop And Error อย่าใช้ manual execution แล้วคาดว่าจะเกิด Error Trigger แบบเดียวกันทุกกรณี การผิดพลาดที่ถูกจับและแปลงเป็นข้อมูลไปแล้วอาจไม่ทำให้ workflow ทั้งรอบ failed จึงต้องมี audit ใน error branch ของเราเอง

## Recovery ต่างจาก Retry

Retry คือเครื่องลองอีกครั้ง ส่วน Recovery คือทำให้งานกลับไปอยู่ในสถานะที่ถูกต้อง อาจเป็นคนแก้ข้อมูลแล้วส่งใหม่ หรือ replay เฉพาะรายการที่ล้มเหลว ต้องตรวจ side effects ที่เกิดไปแล้วก่อนเริ่มใหม่ โดยเฉพาะ email และการสร้าง task

## ชั้น Core: Error มีอย่างน้อยสี่ชั้น

| ชั้น | ตัวอย่าง | สิ่งที่ต้องเก็บ |
|---|---|---|
| transport | timeout, DNS, connection reset | endpoint, attempt, elapsed |
| protocol | HTTP 401, 429, 503 | status, safe response excerpt |
| data/contract | field หาย, type ผิด, JSON พัง | reason code, schema version |
| business | duplicate conflict, policy reject | business key, outcome |

อย่ารวมทั้งหมดเป็น `something went wrong` เพราะวิธีแก้และผู้รับผิดชอบต่างกัน

## ชั้น Practice: สร้าง failure matrix ก่อนเปิด retry

```text
case=422        expected=rejected        retry=0
case=429        expected=retry_pending   retry<=3
case=503        expected=retry_pending   retry<=3
case=timeout    expected=unknown         ตรวจ idempotency ก่อน retry
case=conflict   expected=needs_review    retry=0
```

รันทีละกรณีด้วย event_id ใหม่ จด execution ID และตรวจ service state ด้วย ไม่พอที่จะเห็น error branch ถูกเปิด

## ชั้น Deep Dive: Continue On Fail เปลี่ยน error เป็น data

เมื่อตั้งให้ node ทำต่อแม้ผิดพลาด workflow อาจจบเป็น success เพราะ error ถูกส่งออกมาเป็น item แล้ว หน้าที่ของคุณคือ normalize error และ route อย่างชัดเจน มิฉะนั้น monitoring ระดับ workflow จะมองไม่เห็น business failure

```text
node throws → execution failed → Error Workflow อาจรับรู้
node never-error → output เป็น error data → ต้องมี IF/Switch + audit ของเรา
```
