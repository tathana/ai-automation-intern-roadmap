# FlowGuard — Runbook Template

คัดลอกไฟล์นี้เป็น `runbook.md` ในผลงานของคุณ แล้วแทนช่องที่ระบุ “กรอก” ด้วยสิ่งที่รันจริง ไม่ใส่ secrets

## Environment

- n8n version: กรอก
- Workflow name และ ID: กรอก
- Mock base URL: กรอก
- Test date/timezone: กรอก
- วิธีเริ่ม API: ดู [Lab](../lab/README.md) และระบุ environment ที่ใช้จริง

## ขั้นตอน smoke test

1. GET /health ต้องตอบ status=ok
2. Import workflow เป็นสำเนาใหม่และตรวจ URL
3. ส่ง event_id ใหม่ amount_minor=1200
4. ตรวจ API record แล้ว replay ด้วย key เดิม
5. ตรวจว่า created ครั้งเดียวและ duplicate ไม่สร้างผลข้างเคียงซ้ำ

## เมื่อเกิดเหตุ

| อาการ | จุดที่ตรวจ | วิธีแก้/ผู้รับผิดชอบ |
|---|---|---|
| 422 | body และ schema | กรอก |
| 429 | Retry-After และ attempt | กรอก |
| 503 เกินเพดาน | audit และ review queue | กรอก |
| Timeout | key และ record ใน API | กรอก |
| 409 | payload เดิมกับใหม่ | กรอก |

## Replay และหยุดระบบ

เขียนว่าเลือกเฉพาะ failed IDs อย่างไร, ทำไม key ต้องเดิม, ตรวจ notification ซ้ำอย่างไร และปิด trigger โดยไม่ลบ workflow/history อย่างไร ถ้ามีจุดที่ยังทำไม่ได้ให้บอกข้อจำกัดตรง ๆ

