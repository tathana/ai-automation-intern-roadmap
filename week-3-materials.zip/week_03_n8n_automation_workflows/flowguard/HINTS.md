# FlowGuard — คำใบ้เป็นลำดับ

## ระดับ 1: ดูข้อมูลก่อนดูเส้น

เปิด Seed Batch มี items เท่าไร? `events` อยู่ตรงไหน? ถ้า HTTP Request อ่าน `$json.event_id` แต่ input มีเพียง `$json.events` แสดงว่าเส้นต่อถูกก็ยังส่งผิดได้

## ระดับ 2: รักษา identity

อย่าสร้าง event_id จากเวลาปัจจุบันหรือ execution ID ให้ใช้ key จาก input ที่ stable แล้วเก็บ context แยกจาก HTTP response หลัง node เปลี่ยน output ให้ใช้ item linking อย่างถูกต้องหรือรวมกลับด้วย key ไม่ใช้ first() แก้ทุกปัญหา

## ระดับ 3: เปลี่ยน success จากคำประกาศเป็นข้อสรุป

ตรวจ statusCode และ body ตาม contract ก่อนสร้าง success result หาก Never Error คืน 503 เป็นข้อมูลปกติ ต้องแยกทางเอง อย่ารอ Error Workflow จับปัญหาที่ workflow ของคุณถือว่าปกติไปแล้ว

## ระดับ 4: ทดลองวงรอบสั้นที่สุด

เริ่ม transient เพียง 1 item เก็บ attempt=1,2,3 ให้ถูกก่อนขยายเป็น batch ระวังการใช้ counter ร่วมกันทั้ง batch เพราะรายการที่สองอาจได้รับ attempt ต่อจากรายการแรก

## ระดับ 5: เส้นทางแก้ที่เป็นไปได้

```text
Seed/Webhook → Normalize list → Split Out → Validate
                                             ├─ invalid → rejected result
                                             └─ valid → HTTP
                                                          ├─ accepted → result
                                                          ├─ conflict → review
                                                          └─ retryable → bounded retry → result
ทุกผล → Summary/Audit ตาม record_id → ตรวจจำนวนเท่ากับ input
```

ภาพนี้ไม่ใช่ผังสาย Merge ที่นำไปต่อได้โดยไม่ตั้งค่า ต้องตรวจว่า branch ใดมี items และเลือกวิธีรวมที่ไม่รอ input ที่ไม่มีการรัน หากเริ่มยากให้ทำ per-item sub-workflow คืนหนึ่ง result เสมอแล้วรวมที่ workflow หลัก

