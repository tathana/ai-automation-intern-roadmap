# Special Challenge — FlowGuard

ทีม Ops มี flow รับเหตุการณ์แล้วส่ง API แต่รายงานว่าสำเร็จทั้งที่ API ปฏิเสธ บางรายการซ้ำ บางรายการหาย หน้าที่คุณคือซ่อมและอธิบายหลักฐาน ไม่ใช่เพียงทำให้ execution จบ

## Starter ที่ตั้งใจให้ผิด

Import [flowguard_broken.json](../workflows/flowguard_broken.json) เป็น workflow ใหม่ อ่านชื่อ node และ code ก่อนรัน ทุก URL ต้องยังเป็น localhost ของ mock ไม่มี external notification

ข้อผิดใน starter มีอย่างน้อย: list ถูกเก็บใน item เดียว, อ่าน field ผิด path, เปลี่ยน business key ทุก execution, request ไม่รักษารูปแบบที่ API ต้องการ และรายงาน succeeded โดยไม่อ่าน HTTP response ยังไม่มี bounded retry/durable review จึงเป็นสิ่งที่ผู้เรียนต้องเพิ่ม ไม่ใช่ความสามารถที่มีแล้ว

## ข้อกำหนดของฉบับแก้

1. รับหนึ่งหรือหลาย events แล้วไม่ทิ้ง record
2. ใช้ event_id เดิมข้าม retries; payload เปลี่ยนกับ key เดิมต้อง review
3. 422 ไม่ retry; 429/503 retry ตาม policy รวมไม่เกิน 3 attempts
4. network timeout ไม่สรุปว่า operation ไม่เคยเกิด
5. ผลสรุปแยก succeeded/rejected/retry_exhausted/needs_review
6. export ไม่มี secrets และมี runbook ส่งต่อได้

## Test matrix

| Case | Input | Expected |
|---|---|---|
| A | ใหม่ normal | 201 แล้ว succeeded |
| B | ส่ง A ซ้ำ | 200 duplicate; record เดิม |
| C | key A แต่ amount ใหม่ | 409 needs_review |
| D | amount=-1 | 422 rejected; ไม่ retry |
| E | ใหม่ transient | 503,503,201; created ครั้งเดียว |
| F | ใหม่ permanent | 503 สามครั้ง; retry_exhausted |
| G | ใหม่ rate_limit | 429 แล้ว 201; เคารพเวลารอ |
| H | input ว่าง | summary 0 records; ไม่มี success ปลอม |
| I | batch มีทั้ง valid/invalid | สรุปครบทุก input ไม่หยุดหายครึ่งทาง |
| J | หยุด mock แล้วเรียก | error/unknown ที่ตามแก้ได้ ไม่ succeeded |

## เกณฑ์คะแนน 100

Data shape/expressions 20, routing ตามข้อเท็จจริง 20, retry/recovery 20, idempotency/audit 20, tests/runbook/privacy 20 ผ่าน 80 และ **ห้ามมี false success, retry ไม่สิ้นสุด หรือ secret ใน export** แม้คะแนนรวมถึง

## ส่งอะไร

`flowguard_fixed.json`, `test_results.md`, `runbook.md` และคำอธิบาย before/after ของอย่างน้อย 3 bugs ตัวอย่างชื่อไฟล์เป็นสิ่งที่คุณต้องสร้าง ไม่ได้ใส่เฉลยสำเร็จไว้ล่วงหน้า

อ่าน [Hints](HINTS.md) เมื่อทดลองเองแล้วติด ไม่จำเป็นต้องแก้ครบในครั้งเดียว
