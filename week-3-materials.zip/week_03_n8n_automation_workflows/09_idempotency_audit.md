# 09 — Idempotency, Deduplication และ Audit

## ทำไม webhook เดิมมาสองครั้ง

ผู้ส่งอาจไม่ได้รับ response ทั้งที่ server บันทึกแล้ว จึงส่งซ้ำ นี่เป็นเรื่องปกติของระบบเครือข่าย การป้องกันซ้ำจึงต้องออกแบบ ไม่ใช่หวังว่าผู้ส่งจะไม่กดอีกครั้ง

```text
ผู้ส่ง → E101 → API บันทึกสำเร็จ
                  ↓ response หายระหว่างทาง
ผู้ส่ง → E101 อีกครั้ง → คืนผลเดิม ไม่สร้างงานใหม่
```

**Deduplication** ตรวจว่าข้อมูลซ้ำหรือไม่ ส่วน **Idempotency** รับประกันตาม contract ว่าการทำ operation เดิมซ้ำไม่เพิ่มผลข้างเคียง ตัวอย่างนี้ใช้ event_id เป็น key ของ operation สำหรับระบบจริงมักต้องเพิ่ม source/tenant เพื่อป้องกัน key ชนกัน

## ไม่ใช้ execution ID เป็น business key

Execution ID เปลี่ยนทุกครั้งที่รัน หากใช้มันป้องกันซ้ำ request ที่ retry จะมี key ใหม่ทันที ใช้ ID ที่คงเดิมข้าม retries เช่น event_id จากผู้ส่ง พร้อมตรวจว่า payload เดิมจริง

กรณี E101 amount=1200 แล้วส่ง E101 amount=9000 ไม่ควรคืน succeeded เงียบ ๆ mock จะตอบ 409 เพราะ key เดิมมีความหมายใหม่

## ทำไม check ก่อน insert ยังไม่พอ

```text
Request A: ไม่พบ E101 ─┐
Request B: ไม่พบ E101 ─┤ เกิดพร้อมกัน
                       ↓
ถ้าไม่มี UNIQUE ทั้งคู่สามารถ insert ได้
```

ให้ฐานข้อมูลมี unique constraint และทำการตรวจ/บันทึกใน transaction อย่าใช้ JavaScript Set ใน Code node เป็นหลักฐานว่า dedup ข้าม executions ได้ เพราะหน่วยความจำและ lifecycle ไม่ใช่ durable store

Remove Duplicates ช่วยงานบางแบบได้ แต่ต้องแยกโหมดตรวจภายใน input กับข้าม execution และทดสอบ concurrency/retention ของโหมดที่ใช้ ไม่แทนฐานข้อมูลโดยอัตโนมัติ

## สถานะควรแยกให้ตามงานได้

`received` รับเข้าแล้ว, `processing` เริ่มทำ, `succeeded` ทำตาม contract เสร็จ, `rejected` ข้อมูลไม่ผ่าน, `retry_pending` รอลองใหม่, `needs_review` ต้องให้คนตรวจ `duplicate` มักเป็นผลของการรับซ้ำ ไม่จำเป็นต้องเขียนทับสถานะธุรกิจเดิม

Audit record ควรมี event_id, attempt, stage, outcome, timestamp และ execution_id ที่สัมพันธ์กัน เก็บ record การเปลี่ยนแปลงเพิ่ม ไม่เขียนทับประวัติทั้งหมดด้วยข้อความล่าสุด

## Side effect ถัดไปยังซ้ำได้

แม้ API สร้าง task เพียงครั้งเดียว แต่ node ส่ง email หลัง API อาจส่งซ้ำทุกครั้งที่ workflow replay ใช้ notification key แยก หรือ outbox pattern ในระบบจริง อย่าเรียก flow ทั้งระบบว่า exactly-once จากการมี unique event_id เพียงจุดเดียว

## ชั้น Practice: แยกสามรหัสให้ออก

```text
execution_id  = รอบที่ n8n ทำงาน เช่น 9182
event_id      = เหตุการณ์ที่ผู้ส่งตั้ง เช่น PAY-2026-001
idempotency_key = ขอบเขต side effect เช่น notify:PAY-2026-001:review-v1
```

หนึ่ง event อาจมีหลาย executions เพราะ retry/replay แต่ side effect เดียวควรตรวจ idempotency key ก่อนสร้างซ้ำ

ตัวอย่าง state transition ที่ audit อ่านรู้เรื่อง:

```text
09:00 received      attempt=0 execution=9182
09:00 processing    attempt=1 execution=9182
09:01 retry_pending attempt=1 reason=upstream_503
09:03 processing    attempt=2 execution=9190
09:03 succeeded     attempt=2 result_id=R77
```

## ชั้น Deep Dive: key เดิมแต่ payload ต่างกัน

ถ้า `event_id=E1` เคยรับ amount 1200 แล้วคำขอใหม่ใช้ E1 กับ amount 9000 ไม่ควรตอบ duplicate success เฉย ๆ เก็บ hash ของ payload ที่มีนัยสำคัญแล้วตอบ conflict/review นี่ช่วยตรวจ caller ที่ reuse key ผิด

Idempotency ไม่ได้แปลว่าทุกอย่างเกิด “ครั้งเดียวทั่วจักรวาล” แต่แปลว่าการเรียกซ้ำในขอบเขตที่กำหนดให้ผลธุรกิจที่ควบคุมได้
