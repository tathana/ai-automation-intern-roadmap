# 17 — Real Team Workflow Lifecycle: จากโจทย์ถึง Production Execution

## ภาพวงจรจริง

<div class="n8n-board"><div class="n8n-flow"><div class="n8n-state">Discover<br><small>process + owner</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Design<br><small>contract + failure</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Develop<br><small>synthetic + pin</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Review<br><small>JSON + docs</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Stage<br><small>real dependency</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Publish<br><small>limited rollout</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Operate<br><small>executions + recovery</small></div></div></div>

## 1. Discovery ก่อน Canvas

ทีมที่ทำงานดีไม่ได้เปิด node search ทันที แต่ขอดู current process, input/output จริงที่ได้รับอนุญาต, owner, baseline, failure และ side effect แล้วเขียน node contract บนกระดาษ

## 2. Development

- ใช้ development instance/project/workflow copy
- synthetic data ก่อน; pin เฉพาะพัฒนา node ปลายทาง
- ตั้งชื่อ node ด้วย verb + object เช่น `Normalize Intake`
- แยก config/credential reference จาก logic
- ทดสอบ node ทีละจุดและ whole flow
- unpin ก่อน integration test

## 3. Review

ส่ง workflow JSON/ระบบ source control ตาม plan ที่มี พร้อม README, sample payload, expected cases, credential names, environment URL mapping และ runbook ผู้ตรวจดู logic change ไม่ใช่เพียงตำแหน่งกล่อง

ฟีเจอร์ source control/environments และ RBAC ขึ้นกับแผนของ n8n ห้ามเขียน playbook ที่สมมติว่าทุก instance มี ให้มี fallback เป็น export/review/import ที่ควบคุมและ audit ได้

## 4. Staging

```text
saved workflow
  ↓ map staging credentials/config
publish/activate ตามรุ่นและ policy
  ↓ test trigger จริง
inspect execution + downstream state
  ↓ invalid/duplicate/timeout/replay
owner sign-off
```

การ push saved workflow ไม่จำเป็นต้องเท่ากับ published version ในปลายทาง จึงต้องตรวจทั้ง version และ publish state

## 5. Production Rollout

- ปิด/จำกัด side effect ก่อนเมื่อทำได้
- เริ่ม sample/tenant/ช่วงเวลาจำกัด
- ตั้ง execution retention/alert/owner
- ตรวจ queue/oldest age/failure categories และ downstream state
- มีวิธี disable trigger โดยไม่ลบหลักฐาน

## 6. Incident และ Replay

```text
execution failed
  ↓ capture ID + version + input summary
side effect เกิดแล้วหรือยัง?
  ├─ unknown → query source of truth/idempotency record
  ├─ yes → do not blindly replay
  └─ no  → fix cause, replay with same business key
  ↓ verify execution + downstream state
```

## Artifact ที่ทีมควรได้รับ

- workflow JSON/source-controlled version
- node/data/failure diagram
- credential/config inventory ไม่มี secrets
- test cases และ execution evidence
- runbook, owner, disable/replay/rollback
- limitations และ plan/feature assumptions

