# 06 — จัดรูปข้อมูลและแยกเส้นทาง

## Edit Fields: ตั้งชื่อและเลือก field

หลัง Webhook ให้สร้าง Edit Fields ชื่อ `Normalize` เพิ่ม `event_id` แบบ String จาก `$json.body.event_id` และ `amount_minor` แบบ Number จาก `$json.body.amount_minor` โดยตรวจ input ว่าเป็น number จริง อย่าใช้การแปลงชนิดแทน validation ทั้งหมด

หากเลือกเก็บเฉพาะ fields ที่ตั้งไว้ `headers` และ `body` เดิมจะไม่อยู่ใน output ซึ่งเป็นเรื่องดีเมื่ออยากลดข้อมูลที่ส่งต่อ แต่ต้องเก็บ correlation ID ที่จะใช้ตามงานไว้ด้วย

```text
{headers: ..., body: {event_id:E1, amount_minor:1200}}
              ↓ เลือกสิ่งที่ต้องใช้
{event_id:E1, amount_minor:1200}
```

## IF: คำถามที่มีสองคำตอบ

ตัวอย่างเงื่อนไข amount_minor มากกว่า 0: true ส่งตรวจต่อ, false ส่ง validation error อย่าทำ true branch อย่างเดียว เพราะ false branch ที่ไม่มีการจัดการอาจทำให้ webhook ไม่ตอบตามที่ตั้งใจ

`"false"` เป็น string ไม่ใช่ boolean `false` การเทียบผิดชนิดเป็นสาเหตุที่ flow เลี้ยวผิดทาง ตรวจชนิดใน JSON view ก่อนแก้เงื่อนไข

## Switch: หลายสถานะต้องมีทางสำรอง

หลัง HTTP Request ตั้ง route สำหรับ 2xx, 422, 429, 503 และ fallback โดยไม่จำเป็นต้องแยกทุก code เป็น node ต่างหาก fallback ควรเก็บเหตุผลและเข้าคิวตรวจ ไม่ทิ้ง items เงียบ ๆ

ตัวอย่าง 409 ใน mock หมายถึง event_id เดิมแต่ payload เปลี่ยน จึงควร review ไม่ควรถือเป็น duplicate ที่สำเร็จแล้ว

## Split Out กับ Aggregate ทำงานคนละทิศ

```text
{results:[A,B,C]}   1 item
      ↓ Split Out field results
A    B    C         3 items
      ↓ Aggregate ให้เป็น field results
{results:[A,B,C]}   1 item
```

Split Out ใช้เปิดรายการใน array ให้ node ถัดไปทำต่อ item ส่วน Aggregate ใช้รวมผลเพื่อสรุป เช่นจำนวนสำเร็จ/ผิดพลาดก่อนตอบกลับ การมี 0 items อาจทำให้ node ถัดไปไม่รัน ต้องวางแผนกรณี input ว่างด้วย

## Merge: อย่าจับคู่จากตำแหน่งโดยไม่ดู ID

สมมติ input 1 คือ U1,U2 แต่ input 2 จาก API กลับเป็น U2,U1 ถ้ารวมตาม position จะได้ข้อมูลผิดคน เลือก matching field เช่น user_id เมื่อความสัมพันธ์เป็น join ด้วย ID

```text
ฝั่ง A: U1=Ann, U2=Ben
ฝั่ง B: U2=approved, U1=pending
           ↓ match user_id
U1=Ann+pending, U2=Ben+approved
```

ตรวจ missing key และ duplicate key ด้วย เพราะหนึ่ง ID ที่ซ้ำหลายแถวอาจทำให้จำนวนผลลัพธ์เพิ่ม ไม่ใช่ bug ของการแสดงผล อย่าใช้ Merge เป็นทางรวมทุก branch ของ IF โดยไม่ดูว่า node ต้องรอ input ใดและรุ่นที่ใช้ทำงานอย่างไร

## ชั้น Practice: Normalize ก่อน Route

การแยกสองหน้าที่นี้ช่วย debug:

```text
Webhook output ที่ซ้อนหลายชั้น
        ↓ Normalize — ตั้งชื่อ/ชนิด/เก็บเฉพาะที่ใช้
{event_id:"E1", amount_minor:1200, trace_id:"T1"}
        ↓ Validate — ข้อมูลใช้ได้ไหม
valid ─────────────── invalid
  ↓                      ↓
Call API             Respond 422
        ↓ Route outcome — API ตอบว่าอย่างไร
success / retry / review / reject
```

ถ้า route ผิด ให้ตรวจ value และ type ที่หน้า Input ของ IF/Switch เช่น `"1200"` เป็น string ต่างจาก `1200` เป็น number การ cast เป็น number แล้วได้ `NaN` ต้องถูกจัดเป็น invalid ไม่ควรไหลต่อ

## ชั้น Deep Dive: Merge ต้องกำหนด cardinality

**Cardinality** คือความสัมพันธ์จำนวน record เช่น one-to-one หรือ one-to-many ก่อน merge ให้ตอบว่า key หนึ่งค่าควรจับคู่ได้กี่รายการ

```text
candidate 1 คน : resume 1 ฉบับล่าสุด     → one-to-one ตาม policy
candidate 1 คน : interview notes หลายอัน → one-to-many
```

หากคิดว่า one-to-one แต่ input มี key ซ้ำ ให้หยุด/route review แทนเลือกแถวแรกเงียบ ๆ เพราะผลลัพธ์อาจผูกข้อมูลข้ามรายการ
