# Lab — Mock API สำหรับ Week 3

บริการนี้จำลองเหตุการณ์ด้วย SQLite บนเครื่อง ไม่ทำธุรกรรมจริง ไม่ส่งข้อความออก และไม่มี authentication จึงรันเฉพาะ loopback ห้าม deploy API นี้ไป Vercel หรือเปิดรับข้อมูลจริง

## เริ่มบริการ

เปิด PowerShell ที่โฟลเดอร์ `lab` แล้วใช้ environment ใหม่:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8013
```

เปิด `http://127.0.0.1:8013/docs` เพื่อทดลอง API หากมี environment ที่ติดตั้ง dependencies อยู่แล้ว ใช้ environment นั้นได้ ไม่ต้องติดตั้งซ้ำ requirements ระบุช่วงที่รองรับ ไม่ใช่ lockfile สำหรับ production

## Contract และ failure modes

POST `/events` รับ event_id แบบ string, amount_minor แบบ integer บวก และ mode ตัวเลือก ขนาดเงินใช้หน่วยย่อย เช่น 1200 สตางค์ = 12 บาท ตัวอย่างนี้ไม่คำนวณเงินจริง

| mode | ผลสำหรับ event_id ใหม่ |
|---|---|
| normal | 201; ครั้งถัดไป 200 duplicate |
| transient | 503, 503, 201 ตามลำดับ attempts |
| rate_limit | 429 พร้อม Retry-After=1 แล้ว 201 |
| permanent | 503 ทุกครั้ง ใช้ทดสอบ retry exhausted |

attempt counter เก็บข้าม request และการ restart ด้วย SQLite ใช้ key ใหม่สำหรับการทดลองรอบใหม่ Invalid schema 422 เกิดก่อนเข้า handler จึงไม่มี audit ของ event ใน mock นี้ ต้องบันทึก validation error ที่ workflow เอง mode ใช้จำลองความขัดข้อง ไม่เป็นส่วนของ business payload สำหรับตรวจ conflict

```powershell
$w3Payload = @{event_id='LAB-NEW-1'; amount_minor=1200; mode='normal'} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8013/events' -ContentType 'application/json' -Body $w3Payload
Invoke-RestMethod -Uri 'http://127.0.0.1:8013/events/LAB-NEW-1'
Invoke-RestMethod -Uri 'http://127.0.0.1:8013/audit/LAB-NEW-1'
```

## Reset แบบไม่ลบหลักฐาน

หยุดบริการด้วย Ctrl+C แล้วตั้ง `$env:W3_DB_PATH = 'week3_round2.sqlite3'` ก่อนเปิดใหม่ จะเริ่ม database lab ใหม่ เก็บไฟล์เก่าไว้ตรวจสอบ ไม่ลบฐานข้อมูลอื่นในเครื่อง

## ข้อจำกัดที่ตั้งใจไว้

ไม่มี background worker: resume task queued จะไม่ถูกประมวลผลเอง ไม่มี notification, OCR, malware scan หรือระบบ HR login เป็นชุดฝึก contract และ failure handling ไม่ใช่ระบบพร้อมใช้จริง การตรวจ signature ของไฟล์เป็นเพียงเบื้องต้น ไม่ยืนยันว่า parse ได้หรือปลอดภัย

