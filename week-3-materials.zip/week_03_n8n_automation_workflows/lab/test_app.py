import base64
import io
import zipfile
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient
from app import create_app


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path / "test.sqlite3")) as instance:
        yield instance


def event(client, key="E1", amount=1200, mode="normal"):
    return client.post("/events", json={"event_id": key, "amount_minor": amount, "mode": mode})


def test_health(client):
    assert client.get("/health").json()["status"] == "ok"


def test_duplicate_and_conflict(client):
    assert event(client).status_code == 201
    result = event(client)
    assert result.status_code == 200 and result.json()["duplicate"] is True
    assert event(client, amount=9999).status_code == 409
    assert client.get("/events/E1").json()["amount_minor"] == 1200


@pytest.mark.parametrize("amount", [-1, 0, "1200", True])
def test_invalid_amount(client, amount):
    assert event(client, amount=amount).status_code == 422
    assert client.get("/events/E1").status_code == 404


def test_transient(client):
    assert [event(client, mode="transient").status_code for _ in range(3)] == [503, 503, 201]
    outcomes = [r["outcome"] for r in client.get("/audit/E1").json()["records"]]
    assert outcomes == ["http_503", "http_503", "created"]


def test_rate_limit(client):
    first = event(client, mode="rate_limit")
    assert first.status_code == 429 and first.headers["retry-after"] == "1"
    assert event(client, mode="rate_limit").status_code == 201


def test_permanent(client):
    assert [event(client, mode="permanent").status_code for _ in range(3)] == [503]*3
    assert client.get("/events/E1").status_code == 404


def test_pagination(client):
    page, ids = 1, []
    while page is not None:
        data = client.get("/records", params={"page": page}).json()
        ids.extend(row["record_id"] for row in data["results"])
        page = data["next_page"]
    assert ids == ["R1", "R2", "R3", "R4", "R5"]


def test_concurrent_duplicate(client):
    with ThreadPoolExecutor(max_workers=4) as pool:
        statuses = list(pool.map(lambda _: event(client).status_code, range(4)))
    assert sorted(statuses) == [200, 200, 200, 201]


def resume(data=b"%PDF-1.4\nsynthetic lab bytes\n%%EOF", candidate="C1", filename="synthetic.pdf"):
    return {"candidate_id": candidate, "filename": filename, "content_base64": base64.b64encode(data).decode()}


def test_resume_hash_and_identity(client):
    first = client.post("/resume-intake", json=resume()).json()
    again = client.post("/resume-intake", json=resume(filename="renamed.pdf")).json()
    other = client.post("/resume-intake", json=resume(candidate="C2")).json()
    assert again["duplicate"] is True and again["task_id"] == first["task_id"]
    assert other["task_id"] != first["task_id"]
    assert other["file_hash"] == first["file_hash"]
    assert first["status"] == "queued"


@pytest.mark.parametrize("data,filename", [(b"text", "fake.pdf"), (b"%PDF-"+b"x"*100000, "big.pdf"), (b"%PDF-1.4", "bad.exe"), (b"PKxxx", "bad.docx")], ids=["fake_pdf", "oversized", "bad_extension", "bad_docx"])
def test_resume_invalid(client, data, filename):
    assert client.post("/resume-intake", json=resume(data, filename=filename)).status_code == 422


def test_docx_container(client):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr("[Content_Types].xml", "<Types/>")
        archive.writestr("word/document.xml", "<document/>")
    assert client.post("/resume-intake", json=resume(buffer.getvalue(), filename="sample.docx")).status_code == 201


def test_invalid_base64(client):
    payload = resume()
    payload["content_base64"] = "not base64!"
    assert client.post("/resume-intake", json=payload).status_code == 422
