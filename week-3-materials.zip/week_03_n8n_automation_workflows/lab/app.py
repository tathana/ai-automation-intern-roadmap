"""Local-only, synthetic Week 3 service. Not a payment or production API."""
import base64
import binascii
import hashlib
import io
import os
import sqlite3
import zipfile
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field


class Event(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    event_id: str = Field(min_length=1, max_length=100)
    amount_minor: int = Field(gt=0, le=10_000_000)
    mode: Literal["normal", "transient", "rate_limit", "permanent"] = "normal"


class Resume(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    candidate_id: str = Field(min_length=1, max_length=100)
    filename: str = Field(min_length=1, max_length=200)
    content_base64: str = Field(min_length=1, max_length=150_000)


def create_app(db_path=None):
    database = Path(db_path or os.environ.get("W3_DB_PATH", "week3_lab.sqlite3"))
    database.parent.mkdir(parents=True, exist_ok=True)

    def connect():
        con = sqlite3.connect(database, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS events (
          event_id TEXT PRIMARY KEY, amount_minor INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts (
          event_id TEXT PRIMARY KEY, count INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS audit (
          id INTEGER PRIMARY KEY, event_id TEXT NOT NULL,
          outcome TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS resume_tasks (
          task_id INTEGER PRIMARY KEY, candidate_id TEXT NOT NULL,
          file_hash TEXT NOT NULL, status TEXT NOT NULL,
          UNIQUE(candidate_id, file_hash));
        """)

    app = FastAPI(title="Week 3 Local Synthetic Lab")

    @app.get("/health")
    def health():
        return {"status": "ok", "scope": "local synthetic lab"}

    @app.post("/events")
    def submit(event: Event):
        with connect() as con:
            con.execute("BEGIN IMMEDIATE")
            old = con.execute("SELECT * FROM events WHERE event_id=?", (event.event_id,)).fetchone()
            if old:
                if old["amount_minor"] != event.amount_minor:
                    con.execute("INSERT INTO audit(event_id,outcome) VALUES (?,?)", (event.event_id, "conflict"))
                    return JSONResponse({"status": "conflict", "event_id": event.event_id}, status_code=409)
                con.execute("INSERT INTO audit(event_id,outcome) VALUES (?,?)", (event.event_id, "duplicate"))
                return {"event_id": event.event_id, "status": "succeeded", "duplicate": True}
            con.execute("INSERT INTO attempts VALUES (?,1) ON CONFLICT(event_id) DO UPDATE SET count=count+1", (event.event_id,))
            attempt = con.execute("SELECT count FROM attempts WHERE event_id=?", (event.event_id,)).fetchone()[0]
            status = 200
            if event.mode == "permanent" or (event.mode == "transient" and attempt <= 2):
                status = 503
            elif event.mode == "rate_limit" and attempt == 1:
                status = 429
            if status != 200:
                con.execute("INSERT INTO audit(event_id,outcome) VALUES (?,?)", (event.event_id, f"http_{status}"))
                return JSONResponse({"event_id": event.event_id, "status": "retryable_error", "attempt": attempt}, status_code=status, headers={"Retry-After": "1"})
            con.execute("INSERT INTO events VALUES (?,?)", (event.event_id, event.amount_minor))
            con.execute("INSERT INTO audit(event_id,outcome) VALUES (?,?)", (event.event_id, "created"))
            return JSONResponse({"event_id": event.event_id, "status": "succeeded", "duplicate": False}, status_code=201)

    @app.get("/events/{event_id}")
    def get_event(event_id: str):
        with connect() as con:
            row = con.execute("SELECT * FROM events WHERE event_id=?", (event_id,)).fetchone()
            if row is None:
                raise HTTPException(404, "Event not created")
            return dict(row)

    @app.get("/audit/{event_id}")
    def audit(event_id: str):
        with connect() as con:
            return {"records": [dict(row) for row in con.execute("SELECT * FROM audit WHERE event_id=? ORDER BY id", (event_id,))]}

    @app.get("/records")
    def records(page: int = 1):
        if page < 1:
            raise HTTPException(422, "page must be >= 1")
        rows = [{"record_id": f"R{i}"} for i in range(1, 6)]
        start = (page - 1) * 2
        return {"results": rows[start:start+2], "next_page": page+1 if start+2 < len(rows) else None}

    @app.post("/resume-intake")
    def intake(resume: Resume):
        try:
            data = base64.b64decode(resume.content_base64, validate=True)
        except (ValueError, binascii.Error):
            raise HTTPException(422, "Invalid base64")
        if not data or len(data) > 100_000:
            raise HTTPException(422, "Lab accepts 1..100000 decoded bytes")
        suffix = Path(resume.filename).suffix.lower()
        valid = suffix == ".pdf" and data.startswith(b"%PDF-")
        if suffix == ".docx":
            try:
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    names = set(archive.namelist())
                    valid = {"[Content_Types].xml", "word/document.xml"}.issubset(names)
            except zipfile.BadZipFile:
                valid = False
        if not valid:
            raise HTTPException(422, "Unsupported extension or file signature")
        digest = hashlib.sha256(data).hexdigest()
        with connect() as con:
            con.execute("BEGIN IMMEDIATE")
            old = con.execute("SELECT * FROM resume_tasks WHERE candidate_id=? AND file_hash=?", (resume.candidate_id, digest)).fetchone()
            if old:
                return {**dict(old), "duplicate": True}
            cursor = con.execute("INSERT INTO resume_tasks(candidate_id,file_hash,status) VALUES (?,?,?)", (resume.candidate_id, digest, "queued"))
            task_id = cursor.lastrowid
            con.execute("INSERT INTO audit(event_id,outcome) VALUES (?,?)", (f"resume:{task_id}", "queued"))
            return JSONResponse({"task_id": task_id, "candidate_id": resume.candidate_id, "file_hash": digest, "status": "queued", "duplicate": False}, status_code=201)

    return app


app = create_app()
