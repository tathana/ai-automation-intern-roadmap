# 04 — Triggers, Webhooks และ Schedule

## Trigger ตอบคำถามว่าเริ่มเมื่อไร

Manual Trigger ใช้กดทดลอง; Webhook เริ่มเมื่อระบบอื่นส่ง HTTP request; Schedule เริ่มตามเวลา อย่าสับสน Trigger กับ Action: Trigger เริ่มรอบ ส่วน Action ทำงานเมื่อข้อมูลเดินมาถึง

## สร้าง Webhook ที่มองข้อมูลออก

เพิ่ม Webhook เลือก POST, Path `w3-intake`, Response mode **Using Respond to Webhook Node** แล้วเพิ่ม Respond to Webhook ไว้ปลายทาง เลือกตอบ JSON

กด Listen for Test Event แล้วคัดลอก **Test URL จาก UI** ไม่พิมพ์เดาจากตัวอย่าง ส่งจาก PowerShell:

```powershell
$w3Url = Read-Host 'Paste the test webhook URL'
$w3Body = @{event_id='E101'; amount_minor=1200} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri $w3Url -ContentType 'application/json' -Body $w3Body
```

Webhook มักส่ง output ที่มี `headers`, `query`, `params`, `body` ดังนั้น field อยู่ `$json.body.event_id` ไม่ใช่ `$json.event_id` หลังจาก Edit Fields ดึง body ออกมาแล้ว path จึงเปลี่ยนตาม output ใหม่

```text
HTTP body {event_id: E101}
        ↓ Webhook
item.json.body.event_id
        ↓ Normalize
item.json.event_id
```

## Test URL กับ Production URL

Test URL ใช้ขณะฟัง test event; Production URL ใช้กับ workflow ที่เปิดใช้งาน/เผยแพร่แล้วตามรุ่น UI การกด Save อย่างเดียวไม่ได้ยืนยันว่า production endpoint รับงานอยู่ อย่าส่งข้อมูลจริงทดสอบ

ถ้าได้ 404 ให้ตรวจ URL, method, workflow state และช่วงที่กำลัง listen ก่อนแก้ business logic การตอบ 200 จาก endpoint อื่นไม่ได้ยืนยันว่าถึง workflow ที่ต้องการ

## ตอบเมื่อไร และตอบว่าอะไร

ถ้ารอ API ทำเสร็จแล้วจึงตอบ เป็น synchronous flow ถ้ารับเข้าคิวก่อนแล้วตอบ 202 เป็น asynchronous flow แต่ต้องมีการเก็บ task อย่างทนทานจริงก่อนตอบ accepted ไม่ใช่ตอบก่อนแล้วหวังว่า node หลังจากนั้นจะทำงานสำเร็จ

```text
รับ request → บันทึก task สำเร็จ → 202 {status: queued, task_id: ...}
                              ↓ ภายหลัง
                         worker ประมวลผล
```

หนึ่ง request มี HTTP response เดียว ออกแบบทุก branch ให้ไปตอบได้โดยไม่ตอบซ้ำ กรณีงานยาวให้ใช้ task ID และ endpoint ตรวจสถานะแทนการค้าง connection

## Schedule และ Timezone

ตั้ง workflow timezone เป็น `Asia/Bangkok` สำหรับเวลาไทย แล้วกำหนดตาราง เช่นทุกวัน 09:00 ทดสอบด้วยช่วงสั้นใน lab ก่อน และปิด schedule หลังทดลอง เก็บ timestamp สำหรับ audit เป็น ISO 8601 พร้อม offset หรือ UTC เช่น `2026-09-10T02:00:00Z`

การรันตามเวลาไม่รับประกัน exactly once: เครื่องอาจหยุดหรือสองรอบอาจซ้อนกัน งานประจำวันจึงยังต้องมี business key เช่น `daily-report:2026-09-10` และนโยบายเมื่อรอบก่อนยังไม่จบ

