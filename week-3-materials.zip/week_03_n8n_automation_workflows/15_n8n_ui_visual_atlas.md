# 15 — n8n UI Visual Atlas: มองหน้าจอแล้วรู้ว่ากำลังตรวจอะไร

ภาพในบทนี้เป็น **schematic mock** อิง mental model ของ n8n ไม่ใช่ screenshot ที่รับประกันตำแหน่งปุ่มทุกเวอร์ชัน เครื่องฝึกตรวจพบ n8n 1.115.3; ชื่อ Active/Publish และตำแหน่ง panel อาจต่างในระบบบริษัท

<style>
.n8n-board{margin:1.2rem 0;padding:1rem;border:1px solid #cbd9df;border-radius:12px;background:#f7fafb;color:#173047;overflow:auto}.n8n-top{display:flex;justify-content:space-between;gap:.75rem;align-items:center;padding:.55rem .75rem;background:#203746;color:#fff;border-radius:8px}.n8n-canvas{min-width:690px;padding:1.5rem .75rem;display:flex;align-items:center;gap:.5rem;background-image:radial-gradient(#cbd9df 1px,transparent 1px);background-size:18px 18px}.n8n-node{min-width:112px;padding:.75rem;border:1px solid #93aab5;border-radius:9px;background:#fff;text-align:center;box-shadow:0 3px 8px rgba(20,50,60,.08)}.n8n-arrow{color:#08756b;font-weight:700}.n8n-panel{display:grid;grid-template-columns:1fr 1.25fr 1fr;gap:1px;background:#cbd9df;border:1px solid #cbd9df}.n8n-pane{background:#fff;padding:.8rem;min-height:150px}.n8n-label{font-size:.8rem;letter-spacing:.08em;color:#527080;font-weight:700}.n8n-good{color:#08756b}.n8n-bad{color:#a43d3d}.n8n-flow{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:.55rem}.n8n-state{padding:.55rem .75rem;background:#e7f2f0;border-radius:8px;text-align:center}.n8n-callout{padding:.75rem 1rem;border-left:4px solid #08756b;background:#eaf5f3;margin:1rem 0}@media(max-width:700px){.n8n-panel{grid-template-columns:1fr}.n8n-canvas{min-width:620px}}
</style>

## ภาพที่ 1: Editor มีสามคำถามหลัก

<div class="n8n-board" role="img" aria-label="ภาพจำลอง n8n editor มี canvas และ input parameters output">
  <div class="n8n-top"><span>W3 — HR Synthetic Intake</span><span>Save · Test workflow · Publish</span></div>
  <div class="n8n-canvas"><div class="n8n-node">Webhook<br><small>trigger</small></div><span class="n8n-arrow">→</span><div class="n8n-node">Normalize<br><small>2 items</small></div><span class="n8n-arrow">→</span><div class="n8n-node">Intake API<br><small>HTTP 201</small></div><span class="n8n-arrow">→</span><div class="n8n-node">Route<br><small>queued</small></div></div>
  <div class="n8n-panel"><div class="n8n-pane"><div class="n8n-label">INPUT</div><p>ของจริงที่ node ได้รับ</p><code>event_id: HR-001</code><br><code>candidate_id: C1</code></div><div class="n8n-pane"><div class="n8n-label">PARAMETERS</div><p>สิ่งที่เราสั่ง node</p><code>POST /resume-intake</code><br><code>Body: {{$json}}</code></div><div class="n8n-pane"><div class="n8n-label">OUTPUT</div><p>ของจริงที่ node ส่งต่อ</p><code>statusCode: 201</code><br><code>task_id: T7</code></div></div>
</div>

```text
INPUT: ฉันได้รับอะไรจริง
PARAMETERS: ฉันถูกตั้งให้ทำอะไร
OUTPUT: ฉันส่งอะไรจริง
```

สีเขียวตอบเพียงว่า node ไม่ throw error ในเงื่อนไขนั้น ไม่ได้ตอบว่า business outcome ถูกต้อง

## ภาพที่ 2: Data Mapping และ Expression

<div class="n8n-board"><div class="n8n-panel"><div class="n8n-pane"><div class="n8n-label">INPUT JSON</div><pre><code>{
  "body": {
    "candidate_id": "C001"
  }
}</code></pre></div><div class="n8n-pane"><div class="n8n-label">EXPRESSION</div><p><code>{{$json.body.candidate_id}}</code></p><p>$json → body → candidate_id</p></div><div class="n8n-pane"><div class="n8n-label">PREVIEW</div><p class="n8n-good"><strong>C001</strong></p><p>ถ้าเป็น undefined ให้ย้อนดู Input ของ item นี้</p></div></div></div>

n8n สามารถลาก field จาก Input pane ไป parameter เพื่อสร้าง expression ได้ แต่ยังต้องอ่าน expression เอง เพราะ node name, item linking และ null/missing semantics อาจทำให้ผลต่างจากที่คิด

## ภาพที่ 3: Executions คือหลักฐานหลังเหตุการณ์

<div class="n8n-board"><div class="n8n-top"><span>Execution #1842 · 10:32:18</span><span class="n8n-bad">Failed</span></div><div class="n8n-canvas"><div class="n8n-node n8n-good">Webhook<br>1 item</div><span class="n8n-arrow">→</span><div class="n8n-node n8n-good">Normalize<br>1 item</div><span class="n8n-arrow">→</span><div class="n8n-node n8n-bad">Intake API<br>503</div><span class="n8n-arrow">→</span><div class="n8n-node">Route<br>not run</div></div><div class="n8n-callout"><strong>ก่อนแก้:</strong> จด execution ID, workflow version/time, node แรกที่เสีย, input ที่ตัดข้อมูลลับแล้ว, status/error และ state ในระบบปลายทาง</div></div>

การ retry มีความหมายต่างกันระหว่างใช้ workflow ที่บันทึกล่าสุดกับ workflow เดิมของ execution ต้องเลือกตามเป้าหมายการพิสูจน์ และตรวจ side effect ก่อน retry

## ภาพที่ 4: Test กับ Production เป็นคนละรอบ

<div class="n8n-board"><div class="n8n-flow"><div class="n8n-state">Test URL<br><small>listen ชั่วคราว</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Manual/Test execution<br><small>mock/pinned ได้</small></div><span class="n8n-arrow">≠</span><div class="n8n-state">Production URL<br><small>published/active</small></div><span class="n8n-arrow">→</span><div class="n8n-state">Production execution<br><small>runtime credentials/network</small></div></div></div>

ทดสอบบน Editor ไม่ได้พิสูจน์ว่า production trigger, credentials, network, timezone และ dependency จริงพร้อม

## โน้ตที่ควรเขียนข้างทุก workflow

- trigger และ owner
- business key/idempotency key
- input/output schema
- side effects
- failure/retry/review route
- credentials/config names โดยไม่มีค่าลับ
- test payload และ expected result
- disable/rollback และ runbook link

