# 18 — n8n Production Operations Reference

บทนี้ใช้คุยกับทีม platform/operations ไม่ใช่ checklist ที่ intern ต้องเปลี่ยนเอง Infrastructure และ feature availability ต้องอิง instance/plan/policy จริง

## Deployment Shapes

<div class="n8n-board"><div class="n8n-panel"><div class="n8n-pane"><div class="n8n-label">SMALL / CONTROLLED</div><p>n8n main process</p><p>Database</p><p>เหมาะ volume ต่ำและ failure domain ที่ยอมรับได้</p></div><div class="n8n-pane"><div class="n8n-label">QUEUE MODE</div><p>Main/webhook processes</p><p>Redis queue → workers</p><p>Postgres/state + shared binary strategy</p></div><div class="n8n-pane"><div class="n8n-label">MANAGED CLOUD</div><p>Provider operates platform</p><p>ทีมยังรับผิดชอบ workflow, credentials, data, retries และ side effects</p></div></div></div>

## คำถามก่อนเลือกหรือเปลี่ยน Deployment

- volume, concurrency และ execution duration เท่าไร
- webhook latency/availability requirement คืออะไร
- state/database/backup/restore อยู่ที่ไหน
- binary files เก็บอย่างไรและหมดอายุเมื่อไร
- encryption key/secrets ใครดูแลและ rotate อย่างไร
- task runners/Code node ถูกจำกัดอย่างไร
- log, metrics, traces และ alerts ส่งไปไหน
- upgrade/migration/rollback ถูก rehearsal หรือยัง

## Execution Data

Execution history ช่วย debug แต่มีค่าใช้จ่ายด้าน storage และ privacy กำหนด save success/error/manual, retention/pruning และสิทธิ์เข้าถึงตามความต้องการ ไม่เก็บ raw payload “เผื่อไว้” โดยไม่มี purpose

## Binary Data

Resume/image/archive มีขนาดและ sensitivity ต่างจาก JSON ต้องคิด storage mode, lifetime, multi-worker access, backup, malware/file validation และ deletion การเห็น binary ใน node ไม่ได้แปลว่าปลอดภัยหรือ durable

## Concurrency และ Rate Limits

```text
incoming rate > worker/provider capacity
        ↓
queue age โต → timeout/retry เพิ่ม → duplicate/incident risk
```

ใช้ concurrency limit, batching, provider quota, backpressure และ alert จาก oldest age ไม่แก้ด้วยเพิ่ม retry อย่างเดียว

## Security Baseline

- TLS/reverse proxy/base URL ถูกต้อง
- authentication/RBAC/projects ตาม plan
- credentials least privilege และ rotation
- block/restrict risky nodes ตาม policy
- SSRF/file/path risks ถูกควบคุม
- execution data/log redaction
- backup มี encryption และ restore test
- community/custom node ผ่าน review

## Operations Dashboard ที่มีความหมาย

```text
trigger received
→ accepted/rejected by category
→ execution success/failed/waiting
→ queue depth + oldest age
→ dependency latency/rate limit
→ business outcome + side-effect duplicates
```

Workflow success rate อย่างเดียวซ่อน business failure ได้ โดยเฉพาะเมื่อ Continue On Fail/Never Error เปลี่ยน error เป็น data

## Intern Boundary

คุณควรถาม architecture, เก็บ execution evidence, ทำ workflow safe และแจ้ง risk ได้ แต่ไม่ควรเปลี่ยน database, queue mode, retention, encryption key หรือ production credentials โดยไม่มี technical owner และ change procedure

