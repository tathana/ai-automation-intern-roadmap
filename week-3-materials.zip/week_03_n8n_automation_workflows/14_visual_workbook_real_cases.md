# 14 — Visual Workbook: จาก Canvas สู่ Workflow งานจริง

บทนี้เป็นภาพรวมสำหรับกลับมาเปิดเมื่อต้องสร้าง workflow ใหม่ ไม่ได้เพิ่ม node ใหม่เพื่อให้ flow ดูซับซ้อน แต่รวมวิธีคิดจากบท 01–13 ให้เป็นภาพเดียว

## Core: Workflow HR Resume Intake แบบไม่ให้ AI ตัดสินคน

เป้าหมายคือช่วยลดงานคัดลอก/จัดคิวและเตรียมหลักฐานให้ HR ตรวจ ไม่ใช่ auto-hire หรือ auto-reject

```text
ระบบรับสมัคร
    │ POST candidate_id + file reference + event_id
    v
┌─────────┐   ┌───────────┐   ┌────────────┐   ┌────────────┐
│ Webhook │ → │ Normalize │ → │ Intake API │ → │ Route      │
└─────────┘   └───────────┘   └────────────┘   └─────┬──────┘
                                                      │
                        queued ────────────────────────┤
                        invalid → Respond 422          │
                        conflict → Review              │
                        temporary failure → Retry      │
                                                      v
                                             Respond ตามข้อเท็จจริง
```

ใน Week 3 ให้หยุดที่ **สร้างงาน intake และ orchestration ที่ตรวจสอบได้** ส่วนสกัดข้อความ/LLM อยู่ Week 4 และ worker/durable state อยู่ Week 5

## Practice: Node-by-node contract

| Node | Input ที่ใช้ | Output ที่ต้องคงไว้ | Failure สำคัญ |
|---|---|---|---|
| Webhook | HTTP request | headers/body/query | method/path/body ผิด |
| Normalize | nested body | event_id, candidate_id, file_ref, trace_id | field หาย/type ผิด |
| Intake API | normalized item | statusCode + body | timeout/422/409/503 |
| Route | full response | branch + reason | อ่าน path/status ผิด |
| Respond | business outcome | HTTP status/body | ตอบซ้ำหรือไม่ตอบ |

ลองกรอก expected value ของ synthetic candidate `C1` ในตารางก่อนรัน แล้วเทียบกับ Output pane หลังรัน นี่คือวิธีเปลี่ยนการ “ลองกดดู” ให้เป็นการทดลองที่ตรวจได้

## จำลองหน้าตาเมื่อตรวจ node

```text
┌ Canvas ───────────────────────────────────────────────────────────┐
│ [Webhook]──[Normalize]──[Intake API]──[Switch]──[Respond]        │
└──────────────────────────────────────────────────────────────────┘
┌ Selected: Intake API ────────────────────────────────────────────┐
│ INPUT (1 item)       │ PARAMETERS          │ OUTPUT (1 item)      │
│ event_id: HR-001     │ POST http://...     │ statusCode: 201      │
│ candidate_id: C1     │ JSON body: {{$json}}│ body.status: queued  │
│ file_ref: synth-01   │ timeout: 3000       │ body.task_id: T7     │
└──────────────────────────────────────────────────────────────────┘
```

คำถามที่ต้องตอบจากภาพนี้:

1. `queued` มาจาก HTTP status หรือ body field
2. ถ้า output เป็น 503 Switch ไปทางใด
3. ถ้า request timeout แต่ API สร้าง T7 แล้ว retry จะกัน T8 อย่างไร
4. ข้อมูลใดไม่ควรปรากฏใน execution screenshot

## Real Case A: Daily Operations Report

```text
Schedule 09:00
   ↓ business_key = daily-report:YYYY-MM-DD
Fetch API pages → Aggregate totals → Python ตรวจตัวเลข
   ↓
สร้าง draft summary → Human review → Publish
```

จุดเสี่ยง: timezone ผิด, หน้าซ้ำ, API ให้ข้อมูลไม่ครบ, summary เปลี่ยนตัวเลข และ publish ซ้ำ จึงต้องมี source counts, report date, version และ publish key

## Real Case B: Support Ticket Triage

```text
Webhook → Normalize → Rule checks → Classify API
                               ├─ confidence/evidence ไม่พอ → review
                               ├─ known category → queue ของทีม
                               └─ prohibited action → reject/alert
```

อย่าให้ผล classification ส่งข้อความหาลูกค้าทันทีในรุ่นแรก แยก **suggestion** ออกจาก **external side effect** แล้วให้คนตรวจข้อความก่อน

## Real Case C: Transaction Review Queue

```text
event_id + transaction facts
        ↓
Python rule service คืน flags/reasons
        ↓
n8n สร้าง review task และแจ้งผู้รับผิดชอบ
        ↓
ผู้ตรวจตัดสินในระบบที่มีสิทธิ์และ audit
```

n8n ประสานงาน ส่วนกฎจำนวนเงิน/สถานะที่ต้อง unit test อยู่ใน Python/SQL และการตัดสินสิทธิ์อยู่ downstream service ไม่ฝากไว้กับ IF nodes ยาวหลายสิบเงื่อนไข

## From Mock to Production Checklist

```text
Mock payload ผ่าน
   ↓ ใช้ staging endpoint + synthetic data
credentials/reference พร้อม
   ↓ ทดสอบ invalid, duplicate, timeout, replay
execution evidence + service state ตรงกัน
   ↓ ตรวจ privacy, retention, rate limit, owner, rollback
เปิดใช้งานแบบจำกัดและเฝ้าดู
```

คำว่า production-ready ใช้ได้เมื่อทุก dependency จริง, authentication, durable state, failure recovery และ monitoring ถูกทดสอบตาม environment นั้น ไม่ใช่เพียง import JSON แล้วทุก node เป็นสีเขียว

## Mini Challenge: Workflow Design Review

เลือกหนึ่ง case ด้านบน แล้วส่งมอบสิ่งต่อไปนี้โดยไม่ใช้ข้อมูลจริง:

- ASCII flow และ node contracts
- payload ถูก/ผิด/ซ้ำ/ชั่วคราวล้มเหลวอย่างละหนึ่ง
- expected HTTP และ business status
- idempotency key ของ side effect
- ภาพหรือบันทึก execution ID พร้อม actual output
- limitation สามข้อและสิ่งที่จะเพิ่มก่อนใช้ production

หากเพื่อนอ่านแล้วบอกได้ว่าจุดไหน retry, จุดไหนให้คนตรวจ และจุดไหนเกิด side effect งานออกแบบถือว่าผ่านระดับพื้นฐานสำหรับส่งทีมตรวจ
