# 16 — Build from Blank Canvas: สร้าง Workflow จริงแบบทีละคลิก

เป้าหมาย: รับ synthetic event → normalize → ส่ง Mock API → route ตาม HTTP/business status → ตอบตามข้อเท็จจริง

## ภาพรวมก่อนเปิด n8n

<div class="n8n-board"><div class="n8n-flow"><div class="n8n-state">Webhook<br>รับ POST</div><span class="n8n-arrow">→</span><div class="n8n-state">Edit Fields<br>contract กลาง</div><span class="n8n-arrow">→</span><div class="n8n-state">HTTP Request<br>FastAPI</div><span class="n8n-arrow">→</span><div class="n8n-state">Switch<br>status</div><span class="n8n-arrow">→</span><div class="n8n-state">Respond<br>truthful result</div></div></div>

## Step 0: เตรียมหลักฐาน

เปิด Mock API ตาม `lab/README.md` แล้ว probe `/health` จาก network เดียวกับ n8n สร้าง workflow ใหม่ชื่อ `W3 - Intake From Blank - <ชื่อคุณ>` อย่าแก้ตัวอย่างต้นฉบับ

## Step 1: Webhook

ตั้ง Method `POST`, Path ที่ไม่ชนงานอื่น เช่น `w3-intake-thanaphat`, Response mode ให้ใช้ Respond to Webhook node ตาม UI รุ่นที่ใช้ กด listen/test แล้วส่ง:

```json
{"event_id":"BLANK-001","amount_minor":1200,"mode":"normal"}
```

Expected Input/Output ของ Webhook ต้องเห็น body จริง อย่าเดาว่า field อยู่ `$json.event_id`; บางรูปแบบอยู่ `$json.body.event_id`

## Step 2: Normalize Intake

เพิ่ม Edit Fields/Set และสร้าง contract กลาง:

```text
event_id      string required
amount_minor  integer >= 0
mode          string default normal
trace_id      event_id ใน lab
```

ใช้ drag-and-drop จาก Input เพื่อสร้าง expression แล้วเปิด preview ทดสอบ missing field ด้วย อย่า normalize เป็น string ทุกอย่างจน type error ถูกซ่อน

## Step 3: Submit Event

เพิ่ม HTTP Request:

```text
Method: POST
URL: ตามตำแหน่ง Mock API จากมุมของ n8n
Send Body: JSON
Body: normalized fields เท่านั้น
Timeout: 3000 ms สำหรับ lab
Full response: on
Never error: on เฉพาะเพื่อฝึก route status ด้วยตัวเอง
```

Expected:

```json
{"statusCode":201,"body":{"status":"accepted"}}
```

รูปร่างจริงขึ้นกับ options/version ให้เชื่อ Output pane ไม่ใช่จำ path จากหนังสือ

## Step 4: Route Outcome

เพิ่ม Switch ด้วยลำดับที่ไม่กลบกัน:

```text
201/200 + body success → accepted
422 → rejected_input
409 → conflict_review
429/503 → retry_candidate
default → unexpected_review
```

ทุก branch ต้องจบด้วย outcome ที่อธิบายได้ ห้ามสร้าง default เป็น success

## Step 5: Respond

ตอบ status/body ตามสิ่งที่เกิดขึ้นจริง ถ้า upstream 503 และระบบยังไม่ durable อย่าตอบ `success`; อาจตอบ 503 หรือ 202 เฉพาะเมื่อมี persisted task ที่ติดตามได้แล้ว

## Step 6: Failure Lab

รันด้วย event ID ใหม่ทุกกรณี:

| mode/input | คาดหวัง | retry |
|---|---|---|
| normal | accepted | no |
| amount -1 | rejected | no |
| rate_limit | retry candidate | bounded |
| transient | retry candidate | bounded |
| permanent | terminal/review | no automatic loop |

## Step 7: Evidence

เก็บ workflow name/version, test payload, execution IDs, expected/actual table, screenshot ที่ปิดข้อมูลลับ, service state และ limitation จากนั้น export สำเนาที่ inactive ตรวจ pinned data/URL/credential references ก่อน commit

## Definition of Done

เพื่อน import แล้วสร้าง credential/config ตาม README, รัน normal/invalid/temporary case และอธิบายได้ว่า node ไหนรับผิดชอบ contract, retry, side effect และ truthful response

