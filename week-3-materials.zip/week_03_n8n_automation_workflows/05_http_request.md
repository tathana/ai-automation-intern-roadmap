# 05 — HTTP Request เชื่อม FastAPI

## จาก Python client สู่ node

ที่ Week 2 เราเขียน `client.post(url, json=payload)` ตอนนี้ตั้งส่วนเดียวกันผ่าน UI: Method, URL, Headers, Body และ Timeout ไม่จำเป็นต้องลืมความรู้ HTTP เดิม

เปิด mock ตาม [Lab](lab/README.md) แล้วสร้าง HTTP Request ตามนี้:

| ช่อง | ค่า |
|---|---|
| Method | POST |
| URL | `http://127.0.0.1:8013/events` สำหรับ n8n native |
| Send Body | เปิด |
| Body Content Type | JSON |
| Specify Body | Using JSON |
| JSON (expression) | `{{ {event_id: $json.event_id, amount_minor: $json.amount_minor} }}` |
| Timeout | 3000 milliseconds สำหรับ lab |
| Include Response Headers and Status | เปิด |
| Never Error | เปิดเฉพาะเมื่อจะ route status เองตามบทนี้ |

การคืน object จาก expression ช่วยรักษา amount_minor เป็น number การนำ string มาต่อเป็น JSON เองเสี่ยงเครื่องหมาย quote ผิดและชนิดข้อมูลเพี้ยน

## อ่าน output ให้ครบสองชั้น

เมื่อเปิด full response ให้ตรวจ output จริง โดยทั่วไปมี `statusCode`, `headers`, `body`:

```json
{"statusCode":201,"headers":{},"body":{"event_id":"E101","status":"succeeded","duplicate":false}}
```

จึงอ่าน `$json.body.status` ไม่ใช่ `$json.status` หากไม่เปิด full response รูปร่างอาจต่างออกไป ทุกครั้งที่เปลี่ยน option ต้องทบทวน expression ของ node ถัดไปด้วย

## Never Error ไม่ได้ทำให้ปัญหาหายไป

เมื่อเปิด option นี้ HTTP 422/503 สามารถออกทาง output ปกติเพื่อให้เราแยกเอง จึงต้องมี Switch หรือ IF ตรวจ status ต่อ **อย่าต่อเข้ากล่อง succeeded ทันที** ส่วน network error และ timeout ยังต้องมีเส้นทางรับ error แยกต่างหาก

```text
HTTP Request
    ├─ ได้ response → ตรวจ statusCode → ตรวจ body.status
    └─ ไม่มี response → error path → สถานะ unknown/retry_pending
```

ใช้ status 2xx เป็นเพียงเงื่อนไขชั้นแรก ในระบบอื่น 200 อาจหมายถึงรับคำขอได้แต่ธุรกิจ rejected ตัวอย่าง mock นี้ให้ความหมายไว้ชัดใน contract จึงตัดสินใจตาม contract ไม่ใช่ท่องว่า 200 คือสำเร็จเสมอ

## Debug ตามชั้น

Connection refused: บริการอาจยังไม่เปิดหรือ port ผิด; 404: path ผิด; 405: method ผิด; 422: body ไม่ตรง schema; 401/403: ตรวจ credentials และสิทธิ์ ไม่ retry ด้วยข้อมูลเดิมซ้ำ ๆ

เริ่มด้วย GET `/health` ก่อน POST `/events` เพื่อตัดปัญหา network ออกจาก schema จากนั้นเปรียบเทียบ request ที่ส่งจาก PowerShell กับที่ n8n ส่งจริง

