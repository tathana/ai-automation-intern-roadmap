# 10 — Credentials, Export และ Runbook

## Credentials ไม่ใช่ข้อความที่จะใส่ใน node

ให้เก็บ token ผ่าน Credentials ของ n8n และเลือก credential ใน node แทนการพิมพ์ Authorization header จริงลงใน workflow ตัวอย่างในชุดนี้ไม่มี API key เพราะเป็น localhost lab เท่านั้น ไม่ใช่แนวทางสำหรับ endpoint สาธารณะ

Environment variable เหมาะกับ config ที่ขึ้นกับ environment แต่การเข้าถึง env จาก expressions/Code ขึ้นกับการตั้งค่าและรุ่น อย่าปลดข้อจำกัดของ instance เพียงเพื่อให้ตัวอย่างสั้นลง

## ก่อน export ต้องตรวจมากกว่า password

Workflow export อาจมีชื่อ credential/ID, URL ภายใน, email, query, headers หรือ pinned data แม้ไม่ส่งออก secret ที่เข้ารหัสมาด้วย ก็ยังต้องตรวจข้อมูลส่วนตัวใน node parameters และ sample data

```text
ทำงานใน lab → export สำเนา → ตรวจ secrets/PII/pinned data
                               ↓
                         review diff → commit
```

ไฟล์ตัวอย่างต้อง inactive และไม่มี credential จริง Import เป็น workflow ใหม่ก่อน อย่าเปิดใช้งาน schedule/webhook ทันทีจนตรวจ endpoint และ side effects ครบ

## Runbook คือคู่มือให้คนถัดไปรับช่วงได้

เขียนให้ตอบได้ว่า:

- เปิดบริการอะไรและตรวจ health อย่างไร
- รับ payload รูปไหน และใช้ URL ใดใน test/production
- ตรวจ execution และ record ใน API ที่ไหน
- 422/429/503 ต้องทำอะไร ใครเป็นคนแก้
- replay อย่างไรโดยไม่สร้างซ้ำ และเมื่อไรห้าม replay
- ปิด trigger ชั่วคราวอย่างไรโดยไม่ลบประวัติ

## Git diff ของ workflow

ตั้งชื่อ node ให้มีความหมาย เช่น `Normalize Intake` แทน `Edit Fields3` เก็บ JSON พร้อม README และตัวอย่าง payload การเลื่อนตำแหน่ง node ก็ทำให้ diff เปลี่ยนได้ แยกการจัด canvas ออกจากการแก้ logic เมื่อทำได้ เพื่อให้ผู้ตรวจเห็นสิ่งที่สำคัญ

## ขอบเขตความปลอดภัยของ Week 3

ไม่ใช้ resume จริง, ไม่เปิด public webhook ที่ไม่มี authentication, ไม่ส่ง URL จากผู้ใช้เข้า HTTP Request ตรง ๆ เพราะอาจทำให้บริการไปเรียกเครือข่ายภายในที่ไม่ควรเข้าถึง และไม่ปิด SSL verification เพื่อแก้ปัญหา certificate โดยไม่ตรวจสาเหตุ

