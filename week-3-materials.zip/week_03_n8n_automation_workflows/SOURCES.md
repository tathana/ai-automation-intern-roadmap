# แหล่งอ้างอิงและขอบเขตของบทเรียน

ตรวจเอกสารทางการเมื่อ 10 กันยายน 2026 เนื้อหาไทยและตัวอย่างธุรกิจในชุดนี้เรียบเรียงเพื่อการเรียน ไม่ใช่คำแปลทั้งหน้าของเอกสาร n8n

- บท 05 และ 07: [HTTP Request](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.httprequest/) — JSON body, full response, Never Error, batching และ pagination options
- บท 07: [Loop Over Items](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.splitinbatches/) — loop/done outputs, การใช้หลาย items และ reset guard
- บท 08: [Error Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.errortrigger/) — การเชื่อม error workflow และข้อจำกัดการทดสอบแบบ manual
- บท 03: [Code node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.code/) — โหมดการทำงานและภาษาใน Code node
- บท 04: [Webhook](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/) — request/response configuration และ test/production workflow

ชื่อ UI และความสามารถอาจต่างจาก n8n 1.115.3 ที่พบในเครื่อง ให้ดู output และ version จริงประกอบ หาก documentation URL เปลี่ยน ให้ค้นชื่อ node จากหน้าเอกสารหลัก ไม่ใช้ภาพหน้าจอเก่าเป็นข้อยืนยันว่า option ยังอยู่ตำแหน่งเดิม

## การออกแบบเฉพาะ lab

นโยบาย 3 attempts, endpoint port 8013, SQLite schema, mode จำลอง failure, ขนาดไฟล์ 100000 bytes และ dedup `(candidate_id,file_hash)` เป็นการตัดสินใจสำหรับแบบฝึกนี้ ไม่ใช่ข้อบังคับของ n8n หรือบริษัท

## คำที่ไม่ควรสรุปเกินหลักฐาน

Production-style หมายถึงฝึกแนวคิด reliability และ handoff ไม่ใช่รับรอง production-ready; queued ไม่ใช่ processed; file signature ผ่านไม่ใช่ safe document; mock tests ผ่านไม่เท่ากับการเชื่อมระบบบริษัทผ่าน

