# 12 — Week 3 Cheat Sheet

## หยิบใช้ขณะทำ lab

| ต้องการ | ตัวอย่าง/จุดตรวจ |
|---|---|
| อ่าน item ปัจจุบัน | `{{ $json.event_id }}` |
| อ่าน body จาก Webhook | `{{ $json.body.event_id }}` |
| fallback เมื่อ null/ไม่มีค่า | `{{ $json.country ?? 'UNKNOWN' }}` |
| ข้อมูลที่สัมพันธ์จาก node ก่อน | `{{ $('Normalize').item.json.event_id }}` |
| Config รายการแรกโดยตั้งใจ | `{{ $('Config').first().json.base_url }}` |
| ทุก items ใน Code | `$input.all()` |
| สร้างผล Code แบบชัดเจน | `return [{json: {ok: true}}];` |
| array ด้านในกลายเป็น items | Split Out |
| items กลายเป็น array | Aggregate |
| จับคู่ข้อมูลคนเดิม | Merge matching fields ด้วย ID |
| ตรวจ HTTP response เต็ม | `$json.statusCode`, `$json.body` |

## ถ้าอาการเป็นแบบนี้

- undefined: ตรวจ path และ input node ปัจจุบัน
- U1 ไปอยู่ทุกแถว: ตรวจ `.first()` และ item linking
- node เขียวแต่ API ไม่สำเร็จ: ตรวจ Never Error และ business status
- retry ไม่เกิด: error ถูกเปลี่ยนเป็นข้อมูลแล้วหรือไม่
- webhook ค้าง: มีทุก branch ไป response หรือไม่
- งานซ้ำหลัง replay: key เปลี่ยนหรือ dedup อยู่แค่ใน memory หรือไม่
- เวลาไม่ตรง: ตรวจ timezone และ timestamp offset

## ก่อนบอกว่าเสร็จ

```text
happy path ผ่าน?
  ↓
invalid + duplicate + temporary failure ผ่าน?
  ↓
ไม่มี secret และมี runbook?
  ↓
คนอื่นนำเข้าและอธิบายวิธีรันได้?
```

## Debug Ladder แบบใช้หน้างาน

```text
1. Trigger เกิดหรือไม่?                 ดู execution มีหรือไม่
2. node รับกี่ items?                   ดู Input count
3. field อยู่ path ไหนและ type อะไร?    ดู JSON view
4. expression ให้ค่าอะไร?               ทดลองทีละช่วง
5. request ออกไปหน้าตาใด?               ตรวจ method/url/body
6. response เป็น transport/protocol/business แบบใด?
7. route ใช้ field หลัง transform ถูกหรือไม่?
8. replay แล้ว side effect ใดอาจซ้ำ?
```

## คำถามก่อนเปิด Active

- test URL ถูกเปลี่ยนเป็น production URL แล้วหรือยัง
- credentials และ environment URL ถูกของ environment หรือไม่
- invalid/empty/duplicate/timeout มีทางไปหรือไม่
- execution retention และข้อมูลอ่อนไหวเหมาะสมหรือไม่
- มีวิธี disable และผู้รับผิดชอบเมื่อแจ้งเตือนหรือไม่
