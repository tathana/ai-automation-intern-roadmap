# 19 — Easy Walkthrough: อ่าน n8n Canvas ให้เหมือนอ่านโปรแกรม

บทนี้รวบภาพของ Week 3 ด้วยภาษาง่าย หากเปิด n8n แล้วเห็นกล่องกับเส้นเต็มหน้า ให้ยังไม่สนใจปุ่มทั้งหมด เริ่มถามเพียงว่า “ข้อมูลก้อนนี้มาจากไหน ตอนนี้หน้าตาเป็นอะไร และกล่องถัดไปคาดหวังอะไร”

## 1. n8n คืออะไรในโปรเจกต์ของเรา

n8n เป็น **workflow orchestrator** ภาษาง่ายคือผู้ประสานงานที่รับเหตุการณ์แล้วเรียกเครื่องมือตามลำดับ:

```text
Webhook รับเรื่อง
  ↓
Edit Fields จัดแบบฟอร์ม
  ↓
HTTP Request ส่งให้ FastAPI
  ↓
Switch แยกทางตามผล
  ↓
Respond/Notify/Review
```

มันไม่ควรเป็นเจ้าของ business rule ทุกอย่าง ถ้ากฎสำคัญถูก copy ไว้ทั้ง Python และ Code node วันหนึ่งสองฝั่งจะให้ผลไม่ตรงกัน

## 2. Node ไม่ได้ส่ง “ตัวแปรเดียว” แต่ส่ง Items

ให้คิดว่าเส้นระหว่าง node เป็นสายพานที่ส่งกล่องข้อมูลหลายกล่อง:

```text
Input items
[
  { json: {event_id: "E1", amount: 100} },
  { json: {event_id: "E2", amount: 200} }
]
       ↓ node ทำงาน
Output items
```

`$json.event_id` คือค่าของ item ปัจจุบัน ไม่ใช่ตัวแปร global ของ workflow ถ้ามีสาม items node ถัดไปอาจทำงานสามครั้งหรือรับสามก้อนตามพฤติกรรมของ node

## 3. Expression อ่านอย่างไร

```text
={{ $json.body.event_id }}
```

แปลทีละส่วน:

```text
={{ ... }}        → ให้ n8n ประเมิน expression
$json             → JSON ของ item ปัจจุบัน
.body              → เข้า field body
.event_id          → อ่าน event_id
```

ก่อนเขียน expression ให้เปิด Output pane ของ node ก่อนหน้าและเดินตาม shape จริง หากข้อมูลอยู่ `body.event_id` แต่เราเขียน `$json.event_id` ปัญหาอยู่ที่ path ไม่ใช่ webhook เสีย

## 4. Test URL กับ Production URL

```text
Test URL
  → ต้องกด Listen/Execute
  → ใช้ทดลองทีละครั้ง

Production URL
  → workflow ต้อง active/published
  → ใช้รับ event ต่อเนื่อง
```

ถ้าส่ง request แล้วเงียบ ให้ตรวจ URL mode และสถานะ workflow ก่อนแก้ node อื่น

## 5. HTTP Request Node คือ API Client

ช่องสำคัญคือ method, URL, headers, body, timeout และ response handling:

```text
n8n JSON
  ↓ map เฉพาะ field ที่ contract รับ
POST /intakes
  ↓
status + response JSON
  ↓ Switch
```

สีเขียวหมายถึง node ทำตาม configuration ได้ ไม่ได้พิสูจน์ว่า business outcome ถูก เช่นเปิด Never Error แล้ว `500` อาจกลายเป็น output สีเขียวที่เราต้อง route เอง

## 6. Transform, Switch และ Merge ต่างกันอย่างไร

- **Edit Fields/Set:** เปลี่ยนรูปร่างข้อมูล เช่นเลือก/ตั้งชื่อ field
- **Code:** ใช้ logic ที่ node ปกติทำไม่สะดวก แต่ไม่ควรเป็นที่ซ่อนระบบทั้งก้อน
- **Switch/If:** แยกทางตามเงื่อนไข
- **Merge:** รวมสายข้อมูล ต้องรู้ว่าจับคู่ตาม index, key หรือ append

```text
Transform = จัดของในกล่องใหม่
Switch    = เลือกสายพาน
Merge     = นำสายพานกลับมารวม
```

## 7. Loop และ Pagination

จำนวน items ไม่เท่ากับจำนวนหน้าของ API:

```text
Page 1 → 100 records + next cursor
Page 2 → 100 records + next cursor
Page 3 → 20 records + no cursor → stop
```

ต้องมี stop condition และ maximum pages ป้องกัน loop ไม่สิ้นสุด ส่วน Split in Batches/Loop Over Items ใช้ควบคุมจำนวนรายการต่อรอบ ไม่ได้สร้าง idempotency ให้อัตโนมัติ

## 8. Retry กับ Idempotency ต้องมาคู่กัน

Timeout แปลว่า client ไม่ได้รับคำตอบ ไม่ได้แปลว่า API ไม่ทำงาน:

```text
n8n POST → API commit แล้ว
             ↓ response หาย
n8n timeout → retry ด้วย event_id เดิม
             ↓
API คืน task เดิม ไม่สร้างซ้ำ
```

Retry เฉพาะ transient failure และมี attempt budget ส่วน validation error ต้องแก้ข้อมูล ไม่ใช่วนส่งซ้ำ

## 9. Execution คือหลักฐานการรัน

เมื่อ debug ให้หา **first wrong node**:

```text
Webhook output ถูก
Edit Fields output ถูก
HTTP body ผิด       ← เริ่มผิดตรงนี้
Switch ผิดตามมา     ← เป็นผล ไม่ใช่ต้นเหตุ
```

ดู input/output/status/timestamp ของแต่ละ node และใช้ข้อมูลสังเคราะห์ ห้าม pin/export PII หรือ credentials

## 10. Human Review Flow

```text
automation เตรียม draft
  ↓ confidence/validation ไม่พอ
สร้าง review item
  ↓ คนตรวจหลักฐาน
approve/edit/reject
  ↓ audit action
ค่อยทำ side effect ที่อนุญาต
```

Human review ไม่ใช่ node ที่ใส่ไว้ให้ diagram ดูปลอดภัย ต้องระบุว่าใคร review, เห็นอะไร, ตัดสินอย่างไร และถ้าไม่ตอบภายในเวลาที่กำหนดเกิดอะไรขึ้น

## 11. อ่าน Code Node ตัวอย่างทีละบรรทัด

```javascript
return items.map((item) => ({
  json: {
    event_id: item.json.event_id,
    amount_minor: Number(item.json.amount_minor),
  },
}));
```

สิ่งที่เกิดขึ้น:

1. `items.map(...)` วนทุก input item และต้องคืน output หนึ่งก้อนต่อ input
2. `item` คือ item ปัจจุบัน ไม่ใช่ array ทั้งหมด
3. `{ json: {...} }` คือรูป item ที่ n8n คาดหวัง
4. `Number(...)` แปลงค่าเป็น number แต่ `Number("abc")` ได้ `NaN` จึงยังต้อง validate ก่อนส่ง API
5. `return` คืน array ใหม่ให้ node ถัดไป

```text
2 input items
  ↓ map ทำ function 2 รอบ
2 normalized output items
```

ถ้าเผลอคืน dict เดียวแทน array หรือห่อ `json` ผิดชั้น node ถัดไปจะเห็น shape ไม่ตรง contract

## ศัพท์สำหรับคุยกับทีม

| ศัพท์ | ภาพจำ |
|---|---|
| Trigger | เหตุการณ์ที่เริ่ม workflow |
| Item | กล่องข้อมูลหนึ่งก้อนบนสายพาน |
| Expression | วิธีหยิบ/คำนวณค่าจาก execution data |
| Execution | ประวัติการวิ่งหนึ่งรอบ |
| Orchestration | จัดลำดับและประสานหลายระบบ |
| Retryable | ผิดชั่วคราวและลองใหม่ได้ตาม policy |
| Idempotency | replay เหตุการณ์เดิมแล้ว side effect ไม่เพิ่ม |
| Credential | secret/config สำหรับเชื่อมระบบ; ไม่ฝังใน export |
| Sub-workflow | workflow ย่อยที่มี input/output contract |

ถ้าเข้าใจบทนี้ ให้กลับไปบท 15–18 แล้วจับคู่ทุกภาพกับคำถามสามข้อ: input shape คืออะไร, node นี้รับผิดชอบอะไร, failure จะปรากฏที่ไหน
