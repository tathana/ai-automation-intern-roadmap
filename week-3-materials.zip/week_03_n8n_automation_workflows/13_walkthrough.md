# 13 — เดิน Flow ตั้งแต่ต้นจนจบ

## เป้าหมายเล็กที่ทดสอบได้

รับ event แล้วให้ mock API บันทึกหนึ่งครั้ง พร้อมคืนผลตามจริง เริ่มจาก Happy Path ก่อน แล้วเพิ่ม failure routes ใน FlowGuard ไม่ต้องวางสิบ node พร้อมกันตั้งแต่ครั้งแรก

## ขั้นที่ 1: เริ่มจากตัวอย่างที่ import ได้

นำเข้า [01_items_lab.json](workflows/01_items_lab.json) เป็น workflow ใหม่ รัน Manual Trigger แล้วดู Seed Items กับ Classify จะได้ E101 needs_review=false และ E102 needs_review=true

จากนั้นเปิด mock API แล้วนำเข้า [02_api_probe.json](workflows/02_api_probe.json) ตรวจ URL ให้ตรง environment ก่อนรัน ไม่เปิด Retry On Fail ในตัวอย่างตั้งต้น

## ขั้นที่ 2: เทียบข้อมูลทุกจุด

| จุด | จำนวน | รูปข้อมูล |
|---|---:|---|
| Seed Event | 1 item | event_id=E101, amount_minor=1200 |
| Submit Event | 1 item | statusCode=201, body.status=succeeded |
| รัน Seed เดิมซ้ำ | 1 item | statusCode=200, body.duplicate=true |

ถ้าครั้งแรกเห็น 200 duplicate=true แสดงว่า E101 เคยถูกส่งเข้า mock database แล้ว ไม่ใช่ตัวอย่างผิด ลอง event_id ใหม่หรือใช้ database lab ใหม่โดยเก็บของเดิมไว้

## ขั้นที่ 3: เปลี่ยน Manual เป็น Webhook

สร้างสำเนา workflow ตั้ง POST path `w3-intake` แล้วให้ Normalize ดึง `body.event_id` และ `body.amount_minor` ต่อ Submit Event ตามบท 05 จากนั้น route status ก่อน Respond to Webhook

```text
Webhook → Normalize → Submit Event
                         ├─ 2xx + succeeded → ตอบผลจริง
                         ├─ 422 → ตอบ 422 พร้อมเหตุผล
                         ├─ 409 → ตอบ 409 / review
                         └─ 429/503 → retry policy หรือบอก retry_pending
```

หากไม่ได้สร้างคิว durable จริง อย่าตอบ 202 queued ให้ตอบ error ที่สอดคล้องกับ contract ของ endpoint lab และให้ผู้ส่งทราบว่าต้องลองใหม่ด้วย key เดิม

## ขั้นที่ 4: ทำ failure experiment

ตั้ง event_id ใหม่ amount_minor=-1 ควรได้ 422 โดยไม่บันทึก event แล้วเปลี่ยนเป็น 1200 กับ field `mode=transient` ส่งสามครั้งด้วย event_id เดิม จะได้ 503,503,201 จาก mock หาก node ไม่ส่ง mode ไป API จะไม่ได้ทดลอง failure ที่ตั้งใจ

## ขั้นที่ 5: ส่งมอบหลักฐาน

บันทึก input, expected, actual, execution ID และ GET `/events/E101` อย่าใช้จำนวน node สีเขียวเป็นเกณฑ์แทนข้อมูลในบริการ เป้าหมายคืออธิบายได้ว่าทำไมผลที่เห็นจึงถูกต้อง และถ้า replay แล้วอะไรจะเกิดซ้ำ

