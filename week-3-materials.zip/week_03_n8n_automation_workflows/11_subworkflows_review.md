# 11 — Sub-workflows และ Human Review

## แยก workflow เหมือนแยก function

ถ้า flow หลักยาวจนอ่านไม่รู้เรื่อง ให้แยกส่วนที่มี input/output ชัด เช่น `Validate Intake` ไม่ใช่แยกทุก node เป็น workflow เพราะจะตามงานยากขึ้น

```text
Workflow หลัก
    ↓ {event_id, amount_minor}
Execute Sub-workflow
    ↓
Workflow ย่อย: ตรวจและคืน {event_id, valid, reasons}
    ↓
Workflow หลักเลือก route
```

สร้าง workflow ย่อยด้วย Execute Sub-workflow Trigger (บางรุ่นแสดง When Executed by Another Workflow) กำหนด fields/contract แล้วใช้ Execute Sub-workflow ในตัวหลักเลือก workflow นั้น ถ้าขั้นถัดไปต้องใช้ผล ให้เลือก wait for completion

## รับหลาย items ต้องตัดสินใจให้ชัด

โหมดเรียกครั้งเดียวด้วยหลาย items กับเรียกต่อ item ให้ผลด้านจำนวน executions และรูป output ต่างกัน ทดลองสอง items ก่อน ถ้า sub-workflow คาดว่าจะรับหนึ่ง record แต่ได้รับทั้ง batch ต้องแก้ contract ไม่ใช้ `.first()` ทิ้งข้อมูลที่เหลือ

Export หลาย workflows แล้ว ID ของตัวที่ถูกเรียกอาจต่างหลัง import อีกเครื่อง ให้ตั้งการอ้างอิงใหม่และบันทึกใน runbook

## Human Review คือขั้นตอนที่มีข้อมูล ไม่ใช่แค่ส่งข้อความ

Review task ต้องมี task_id, reason, status=pending, created_at และ references ที่ผู้ตรวจเข้าถึงได้ ไม่แนบข้อมูลส่วนบุคคลทั้งฉบับใน notification

```text
พบข้อสงสัย → สร้าง review task → แจ้ง task_id
                                      ↓
                           คนมีสิทธิ์เปิดตรวจ
                                      ↓
                      บันทึก decision+ผู้ตรวจ+เวลา
```

Wait node สามารถใช้หยุดรอได้ในรูปแบบที่รองรับ แต่ resume URL ไม่ได้แทนระบบ authorization ที่ครบถ้วน ในงานจริงต้องตรวจผู้อนุมัติ, สิทธิ์, task state, expiry และกันการตัดสินใจซ้ำ

## HR Add-on ไม่ตัดสินคนแทน HR

สัปดาห์นี้เตรียมไฟล์และคิวงานเท่านั้น `queued` ไม่ได้แปลว่าผ่านคุณสมบัติ และ `needs_review` ไม่ได้แปลว่าผู้สมัครไม่ดี แยก technical failure ออกจาก hiring decision เสมอ

