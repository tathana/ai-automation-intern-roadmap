# 11 — Sub-workflows และ Human Review

## แยก workflow เหมือนแยก function

ถ้า flow หลักยาวจนอ่านไม่รู้เรื่อง ให้แยกส่วนที่มี input/output ชัด เช่น `Validate Intake` ไม่ใช่แยกทุก node เป็น workflow เพราะจะตามงานยากขึ้น

```text
Workflow หลัก
    ↓ {event_id, amount_minor}
Execute Sub-workflow
    ↓
Workflow ย่อย: ตรวจและคืน {event_id, valid, reasons}
    ↓
Workflow หลักเลือก route
```

สร้าง workflow ย่อยด้วย Execute Sub-workflow Trigger (บางรุ่นแสดง When Executed by Another Workflow) กำหนด fields/contract แล้วใช้ Execute Sub-workflow ในตัวหลักเลือก workflow นั้น ถ้าขั้นถัดไปต้องใช้ผล ให้เลือก wait for completion

## รับหลาย items ต้องตัดสินใจให้ชัด

โหมดเรียกครั้งเดียวด้วยหลาย items กับเรียกต่อ item ให้ผลด้านจำนวน executions และรูป output ต่างกัน ทดลองสอง items ก่อน ถ้า sub-workflow คาดว่าจะรับหนึ่ง record แต่ได้รับทั้ง batch ต้องแก้ contract ไม่ใช้ `.first()` ทิ้งข้อมูลที่เหลือ

Export หลาย workflows แล้ว ID ของตัวที่ถูกเรียกอาจต่างหลัง import อีกเครื่อง ให้ตั้งการอ้างอิงใหม่และบันทึกใน runbook

## Human Review คือขั้นตอนที่มีข้อมูล ไม่ใช่แค่ส่งข้อความ

Review task ต้องมี task_id, reason, status=pending, created_at และ references ที่ผู้ตรวจเข้าถึงได้ ไม่แนบข้อมูลส่วนบุคคลทั้งฉบับใน notification

```text
พบข้อสงสัย → สร้าง review task → แจ้ง task_id
                                      ↓
                           คนมีสิทธิ์เปิดตรวจ
                                      ↓
                      บันทึก decision+ผู้ตรวจ+เวลา
```

Wait node สามารถใช้หยุดรอได้ในรูปแบบที่รองรับ แต่ resume URL ไม่ได้แทนระบบ authorization ที่ครบถ้วน ในงานจริงต้องตรวจผู้อนุมัติ, สิทธิ์, task state, expiry และกันการตัดสินใจซ้ำ

## HR Add-on ไม่ตัดสินคนแทน HR

สัปดาห์นี้เตรียมไฟล์และคิวงานเท่านั้น `queued` ไม่ได้แปลว่าผ่านคุณสมบัติ และ `needs_review` ไม่ได้แปลว่าผู้สมัครไม่ดี แยก technical failure ออกจาก hiring decision เสมอ

## ชั้น Core: Sub-workflow คือ function ของโลก workflow

sub-workflow ที่ดีมี input/output contract เล็กและชัด เช่น `create_review_task({subject_id, reason_codes, evidence_refs})` ไม่ผูกกับโครงสร้าง Webhook ทั้งก้อน

```text
Main workflow
Normalize → Analyze → needs_review?
                         ↓ yes
              Execute Sub-workflow
                         ↓
Review workflow: validate → persist task → return task_id
```

ประโยชน์คือใช้ซ้ำและทดสอบแยกได้ แต่ถ้า sub-workflow แก้ field เดียวหรือซ่อนสิบ side effects ก็ทำให้ตามงานยากขึ้น

## ชั้น Practice: ออกแบบ review state

ขั้นต่ำควรมี `review_task_id`, `subject_id`, `status`, `reason_codes`, `created_at`, `decided_at`, `reviewer_id` และ version ของข้อมูลที่ตรวจ

```text
pending ──claim โดยผู้ตรวจ──> in_review
in_review ──approve/reject──> decided
in_review ──หมดเวลา────────> pending หรือ expired ตาม policy
decided ──กดซ้ำ────────────> ปฏิเสธ/คืนผลเดิม ไม่สร้าง decision ใหม่เงียบ ๆ
```

## ชั้น Deep Dive: Human-in-the-loop ไม่ใช่ส่งอีเมลแล้วจบ

ช่องทางให้คนตรวจต้องแสดง source/evidence, เหตุผลที่ถูกส่งมา, ข้อมูลเวอร์ชันใด และ action ที่อนุญาต การตัดสินต้อง authenticate, authorize และ audit ได้ หากข้อมูลต้นฉบับเปลี่ยนระหว่างรอ ต้องกำหนดว่าจะ invalidate งานเดิมหรือให้ตรวจ snapshot เดิม
