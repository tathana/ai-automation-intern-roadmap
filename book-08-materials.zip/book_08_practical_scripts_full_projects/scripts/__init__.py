"""Reusable educational script examples."""
