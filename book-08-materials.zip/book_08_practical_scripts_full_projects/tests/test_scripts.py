from pathlib import Path

import httpx
import pytest

from scripts.batch_manifest import build_manifest
from scripts.document_reader import DocumentReadError, read_document
from scripts.safe_http import PermanentHTTPError, request_json
from scripts.sqlite_job_store import JobStore, PayloadConflict
from scripts.structured_io import StructuredDataError, read_rows, write_json_atomic


ROOT = Path(__file__).parents[1]


def test_txt_document_and_unsupported(tmp_path):
    result = read_document(ROOT / "fixtures" / "synthetic_note.txt")
    assert result.kind == "txt" and "Python" in result.text and len(result.file_sha256) == 64
    unsupported = tmp_path / "note.bin"
    unsupported.write_bytes(b"content")
    with pytest.raises(DocumentReadError, match="unsupported_file_type"):
        read_document(unsupported)


def test_pdf_and_docx_document_readers(tmp_path):
    pdf = read_document(ROOT / "fixtures" / "synthetic_resume.pdf")
    assert pdf.kind == "pdf" and pdf.units >= 1 and "Python" in pdf.text

    from docx import Document

    path = tmp_path / "synthetic.docx"
    document = Document()
    document.add_paragraph("Built a Python automation service.")
    table = document.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "Skill"
    table.cell(0, 1).text = "SQL"
    document.save(path)
    docx = read_document(path)
    assert docx.kind == "docx" and "Python" in docx.text and "SQL" in docx.text


def test_csv_json_contract_and_row_limit():
    required = ("event_id", "occurred_at", "amount_minor", "status", "channel")
    assert len(read_rows(ROOT / "fixtures" / "events.csv", required=required)) == 3
    assert len(read_rows(ROOT / "fixtures" / "events.json", required=required)) == 2
    with pytest.raises(StructuredDataError, match="row_limit_exceeded"):
        read_rows(ROOT / "fixtures" / "events.csv", max_rows=2)


def test_xlsx_reader(tmp_path):
    from openpyxl import Workbook

    path = tmp_path / "events.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["event_id", "amount_minor"])
    sheet.append(["E1", 100])
    workbook.save(path)
    rows = read_rows(path, required=("event_id", "amount_minor"))
    assert rows == [{"event_id": "E1", "amount_minor": 100}]


def test_atomic_json_output(tmp_path):
    target = tmp_path / "nested" / "report.json"
    write_json_atomic(target, {"ok": True})
    assert target.read_text(encoding="utf-8").strip().startswith("{")
    assert not list(target.parent.glob("*.tmp"))


def test_manifest_is_relative_and_hashed():
    rows = build_manifest(ROOT / "fixtures", {".txt", ".csv", ".json"})
    assert rows and all(not Path(row["path"]).is_absolute() for row in rows)
    assert all(len(row["sha256"]) == 64 for row in rows if row["state"] == "ready")


def test_job_store_duplicate_conflict_and_claim(tmp_path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    first = store.enqueue("E1", {"value": 1}, now=1)
    assert first == (1, False)
    assert JobStore(store.path).enqueue("E1", {"value": 1}, now=2) == (1, True)
    with pytest.raises(PayloadConflict):
        store.enqueue("E1", {"value": 2}, now=3)
    assert store.claim(now=4)["event_id"] == "E1"
    assert store.claim(now=5) is None


def test_http_client_retry_and_permanent_error():
    attempts = {"count": 0}

    def handler(request):
        attempts["count"] += 1
        return httpx.Response(503 if attempts["count"] == 1 else 200, json={"status": "ok"})

    result = request_json("GET", "https://example.test/health", transport=httpx.MockTransport(handler), sleep=lambda _: None)
    assert result == {"status": "ok"} and attempts["count"] == 2

    transport = httpx.MockTransport(lambda request: httpx.Response(422, json={"detail": "invalid"}))
    with pytest.raises(PermanentHTTPError, match="http_422"):
        request_json("POST", "https://example.test/items", payload={}, transport=transport)
