# 04 — HTTP/API Client ที่ไม่ค้างและไม่ Retry มั่ว

เปิด [safe_http.py](scripts/safe_http.py)

## Flow

```text
prepare request + stable event ID
 ↓ connect/read/write/pool timeout
send
 ├─ 2xx → validate response contract
 ├─ 4xx permanent → return controlled error; no retry
 ├─ 429/5xx selected → bounded backoff/retry
 └─ timeout/network unknown → replay same idempotency key
```

Timeout ไม่ได้พิสูจน์ว่า server ไม่ได้ commit งาน อาจเกิดหลัง server บันทึกแล้วแต่ response กลับไม่ถึง client ดังนั้นการ retry POST ต้องใช้ idempotency contract ไม่ใช่สร้าง event ID ใหม่

## ทำไม Retry เฉพาะบางกรณี

`422` หมายถึงแก้ request ก่อนส่งใหม่ การ retry payload เดิมไม่ได้ช่วย ส่วน `429`, network error หรือ selected `5xx` อาจเป็น transient แต่ต้องมี attempt budget และ backoff

```powershell
python scripts/safe_http.py http://127.0.0.1:8015/health
```

ในงานจริงอย่า log Authorization header, token หรือ response ที่มี PII ทั้งก้อน
