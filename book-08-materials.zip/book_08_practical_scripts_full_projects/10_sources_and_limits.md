# 10 — Sources, Versions และข้อจำกัด

## Primary References

- [Python Standard Library](https://docs.python.org/3/library/) — `pathlib`, `csv`, `json`, `hashlib`, `sqlite3`, `logging`, `argparse`
- [pypdf — Extract Text](https://pypdf.readthedocs.io/en/stable/user/extract-text.html)
- [python-docx documentation](https://python-docx.readthedocs.io/en/stable/)
- [python-docx — Working with Tables](https://python-docx.readthedocs.io/en/stable/user/tables.html)
- [HTTPX Timeouts](https://www.python-httpx.org/advanced/timeouts/)
- [FastAPI documentation](https://fastapi.tiangolo.com/)
- [Pydantic documentation](https://docs.pydantic.dev/)
- [Docker Compose documentation](https://docs.docker.com/compose/)

## ข้อจำกัดที่ห้ามลืม

- ตรวจ dependency รุ่นที่องค์กรอนุมัติก่อนใช้งานจริง เอกสารเล่มนี้ไม่ใช่ lockfile ระยะยาว
- `pypdf` ไม่ใช่ OCR และ PDF ไม่มี semantic structure แบบเดียวกับหน้าเว็บ
- Office/PDF parsers ประมวลผล input ที่อาจไม่น่าเชื่อถือ ต้องมี size/resource isolation/patch policy ตามความเสี่ยงจริง
- HTTP retry ต้องสัมพันธ์กับ method และ idempotency contract
- SQLite มี locking/concurrency/operations trade-offs ควรประเมินใหม่เมื่อหลาย host หรือ throughput สูง
- ตัวอย่าง authentication/token เป็น local demo boundary ไม่ใช่ production identity/RBAC
