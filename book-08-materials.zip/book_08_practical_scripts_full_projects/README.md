# Book 08 — Practical Script Library & Full Reference Projects

เล่มนี้เป็นสะพานระหว่าง “อ่านบทเรียน” กับ “เปิดไฟล์ไปทำงาน” ประกอบด้วยสคริปต์ขนาดเล็กที่หยิบใช้แยกได้ และโปรเจกต์เต็มสองแบบที่แสดงว่าชิ้นส่วนเหล่านั้นถูกประกอบเป็นระบบอย่างไร

## สิ่งที่อยู่ในเล่ม

### Practical Script Library

- อ่าน PDF, DOCX, TXT, CSV, JSON และ XLSX อย่างมีขอบเขต
- สำรวจไฟล์ทั้งโฟลเดอร์และสร้าง manifest
- hash/deduplicate โดยไม่เทียบข้อมูลด้วยตา
- เรียก HTTP API พร้อม timeout และ bounded retry
- ใช้ SQLite transaction/idempotency
- โหลด environment configuration, logging และ CLI
- tests และ safety checklist ก่อนนำไปปรับใช้

### Full Reference Projects

1. **Reliable Intake & Review Platform** — API, SQLite durable queue, worker, Mock AI, evidence validation, retry/lease, human review, audit, n8n, Docker และ tests
2. **Daily Operations Report Automation** — CSV/JSON intake, strict validation, atomic batch import, idempotency, SQLite, report API/CLI, audit, n8n, Docker และ tests

## วิธีใช้โดยไม่กลายเป็น Copy–Paste Engineering

```text
เลือก script
  ↓ อ่าน Input / Output / Failure
  ↓ รัน fixture เล็ก
  ↓ เขียน test ของ use case ตัวเอง
  ↓ เปลี่ยนทีละ boundary
  ↓ ตรวจ log/secret/PII
  ↓ ค่อยนำเข้าโปรเจกต์
```

อย่าคัดลอกทั้งไฟล์เพียงเพราะรันผ่าน ตัวอย่างทั้งหมดมีขอบเขต local/synthetic และต้องปรับ policy, limits, authentication, dependency versions และ observability ตามระบบจริง

## เริ่มจากตรงไหน

- ต้องอ่านเอกสาร: [01 — Document Readers](01_document_readers.md)
- ต้องส่ง batch: [02 — Tabular and Structured Data](02_tabular_structured_data.md)
- ต้องเชื่อม API: [04 — HTTP Client](04_http_api_client.md)
- ต้องเก็บงานไม่ให้หาย/ซ้ำ: [05 — SQLite Job Store](05_sqlite_transactions.md)
- อยากอ่านระบบเต็ม: [08 — Project A](08_full_project_a.md) และ [09 — Project B](09_full_project_b.md)
- เห็น syntax แล้วไม่แน่ใจว่าแต่ละบรรทัดทำอะไร: [11 — Easy Script Walkthrough](11_easy_script_code_walkthrough.md)

## ขอบเขตสำคัญ

- PDF text extraction ไม่ใช่ OCR และไม่รับรองลำดับข้อความจากทุก layout
- ตัวอย่างไม่อ่าน macro-enabled Office files
- ไม่ส่งเอกสารหรือข้อมูลจริงไปบริการภายนอก
- Mock AI ไม่ใช่ตัวชี้วัด accuracy ของโมเดลจริง
- SQLite เหมาะกับ local/small single-host workload ไม่ใช่คำตอบเดียวสำหรับทุก production scale
