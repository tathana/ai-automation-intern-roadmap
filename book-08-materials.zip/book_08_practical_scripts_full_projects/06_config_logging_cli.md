# 06 — Configuration, Logging และ CLI

เปิด [runtime_tools.py](scripts/runtime_tools.py)

## Configuration

อ่าน config จาก environment ที่ boundary เดียว ตรวจชนิด/range ตั้งแต่ startup และอย่าแอบใช้ default ที่อันตราย เช่น production URL หรือ token ว่างแล้วเปิด endpoint สำคัญ

```text
environment strings
 ↓ parse/validate once
Settings dataclass
 ↓ inject
service/repository/client
```

## Logging

ใช้ structured fields ที่ค้นตามเส้นทางงานได้:

```text
event=task_processed task_id=T123 attempt=2 state=needs_review duration_ms=84
```

ไม่ log raw resume, token, full payload หรือ stack trace ให้ end user Correlation ID ช่วยเชื่อม API → worker → n8n แต่ไม่ควรเป็นข้อมูลลับ

## CLI

`argparse` ช่วยให้ command มี `--help`, required arguments และ exit code สม่ำเสมอ แยก `main()` จาก core function เพื่อ test โดยไม่ต้อง spawn process ทุกกรณี

```powershell
python scripts/runtime_tools.py --help
python scripts/runtime_tools.py --show-config
```
