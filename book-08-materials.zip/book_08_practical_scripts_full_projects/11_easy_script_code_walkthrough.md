# 11 — Easy Script Walkthrough: แกะ Code Library ทีละ Pattern

บท 01–07 อธิบาย design และข้อควรระวัง บทนี้พาอ่าน syntax สำคัญใน script จริงเพื่อไม่ให้เห็นโค้ดแล้วต้องเดาความหมายเอง

## `Path` และการตรวจไฟล์

```python
source = Path(path)
if not source.is_file():
    raise DocumentReadError("file_not_found_or_not_regular")
```

`Path(path)` สร้าง object สำหรับจัดการ path ส่วน `.is_file()` เป็น `True` เฉพาะเมื่อ path มีอยู่และเป็นไฟล์ปกติ ช่วยแยก directory ออกจากไฟล์ก่อนเรียก `.read_bytes()`

```text
ข้อความ path → Path object → is_file?
                         ├─ no  → controlled error
                         └─ yes → อ่านต่อ
```

## ทำไมอ่านไฟล์เป็น Chunk ตอน Hash

```python
digest = hashlib.sha256()
with path.open("rb") as handle:
    while chunk := handle.read(1024 * 1024):
        digest.update(chunk)
```

- `rb` = read binary เพราะ hash คำนวณจาก bytes
- `with` ปิดไฟล์ให้อัตโนมัติแม้เกิด exception
- `:=` เก็บผลอ่านไว้ใน `chunk` พร้อมใช้เป็นเงื่อนไข
- อ่านครั้งละ 1 MiB ไม่โหลดไฟล์ใหญ่ทั้งก้อนเข้าหน่วยความจำ
- เมื่ออ่านถึงท้ายไฟล์ได้ `b""` ซึ่งเป็น false แล้ว loop จบ

## List of Dicts มาจากไหน

```python
with source.open("r", encoding="utf-8-sig", newline="") as handle:
    reader = csv.DictReader(handle)
    rows = [dict(row) for row in reader]
```

Header กลายเป็น key และแต่ละบรรทัดกลายเป็น dict:

```text
event_id,amount
E1,100
    ↓
{"event_id": "E1", "amount": "100"}
```

CSV คืน `"100"` เป็น string; domain model ยังต้องแปลง/ตรวจเป็น integer

## `try/except ... from exc`

```python
try:
    payload = json.loads(text)
except json.JSONDecodeError as exc:
    raise StructuredDataError("invalid_json") from exc
```

ชั้น library แปลง error รายละเอียดของ parser เป็น error contract ของเรา ส่วน `from exc` เก็บสาเหตุเดิมไว้ใน traceback สำหรับ debug

## Dependency ที่ Import เฉพาะตอนใช้

```python
if suffix == ".pdf":
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError("install pypdf to read PDF") from exc
```

คนที่ใช้เฉพาะ TXT ยัง import module ได้แม้ไม่มี pypdf แต่เมื่อขออ่าน PDF จะได้ข้อความ dependency ชัด เทคนิคนี้เรียกว่า optional/lazy import ในตัวอย่างเล็ก

## Atomic Replace

```python
with NamedTemporaryFile(..., dir=target.parent, delete=False) as handle:
    json.dump(payload, handle)
    handle.flush()
    os.fsync(handle.fileno())
os.replace(handle.name, target)
```

`flush()` ส่งข้อมูลจาก Python buffer, `fsync()` ขอให้ระบบส่งข้อมูลลง storage, `replace()` สลับชื่อไฟล์เป็นเป้าหมายแบบ atomic ตามความสามารถ filesystem เดียวกัน จึงสร้าง temp ใน directory เดียวกับ target

## Context Manager ของ SQLite

```python
@contextmanager
def connection(self):
    connection = sqlite3.connect(self.path)
    try:
        with connection:
            yield connection
    finally:
        connection.close()
```

`yield` ส่ง connection ให้ block ผู้เรียกชั่วคราว `with connection` commit เมื่อจบปกติและ rollback เมื่อ exception ส่วน `finally` ปิด connection เสมอ

## HTTP Retry Loop

```python
for attempt in range(1, attempts + 1):
    try:
        return send_and_parse()
    except transient_errors:
        if attempt == attempts:
            break
        sleep(min(2 ** (attempt - 1), 4))
```

`range(1, attempts + 1)` ทำให้เลขรอบเริ่ม 1, `2 ** (attempt - 1)` ได้ backoff 1, 2, 4 วินาที และ `min(..., 4)` จำกัดเพดาน ตัวอย่างจริงแยก permanent error เพื่อไม่ retry `422` อย่างไร้ประโยชน์

## Dataclass Settings

```python
@dataclass(frozen=True)
class Settings:
    database_path: str
    http_timeout_seconds: float
```

Dataclass ช่วยสร้าง constructor/representation จาก field ส่วน `frozen=True` ป้องกันการแก้ค่าโดยไม่ตั้งใจหลัง startup ไม่ได้ทำให้ secret ปลอดภัยขึ้น—ยังต้องไม่ print/log secret

## วิธีฝึกกับแต่ละ Script

1. ทาย output จาก fixture ก่อนรัน
2. รัน happy path
3. เปลี่ยน input ให้ผิดหนึ่งเรื่อง
4. อ่าน traceback/controlled error
5. เปิด test ที่เกี่ยวข้อง
6. เปลี่ยน limit เล็กหนึ่งจุดและเพิ่ม test
7. อธิบาย input/output/side effect/failure ด้วยภาษาตัวเอง
