# 00 — Mental Model: Script ที่ใช้ซ้ำได้ต้องมี Contract

สคริปต์ที่ “ใช้ได้บนเครื่องเรา” ยังไม่เท่ากับสคริปต์ที่ทีมใช้ต่อได้ ก่อนเขียนให้ตอบห้าข้อ:

| คำถาม | ตัวอย่าง document reader |
|---|---|
| Input คืออะไร | path ที่ caller เลือกไว้แล้ว |
| Output คืออะไร | text + metadata/hash |
| Side effect คืออะไร | อ่านไฟล์; ไม่ลบ/ย้าย/ส่งออก |
| Failure คืออะไร | unsupported, encrypted, empty, too large |
| Trust boundary อยู่ไหน | filename/extension ยังไม่ใช่หลักฐานว่าไฟล์ปลอดภัย |

## โครงที่ควรเห็น

```text
CLI/API input
   ↓ parse + validate
pure/core function
   ↓ typed result
side-effect boundary
   ↓ file / network / database
observable result + controlled error
```

แยก core function ออกจาก `argparse`, HTTP route และ `print()` เพื่อให้ test logic โดยไม่ต้องเปิด network หรือเขียนไฟล์จริงทุกครั้ง

## Copy แล้วต้องเปลี่ยนอะไรบ้าง

1. limits: ขนาดไฟล์, จำนวนหน้า/แถว, timeout
2. policy: extension/MIME, path allowlist, PII handling
3. contracts: required columns/fields และ error shape
4. observability: correlation ID, log fields, metrics
5. recovery: retry ได้หรือไม่, idempotency key คืออะไร

> Script library เป็น starting point ไม่ใช่ production guarantee คำว่า reusable หมายถึง boundary ชัดและมี test ไม่ใช่ใช้ได้โดยไม่ต้องอ่าน
