# 09 — Full Project B: Daily Operations Report Automation

โปรเจกต์นี้เป็น reference implementation ใหม่สำหรับงาน automation ที่ deterministic ทั้งเส้น ไม่ใช้ LLM เพื่อแสดงว่า AI ไม่จำเป็นกับทุกปัญหา

```text
CSV/JSON file หรือ POST /batches
  ↓ strict record validation
canonical batch hash + UNIQUE batch_id
  ↓ atomic SQLite import + audit
GET/CLI daily report
  ↓ JSON output แบบ atomic
n8n ส่งเข้า API และ route duplicate/conflict/failure
```

## Business Contract

แต่ละ event มี `event_id`, `occurred_at`, `amount_minor`, `status` (`success`/`failed`) และ `channel` ถ้า batch เดิม/payload เดิมส่งซ้ำต้องคืน batch เดิมโดยไม่เพิ่ม event ถ้า batch ID เดิมแต่ payloadเปลี่ยนต้อง conflict

รายงานรายวันคืนจำนวนทั้งหมด, success/failed, success amount, breakdown ตาม channel และ timestamp รุ่น report โดยคำนวณจาก rows ใน DB ไม่เชื่อ aggregate จาก client

## วิธีรัน

เปิด [Project B Guided Code Tour](full_projects/project_b_daily_ops_report/GUIDED_CODE_TOUR.md) เพื่อไล่ CSV → Pydantic → transaction → SQL report ทีละ block จากนั้นเปิด [Project B README](full_projects/project_b_daily_ops_report/README.md) และเริ่มจาก:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -q
```

จากนั้นทดลอง CLI import/report แล้วค่อยเปิด API และ n8n

## จุดที่ควรศึกษา

- validation แยก parser syntax ออกจาก domain rule
- database transaction ทำให้ batch ไม่เข้าครึ่งเดียว
- idempotency ทำให้ safe replay หลัง timeout
- report output เขียนแบบ temporary + replace
- tests พิสูจน์ restart, duplicate, conflict, invalid row และ aggregate
- README/runbook ระบุ limitation ของ SQLite และ local authentication
