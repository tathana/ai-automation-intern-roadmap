# 02 — CSV, JSON และ Excel

เปิด [structured_io.py](scripts/structured_io.py) สำหรับ reader/writer ที่คืน `list[dict]` และตรวจ required columns

## Mental Model

```text
bytes/file
 ↓ parser ของ format
rows: list[dict[str, object]]
 ↓ validate required fields/types/business rules
domain records
 ↓ process/store/report
```

Parser เพียงบอกว่า syntax อ่านได้ ไม่ได้บอกว่าข้อมูลถูกต้อง เช่น CSV มีคอลัมน์ `amount_minor` แต่ค่าเป็น `"ten"` ยังต้องให้ model/domain validator ปฏิเสธ

## CSV

เปิดด้วย `newline=""` และระบุ encoding เพื่อให้โมดูล `csv` จัดการบรรทัดได้ถูกต้อง ตรวจ header ซ้ำ/ว่างและจำกัดจำนวนแถว

## JSON

ประกาศก่อนว่าจะรับ JSON array หรือ object ที่มี key เช่น `records` อย่าเขียน code ที่เดาได้หลาย shape จน caller ไม่รู้ contract

## XLSX

ใช้ `openpyxl` แบบ `read_only=True`, `data_only=True` และเลือก worksheet/required header ชัด ตัวอย่างไม่อ่าน `.xls`, `.xlsm` หรือสูตรเป็น logic; `data_only=True` อ่าน cached result ซึ่งอาจไม่มีหรือเก่าได้ จึงต้องบันทึก limitation

## การเขียน Output แบบ Atomic

ไฟล์รายงานควรเขียน temporary file ใน directory เดียวกันก่อน แล้ว replace เป้าหมายเมื่อเขียนเสร็จ:

```text
report.json.tmp
  ↓ write + flush สำเร็จ
replace
  ↓
report.json
```

ช่วยลดโอกาสมี output ครึ่งไฟล์เมื่อ process หยุด แต่ไม่ได้แทน backup/versioning

## ทดลอง

```powershell
python scripts/structured_io.py fixtures/events.csv --required event_id occurred_at amount_minor status
python scripts/structured_io.py fixtures/events.json --required event_id occurred_at amount_minor status
```
