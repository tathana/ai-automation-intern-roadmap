# 07 — Testing และ Safety Checklist สำหรับ Script

## Test Pyramid ขนาดเล็ก

```text
มาก: pure/unit — normalize, validate, hash, aggregate
กลาง: file/SQLite integration — tmp_path, real parser, transaction
น้อย: HTTP/process/Docker — boundary จริงและ clean start
```

## Checklist ก่อน Copy ไปใช้งาน

- [ ] ใช้ synthetic fixture ก่อนข้อมูลจริง
- [ ] input/output/error contract เขียนไว้แล้ว
- [ ] จำกัด size/pages/rows/timeout/attempts
- [ ] path มาจาก trusted caller และไม่รับ arbitrary URL/path ผ่าน public API
- [ ] ไม่มี secret/PII ใน source, fixture, log และ test snapshot
- [ ] write เป็น atomic/transactional เท่าที่เหมาะสม
- [ ] retry operation มี idempotency
- [ ] dependency/version ตรง environment ปัจจุบัน
- [ ] tests มี happy, invalid, empty, duplicate และ dependency failure
- [ ] README ระบุ exact CWD/interpreter/expected output

## คำถาม Review

1. ถ้ารันซ้ำสองครั้ง side effect เพิ่มหรือไม่
2. ถ้าหยุดกลางทางตรวจสถานะและทำต่ออย่างไร
3. ถ้า input ใหญ่หรือ malformed ระบบใช้ทรัพยากรเท่าไร
4. ถ้า dependency ตอบช้า/ผิด schema เราเชื่ออะไร
5. คนรับช่วงต่อพิสูจน์ได้อย่างไรว่ารุ่นนี้ผ่าน
