# 05 — SQLite Transaction และ Durable Job Store

เปิด [sqlite_job_store.py](scripts/sqlite_job_store.py)

## กฎหลัก

```text
BEGIN IMMEDIATE
  ↓ insert event/task/audit
COMMIT
  ↓ จึงตอบ accepted
```

ถ้าสามการเขียนเป็น business action เดียวกัน ต้องสำเร็จหรือล้มเหลวร่วมกัน อย่าตอบ `202` ก่อน commit

## Unique Constraint เป็นด่านจริง

การ `SELECT` ก่อนแล้วค่อย `INSERT` อย่างเดียวมี race เมื่อ request มาพร้อมกัน วาง `UNIQUE(event_id)` ที่ database แล้วจัดการ collision ด้วย hash/contract:

```text
same event + same canonical payload → duplicate เดิม
same event + different payload      → conflict
```

## Transaction ไม่ควรครอบ Network Call

```text
transaction A: claim + lease → commit
call provider/API นอก transaction
transaction B: persist result if lease token valid → commit
```

การเปิด write transaction ระหว่างรอ network ทำให้ writer อื่นติด lock โดยไม่จำเป็น

## ทดลอง

```powershell
python scripts/sqlite_job_store.py --db tmp/jobs.sqlite3 enqueue DEMO-001
python scripts/sqlite_job_store.py --db tmp/jobs.sqlite3 claim
python scripts/sqlite_job_store.py --db tmp/jobs.sqlite3 list
```

ไฟล์นี้เป็น educational single-host store ยังไม่ใช่ distributed queue
