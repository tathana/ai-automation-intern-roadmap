# 08 — Full Project A: Reliable Intake & Review Platform

โปรเจกต์นี้ยก capstone ที่ผ่านการทดสอบจาก Book 05 มาเป็น reference source เต็ม ไม่ใช่ starter ที่เว้น TODO

```text
Transaction/Resume Intake API
  ↓ SQLite task + audit (atomic)
Worker claim + lease
  ↓ deterministic rules / Mock AI
output contract + evidence validation
  ↓ succeeded / retry_pending / needs_review / failed
Human review with token + idempotent decision
```

## สิ่งที่ครอบคลุม

- FastAPI/Pydantic contracts และ truthful HTTP errors
- durable SQLite queue, unique constraints และ restart persistence
- concurrent intake/claim tests
- bounded retry, lease reclaim และ stale-worker protection
- PDF/DOCX local CLI ingestion พร้อม limits
- Mock AI, invalid JSON และ hallucination scenarios
- lexical evidence validation และ human review
- audit history, Docker Compose, CI, runbook และ n8n examples

เปิด [Project A README](full_projects/project_a_reliable_intake_review/README.md) แล้วรัน native tests ก่อน Docker โปรเจกต์ใช้ synthetic fixtures และไม่ทำ hiring/financial action จริง

## เส้นทางอ่าน Code

```text
models.py → api.py → repository.py
          → service.py → worker.py
tests/test_capstone.py → RUNBOOK.md → compose.yaml
```

อ่าน test คู่กับ implementation ทุกครั้ง โดยเฉพาะ duplicate/conflict, concurrent claim, retry budget, stale lease และ review idempotency
