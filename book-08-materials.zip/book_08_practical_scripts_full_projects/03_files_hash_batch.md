# 03 — Batch Files, Manifest, Hash และ Deduplication

เปิด [batch_manifest.py](scripts/batch_manifest.py)

## ทำไมไม่วนทุกไฟล์แล้วประมวลผลทันที

แยก discovery ออกจาก processing ทำให้ตรวจ scope ก่อนเกิด side effect:

```text
discover files
 ↓ filter extension + reject symlink ตาม policy
build manifest: relative path, size, sha256
 ↓ review/count/limit
process approved manifest
```

SHA-256 ช่วยเทียบ bytes ว่าเหมือนกัน แต่ไม่บอกว่าเอกสารสองไฟล์ “ความหมายเดียวกัน” และ hash ของ extracted text ต่างจาก hash ของ original bytes ต้องตั้งชื่อ field เช่น `file_sha256` กับ `text_sha256` ให้ชัด

## Idempotency Key ไม่จำเป็นต้องเท่ากับ File Hash

```text
task_key = file_sha256 + parser_version + policy_version
```

ไฟล์เดิมแต่ parser รุ่นใหม่อาจสมควรประมวลผลใหม่ ในทางกลับกัน client retry request เดิมควรได้ task เดิม จึงต้องเขียน contract ตาม business event ไม่ใช่เลือก hash แบบสุ่ม

## ทดลอง

```powershell
python scripts/batch_manifest.py fixtures --extension .json .csv .txt
```

สคริปต์ไม่ follow symlink และคืน relative path เพื่อไม่เผย absolute directory ใน manifest ที่นำไปแชร์
