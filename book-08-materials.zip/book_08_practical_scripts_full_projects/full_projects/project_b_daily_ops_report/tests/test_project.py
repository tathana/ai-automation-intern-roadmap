from datetime import date
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

from ops_report.api import create_app
from ops_report.cli import load_records
from ops_report.models import BatchRequest
from ops_report.repository import BatchConflict, EventConflict, Store
from ops_report.service import accept_batch, create_report, write_report_atomic


ROOT = Path(__file__).parents[1]


def batch(batch_id="B1", event_id="E1", amount=100, status="success", channel="app"):
    return BatchRequest(
        batch_id=batch_id,
        records=[
            {
                "event_id": event_id,
                "occurred_at": "2026-09-13T08:00:00+07:00",
                "amount_minor": amount,
                "status": status,
                "channel": channel,
            }
        ],
    )


def test_csv_loader_and_validation():
    rows = load_records(ROOT / "fixtures" / "events.csv")
    parsed = BatchRequest(batch_id="CSV-1", records=rows)
    assert len(parsed.records) == 3 and parsed.records[0].amount_minor == 12500


def test_atomic_import_duplicate_conflict_and_restart(tmp_path):
    path = tmp_path / "ops.sqlite3"
    store = Store(path)
    assert store.import_batch(batch(), now=1) == (1, False)
    assert Store(path).import_batch(batch(), now=2) == (1, True)
    with pytest.raises(BatchConflict, match="BATCH_PAYLOAD_CONFLICT"):
        store.import_batch(batch(amount=999), now=3)
    assert len(store.audit("B1")) == 1


def test_event_cannot_enter_another_batch(tmp_path):
    store = Store(tmp_path / "ops.sqlite3")
    store.import_batch(batch("B1", "E1"))
    with pytest.raises(EventConflict, match="EVENT_ALREADY_IMPORTED"):
        store.import_batch(batch("B2", "E1"))
    assert store.audit("B2") == []


def test_daily_report_and_atomic_output(tmp_path):
    store = Store(tmp_path / "ops.sqlite3")
    store.import_batch(
        BatchRequest(
            batch_id="B1",
            records=[
                batch(event_id="E1", amount=100).records[0],
                batch(event_id="E2", amount=50, status="failed", channel="web").records[0],
                batch(event_id="E3", amount=25, channel="web").records[0],
            ],
        )
    )
    report = create_report(store, date(2026, 9, 13))
    assert (report.total, report.success, report.failed, report.success_amount_minor) == (3, 2, 1, 125)
    assert [row.channel for row in report.channels] == ["app", "web"]
    target = tmp_path / "reports" / "daily.json"
    write_report_atomic(target, report)
    assert '"total": 3' in target.read_text(encoding="utf-8")
    assert not list(target.parent.glob("*.tmp"))


def test_api_contract_validation_and_conflicts(tmp_path):
    client = TestClient(create_app(str(tmp_path / "api.sqlite3")))
    payload = batch().model_dump(mode="json")
    first = client.post("/batches", json=payload)
    assert first.status_code == 202 and first.json()["duplicate"] is False
    assert client.post("/batches", json=payload).json()["duplicate"] is True
    conflict = {**payload, "records": [{**payload["records"][0], "amount_minor": 999}]}
    assert client.post("/batches", json=conflict).status_code == 409
    assert client.post("/batches", json={**payload, "records": []}).status_code == 422
    assert client.get("/ready").status_code == 200
    report = client.get("/reports/2026-09-13")
    assert report.status_code == 200 and report.json()["total"] == 1
    assert client.get("/batches/B1/audit").status_code == 200
    assert client.get("/batches/missing/audit").status_code == 404
