from __future__ import annotations

from datetime import date
import os

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

from .models import BatchAccepted, BatchRequest, DailyReport
from .repository import BatchConflict, EventConflict, Store
from .service import accept_batch, create_report


def create_app(path: str | None = None) -> FastAPI:
    store = Store(path or os.environ.get("OPS_DB", "data/ops.sqlite3"))
    app = FastAPI(title="Daily Operations Report Automation", version="1.0.0")
    app.state.store = store

    @app.exception_handler(BatchConflict)
    @app.exception_handler(EventConflict)
    async def conflict_handler(request, exc):
        return JSONResponse(status_code=409, content={"detail": str(exc)})

    @app.get("/health")
    def health():
        return {"status": "alive", "scope": "local-synthetic"}

    @app.get("/ready")
    def ready():
        try:
            if store.ready():
                return {"status": "ready", "database": "sqlite"}
        except Exception:
            pass
        raise HTTPException(503, "database_not_ready")

    @app.post("/batches", response_model=BatchAccepted, status_code=202)
    def create_batch(batch: BatchRequest):
        return accept_batch(store, batch)

    @app.get("/reports/{day}", response_model=DailyReport)
    def get_report(day: date):
        return create_report(store, day)

    @app.get("/batches/{batch_id}/audit")
    def get_audit(batch_id: str):
        records = store.audit(batch_id)
        if not records:
            raise HTTPException(404, "batch_not_found")
        return {"batch_id": batch_id, "records": records}

    return app


app = create_app()
