from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Event(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_id: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9._:-]+$")
    occurred_at: datetime
    amount_minor: int = Field(ge=0, le=1_000_000_000)
    status: Literal["success", "failed"]
    channel: str = Field(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")

    @field_validator("event_id", "channel", mode="before")
    @classmethod
    def reject_untrimmed(cls, value):
        if not isinstance(value, str) or value != value.strip():
            raise ValueError("must be a trimmed string")
        return value

    @field_validator("amount_minor", mode="before")
    @classmethod
    def require_integer_amount(cls, value):
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("amount_minor must be an integer, not a numeric string")
        return value


class BatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    batch_id: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9._:-]+$")
    records: list[Event] = Field(min_length=1, max_length=1_000)

    @field_validator("batch_id", mode="before")
    @classmethod
    def reject_untrimmed_batch(cls, value):
        if not isinstance(value, str) or value != value.strip():
            raise ValueError("must be a trimmed string")
        return value

    @model_validator(mode="after")
    def unique_events(self):
        keys = [record.event_id for record in self.records]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate event_id inside batch")
        return self


class BatchAccepted(BaseModel):
    batch_id: str
    record_count: int
    duplicate: bool


class ChannelSummary(BaseModel):
    channel: str
    total: int
    success: int
    failed: int
    success_amount_minor: int


class DailyReport(BaseModel):
    day: date
    total: int
    success: int
    failed: int
    success_amount_minor: int
    channels: list[ChannelSummary]
    report_version: str = "v1"
