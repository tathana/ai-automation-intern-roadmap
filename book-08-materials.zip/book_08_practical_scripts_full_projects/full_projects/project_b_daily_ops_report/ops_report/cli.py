from __future__ import annotations

import argparse
import csv
from datetime import date
import json
import os
from pathlib import Path

from pydantic import ValidationError

from .models import BatchRequest
from .repository import BatchConflict, EventConflict, Store
from .service import accept_batch, create_report, write_report_atomic


def load_records(path: str | Path) -> list[dict]:
    source = Path(path)
    if source.suffix.casefold() == ".csv":
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            return [dict(row) | {"amount_minor": int(row["amount_minor"])} for row in csv.DictReader(handle)]
    if source.suffix.casefold() == ".json":
        payload = json.loads(source.read_text(encoding="utf-8-sig"))
        records = payload if isinstance(payload, list) else payload.get("records")
        if not isinstance(records, list):
            raise ValueError("JSON must be an array or contain records")
        return records
    raise ValueError("only .csv and .json are supported")


def main() -> int:
    parser = argparse.ArgumentParser(description="Daily operations report CLI")
    parser.add_argument("--db", default=os.environ.get("OPS_DB", "data/ops.sqlite3"))
    commands = parser.add_subparsers(dest="command", required=True)
    importer = commands.add_parser("import")
    importer.add_argument("--batch-id", required=True)
    importer.add_argument("--file", required=True)
    report = commands.add_parser("report")
    report.add_argument("--day", required=True)
    report.add_argument("--output")
    args = parser.parse_args()
    store = Store(args.db)
    try:
        if args.command == "import":
            result = accept_batch(store, BatchRequest(batch_id=args.batch_id, records=load_records(args.file)))
            print(result.model_dump_json(indent=2))
        else:
            result = create_report(store, date.fromisoformat(args.day))
            if args.output:
                write_report_atomic(args.output, result)
            print(result.model_dump_json(indent=2))
    except (OSError, ValueError, json.JSONDecodeError, ValidationError, BatchConflict, EventConflict) as exc:
        print(json.dumps({"ok": False, "error_type": type(exc).__name__, "detail": str(exc)}))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
