from __future__ import annotations

from contextlib import contextmanager
from datetime import date
import hashlib
import json
from pathlib import Path
import sqlite3
import time

from .models import BatchRequest, DailyReport


class BatchConflict(ValueError):
    pass


class EventConflict(ValueError):
    pass


def canonical_batch(batch: BatchRequest) -> str:
    return json.dumps(batch.model_dump(mode="json"), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


class Store:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS batches(
                  batch_id TEXT PRIMARY KEY,
                  payload_hash TEXT NOT NULL,
                  payload TEXT NOT NULL,
                  record_count INTEGER NOT NULL,
                  created REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events(
                  event_id TEXT PRIMARY KEY,
                  batch_id TEXT NOT NULL REFERENCES batches(batch_id),
                  occurred_at TEXT NOT NULL,
                  day TEXT NOT NULL,
                  amount_minor INTEGER NOT NULL,
                  status TEXT NOT NULL,
                  channel TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit(
                  id INTEGER PRIMARY KEY,
                  batch_id TEXT NOT NULL,
                  action TEXT NOT NULL,
                  at REAL NOT NULL,
                  details TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS events_day ON events(day);
                """
            )

    @contextmanager
    def connection(self):
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def import_batch(self, batch: BatchRequest, now: float | None = None) -> tuple[int, bool]:
        raw = canonical_batch(batch)
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        timestamp = time.time() if now is None else now
        with self.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT payload_hash,record_count FROM batches WHERE batch_id=?", (batch.batch_id,)
            ).fetchone()
            if existing:
                if existing["payload_hash"] != digest:
                    raise BatchConflict("BATCH_PAYLOAD_CONFLICT")
                return int(existing["record_count"]), True
            event_ids = [record.event_id for record in batch.records]
            placeholders = ",".join("?" for _ in event_ids)
            collision = connection.execute(
                f"SELECT event_id FROM events WHERE event_id IN ({placeholders}) LIMIT 1", event_ids
            ).fetchone()
            if collision:
                raise EventConflict(f"EVENT_ALREADY_IMPORTED:{collision['event_id']}")
            connection.execute(
                "INSERT INTO batches VALUES (?,?,?,?,?)",
                (batch.batch_id, digest, raw, len(batch.records), timestamp),
            )
            connection.executemany(
                "INSERT INTO events VALUES (?,?,?,?,?,?,?)",
                [
                    (
                        record.event_id,
                        batch.batch_id,
                        record.occurred_at.isoformat(),
                        record.occurred_at.date().isoformat(),
                        record.amount_minor,
                        record.status,
                        record.channel,
                    )
                    for record in batch.records
                ],
            )
            connection.execute(
                "INSERT INTO audit(batch_id,action,at,details) VALUES (?,?,?,?)",
                (batch.batch_id, "batch_imported", timestamp, json.dumps({"record_count": len(batch.records)})),
            )
            return len(batch.records), False

    def report(self, day: date) -> DailyReport:
        day_text = day.isoformat()
        with self.connection() as connection:
            total = connection.execute(
                """SELECT COUNT(*) total,
                          SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) success,
                          SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed,
                          SUM(CASE WHEN status='success' THEN amount_minor ELSE 0 END) success_amount
                   FROM events WHERE day=?""",
                (day_text,),
            ).fetchone()
            channels = connection.execute(
                """SELECT channel, COUNT(*) total,
                          SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) success,
                          SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed,
                          SUM(CASE WHEN status='success' THEN amount_minor ELSE 0 END) success_amount_minor
                   FROM events WHERE day=? GROUP BY channel ORDER BY channel""",
                (day_text,),
            ).fetchall()
        return DailyReport(
            day=day,
            total=int(total["total"] or 0),
            success=int(total["success"] or 0),
            failed=int(total["failed"] or 0),
            success_amount_minor=int(total["success_amount"] or 0),
            channels=[dict(row) for row in channels],
        )

    def audit(self, batch_id: str) -> list[dict]:
        with self.connection() as connection:
            return [
                {**dict(row), "details": json.loads(row["details"])}
                for row in connection.execute(
                    "SELECT action,at,details FROM audit WHERE batch_id=? ORDER BY id", (batch_id,)
                )
            ]

    def ready(self) -> bool:
        with self.connection() as connection:
            return connection.execute("SELECT 1").fetchone()[0] == 1
