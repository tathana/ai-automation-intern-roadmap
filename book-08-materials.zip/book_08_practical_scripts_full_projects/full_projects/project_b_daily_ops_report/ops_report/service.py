from __future__ import annotations

import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

from .models import BatchAccepted, BatchRequest, DailyReport
from .repository import Store


def accept_batch(store: Store, batch: BatchRequest) -> BatchAccepted:
    count, duplicate = store.import_batch(batch)
    return BatchAccepted(batch_id=batch.batch_id, record_count=count, duplicate=duplicate)


def create_report(store: Store, day) -> DailyReport:
    return store.report(day)


def write_report_atomic(path: str | Path, report: DailyReport) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = ""
    try:
        with NamedTemporaryFile("w", encoding="utf-8", dir=target.parent, delete=False, suffix=".tmp") as handle:
            json.dump(report.model_dump(mode="json"), handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
            temporary = handle.name
        os.replace(temporary, target)
    finally:
        if temporary:
            Path(temporary).unlink(missing_ok=True)
