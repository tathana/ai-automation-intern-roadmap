# Runbook — Daily Operations Report Automation

## Known Good Check

```powershell
python -m pytest -q
python -m ops_report.cli --db tmp/check.sqlite3 import --batch-id CHECK-001 --file fixtures/events.csv
python -m ops_report.cli --db tmp/check.sqlite3 report --day 2026-09-13
```

## Symptom → First Boundary

| Symptom | ตรวจแรก | Safe action |
|---|---|---|
| CLI อ่าน CSV ไม่ได้ | CWD, path, header, UTF-8 | รัน fixture เดิม; ไม่แก้โดย ignore columns |
| API `422` | response detail + request shape | เทียบ OpenAPI/Pydantic contract |
| API `409` | batch ID/event ID และ payload hash | replay payloadเดิม; อย่าสุ่ม ID เพื่อซ่อน conflict |
| report เป็นศูนย์ | day/timezone และ DB path | query DB/path ที่ process ใช้จริง |
| Compose API ไม่เห็น native data | named volume vs host `data/` | เลือก mode/DB ชัด; ไม่คัดลอก DB ขณะเขียน |
| readiness `503` | permissions/path/schema | ตรวจ container logs และ mounted volume |

## Safe Restart

Native: หยุดด้วย `Ctrl+C` แล้วเปิดคำสั่งเดิมพร้อม `OPS_DB` เดิม SQLite เก็บ accepted batch ไว้

Compose:

```powershell
docker compose restart api
docker compose ps
docker compose logs --tail 50 api
```

อย่าใช้ `down -v` ระหว่างการทดสอบ persistence เพราะคำสั่งนั้นลบ named volume

## Evidence ก่อน Handoff

- commit/version และ Python/Docker version
- exact test command + result
- batch ID synthetic ที่ใช้ demo
- duplicate/conflict evidence
- report expected/actual
- known limitations และ owner ขั้นถัดไป

## Incident Boundary

ระบบตัวอย่างไม่มีเงินจริงและไม่มี downstream side effect หากนำ pattern ไปใช้จริง ต้องเพิ่ม authentication, backup/restore, migrations, monitoring, retention, incident contact และ reconciliation ตาม policy องค์กร
