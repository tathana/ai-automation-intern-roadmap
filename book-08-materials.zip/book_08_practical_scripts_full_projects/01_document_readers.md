# 01 — Document Readers: PDF, DOCX และ TXT

## ภาพรวม

```text
path
 ↓ ตรวจชนิด + size ก่อน
reader ตาม format
 ↓ extract text
normalize whitespace แบบไม่ทำลายหลักฐาน
 ↓ ตรวจ empty/length
DocumentText(text, sha256, pages, warnings)
```

เปิด [document_reader.py](scripts/document_reader.py) เพื่อดู implementation ที่รวม dispatch และ limits ไว้จุดเดียว

## PDF

`pypdf.PdfReader` อ่าน text layer ของแต่ละหน้าได้ แต่ PDF ที่เป็นภาพสแกนมักไม่มี text ให้ดึง และ layout หลายคอลัมน์อาจได้ลำดับคำไม่เหมือนที่ตามองเห็น

```python
from pypdf import PdfReader

reader = PdfReader("synthetic.pdf")
text = "\n".join(page.extract_text() or "" for page in reader.pages)
```

ก่อนวนทุกหน้า ตัวอย่างตรวจ file size, encryption และจำนวนหน้า หลัง extract ตรวจ empty อีกครั้ง ถ้า empty ให้ส่งไปเส้นทาง OCR/review ที่ประกาศไว้ ไม่ควรสร้างข้อความเดาเอง

## DOCX

DOCX เป็น ZIP package ไม่ใช่ text file ธรรมดา Reader จึงตรวจจำนวน entries และ uncompressed size เพื่อจำกัด zip expansion จากนั้นอ่าน paragraphs และ tables ตาม document order เท่าที่ API รองรับ

```text
DOCX package
 ├─ paragraphs
 ├─ tables/cells
 └─ other objects เช่น image/text box
```

ตัวอย่างนี้ไม่ทำ OCR รูปใน DOCX และไม่รับรอง text box/complex layout ทุกชนิด จึงต้องมี warning/fixture ตามเอกสารจริงที่ระบบจะรองรับ

## TXT

TXT ดูง่ายแต่ยังต้องกำหนด encoding และ size ตัวอย่างใช้ UTF-8 แบบ strict หากเจอไฟล์จากระบบเก่าที่เป็น encoding อื่น ให้ตรวจและแปลงใน ingestion boundary แยก ไม่ใช้ `errors="ignore"` จนข้อมูลหายเงียบ

## ทดลอง

```powershell
python scripts/document_reader.py fixtures/synthetic_note.txt
python scripts/document_reader.py fixtures/synthetic_resume.pdf
```

Expected คือ JSON metadata และ preview ไม่ใช่การ print เอกสารทั้งหมด เพราะ log/terminal อาจถูกเก็บย้อนหลัง

## Failure ที่ต้องทดสอบ

- extension ไม่รองรับ
- ไฟล์เกิน limit
- PDF encrypted/เกินจำนวนหน้า
- PDF scan แล้ว text ว่าง
- DOCX expansion สูงผิดปกติ
- TXT encoding ไม่ถูกต้อง
- path ไม่มีจริงหรือเป็น directory
