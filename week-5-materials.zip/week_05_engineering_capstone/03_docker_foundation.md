# 03 — Docker: Image, Container และ Build Context

## ทำไมมี Docker ทั้งที่ Python รันได้แล้ว

เครื่องเราอาจมี Python และ package พร้อม แต่เครื่องเพื่อนอาจไม่เหมือนกัน Docker ช่วยกำหนดสภาพแวดล้อมสำหรับรันไว้เป็น image ถึงอย่างนั้นก็ไม่ได้ทำให้ทุกเครื่องเหมือนกันทุกด้าน: architecture, kernel, network และการตั้งค่าภายนอกยังมีผล

```text
Dockerfile + source + dependencies
               ↓ docker build
             image       ← แบบสำเร็จสำหรับเริ่ม process
               ↓ run
           container     ← instance ที่กำลังรัน
```

Image ไม่ใช่ container และ container ที่หยุดไม่ได้แปลว่า image หาย หนึ่ง image ใช้สร้างหลาย container ได้ เช่น API กับ worker ใช้ source เดียวกันแต่คนละคำสั่งเริ่มต้น

## อ่าน Dockerfile ทีละส่วน

เปิด [Dockerfile](capstone/Dockerfile) แล้วไล่ตามนี้:

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY course ./course
```

`FROM` เลือก base image, `WORKDIR` กำหนด directory สำหรับคำสั่งถัดไป, `COPY` นำไฟล์จาก **build context** เข้า image, `RUN` ทำระหว่าง build ไม่ใช่ทุกครั้งที่เปิด container ส่วน `CMD` เป็นคำสั่งเริ่มต้นตอนรันและ override ได้

เรา copy requirements ก่อน source เพื่อให้การแก้ Python อย่างเดียวอาจใช้ dependency layer เดิมได้ แต่ cache ไม่ใช่คำรับประกันว่า dependency ล่าสุดปลอดภัย ต้องมีรอบอัปเดตและตรวจตามกระบวนการของทีม Tag `python:3.12-slim` เปลี่ยนเนื้อหาได้ จึงไม่เท่ากับ pin digest ที่ reproducible กว่า

## Build context คือไฟล์ที่ส่งให้การ build

```powershell
docker build -t week5-capstone:local .
```

จุดท้ายคำสั่งหมายถึง directory ปัจจุบันเป็น context ไม่ใช่สัญลักษณ์ตกแต่ง ถ้ารันผิด folder อาจหา requirements ไม่พบ หรือส่งไฟล์ที่ไม่ตั้งใจเข้า build ได้ `.dockerignore` จึงกัน `.env`, `.git`, DB และ cache ออกต่างหากจาก `.gitignore`

## USER และ EXPOSE ช่วยอะไร

ตัวอย่างสร้างผู้ใช้ `appuser` แล้วใช้ `USER appuser` เพื่อไม่รัน application เป็น root โดยไม่จำเป็น แต่ non-root ไม่ใช่ sandbox ที่แก้ความเสี่ยงทั้งหมด ส่วน `EXPOSE 8015` เป็นข้อมูลประกอบ image ไม่ได้เปิด port บน host ให้เอง ต้อง publish port ตอน run/Compose

ลองอธิบายโดยไม่เปิดบท: ทำไมแก้ source แล้ว container เก่ายังไม่เห็นการเปลี่ยนแปลง? เพราะตัวอย่าง copy source เข้า image ตอน build ไม่ได้ bind mount source จากเครื่อง จึงต้อง rebuild/recreate ที่เกี่ยวข้อง
