# Verification — ขอบเขตหลักฐาน Week 5

## สิ่งที่ตรวจและสิ่งที่ต้องแยก

ตรวจบน Windows วันที่ 12 กันยายน 2026: Python 3.12.7, FastAPI 0.126.0, Pydantic 2.8.2, pytest 7.4.4, httpx 0.27.0, pypdf 6.13.1 และ python-docx 1.2.0

ผล reference Capstone: **24 tests ผ่าน** ผล ReleaseGuard starter: **8 ไม่ผ่าน / 2 ผ่านตามที่ตั้งใจ** เป็นจุดเริ่มให้ผู้เรียนแก้ ไม่ใช่ผล release ของ reference

Native HTTP ตรวจ demo Transaction/HR normal, transient, timeout และ hallucination พร้อมแยก API/worker คนละ process และทดลอง restart API แล้วส่ง event เดิมได้ task เดิม

n8n native 1.115.3: import workflow สองไฟล์เข้า state ทดสอบแยกแล้ว execute แต่ละไฟล์สองครั้ง รวม **4 executions ผ่าน** ยืนยัน HTTP 202, task ID และ duplicate false/true ตามลำดับ ตรวจเฉพาะ intake probes ไม่ใช่ production webhook หรือ Compose n8n รายงาน [Native runtime results](runtime_report.json) ไม่มี credentials และใช้ข้อมูลสังเคราะห์

Docker Compose v5.1.1 ผ่าน `config --quiet` แต่ **ยังไม่ได้ build/run containers** เนื่องจาก Docker Engine ไม่เปิด จึงยังไม่รับรอง image build, volume permissions, container restart หรือ n8n Compose networking บนเครื่องนี้

ชุด pytest ของ Capstone ตรวจ strict input, durable dedup/conflict, velocity boundary, concurrent intake/claim, stale lease, retry budget, mock output validation, review auth/decision idempotency และ parser smoke tests แยก temp DB ทุก test ไม่ใช้ข้อมูลจริง

ReleaseGuard เป็น starter ที่ตั้งใจให้ไม่ผ่าน acceptance tests ห้ามนับผล red tests ของ challenge รวมกับผล reference Capstone

## ไม่อ้างเกินขอบเขต

- Mock provider ไม่เรียกโมเดลจริง จึงไม่ใช่ผลประเมิน accuracy, latency หรือ cost ของ AI จริง
- SQLite lab เป็นเครื่องเดียว ไม่ผ่านการทดสอบ distributed queue/network filesystem
- Lease tests บางส่วนใช้ simulated time; แยกจาก native process restart และ container restart
- PDF fixtures เป็น synthetic จาก Week 4; DOCX test สร้างไฟล์ชั่วคราวเพื่อตรวจ parser ไม่รับรอง layout ทุกชนิดหรือ OCR
- Workflow intake probes ตรวจ HTTP 202 และ duplicate ไม่ได้รอ business completion
- Compose configuration check ไม่เท่ากับ build/run container สำเร็จ
- Review token เป็น local demo ไม่ใช่ SSO/RBAC และ intake endpoints ยังไม่มี auth

ก่อนใช้งานจริงให้อ่าน known limitations ในบท 07, 08 และ 13 ร่วมกับ README แล้วทำ runtime/permission/security checks ใน environment ที่ทีมอนุมัติ
