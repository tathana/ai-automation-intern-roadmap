# 16 — Easy Walkthrough: จากโค้ดที่รันได้สู่ระบบที่ทีมรับช่วงต่อได้

Week 5 มีศัพท์ infrastructure เยอะ บทนี้จะผูกทั้งหมดกับคำถามเดียว: “ถ้าเราปิดเครื่อง เปิดใหม่ หรือส่ง repo ให้เพื่อน เขารันระบบและตรวจว่าเชื่อถือได้อย่างไร”

## 1. Project Structure ไม่ใช่การสร้างโฟลเดอร์ให้เยอะ

```text
api.py        รับ/ตอบ HTTP
models.py     contract ของข้อมูล
service.py    ลำดับ business use case
repository.py ติดต่อ database
worker.py     ทำงานเบื้องหลัง
tests/        หลักฐาน behavior
```

แยกเมื่อ responsibility ต่างกันจริง ถ้าโปรเจกต์เล็กไฟล์เดียวอ่านง่ายกว่า ก็เริ่มไฟล์เดียวแล้ว split เมื่อมีเหตุผล

## 2. Git Team Workflow

```text
sync main → branch งานหนึ่งเรื่อง → commit เล็ก
→ push → PR → review/checks → merge
```

Commit ที่ดีตอบว่าเปลี่ยนพฤติกรรมอะไรและตรวจอย่างไร ไม่ใช่เพียง backup ทุกอย่าง ส่วน PR คือพื้นที่อธิบาย context/trade-off/evidence ให้ทีมตรวจ

## 3. Image กับ Container

```text
Dockerfile + source + dependencies
  ↓ docker build
Image = แบบพิมพ์ที่เปลี่ยนไม่ได้
  ↓ docker run
Container = process ที่กำลังรันจากแบบพิมพ์
```

แก้ source บน host แล้ว container เดิมไม่เปลี่ยนเสมอไป ต้องรู้ว่าใช้ bind mount หรือ rebuild image

## 4. Build Context

Build context คือกองไฟล์ที่ส่งให้ Docker build ถ้าส่งทั้ง repo อาจช้าและเผลอรวม `.env`, database หรือเอกสารสำคัญ `.dockerignore` จึงเป็นทั้ง performance และ safety boundary

## 5. Ports และ Network

```text
Windows host: localhost:8015
       ↓ port publish
container api:8015

container n8n → http://api:8015
```

`localhost` หมายถึง process/container ตัวเองเสมอ Container ที่จะเรียก API อีก service ใช้ service name บน Compose network ไม่ใช่ `localhost`

## 6. Volume และ Environment

- Volume เก็บข้อมูลนอก writable layer ของ container เพื่อให้ recreate แล้วยังอยู่
- Environment variable ส่ง config ตอน runtime ไม่ควร hardcode secret ใน image/source

Volume ไม่ใช่ backup และ `docker compose down -v` ขอให้ลบ volume ด้วย จึงไม่ใช้เป็นคำสั่ง restart ทั่วไป

## 7. Compose และ Healthcheck

Compose บอกว่ามี service อะไร ใช้ image/command/network/volume/env อย่างไร แต่ไม่ได้ย้าย business logic ไปไว้ YAML

```text
running = process ยังไม่หยุด
healthy = healthcheck ที่กำหนดผ่าน
ready   = application พร้อมรับงานตาม dependency ที่ตรวจ
```

ทั้งสามคำไม่เท่ากัน Worker อาจ running แต่ backlog ไม่ขยับได้

## 8. Durable State และ Transaction

ถ้า API ตอบรับงานก่อนเขียน DB สำเร็จ process ล่มแล้วงานหายได้:

```text
validate → BEGIN → task + audit → COMMIT → 202
```

Transaction boundary คือจุดที่เราประกาศว่า business action ไหนต้องสำเร็จร่วมกัน

## 9. Worker, Retry และ Lease

```text
queued → worker A claim + lease token A
       → processing
       ├─ success → persist if token A ยัง valid
       ├─ transient → retry_pending + next time
       └─ permanent/budget exhausted → failed/review
```

Lease คือสิทธิ์ชั่วคราว ถ้า worker A หาย สิทธิ์หมดและ worker B รับต่อได้ Token ป้องกัน A ที่กลับมาช้าเขียนทับผลใหม่ของ B

## 10. Human Review และ Side Effect

AI result, review decision และ external side effect เป็นคนละสิ่ง:

```text
draft result → human decision committed → outbox/action → external system
```

ถ้าส่งอีเมลหรือเรียกระบบภายนอกแล้ว response หาย ต้องมี idempotency/reconciliation ไม่ใช่กดส่งใหม่แบบเดา

## 11. Tests และ CI

Unit test ตรวจ rule เร็ว Integration test ตรวจ DB/API boundary และ end-to-end smoke ตรวจเส้นสำคัญ CI เพียงรัน checks แบบสม่ำเสมอ ไม่ได้ทำให้ test ที่อ่อนกลายเป็นหลักฐานที่ดี

## 12. Logs, Metrics และ Debug

```text
correlation_id เดียว
API accepted → task queued → worker claimed → provider result
→ validator → review → side effect
```

Logs บอกเหตุการณ์แต่ละรายการ Metrics บอกแนวโน้ม เช่น backlog/age/error rate และ traces เชื่อมเวลาระหว่าง component เริ่ม debug จาก first wrong boundary ไม่เริ่มด้วย restart ทุกอย่าง

## 13. README กับ Runbook

- README: ระบบคืออะไร ตั้งค่า/รัน/test/demo อย่างไร
- Runbook: เมื่อค้าง/ล่ม/ผิดปกติตรวจและ recovery อย่างไร
- ADR: ทำไมเลือก design นี้และ trade-off อะไร

Definition of Done ที่ดีต้องรวม tests, docs, security/config check และ clean-start rehearsal ไม่ใช่เพียง code เสร็จ

## 14. อ่าน Dockerfile ทีละคำสั่ง

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY course ./course
CMD ["python", "-m", "uvicorn", "course.api:app", "--host", "0.0.0.0"]
```

- `FROM` เลือก base image ไม่ใช่ติดตั้ง Python บน Windows host
- `WORKDIR` ตั้ง directory สำหรับคำสั่งถัดไปใน image
- `COPY requirements.txt` แยกก่อน source เพื่อใช้ build cache ได้ดีขึ้น
- `RUN` ทำตอน build และผลถูกเก็บใน image layer
- `COPY course` นำ source ที่อนุญาตใน build context เข้า image
- `CMD` เป็น default command ตอน container เริ่ม ไม่ได้ทำตอน build
- JSON-array form ไม่ผ่าน shell จึงส่ง arguments ตรงกว่า string form

## 15. อ่าน Conditional Update ของ Lease

```python
changed = connection.execute(
    "UPDATE tasks SET state=? "
    "WHERE id=? AND state='running' AND lease_token=? AND lease_until>?",
    (next_state, task_id, token, now),
).rowcount

if changed != 1:
    return False
```

SQL ไม่ได้ update จาก `id` อย่างเดียว แต่กำหนดว่า task ต้องยัง running, token ต้องเป็นของ worker นี้ และ lease ยังไม่หมด `.rowcount` บอกจำนวนแถวที่เปลี่ยน:

```text
1 row → worker ยังมีสิทธิ์ บันทึกผลสำเร็จ
0 row → state/token/time ไม่ตรง ปฏิเสธผลเก่า
```

นี่เรียกว่า **compare-and-set style guard** ช่วยให้การตรวจสิทธิ์กับการเขียนเกิดในคำสั่งเดียว ลดช่อง race ระหว่าง SELECT กับ UPDATE

## ลำดับฝึกที่เบาที่สุด

```text
native tests
→ learning_walkthrough.py
→ API + worker คนละ terminal
→ duplicate/retry/lease/review
→ Dockerfile
→ Compose
→ failure drill
→ README/runbook/demo
```

ถ้าขั้นใดไม่ผ่าน ให้หยุดที่ boundary นั้น อย่าเพิ่ม n8n/Docker/AI พร้อมกันจนมีตัวแปรเปลี่ยนหลายตัว
