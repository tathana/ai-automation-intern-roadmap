# 15 — Visual Notes: Docker, Durable Worker และ Production Flow

## Build กับ Run เป็นคนละช่วง

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Dockerfile + Context</div><span class="visual-arrow">build →</span><div class="visual-box">Image<br><small>versioned artifact</small></div><span class="visual-arrow">run + config →</span><div class="visual-box">Container Process</div><span class="visual-arrow">state →</span><div class="visual-box">Volume / Database</div></div></div>

## Port และ Network

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Browser<br><code>:8015</code></div><span class="visual-arrow">host port →</span><div class="visual-box">Docker mapping<br><code>8015:8000</code></div><span class="visual-arrow">container port →</span><div class="visual-box">Uvicorn<br><code>0.0.0.0:8000</code></div></div></div>

ระหว่าง containers ใช้ service name และ container port เช่น `http://api:8000` ไม่ใช้ host mapping โดยไม่จำเป็น

## Compose Readiness

<div class="visual-board"><div class="visual-flow"><div class="visual-box">container started</div><span class="visual-arrow">≠</span><div class="visual-box">process alive</div><span class="visual-arrow">≠</span><div class="visual-box">dependencies ready</div><span class="visual-arrow">≠</span><div class="visual-box">user journey verified</div></div></div>

Healthcheck ต้องตรวจสิ่งที่ caller ต้องพึ่ง และ startup order ไม่แทน runtime recovery

## Durable Task และ Crash Recovery

<div class="visual-board"><div class="visual-flow"><div class="visual-box">API transaction<br><small>task + audit</small></div><span class="visual-arrow">→</span><div class="visual-box">queued</div><span class="visual-arrow">claim lease →</span><div class="visual-box">processing</div><span class="visual-arrow">→</span><div class="visual-box">result transaction</div></div><div class="visual-flow"><div class="visual-box">worker crash</div><span class="visual-arrow">→ lease expires →</span><div class="visual-box">reclaim same task</div><span class="visual-arrow">→</span><div class="visual-box">one logical outcome</div></div></div>

## Observability Journey

<div class="visual-board"><div class="visual-flow"><div class="visual-box">request_id</div><span class="visual-arrow">→</span><div class="visual-box">task_id</div><span class="visual-arrow">→</span><div class="visual-box">attempt_id</div><span class="visual-arrow">→</span><div class="visual-box">review_id</div><span class="visual-arrow">→</span><div class="visual-box">side_effect_id</div></div><div class="visual-grid"><div class="visual-pane"><div class="visual-label">LOG</div><p>เหตุการณ์เฉพาะรายการ</p></div><div class="visual-pane"><div class="visual-label">METRIC</div><p>queue age/error/latency</p></div><div class="visual-pane"><div class="visual-label">TRACE</div><p>เส้นทางข้าม component</p></div></div></div>

