# 12 — Transaction Capstone: รับงานซ้ำได้และตรวจความผิดปกติเป็นระบบ

## ปัญหาที่แก้และสิ่งที่ไม่ทำ

เราจำลองทีมที่รับ transaction events แล้วต้องรวบรวมรายการควรตรวจ AI ช่วยสร้างข้อความ mock ประกอบ แต่ **กฎตรวจความผิดปกติเป็น deterministic rules** ไม่ยกหน้าที่ตัดสินยอดเงินให้ AI และไม่ตัดสินว่าเป็น fraud

```text
event → strict validation → durable dedup
    ↓ ใหม่เท่านั้นจึงนับ velocity
large amount / velocity rules → task
    ↓ worker
mock summary + ตรวจ rule labels → result + review
```

## อ่าน payload

```json
{"event_id":"E1","user_id":"U1","amount_minor":150000,"currency":"THB","mode":"normal"}
```

`amount_minor` เป็น integer หน่วยสตางค์ จึงเท่ากับ 1500 บาท `mode` เป็นสวิตช์จำลอง failure สำหรับเรียน ไม่ใช่ field ที่ควรให้ผู้ใช้ production ควบคุม เลือก strict validation จึงไม่แปลง string `"150000"` เป็น int ให้เงียบ ๆ

กฎ large amount คืออย่างน้อย 100000 สตางค์ ส่วน velocity คืออย่างน้อย 3 events ของ user เดียวในช่วง `(now-60, now]` รวม event ปัจจุบัน ใช้ **เวลา intake ที่ server รับ** ไม่ใช่เวลาเกิดธุรกรรมจริง ไม่รองรับ late-event/event-time processing และ threshold นี้เป็นตัวเลขฝึก ไม่ใช่นโยบายบริษัท

รายการที่เข้าเกณฑ์สร้าง review ตั้งแต่ transaction intake จึงไม่ต้องรอ AI สำเร็จก่อน คนยังตรวจ anomaly ได้เมื่อ worker/provider หยุด หาก AI output ใช้ไม่ได้ result จะมี rules เดิมกับ `summary_unavailable: true` ไม่สร้างข้อความสรุปปลอมให้ดูเหมือนสำเร็จ

## ทดลองสามรอบ

เริ่มตาม README แล้วรัน `python demo.py transaction` จะส่ง event เดิมซ้ำเพื่อเห็น task เดียว จากนั้นส่ง E2/E3 เพื่อเห็น velocity การส่ง payload เดิมซ้ำเพิ่ม audit `duplicate_received` แต่ไม่เพิ่ม event count

เปลี่ยน amount โดยใช้ event_id เดิมเพื่อทดลอง 409 จากนั้นใช้ ID ใหม่กับ mode `invalid_json` หรือ `timeout` เพื่อดู needs_review และ retry อย่าเปลี่ยน mode ด้วย ID เก่าแล้วคิดว่าเป็นงานทดลองใหม่ เพราะระบบถือว่า identity เดิมแต่ข้อมูลขัดแย้ง

## สิ่งที่ต้องอธิบายตอน demo

ให้เปิด task และ audit ควบคู่กัน: request รับเมื่อไร, claim กี่ครั้ง, result ผ่านหรือรอตรวจ และ review แยกจาก result อย่างไร สำหรับ summary ตัวอย่างตรวจโครงสร้างและ rule labels แต่ **ไม่ได้มี semantic verifier ที่พิสูจน์ข้อความสรุปอิสระของ LLM** เพราะ provider ปัจจุบันเป็น mock คงที่

## Acceptance ของ Core

ส่งซ้ำได้ task เดิมหลัง reopen DB; ID เดิมข้อมูลต่างถูกปฏิเสธ; duplicate ไม่เพิ่ม velocity; เงินเก็บหน่วยย่อย; failed AI ไม่ทำให้ event หาย; review decision ส่งซ้ำได้โดยไม่เปลี่ยน AI result ทดสอบสิ่งเหล่านี้ก่อนตกแต่ง dashboard

Stretch ที่คุ้มคือเพิ่ม per-rule configuration และ regression tests, event-time handling, outbox และ production auth ตามโจทย์จริง ไม่ต้องทำทุกอย่างเพื่อให้หน้าตาเหมือนระบบขนาดใหญ่

## เริ่มแบบเห็นผลทีละขั้นใน terminal เดียว

```powershell
python learning_walkthrough.py transaction
```

ใช้ DB ใหม่ชั่วคราวทุกครั้ง ส่ง E1 = 500, E2 = 100000, E3 = 500 สตางค์ ของ user เดียวกันในช่วงเวลาจำลองที่ใกล้กัน ผลกฎควรเป็น:

```text
E1 → []                       ยอดไม่สูง และยังไม่ครบ 3 events
E2 → [large_amount]           เท่ากับ threshold จึงเข้าเกณฑ์
E3 → [velocity_3_in_60s]      event ที่สามในช่วงเวลา
```

`[]` คือ list ว่าง ไม่ได้หมายถึง error ส่วน E3 ยอดไม่สูงก็ยังเข้า velocity ได้ เพราะกฎดูคนละเรื่อง นี่ช่วยให้ไม่สรุปว่า anomaly เกิดได้จากยอดเงินอย่างเดียว

## ต่อผ่าน HTTP — ต้องเปิดอะไรบ้าง

ทำ native setup ใน README ก่อน Terminal A เปิด API, B เปิด worker และ C ส่งข้อมูล ถ้าเรียน Docker ให้เลือก Compose แทน A/B ไม่เปิดสองระบบบน port เดียวกันพร้อมกัน

ใน terminal C:

```powershell
$body = @{ event_id="E-lesson12-01"; user_id="U-learning"; amount_minor=150000; currency="THB" } | ConvertTo-Json
$accepted = Invoke-RestMethod http://127.0.0.1:8015/transactions -Method Post -ContentType "application/json" -Body $body
$accepted
Invoke-RestMethod "http://127.0.0.1:8015/tasks/$($accepted.task_id)" | ConvertTo-Json -Depth 8
```

`@{...}` เป็น hashtable ของ PowerShell แล้ว `ConvertTo-Json` เปลี่ยนเป็น JSON text `-Method Post` ส่งงานใหม่ตาม endpoint ส่วน `$accepted.task_id` อ่าน ID ที่ API คืน ไม่เดาว่าต้องเป็น 1 เสมอ นิพจน์ `$()` ใน string ใช้แทรกค่า ID ลง URL

ถ้า worker เร็ว อาจเห็น succeeded ตั้งแต่ GET ครั้งแรก ถ้ายัง queued/running ให้ GET อีกครั้ง ไม่ส่ง POST ใหม่ด้วย ID ใหม่เพียงเพื่อเช็กผล เพราะจะเป็นคนละ event

## ทดลอง duplicate และ conflict อย่างมีเหตุผล

ส่ง `$body` เดิมซ้ำ ควรได้ task ID เดิมและ duplicate true แม้ state ตอนรับซ้ำอาจเป็น succeeded แล้ว หากเปลี่ยน amount แต่เก็บ event_id เดิม ควรได้ HTTP 409 โดย PowerShell อาจแสดงเป็น error ของ request นี่คือการป้องกัน conflict ตามที่ตั้งใจ ไม่ใช่ให้แก้ server จนรับทุกอย่าง

หากต้องการเริ่มกรณีใหม่ให้ใช้ event_id ใหม่ เช่น E-lesson12-02 อย่าใช้ ID ใหม่สำหรับ retry ของ event เดิม เพราะจะทำให้ dedup ช่วยไม่ได้

## เช็ก failure แบบมีผลคาดหวัง

```powershell
python demo.py transaction --mode invalid_json
python demo.py transaction --mode timeout
```

ตัวแรกควรมี needs_review พร้อม summary_unavailable ตัวที่สอง retry จนครบ 3 แล้ว failed แต่ event/rules และรายการตรวจยังอยู่ คำว่า failed ตรงนี้คือการประมวลผล task ไม่สำเร็จตาม contract ไม่ได้ลบธุรกรรมต้นทาง

จุดตรวจ: อธิบายได้ว่าทำไมเราเชื่อ rules จากโค้ดที่กำหนด แต่ไม่ถือ free-text summary ของ AI เป็นแหล่งจริงแทน DB และกฎ
