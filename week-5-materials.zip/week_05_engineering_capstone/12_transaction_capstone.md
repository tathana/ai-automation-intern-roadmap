# 12 — Transaction Capstone: รับงานซ้ำได้และตรวจความผิดปกติเป็นระบบ

## ปัญหาที่แก้และสิ่งที่ไม่ทำ

เราจำลองทีมที่รับ transaction events แล้วต้องรวบรวมรายการควรตรวจ AI ช่วยสร้างข้อความ mock ประกอบ แต่ **กฎตรวจความผิดปกติเป็น deterministic rules** ไม่ยกหน้าที่ตัดสินยอดเงินให้ AI และไม่ตัดสินว่าเป็น fraud

```text
event → strict validation → durable dedup
    ↓ ใหม่เท่านั้นจึงนับ velocity
large amount / velocity rules → task
    ↓ worker
mock summary + ตรวจ rule labels → result + review
```

## อ่าน payload

```json
{"event_id":"E1","user_id":"U1","amount_minor":150000,"currency":"THB","mode":"normal"}
```

`amount_minor` เป็น integer หน่วยสตางค์ จึงเท่ากับ 1500 บาท `mode` เป็นสวิตช์จำลอง failure สำหรับเรียน ไม่ใช่ field ที่ควรให้ผู้ใช้ production ควบคุม เลือก strict validation จึงไม่แปลง string `"150000"` เป็น int ให้เงียบ ๆ

กฎ large amount คืออย่างน้อย 100000 สตางค์ ส่วน velocity คืออย่างน้อย 3 events ของ user เดียวในช่วง `(now-60, now]` รวม event ปัจจุบัน ใช้ **เวลา intake ที่ server รับ** ไม่ใช่เวลาเกิดธุรกรรมจริง ไม่รองรับ late-event/event-time processing และ threshold นี้เป็นตัวเลขฝึก ไม่ใช่นโยบายบริษัท

รายการที่เข้าเกณฑ์สร้าง review ตั้งแต่ transaction intake จึงไม่ต้องรอ AI สำเร็จก่อน คนยังตรวจ anomaly ได้เมื่อ worker/provider หยุด หาก AI output ใช้ไม่ได้ result จะมี rules เดิมกับ `summary_unavailable: true` ไม่สร้างข้อความสรุปปลอมให้ดูเหมือนสำเร็จ

## ทดลองสามรอบ

เริ่มตาม README แล้วรัน `python demo.py transaction` จะส่ง event เดิมซ้ำเพื่อเห็น task เดียว จากนั้นส่ง E2/E3 เพื่อเห็น velocity การส่ง payload เดิมซ้ำเพิ่ม audit `duplicate_received` แต่ไม่เพิ่ม event count

เปลี่ยน amount โดยใช้ event_id เดิมเพื่อทดลอง 409 จากนั้นใช้ ID ใหม่กับ mode `invalid_json` หรือ `timeout` เพื่อดู needs_review และ retry อย่าเปลี่ยน mode ด้วย ID เก่าแล้วคิดว่าเป็นงานทดลองใหม่ เพราะระบบถือว่า identity เดิมแต่ข้อมูลขัดแย้ง

## สิ่งที่ต้องอธิบายตอน demo

ให้เปิด task และ audit ควบคู่กัน: request รับเมื่อไร, claim กี่ครั้ง, result ผ่านหรือรอตรวจ และ review แยกจาก result อย่างไร สำหรับ summary ตัวอย่างตรวจโครงสร้างและ rule labels แต่ **ไม่ได้มี semantic verifier ที่พิสูจน์ข้อความสรุปอิสระของ LLM** เพราะ provider ปัจจุบันเป็น mock คงที่

## Acceptance ของ Core

ส่งซ้ำได้ task เดิมหลัง reopen DB; ID เดิมข้อมูลต่างถูกปฏิเสธ; duplicate ไม่เพิ่ม velocity; เงินเก็บหน่วยย่อย; failed AI ไม่ทำให้ event หาย; review decision ส่งซ้ำได้โดยไม่เปลี่ยน AI result ทดสอบสิ่งเหล่านี้ก่อนตกแต่ง dashboard

Stretch ที่คุ้มคือเพิ่ม per-rule configuration และ regression tests, event-time handling, outbox และ production auth ตามโจทย์จริง ไม่ต้องทำทุกอย่างเพื่อให้หน้าตาเหมือนระบบขนาดใหญ่
