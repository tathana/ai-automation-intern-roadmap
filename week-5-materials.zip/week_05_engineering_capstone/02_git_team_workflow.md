# 02 — Git Team Workflow: จากงานส่วนตัวสู่การส่งให้ทีมตรวจ

## ใช้พื้นฐานเดิม ไม่ต้องเรียน Git ใหม่ทั้งหมด

ถ้ายังสับสน working tree, staging และ commit ให้เปิด Special Track 00 ที่เคยเรียนก่อน บทนี้เพิ่มเส้นทางทำงานเป็นทีม: รับงาน → branch → เปลี่ยนแปลงเล็ก → tests → review → merge โดยตัวอย่างให้ทำใน repository ฝึกแยก ไม่ทดลองกับ repository บริษัท

```text
main ที่สะอาด
    ↓ สร้าง branch
feature/review-note
    ↓ แก้ + ตรวจ diff + tests
commit → push branch → Pull Request → review → merge
```

## ทำงานหนึ่งเรื่องให้จบหนึ่งชุด

```powershell
git status
git switch -c feature/review-note
git diff
git add course/models.py tests/test_capstone.py
git diff --staged
git commit -m "Reject blank review notes"
```

`switch -c` สร้างและย้ายไป branch ใหม่ `diff` แสดงส่วนที่แก้แต่ยังไม่ stage ส่วน `diff --staged` แสดงสิ่งที่จะเข้า commit จริง การระบุไฟล์ใน `git add` ช่วยให้ไม่เผลอรวม DB หรือไฟล์อื่นที่ไม่เกี่ยวกับงาน อย่าคัดลอก path ตามตัวอย่างถ้าคุณไม่ได้แก้ไฟล์นั้น

เมื่อมี remote ของ **repo ฝึกของตัวเอง** แล้ว จึงใช้ `git push -u origin feature/review-note` คำว่า `-u` ตั้ง upstream ให้ branch นี้ ไม่ได้ทำให้ branch merge เข้า main อัตโนมัติ

## Pull Request ควรเล่าอะไร

เขียนสั้น ๆ ว่าเปลี่ยนพฤติกรรมใด, เพราะเหตุใด, ทดสอบแบบไหน และมีความเสี่ยงอะไร เช่น “ไม่ยอมรับ note ที่เป็นช่องว่างล้วน เพิ่ม validation และ regression test; ไม่เปลี่ยน schema DB” คน review จะตรวจผลได้เร็วกว่าข้อความว่า “update code”

## เมื่อเกิด conflict

Conflict ไม่ได้หมายความว่าโค้ดของคนหนึ่งผิด แต่ Git เลือกการรวมข้อความแทนเราไม่ได้ อ่านเจตนาของทั้งสองฝั่งก่อนลบ markers `<<<<<<<`, `=======`, `>>>>>>>` แล้วรัน tests ที่เกี่ยวข้อง ไม่เลือก Accept Current ทั้งหมดโดยยังไม่เข้าใจ

```text
พบ conflict → อ่านบริบททั้งสองฝั่ง → แก้ให้ตรง contract
           → ตรวจ markers ค้าง → tests → commit การ merge
```

## ย้อนการเปลี่ยนแปลงอย่างปลอดภัย

สำหรับ commit ที่แชร์แล้ว โดยทั่วไป `git revert <commit>` สร้าง commit ใหม่ที่ย้อนผลเดิมและเก็บประวัติไว้ แต่ก่อนทำต้องตรวจ commit และผลกระทบ หาก DB schema หรือ external action เปลี่ยนไป การ revert source ไม่ได้ย้อนข้อมูลหรืออีเมลที่ส่งแล้ว หลีกเลี่ยง force push และ `reset --hard` ในเส้นทางฝึกนี้

Git เก็บประวัติ source ไม่ใช่ที่เก็บ secrets หาก token เคยถูก commit การลบออกจากไฟล์ปัจจุบันอย่างเดียวไม่พอ ต้องเพิกถอน/หมุน token และประสานทีมเรื่องประวัติที่หลุดด้วย
