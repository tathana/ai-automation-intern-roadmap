# 02 — Git Team Workflow: จากงานส่วนตัวสู่การส่งให้ทีมตรวจ

## ใช้พื้นฐานเดิม ไม่ต้องเรียน Git ใหม่ทั้งหมด

ถ้ายังสับสน working tree, staging และ commit ให้เปิด Special Track 00 ที่เคยเรียนก่อน บทนี้เพิ่มเส้นทางทำงานเป็นทีม: รับงาน → branch → เปลี่ยนแปลงเล็ก → tests → review → merge โดยตัวอย่างให้ทำใน repository ฝึกแยก ไม่ทดลองกับ repository บริษัท

```text
main ที่สะอาด
    ↓ สร้าง branch
feature/review-note
    ↓ แก้ + ตรวจ diff + tests
commit → push branch → Pull Request → review → merge
```

## ทำงานหนึ่งเรื่องให้จบหนึ่งชุด

```powershell
git status
git switch -c feature/review-note
git diff
git add course/models.py tests/test_capstone.py
git diff --staged
git commit -m "Reject blank review notes"
```

`switch -c` สร้างและย้ายไป branch ใหม่ `diff` แสดงส่วนที่แก้แต่ยังไม่ stage ส่วน `diff --staged` แสดงสิ่งที่จะเข้า commit จริง การระบุไฟล์ใน `git add` ช่วยให้ไม่เผลอรวม DB หรือไฟล์อื่นที่ไม่เกี่ยวกับงาน อย่าคัดลอก path ตามตัวอย่างถ้าคุณไม่ได้แก้ไฟล์นั้น

เมื่อมี remote ของ **repo ฝึกของตัวเอง** แล้ว จึงใช้ `git push -u origin feature/review-note` คำว่า `-u` ตั้ง upstream ให้ branch นี้ ไม่ได้ทำให้ branch merge เข้า main อัตโนมัติ

## Pull Request ควรเล่าอะไร

เขียนสั้น ๆ ว่าเปลี่ยนพฤติกรรมใด, เพราะเหตุใด, ทดสอบแบบไหน และมีความเสี่ยงอะไร เช่น “ไม่ยอมรับ note ที่เป็นช่องว่างล้วน เพิ่ม validation และ regression test; ไม่เปลี่ยน schema DB” คน review จะตรวจผลได้เร็วกว่าข้อความว่า “update code”

## เมื่อเกิด conflict

Conflict ไม่ได้หมายความว่าโค้ดของคนหนึ่งผิด แต่ Git เลือกการรวมข้อความแทนเราไม่ได้ อ่านเจตนาของทั้งสองฝั่งก่อนลบ markers `<<<<<<<`, `=======`, `>>>>>>>` แล้วรัน tests ที่เกี่ยวข้อง ไม่เลือก Accept Current ทั้งหมดโดยยังไม่เข้าใจ

```text
พบ conflict → อ่านบริบททั้งสองฝั่ง → แก้ให้ตรง contract
           → ตรวจ markers ค้าง → tests → commit การ merge
```

## ย้อนการเปลี่ยนแปลงอย่างปลอดภัย

สำหรับ commit ที่แชร์แล้ว โดยทั่วไป `git revert <commit>` สร้าง commit ใหม่ที่ย้อนผลเดิมและเก็บประวัติไว้ แต่ก่อนทำต้องตรวจ commit และผลกระทบ หาก DB schema หรือ external action เปลี่ยนไป การ revert source ไม่ได้ย้อนข้อมูลหรืออีเมลที่ส่งแล้ว หลีกเลี่ยง force push และ `reset --hard` ในเส้นทางฝึกนี้

Git เก็บประวัติ source ไม่ใช่ที่เก็บ secrets หาก token เคยถูก commit การลบออกจากไฟล์ปัจจุบันอย่างเดียวไม่พอ ต้องเพิกถอน/หมุน token และประสานทีมเรื่องประวัติที่หลุดด้วย

## ทำความเข้าใจสถานะก่อนใช้คำสั่ง

**Repository** เก็บประวัติงาน, **commit** คือ snapshot ที่บันทึกแล้ว และ **branch** คือชื่อที่ชี้ตำแหน่งหนึ่งของประวัติ ไม่ใช่การ copy โฟลเดอร์ทั้งชุดให้เราเห็นอีกอัน ส่วน GitHub เป็นบริการเก็บ repo/ทำงานร่วมกัน ไม่ใช่ Git ตัวเดียวกัน

```text
แก้ไฟล์ใน editor → working tree เปลี่ยน
git add          → เลือกเนื้อหาที่จะบันทึก (staging)
git commit       → บันทึก snapshot ในเครื่อง
git push         → ส่ง commits ไป remote
```

`git add` ไม่ได้ส่งงานขึ้นอินเทอร์เน็ต และ commit แล้วไม่จำเป็นต้องมี GitHub จึงจะดูประวัติได้ หากแก้ไฟล์ต่อหลัง add ต้อง add เวอร์ชันใหม่อีกครั้งก่อน commit มิฉะนั้น snapshot จะยังเป็นส่วนที่ stage ไว้ก่อนหน้า

## Lab มือใหม่ — ไม่ต้องมี remote ก็ฝึกได้

เลือก folder ฝึกใหม่ **นอก repo เดิม** ก่อนใช้คำสั่งเหล่านี้ ไม่รัน `git init` ซ้อนในโฟลเดอร์เว็บบทเรียนหรือ Capstone ที่มี repo อยู่แล้ว:

```powershell
git init -b main
git status
```

ใช้ editor สร้าง `README.md` เขียนหนึ่งบรรทัดว่าโปรเจกต์นี้ฝึกอะไร จากนั้น:

```powershell
git add README.md
git diff --staged
git commit -m "Add practice project overview"
git switch -c feature/setup-notes
```

เพิ่มวิธีรันใน README ด้วย editor แล้ว `git diff` ควรเห็นเฉพาะข้อความใหม่ ตรวจแล้วค่อย add/commit อีกครั้ง ถ้า Git ถาม identity ให้ตั้งชื่อ/อีเมลของคุณตาม Special Track ไม่คัดลอกชื่อคนอื่นมาใช้

```powershell
git add README.md
git commit -m "Document local setup steps"
git switch main
git merge feature/setup-notes
git log --oneline --graph --all
```

Lab นี้ยังไม่มีการแก้ main แข่งกัน จึงมัก merge แบบ fast-forward คือเลื่อน main ไปยัง commit ล่าสุดของ feature ไม่ได้จำเป็นต้องสร้าง merge commit ทุกครั้ง จบแล้ว `git status` ควร clean และ README มีเนื้อหาที่เพิ่ม

## ก่อนทำงานกับ remote จริง

`git fetch origin` รับข้อมูลประวัติจาก remote โดยไม่ merge เข้า branch ที่ทำอยู่ ใช้ดูความเปลี่ยนแปลงก่อน หากทีมใช้ `git pull --ff-only` แล้วคำสั่งปฏิเสธเพราะประวัติแยกกัน ให้หยุดตรวจ ไม่แก้ด้วย force push Git ไม่รู้ว่าโค้ดรวมแล้วทำงานถูก ต้องรัน tests และให้คน review ด้วย

จุดตรวจ: อธิบายได้ว่าไฟล์แก้แล้วแต่ยังไม่ add, add แล้วแต่ยังไม่ commit และ commit แล้วแต่ยังไม่ push ต่างกันอย่างไร จากนั้นค่อยเรียน conflict ใน repo ฝึก
