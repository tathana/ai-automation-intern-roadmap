# Drills — 6 ชุดฝึกก่อนทำ ReleaseGuard

## Drill 1: Refactor โดยพฤติกรรมไม่เปลี่ยน

เปิด repository แล้วแยกค่ากฎ 100000 และ 60 เป็นชื่อ constant ที่สื่อหน่วย เพิ่ม type hints ให้ฟังก์ชันที่คุณอ่านคล่องก่อน อย่าแยก transaction เป็นหลาย connection โดยไม่ตั้งใจ รัน tests ก่อนและหลัง แล้วตรวจ diff ว่าเปลี่ยนโครงสร้างจริง ไม่เปลี่ยน threshold แอบแฝง

ส่งงาน: diff เล็กหนึ่งชุด พร้อมคำอธิบายว่าทำให้อ่านง่ายขึ้นตรงไหน และ test ใดป้องกันพฤติกรรมเดิม

## Drill 2: Git conflict ใน repo ฝึก

คัดลอกข้อความสองบรรทัดไป repo ฝึกใหม่ commit บน main สร้าง branch สองชื่อแล้วแก้บรรทัดเดียวกันคนละแบบ merge ทีละ branch เพื่อพบ conflict อ่านทั้งสองฝั่งและแก้เป็นข้อความที่รักษาความหมายทั้งคู่ ตรวจ markers ค้างและ commit การแก้

ส่งงาน: `git log --oneline --graph --all` และคำอธิบายก่อน/หลัง ไม่ใช้ force push หรือ reset hard ไม่ต้องแตะ remote บริษัท

## Drill 3: Docker network debugging

ในสำเนา config เปลี่ยน URL ของ n8n container เป็น `localhost:8015` แล้วทายว่าทำไมไม่ถึง API เปรียบเทียบกับ `api:8015` จากนั้นอธิบาย host port กับ container port โดยไม่จำคำสั่งอย่างเดียว ถ้า Engine ยังไม่พร้อม ทำ diagram/read-through ได้แต่ยังไม่นับ runtime ผ่าน

ส่งงาน: ผู้เรียกอยู่ที่ไหน, URL ที่ใช้, error ที่เห็นจริง และวิธีตรวจหลังแก้

## Drill 4: Persistence

ส่ง synthetic event จด task ID หยุดแล้วเปิด API/worker ด้วย DB เดิม ส่ง payload เดิมอีกครั้ง ต้องได้ ID เดิมและ duplicate true ทดลองอีก DB path ในสำเนาแล้วสังเกตว่าเป็นคนละฐานข้อมูล ไม่ใช่ระบบ dedup ล้มเหลว

ส่งงาน: commands, DB path ที่ใช้โดยไม่แนบ DB จริง, ID ก่อน/หลัง และ counts

## Drill 5: Crash และ stale completion

อ่าน test expired worker แล้วเปลี่ยนเวลาในสำเนา: finish ก่อน lease หมดหนึ่งวินาทีและตรงเวลาหมดพอดี คาดว่ากรณีใดผ่าน เพราะเงื่อนไขใช้ `lease_until > now` ไม่ใช่ `>=` จากนั้นเพิ่ม test ของตัวเองและอธิบายว่า token เก่าป้องกันอะไร

ส่งงาน: test ใหม่และ flow worker A/B ไม่อ้างว่าจำลอง clock คือทดสอบไฟดับจริง

## Drill 6: Handoff rehearsal

ให้เพื่อนหรือ terminal/environment ใหม่ทำตาม README โดยคุณจดจุดติดแทนการแก้ให้ทันที ตรวจ sample, expected result และขั้นตอนหยุดระบบ เพิ่ม troubleshooting เฉพาะปัญหาที่พบ ไม่เขียนคู่มือยาวแต่ไม่เคยลอง

ส่งงาน: README patch, รายการ checks ที่ผ่าน, รายการยังไม่ทดสอบ และ demo 5 นาที ไม่มีข้อมูลจริง/secret

## ประเมินตัวเอง

ผ่านเมื่ออธิบายเหตุผลได้และมีหลักฐานทำซ้ำ ไม่ใช่แค่คัดลอก output ถ้า AI ช่วยเขียนให้ ลองเปลี่ยน input แล้วทายผลก่อนรัน พร้อมชี้บรรทัดที่ทำให้เกิดผลนั้น
