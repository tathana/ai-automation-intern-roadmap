"""Small teaching package with no import-time external side effects."""
