"""Week 5 local-only synthetic capstones."""
