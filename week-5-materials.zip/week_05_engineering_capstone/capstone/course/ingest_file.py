"""CLI for trusted synthetic PDF/DOCX. Does not accept paths through the API."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import httpx
from pypdf import PdfReader
from docx import Document
from docx.table import Table


def extract(path):
    path=Path(path)
    if path.stat().st_size>2_000_000:
        raise ValueError('file_too_large')
    data=path.read_bytes()
    if len(data)>2_000_000:
        raise ValueError('file_too_large')
    if path.suffix.lower()=='.pdf':
        reader=PdfReader(path)
        if reader.is_encrypted or len(reader.pages)>10:
            raise ValueError('encrypted_or_too_many_pages')
        text='\n'.join(p.extract_text() or '' for p in reader.pages)
    elif path.suffix.lower()=='.docx':
        with zipfile.ZipFile(path) as archive:
            if len(archive.infolist())>200 or sum(i.file_size for i in archive.infolist())>10_000_000:
                raise ValueError('docx_expansion_limit')
        doc=Document(path)
        text='\n'.join('\n'.join(' | '.join(c.text for c in row.cells) for row in b.rows) if isinstance(b,Table) else b.text for b in doc.iter_inner_content())
    else:
        raise ValueError('unsupported_file_type')
    if not text.strip() or len(text)>20_000:
        raise ValueError('empty_or_text_too_large')
    return text,hashlib.sha256(data).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--file',action='append',required=True,help='Repeat for a synthetic batch')
    parser.add_argument('--candidate-id',required=True,help='All files in this invocation belong to this candidate')
    parser.add_argument('--url',default='http://127.0.0.1:8015')
    args=parser.parse_args()
    for filename in args.file:
        try:
            text,file_hash=extract(filename)
            response=httpx.post(args.url+'/resumes',json={'candidate_id':args.candidate_id,'document_text':text},timeout=10)
            response.raise_for_status()
            print(json.dumps({'file_hash':file_hash,**response.json()}))
        except Exception as exc:
            print(json.dumps({'state':'local_ingest_error','error_type':type(exc).__name__}))


if __name__=='__main__':
    main()
