import argparse
import json
import os
from time import time, sleep
from .repository import Store
from .service import process_one


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--once',action='store_true')
    args=parser.parse_args()
    store=Store(os.environ.get('CAPSTONE_DB','data/capstone.sqlite3'))
    while True:
        try:
            worked=process_one(store,time)
        except Exception as exc:
            # Unexpected failures remain recoverable by lease expiry, never fake success.
            print(json.dumps({'stage':'worker','error_type':type(exc).__name__}),flush=True)
            if args.once:
                raise
            sleep(1)
            continue
        if args.once:
            print(json.dumps({'worked':worked}),flush=True)
            return
        if not worked:
            sleep(.5)


if __name__=='__main__':
    main()
