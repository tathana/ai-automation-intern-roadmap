# Capstone Runbook — ตรวจอย่างปลอดภัยก่อนแก้

## Queued ค้าง

GET task เพื่อยืนยัน ID แล้วดู worker เปิดอยู่หรือไม่ ถ้า native ตรวจ working directory และ CAPSTONE_DB ของทั้งสอง terminal ถ้า Compose ดู `docker compose ps` และ logs ของ worker ตรวจว่า volume/path ตรงกัน ไม่ลบ DB เพื่อให้สถานะหาย

## Running ค้าง

ตรวจ audit ว่า claimed เมื่อไร หาก worker หยุดจริง เปิด worker ใหม่และรอ lease 30 วินาทีหมด งานจะถูก claim ใหม่ถ้ายังมี budget เมื่อ crash หมด 3 attempts จะ failed พร้อม review หากงานจริงใช้เวลามากกว่า lease ต้องปรับ protocol/renewal ไม่ใช่เพิ่มจำนวน worker อย่างเดียว

## Review ตอบ 503 หรือ 401

503 หมายถึง API ยังไม่มี token ที่ผ่านเงื่อนไข config หรือใช้ placeholder; ตั้ง token ใหม่และ restart API 401 หมายถึง header ไม่ตรง ตรวจรูปแบบ Bearer และ session ที่ตั้ง environment อย่าเปิด log token เพื่อ debug

## 409 เมื่อส่งซ้ำ

อ่าน payload เดิมกับใหม่โดยใช้ข้อมูลสังเคราะห์ ตรวจว่า event_id เดิมแต่ amount/mode ต่างหรือไม่ การเปลี่ยน business data ต้องมี identity และกระบวนการแก้ที่ชัด ไม่ลบแถว dedup เพื่อให้ request ผ่าน

## API healthy แต่ไม่มีผล

Healthcheck ไม่ตรวจว่า worker ยังทำงาน ดู task state, attempts และ audit ก่อน `succeeded` ของ HR ยังมี pending review ได้เพราะสถานะเทคนิคกับการตัดสินใจแยกกัน

## Recovery rehearsal

ใช้สำเนา lab เท่านั้น: ส่งงานแล้วหยุด worker, ตรวจ task ยังอยู่, เปิด worker ใหม่, ตรวจผลและ audit จดเวลากับ ID ถ้าใช้ native ไม่ได้จำลอง container failure; ถ้าใช้เวลาจำลองใน test ไม่ได้พิสูจน์ reboot ของเครื่องจริง ให้ระบุวิธีทดสอบตามที่ทำ

## Backup/restore rehearsal

หยุด API/worker ของ lab ให้แน่ใจว่าไม่มี writer ค้าง สำรอง DB ไป path ใหม่ที่ระบุชัด แล้วทดลองเปิดสำเนาผ่าน Store ใน environment แยก ตรวจ counts และ task ที่รู้จัก ไม่ overwrite ต้นฉบับ การสำรองขณะระบบ live ควรใช้ SQLite backup API พร้อมทดสอบตามรูปแบบ journal ที่ใช้

## ส่งต่อปัญหาให้ทีม

บันทึก version, task ID สังเคราะห์, expected/actual, audit action และวิธีทำซ้ำ ถ้าพบข้อมูลจริงหลุดให้หยุดการเผยแพร่และทำตามกระบวนการองค์กร ไม่แนบ DB ทั้งก้อนใน issue สาธารณะ
