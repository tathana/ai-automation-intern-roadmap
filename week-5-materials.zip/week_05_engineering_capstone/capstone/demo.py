"""Synthetic HTTP demo. Start API and worker before running this script."""
import argparse
import json
import time
import uuid
import httpx


def wait_task(client, tid):
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        response=client.get(f'/tasks/{tid}')
        response.raise_for_status()
        task=response.json()
        if task['state'] in {'succeeded','needs_review','failed'}:
            return task
        time.sleep(.25)
    raise TimeoutError('Task not finished in 20s; inspect worker and task audit')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('kind',choices=['transaction','hr'])
    parser.add_argument('--url',default='http://127.0.0.1:8015')
    parser.add_argument('--mode',choices=['normal','transient','timeout','invalid_json','hallucination'],default='normal')
    args=parser.parse_args()
    run=uuid.uuid4().hex[:10]
    with httpx.Client(base_url=args.url,timeout=5) as client:
        if args.kind=='transaction':
            endpoint='/transactions'
            body={'event_id':'E-'+run,'user_id':'U-'+run,'amount_minor':150000,'mode':args.mode}
        else:
            endpoint='/resumes'
            body={'candidate_id':'C-'+run,'document_text':'Built a Python ETL project. Built a SQL reporting project.','mode':args.mode}
        first=client.post(endpoint,json=body)
        first.raise_for_status()
        repeated=client.post(endpoint,json=body)
        repeated.raise_for_status()
        assert first.json()['task_id']==repeated.json()['task_id']
        assert repeated.json()['duplicate'] is True
        tids=[first.json()['task_id']]
        if args.kind=='transaction':
            for suffix in ['-2','-3']:
                response=client.post(endpoint,json={**body,'event_id':body['event_id']+suffix,'amount_minor':500})
                response.raise_for_status()
                tids.append(response.json()['task_id'])
        print(json.dumps({'accepted':first.json(),'repeated':repeated.json()},indent=2))
        for tid in tids:
            print(json.dumps(wait_task(client,tid),indent=2,ensure_ascii=False))
        print(json.dumps(client.get('/summary').json(),indent=2))


if __name__=='__main__':
    main()
