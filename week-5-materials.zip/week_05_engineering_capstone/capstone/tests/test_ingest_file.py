from pathlib import Path
import hashlib
import pytest
from course.ingest_file import extract


def test_synthetic_pdf():
    path=Path(__file__).parents[1]/'fixtures'/'synthetic_resume.pdf'
    text,digest=extract(path)
    assert 'Python' in text
    assert digest==hashlib.sha256(path.read_bytes()).hexdigest()


def test_empty_pdf_rejected():
    path=Path(__file__).parents[1]/'fixtures'/'empty_document.pdf'
    with pytest.raises(ValueError,match='empty_or_text_too_large'):
        extract(path)


def test_docx_parser_smoke(tmp_path):
    # Temporary parser input, not a user-facing Word document or layout fixture.
    from docx import Document
    path=tmp_path/'synthetic.docx'
    document=Document()
    document.add_paragraph('Built a Python ETL project.')
    table=document.add_table(rows=1,cols=1)
    table.cell(0,0).text='Built a SQL reporting project.'
    document.save(path)
    text,digest=extract(path)
    assert 'Python' in text and 'SQL' in text
    assert len(digest)==64


def test_unsupported_type(tmp_path):
    path=tmp_path/'file.txt'
    path.write_text('synthetic',encoding='utf-8')
    with pytest.raises(ValueError,match='unsupported_file_type'):
        extract(path)
