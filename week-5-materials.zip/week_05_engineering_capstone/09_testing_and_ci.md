# 09 — Integration Testing และ CI ที่มีความหมาย

## ทดสอบผลที่สำคัญ ไม่ใช่แค่บรรทัดที่รันผ่าน

Unit test เหมาะกับกฎเล็ก ๆ เช่นจำนวนเงินถึง threshold หรือไม่ Integration test ตรวจหลายส่วนทำงานร่วมกัน เช่น request ผ่าน Pydantic แล้วบันทึก DB และ worker อ่านต่อ ชุดนี้ใช้ฐานข้อมูลชั่วคราวแยกแต่ละ test ไม่แตะ DB ที่คุณอ่านงานอยู่

```powershell
python -m pytest tests -q
python -m pytest tests -q -k expired_worker
```

`-q` ลดข้อความ, `-k` เลือก test ตามชื่อ รันจาก folder capstone ใช้ interpreter เดียวกับที่ติดตั้ง requirements

## อ่าน test ด้วย Arrange / Act / Assert

```python
tid, _ = store.ingest_transaction(payload, 100)  # Arrange
process_one(store, lambda: 101)                  # Act
assert store.task(tid)['state'] == 'succeeded'   # Assert
```

Arrange เตรียมสถานการณ์ Act ทำสิ่งที่ตรวจ Assert ยืนยันผล ถ้า assert เพียงว่า “ไม่มี exception” อาจพลาดกรณี DB ไม่ถูกเขียนหรือ state ผิด ต้องเลือกผลที่สะท้อน contract จริง

`tmp_path` เป็น pytest fixture ให้ directory ชั่วคราวสำหรับ test นั้น ส่วน `@pytest.mark.parametrize` ใช้รัน test เดียวกับหลาย input ไม่ใช่ loop ภายใน application

## Failure matrix ของงานนี้

| เหตุการณ์ | สิ่งที่ต้องตรวจ |
|---|---|
| event ซ้ำ payload เดิม | task เดียว แม้เปิด Store ใหม่ |
| ID เดิม payload ต่าง | 409 ไม่มีการเขียนทับ |
| สอง worker claim พร้อมกัน | งานหนึ่งถูก claim ได้ครั้งเดียวใน lease นั้น |
| worker เก่ากลับมา | token เก่าเขียนทับไม่ได้ |
| timeout ซ้ำ | ไม่เกิน 3 attempts แล้วมี review |
| AI หลักฐานไม่อยู่ในเอกสาร | needs_review ไม่ส่งผลที่ยังไม่ผ่านต่อ |
| ส่ง review ซ้ำ | ผลเดิมและไม่เปลี่ยน AI result |

## CI คือการรัน checks จาก checkout ใหม่

ไฟล์ `.github/workflows/tests.yml` อยู่ใน Capstone ZIP เป็น template สำหรับเมื่อคุณทำ capstone เป็น repo root ไม่ใช่ workflow ของเว็บบทเรียน มัน checkout source, เตรียม Python, install requirements แล้วรัน pytest โดยไม่มี API key จริง

```text
push / Pull Request
    ↓ เครื่อง CI checkout source
install dependencies → tests → รายงานผ่าน/ไม่ผ่าน
```

CI สีเขียวช่วยยืนยันเฉพาะสิ่งที่ test ครอบคลุม ไม่รับรอง security, container runtime หรือความแม่นยำ AI จริง และ requirements ที่กำหนดช่วงเวอร์ชันอาจ resolve ต่างกันในอนาคต งานส่งมอบจริงควรมี lock/constraints ที่ทีมใช้ พร้อมรอบ update ไม่ freeze ทุกอย่างแล้วลืมดูแล

## อ่าน test จริงโดยไม่ต้องเข้าใจทั้งระบบก่อน

เลือก `test_durable_dedup_and_conflict` ใน tests/test_capstone.py แล้วรัน:

```powershell
python -m pytest tests/test_capstone.py -q -k durable_dedup
```

ควรมี 1 passed และ tests อื่นถูก deselected หมายถึงไม่ได้เลือกมารัน ไม่ใช่ tests เหล่านั้นผ่านหมดแล้ว อ่านทีละช่วง: สร้าง event → รับครั้งแรก → เปิด Store ใหม่ → รับซ้ำ → assert ID เดิม → ทดลองข้อมูลขัดแย้ง → assert ว่ามี event เดียว

```python
with pytest.raises(Conflict):
    reopened.ingest_transaction(event(amount=5), 102)
```

คำสั่งนี้ **คาดหวัง** ให้เกิด Conflict ภายใน block ถ้าไม่มี exception จึงถือว่า test fail ตรงข้ามกับการเขียน try/except เพื่อกลืน error แล้วปล่อย test ผ่าน เหตุการณ์ไม่สำเร็จทางธุรกิจอาจเป็นผล test ที่ผ่านได้ หากตรงกับ contract ที่ต้องป้องกัน

## เวลา test แดง ควรอ่านอะไร

```text
ชื่อ test ที่ fail → input ที่ใช้ → expected → actual
        ↓ หาบรรทัด assertion
ตรวจ implementation หรือ setup → แก้เหตุ → รัน test เดิม
        ↓ ผ่านแล้ว
รันทั้ง suite กัน regression
```

**Regression** คือสิ่งที่เคยทำงานได้กลับเสียหลังแก้ส่วนอื่น ถ้าแก้ threshold เพื่อให้ test หนึ่งผ่าน แต่ไม่ตรวจ boundary อีกสองฝั่ง อาจทำให้กฎเปลี่ยนโดยไม่ตั้งใจ อย่าเปลี่ยน assertion ตาม output ปัจจุบันเพียงเพื่อให้แสดงสีเขียว

## CI อยู่ตรงไหนจึงจะทำงาน

หากนำ Capstone ไปสร้าง repo ฝึกแยก ไฟล์ template ต้องอยู่ที่ `.github/workflows/tests.yml` ของ **repo root** ไม่ใช่ซ่อนอยู่ใน ZIP บนเว็บแล้วคาดว่า GitHub จะรัน Python ภายใน ZIP ให้ เริ่มจาก local tests ผ่านก่อน push แล้วเปิดผลแต่ละ step ในแท็บ Actions ของ repo นั้น

ถ้า CI ลง dependencies ไม่สำเร็จ จะยังสรุปไม่ได้ว่า tests ของคุณ fail เพราะยังไปไม่ถึงขั้นทดสอบ ถ้า local ผ่านแต่ CI fail ให้เทียบ Python version, dependency versions, CWD, ตัวพิมพ์ใหญ่เล็กของชื่อไฟล์ และ config ที่ไม่ได้ commit โดยไม่ส่ง secrets ไปเปิดเผยเพื่อ debug

จุดตรวจ: บอกได้ว่า test ใดพิสูจน์อะไร และสิ่งใดยังไม่ตรวจ อย่าใช้คำว่า “ทดสอบครบ” โดยไม่บอกขอบเขต
