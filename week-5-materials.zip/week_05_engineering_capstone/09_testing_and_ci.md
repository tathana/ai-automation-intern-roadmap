# 09 — Integration Testing และ CI ที่มีความหมาย

## ทดสอบผลที่สำคัญ ไม่ใช่แค่บรรทัดที่รันผ่าน

Unit test เหมาะกับกฎเล็ก ๆ เช่นจำนวนเงินถึง threshold หรือไม่ Integration test ตรวจหลายส่วนทำงานร่วมกัน เช่น request ผ่าน Pydantic แล้วบันทึก DB และ worker อ่านต่อ ชุดนี้ใช้ฐานข้อมูลชั่วคราวแยกแต่ละ test ไม่แตะ DB ที่คุณอ่านงานอยู่

```powershell
python -m pytest tests -q
python -m pytest tests -q -k expired_worker
```

`-q` ลดข้อความ, `-k` เลือก test ตามชื่อ รันจาก folder capstone ใช้ interpreter เดียวกับที่ติดตั้ง requirements

## อ่าน test ด้วย Arrange / Act / Assert

```python
tid, _ = store.ingest_transaction(payload, 100)  # Arrange
process_one(store, lambda: 101)                  # Act
assert store.task(tid)['state'] == 'succeeded'   # Assert
```

Arrange เตรียมสถานการณ์ Act ทำสิ่งที่ตรวจ Assert ยืนยันผล ถ้า assert เพียงว่า “ไม่มี exception” อาจพลาดกรณี DB ไม่ถูกเขียนหรือ state ผิด ต้องเลือกผลที่สะท้อน contract จริง

`tmp_path` เป็น pytest fixture ให้ directory ชั่วคราวสำหรับ test นั้น ส่วน `@pytest.mark.parametrize` ใช้รัน test เดียวกับหลาย input ไม่ใช่ loop ภายใน application

## Failure matrix ของงานนี้

| เหตุการณ์ | สิ่งที่ต้องตรวจ |
|---|---|
| event ซ้ำ payload เดิม | task เดียว แม้เปิด Store ใหม่ |
| ID เดิม payload ต่าง | 409 ไม่มีการเขียนทับ |
| สอง worker claim พร้อมกัน | งานหนึ่งถูก claim ได้ครั้งเดียวใน lease นั้น |
| worker เก่ากลับมา | token เก่าเขียนทับไม่ได้ |
| timeout ซ้ำ | ไม่เกิน 3 attempts แล้วมี review |
| AI หลักฐานไม่อยู่ในเอกสาร | needs_review ไม่ส่งผลที่ยังไม่ผ่านต่อ |
| ส่ง review ซ้ำ | ผลเดิมและไม่เปลี่ยน AI result |

## CI คือการรัน checks จาก checkout ใหม่

ไฟล์ `.github/workflows/tests.yml` อยู่ใน Capstone ZIP เป็น template สำหรับเมื่อคุณทำ capstone เป็น repo root ไม่ใช่ workflow ของเว็บบทเรียน มัน checkout source, เตรียม Python, install requirements แล้วรัน pytest โดยไม่มี API key จริง

```text
push / Pull Request
    ↓ เครื่อง CI checkout source
install dependencies → tests → รายงานผ่าน/ไม่ผ่าน
```

CI สีเขียวช่วยยืนยันเฉพาะสิ่งที่ test ครอบคลุม ไม่รับรอง security, container runtime หรือความแม่นยำ AI จริง และ requirements ที่กำหนดช่วงเวอร์ชันอาจ resolve ต่างกันในอนาคต งานส่งมอบจริงควรมี lock/constraints ที่ทีมใช้ พร้อมรอบ update ไม่ freeze ทุกอย่างแล้วลืมดูแล
