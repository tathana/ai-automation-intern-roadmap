# 06 — Durable State และ Transaction Boundary

## ทำไม set ใน memory ยังไม่พอ

สมมติเราเก็บ event ที่รับแล้วใน `seen_ids = set()` การส่งซ้ำระหว่าง process เดิมทำงานอาจถูกกันได้ แต่เมื่อ restart set ถูกสร้างใหม่เป็นค่าว่าง ระบบจึงรับ event เก่าเป็นงานใหม่ ความจำของ process ต่างจากข้อมูลถาวรในฐานข้อมูล

```text
in-memory set → restart → ว่าง
SQLite file  → restart → เปิดไฟล์เดิม → ยังเห็น event เดิม
```

Durable ใน lab นี้หมายถึง commit ลงไฟล์ DB และกลับมาอ่านได้หลังเปิด process ใหม่ ไม่ได้หมายถึงทน disk เสียหรือเครื่องหาย ต้องมี backup และนโยบายกู้คืนเพิ่มเติม

## ทำไมต้องบันทึก event และ task พร้อมกัน

ถ้าบันทึก event สำเร็จ แต่เครื่องดับก่อนสร้าง task จะเกิดข้อมูลที่รับแล้วแต่ไม่มีใครทำงานต่อ ในทางกลับกัน สร้าง task แต่ไม่บันทึก event อาจทำให้ dedup ไม่เห็นข้อมูลเดิม

```text
BEGIN IMMEDIATE
   ↓ ตรวจ event_id เดิม
   ↓ insert event
   ↓ insert task + audit
COMMIT ทั้งชุด หรือ ROLLBACK ทั้งชุด
```

นี่คือ **atomicity**: การเปลี่ยนแปลงใน transaction สำเร็จหรือย้อนกลับร่วมกัน เปิด [repository.py](capstone/course/repository.py) ดูว่า `BEGIN IMMEDIATE` อยู่ก่อนการตรวจ duplicate เพื่อจัดลำดับผู้เขียน SQLite และให้การอ่าน-ตัดสินใจ-เขียนไม่ถูกอีก writer แทรกกลาง

## UNIQUE constraint คือด่านที่ DB ช่วยยืนยัน

```sql
UNIQUE(kind, task_key)
```

ห้ามมี task สองแถวที่มีคู่ `kind` และ `task_key` เหมือนกัน ส่วน transaction ใช้ `event_id` เป็น primary key ด้วย การเช็กด้วย Python อย่างเดียวอาจมี race condition: สอง request เช็กพร้อมกันว่า “ยังไม่มี” แล้วต่างคนต่าง insert

## ส่ง ID เดิมแต่เนื้อหาเปลี่ยนควรทำอย่างไร

ตัวอย่างเลือกคืน **409 Conflict** ไม่แก้ข้อมูลเดิมเงียบ ๆ เพราะ event identity เดียวกันไม่ควรหมายถึงจำนวนเงินสองค่า JSON ถูก serialize แบบเรียง keys เพื่อเทียบ payload โดยไม่ขึ้นกับลำดับ key แต่ค่าต่างจริง เช่น mode ต่าง ยังคงถือว่า conflict

Resume ใช้ candidate ID + hash ของข้อความ + processing version + job version เป็น key จึงเป็น **text-level dedup** ไม่ใช่ file-level dedup ไฟล์ PDF สองไฟล์ที่ได้ข้อความตรงกันอาจรวมเป็น task เดียว ขณะที่ whitespace ต่างกันทำให้ hash ต่างกัน เมื่อเปลี่ยน job requirements ต้องเปลี่ยน job version ด้วย ไม่เช่นนั้นถือว่า identity เดิมแต่ options ขัดแย้ง ควรเลือกนิยามให้ตรงงานจริง ไม่ใช้คำว่า hash แล้วสมมติว่าปัญหา identity จบทั้งหมด

## Transaction ต้องสั้น

อย่าเปิด DB write transaction ค้างไว้ระหว่างรอ AI เพราะจะทำให้ writer อื่นรอโดยไม่จำเป็น เราจึง claim งานแล้ว commit ก่อนเรียก provider จากนั้นเริ่ม transaction ใหม่เพื่อบันทึกผล การแบ่งนี้ต้องมี lease และการป้องกัน worker เก่าเขียนทับ ซึ่งเป็นหัวข้อถัดไป

## State คืออะไรในภาษาง่าย

State คือข้อมูลว่า “ตอนนี้สิ่งนี้อยู่ขั้นไหน” เช่น task queued หรือ running ไม่ใช่แค่ตัวแปรชื่อ state เมื่อเก็บใน DB เราจึงกลับมาถามสถานะได้แม้ผู้รับ request กับผู้ทำงานเป็นคนละ process

ฐานข้อมูลมี **table** เหมือนชุดข้อมูลหนึ่งชนิด, **row** เป็นหนึ่งรายการ และ **column** เป็นรายละเอียดของรายการ เช่น table tasks มี row ของงานหนึ่งชิ้น และ column attempts บอกจำนวนครั้งที่เริ่มทำงานนั้น ต่างจาก table events ที่เก็บข้อมูลธุรกรรมต้นทาง

## Lab — ดูงานเดิมหลังเปิด Store ใหม่

จาก capstone ใช้ environment ที่ติดตั้ง requirements แล้ว:

```powershell
python learning_walkthrough.py state
```

ส่วนต้นควรเห็น:

```text
first: task_id=1 duplicate=False
reopened: task_id=1 duplicate=True
```

สคริปต์สร้าง DB ชั่วคราว รับ E1 แล้วสร้าง Store object ใหม่ชี้ไฟล์เดิม ก่อนส่ง E1 ซ้ำ จึงพิสูจน์ว่า dedup ไม่ได้อาศัย object เก่าอย่างเดียว แต่ **ไม่ใช่การ restart เครื่องจริง** ผล SQL ควรมี task เดียว state queued และ attempts 0 เพราะยังไม่เรียก worker

## อ่านคำสั่ง SQL ในโค้ดทีละส่วน

```python
row = con.execute(
    'SELECT payload FROM events WHERE event_id=?',
    (payload['event_id'],),
).fetchone()
```

`con` คือ connection กับ DB, `execute()` ส่ง SQL, `?` เป็น placeholder สำหรับค่า และ tuple `(value,)` ต้องมี comma เพราะเป็น tuple สมาชิกเดียว ไม่ใช่วงเล็บครอบค่าเฉย ๆ `fetchone()` ขอผลหนึ่ง row หรือ None เมื่อไม่พบ ใช้ parameter binding ไม่ต่อ string จาก input เข้า SQL เอง

```text
ไม่พบ row → เป็น event ใหม่ → insert
พบ row + payload เหมือน → คืน task เดิม
พบ row + payload ต่าง → Conflict → ไม่เขียนทับ
```

ใน Store ตั้ง `row_factory = sqlite3.Row` จึงอ่าน `row['payload']` ได้ด้วยชื่อ column ส่วน `.lastrowid` หลัง insert ใช้รับ ID ของแถวที่สร้าง และ `.rowcount` ใช้ดูจำนวนแถวที่ UPDATE เปลี่ยนจริง ความหมายต่างกัน อย่าใช้สลับกัน

## `with` ไม่ได้แปลว่าเริ่ม transaction เหมือนกันทุกชนิด

`with store.connection()` ใช้ context manager ที่เราเขียนเอง: เปิด connection, commit/rollback ตามเส้นทาง และปิดใน finally ส่วน `BEGIN IMMEDIATE` ใน method เป็นการเริ่ม write transaction ที่ต้องการจริง ถ้าเกิด exception ก่อนจบ ชุดการเปลี่ยนแปลงจะ rollback ตาม code นี้ อย่าอนุมานว่า `with` ทุก object ใน Python มีพฤติกรรมเกี่ยวกับ DB แบบนี้

จุดตรวจ: ถ้าข้อมูลหายหลังรัน walkthrough จบ เป็นสิ่งที่ตั้งใจเพราะใช้ temporary DB สำหรับเรียน ส่วน API/worker จริงใช้ path ตาม config ต้องไม่เลือก temporary storage หากต้องเก็บงานต่อ
