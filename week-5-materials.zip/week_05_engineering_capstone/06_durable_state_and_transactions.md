# 06 — Durable State และ Transaction Boundary

## ทำไม set ใน memory ยังไม่พอ

สมมติเราเก็บ event ที่รับแล้วใน `seen_ids = set()` การส่งซ้ำระหว่าง process เดิมทำงานอาจถูกกันได้ แต่เมื่อ restart set ถูกสร้างใหม่เป็นค่าว่าง ระบบจึงรับ event เก่าเป็นงานใหม่ ความจำของ process ต่างจากข้อมูลถาวรในฐานข้อมูล

```text
in-memory set → restart → ว่าง
SQLite file  → restart → เปิดไฟล์เดิม → ยังเห็น event เดิม
```

Durable ใน lab นี้หมายถึง commit ลงไฟล์ DB และกลับมาอ่านได้หลังเปิด process ใหม่ ไม่ได้หมายถึงทน disk เสียหรือเครื่องหาย ต้องมี backup และนโยบายกู้คืนเพิ่มเติม

## ทำไมต้องบันทึก event และ task พร้อมกัน

ถ้าบันทึก event สำเร็จ แต่เครื่องดับก่อนสร้าง task จะเกิดข้อมูลที่รับแล้วแต่ไม่มีใครทำงานต่อ ในทางกลับกัน สร้าง task แต่ไม่บันทึก event อาจทำให้ dedup ไม่เห็นข้อมูลเดิม

```text
BEGIN IMMEDIATE
   ↓ ตรวจ event_id เดิม
   ↓ insert event
   ↓ insert task + audit
COMMIT ทั้งชุด หรือ ROLLBACK ทั้งชุด
```

นี่คือ **atomicity**: การเปลี่ยนแปลงใน transaction สำเร็จหรือย้อนกลับร่วมกัน เปิด [repository.py](capstone/course/repository.py) ดูว่า `BEGIN IMMEDIATE` อยู่ก่อนการตรวจ duplicate เพื่อจัดลำดับผู้เขียน SQLite และให้การอ่าน-ตัดสินใจ-เขียนไม่ถูกอีก writer แทรกกลาง

## UNIQUE constraint คือด่านที่ DB ช่วยยืนยัน

```sql
UNIQUE(kind, task_key)
```

ห้ามมี task สองแถวที่มีคู่ `kind` และ `task_key` เหมือนกัน ส่วน transaction ใช้ `event_id` เป็น primary key ด้วย การเช็กด้วย Python อย่างเดียวอาจมี race condition: สอง request เช็กพร้อมกันว่า “ยังไม่มี” แล้วต่างคนต่าง insert

## ส่ง ID เดิมแต่เนื้อหาเปลี่ยนควรทำอย่างไร

ตัวอย่างเลือกคืน **409 Conflict** ไม่แก้ข้อมูลเดิมเงียบ ๆ เพราะ event identity เดียวกันไม่ควรหมายถึงจำนวนเงินสองค่า JSON ถูก serialize แบบเรียง keys เพื่อเทียบ payload โดยไม่ขึ้นกับลำดับ key แต่ค่าต่างจริง เช่น mode ต่าง ยังคงถือว่า conflict

Resume ใช้ candidate ID + hash ของข้อความ + processing version + job version เป็น key จึงเป็น **text-level dedup** ไม่ใช่ file-level dedup ไฟล์ PDF สองไฟล์ที่ได้ข้อความตรงกันอาจรวมเป็น task เดียว ขณะที่ whitespace ต่างกันทำให้ hash ต่างกัน เมื่อเปลี่ยน job requirements ต้องเปลี่ยน job version ด้วย ไม่เช่นนั้นถือว่า identity เดิมแต่ options ขัดแย้ง ควรเลือกนิยามให้ตรงงานจริง ไม่ใช้คำว่า hash แล้วสมมติว่าปัญหา identity จบทั้งหมด

## Transaction ต้องสั้น

อย่าเปิด DB write transaction ค้างไว้ระหว่างรอ AI เพราะจะทำให้ writer อื่นรอโดยไม่จำเป็น เราจึง claim งานแล้ว commit ก่อนเรียก provider จากนั้นเริ่ม transaction ใหม่เพื่อบันทึกผล การแบ่งนี้ต้องมี lease และการป้องกัน worker เก่าเขียนทับ ซึ่งเป็นหัวข้อถัดไป
