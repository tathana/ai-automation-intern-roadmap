# 00 — Assessment และแผนที่เชื่อม Week 1–4

## เรากำลังเพิ่มอะไรจากสัปดาห์ก่อน

Week 1 ทำให้จัดการข้อมูลและทดสอบฟังก์ชันได้ Week 2 ทำให้รับส่งข้อมูลผ่าน API ได้ Week 3 จัดลำดับงานด้วย workflow และ Week 4 เพิ่ม AI พร้อมตรวจผลลัพธ์ Week 5 ไม่ทิ้งสิ่งเหล่านี้ แต่ถามเพิ่มว่า “ถ้าปิดเครื่องแล้วเปิดใหม่ งานที่รับไว้ยังอยู่หรือไม่”

```text
ฟังก์ชันถูกต้อง         ← Week 1
    ↓ เปิดให้เรียกผ่าน HTTP ← Week 2
หลายขั้นตอนทำงานร่วมกัน ← Week 3
    ↓ ใช้ AI แบบมีขอบเขต   ← Week 4
รันซ้ำ + กู้คืน + ส่งมอบ  ← Week 5
```

## แบบทดสอบก่อนเริ่ม

ลองตอบโดยไม่เปิดเฉลย: ถ้า client timeout หลัง server บันทึกข้อมูลแล้ว การส่งซ้ำอาจเกิดอะไร? ถ้าเก็บ `seen_ids = set()` ไว้ใน Python แล้ว restart จะเป็นอย่างไร? ถ้า AI ส่ง JSON ถูก syntax แต่ข้อมูลไม่มีในเอกสาร ถือว่าถูกต้องหรือไม่?

คำตอบที่อยากให้เชื่อมได้คือ timeout ไม่ได้พิสูจน์ว่า server ไม่ทำงาน, in-memory state หายเมื่อ process หยุด และ schema validation ไม่ได้พิสูจน์ความจริงของข้อมูล หากยังไม่คล่อง ให้ย้อนดู idempotency ของ Week 1, retry ของ Week 2 และ evidence ของ Week 4 เฉพาะจุดนั้น ไม่ต้องเริ่มใหม่ทั้งสัปดาห์

## แบ่งขอบเขตความสำเร็จ

**Core:** native API + worker + SQLite + tests + README รันได้บนเครื่องเดียว ข้อมูลสังเคราะห์ทั้งหมด

**Integration:** รันด้วย Compose, ต่อ n8n, ทดลอง restart และตรวจ volume ด้วยตัวเอง โดยบันทึกผลจริงตามเครื่องที่ใช้

**Stretch:** real provider ที่องค์กรอนุมัติ, OCR, production database, authentication หลายผู้ใช้, outbox และระบบแจ้งเตือนจริง อย่าเปลี่ยนชื่อ stretch เป็น “ทำเสร็จแล้ว” เพียงเพราะมีภาพ architecture

## Definition of Done คืออะไร

คือข้อตกลงว่าอะไรต้องเป็นจริงจึงเรียกงานว่าเสร็จ เช่น “ส่ง event เดิมสองครั้งได้ task เดียว แม้เปิด Store ใหม่” ชัดกว่าคำว่า “รองรับ duplicate” เพราะคนอื่นเขียน test ตามได้

ลองเขียนสามข้อของตัวเองก่อนอ่านบทถัดไป โดยใช้รูปแบบ **สถานการณ์ → สิ่งที่ทำ → ผลที่ตรวจได้** ตัวอย่าง: worker ได้งานแล้วหยุด → รอ lease หมด → worker ใหม่รับงานได้ และ worker เก่าเขียนทับไม่ได้

## เริ่มจากศูนย์ — ตั้งโต๊ะทำงานก่อนอ่านโค้ด

ให้ดาวน์โหลด ZIP จากหน้า Week 5 แล้วแตกไฟล์ก่อน อย่ารันไฟล์จากหน้าต่าง preview ของ ZIP เพราะ path และไฟล์ข้างเคียงอาจไม่อยู่ในตำแหน่งที่โปรแกรมคาด เปิด folder `capstone` ใน editor และเปิด PowerShell ที่ folder นี้ คำว่า **terminal** คือหน้าต่างพิมพ์คำสั่ง ส่วน **Python interpreter** คือโปรแกรมที่อ่านและรันโค้ด Python ให้เรา

```powershell
Get-Location
Get-ChildItem
python --version
```

คำสั่งแรกบอกว่ากำลังอยู่ที่ไหน คำสั่งที่สองควรเห็น `course`, `tests`, `requirements.txt` และ `README.md` คำสั่งที่สามควรพบ Python ที่ติดตั้งแล้ว ถ้าไม่พบคำสั่ง `python` ให้จัดการติดตั้ง/เลือก interpreter ก่อน ไม่ใช่เปลี่ยน source เพื่อข้ามขั้นตอนนี้

## Environment คือชุดเครื่องมือของโปรเจกต์

`venv` แยก packages ของงานนี้จากโปรเจกต์อื่น ไม่ใช่เครื่องเสมือนทั้งเครื่อง ทำตามครั้งแรกจาก capstone:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest tests -q
```

`-m pip` คือให้ Python ตัวที่ระบุเป็นผู้รัน pip จึงลดปัญหาลง package ผิด interpreter ส่วน `-r` ขอให้ pip อ่านรายการจากไฟล์ หากมี `.venv` อยู่แล้วและเป็นของ lab นี้ ไม่ต้องสร้างใหม่ทุกครั้ง

ชุด Capstone เดิมควรผ่าน 24 tests ถ้าคุณเพิ่ม tests เองจำนวนอาจมากขึ้นได้ สีเขียวไม่ได้แปลว่าเปิด API แล้ว ขั้นนี้แค่ตรวจโค้ดใน environment ทดสอบ

## แยกโหมดเรียนให้ชัด

```text
อ่าน concept → รัน learning_walkthrough.py ใน terminal เดียว
      ↓ เข้าใจ state/retry/review แล้ว
เปิด API + worker แยก terminal → ทดลอง HTTP
      ↓ Docker Engine พร้อม
รัน Compose → ทดลอง environment ของ containers
```

สคริปต์ [learning_walkthrough.py](capstone/learning_walkthrough.py) ใช้ฐานข้อมูลชั่วคราวและ mock เดิม ไม่ต้องเปิด server ไม่เสียค่า AI และไม่แตะ DB ของ Capstone ที่คุณใช้อยู่ ตัวอย่าง `python learning_walkthrough.py state` ให้แทน `python` ด้วย `.\.venv\Scripts\python.exe` หากยังไม่ได้ activate environment คำสั่งสั้นในบทถัดไปสมมติว่าคุณเลือก interpreter นี้แล้ว

ถ้าอ่านแล้วไม่รู้ว่า output ควรเป็นอะไร ให้หยุดที่จุดตรวจของบทนั้นก่อน ไม่ต้องอ่านข้ามไป Docker เพื่อหวังว่าปัญหาจะหายไปเอง
