# 04 — Ports, Networks, Volumes และ Environment Variables

## localhost ของใคร

นี่เป็นจุดที่ทำให้ต่อ API ไม่ติดบ่อยที่สุด `localhost` หมายถึงเครื่องหรือ container ที่กำลังเรียก ไม่ได้หมายถึง laptop ของเราเสมอไป

| ผู้เรียก | URL ในตัวอย่าง | เหตุผล |
|---|---|---|
| Browser/Python บน host | `http://127.0.0.1:8015` | ใช้ published port |
| n8n ใน Compose เดียวกัน | `http://api:8015` | `api` เป็น service name ใน network |
| API ตรวจสุขภาพตัวเอง | `http://127.0.0.1:8015/health` | เรียกภายใน container ของตัวเอง |

```text
host:127.0.0.1:8015
       ↓ published port
container api:8015 ← Compose network ← n8n
```

`127.0.0.1:8015:8015` ใน Compose คือ **host address : host port : container port** การ bind host address เป็น loopback จำกัดให้ lab นี้เข้าจากเครื่องเดียว อย่าเปลี่ยนเป็น public โดยยังไม่มี auth และการป้องกันข้อมูล

## Volume ต่างจากไฟล์ใน container อย่างไร

ข้อมูลที่เขียนใน writable layer ของ container อาจหายเมื่อ container นั้นถูกลบ ส่วน named volume แยกอายุจาก container จึงเหมาะเก็บ SQLite ของ lab

```text
api ─────┐
         ├── capstone_data volume ── capstone.sqlite3
worker ──┘
```

ทั้งสอง service ต้อง mount volume เดียวกันและใช้ path DB เดียวกัน ถ้า API เขียน `/data/a.sqlite3` แต่ worker อ่าน `/app/data/a.sqlite3` จะดูเหมือน worker ไม่เห็นงาน ทั้งที่แต่ละตัวทำงานปกติ

Volume ไม่ใช่ backup และไม่ได้ป้องกันการลบข้อมูลด้วย SQL คำสั่ง `docker compose down` ตามปกติไม่ลบ named volume แต่ `down -v` ขอให้ลบ volume ด้วย จึง **ไม่ใช้ `-v` ในขั้นตอน restart ของบทนี้** [Docker volumes](https://docs.docker.com/engine/storage/volumes/)

## `.env` ไม่ได้ทำให้ secret ปลอดภัยโดยอัตโนมัติ

`.env.example` เป็นตัวอย่างที่แชร์ได้ ส่วน `.env` เป็นค่าของเครื่องเราและไม่ควร commit Compose อ่านค่า `${REVIEW_TOKEN:-}` จาก environment/ไฟล์ตามการตั้งค่าแล้วส่งให้ API; native Python ตัวอย่างไม่ได้โหลด `.env` เอง ต้องตั้ง `$env:REVIEW_TOKEN` ใน terminal ที่เปิด API

```powershell
$env:CAPSTONE_DB = "data/capstone.sqlite3"
```

นี่ตั้ง environment variable ของ PowerShell session ปัจจุบันและ process ลูก ไม่ได้แก้ source code และ terminal worker อีกหน้าต้องตั้งค่าของตัวเองด้วย `docker compose config` อาจแสดงค่าที่แทนแล้ว รวมถึง secret จึงอย่าโพสต์ output เต็มลงสาธารณะ ใช้ `config --quiet` เมื่อต้องการตรวจ syntax อย่างเดียว
