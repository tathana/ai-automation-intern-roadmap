# Roadmap Coverage — ใช้แผนเดิมต่อโดยรู้ว่าอะไรมีแล้ว

เอกสารนี้ไม่ลดเป้าหมายใน Premium Roadmap เดิม แต่แบ่ง reference ที่ให้รันได้วันนี้ออกจากงาน integration ที่ผู้เรียนต้องทำต่อ เพื่อไม่เรียก prototype ว่า production โดยไม่มีหลักฐาน

## Transaction Track

| ข้อกำหนดเดิม | มีในชุดนี้ | สิ่งที่ต้องทำต่อ |
|---|---|---|
| Schema, durable dedup, DB, large/velocity | API + repository + tests | ปรับ rule policy กับทีม |
| LLM summary / provider failure | mock summary; rules/review ไม่หายเมื่อ AI พัง | ต่อ provider ที่อนุมัติและประเมินจริง |
| Human approval / notification | review queue + decision + audit | ยังไม่ส่ง notification ภายนอก |
| n8n / webhook | Manual intake probes native/Compose | ประกอบ Webhook + auth + response และทดสอบ inbound |
| Docker Compose | Dockerfile/config + ขั้นตอนในบท | build/run/restart จริงเมื่อ Engine พร้อม |
| DB error | transaction boundary + rollback concept | เพิ่ม failure injection ด้าน storage ใน environment แยก |

## HR Track

Text intake, Pydantic output, configurable skill requirements, quote evidence, human review, retry, durable state และ audit มี reference แล้ว ใช้ **mock** จึงเป็นพื้นฐานฝึก Bronze ไม่ใช่การรับรอง LLM จริง

สำหรับเป้าหมาย Silver มี local PDF/DOCX parser, batch แบบ `--file` ซ้ำสำหรับ candidate เดียว, workflow probes, tests และคู่มือ แต่ยังต้องเพิ่ม file-level provenance/dedup, manifest หลาย candidate, production inbound workflow, วัดเวลางานคนจริง และตรวจ container runtime ก่อนถือว่า Silver เสร็จ

OCR, multilingual normalization, distributed workers และระบบสิทธิ์หลายผู้ใช้ยังเป็นงานต่อยอด ไม่แอบใช้ข้อมูลจริงเพื่อทดสอบโดยไม่ได้รับอนุมัติ

## แผนประกอบ inbound webhook ด้วยตัวเอง

```text
Webhook POST (test environment + auth)
    ↓ อ่าน body ไม่ใช่ทั้ง envelope
HTTP Request → POST API /transactions
    ↓ ตรวจ statusCode
Respond to Webhook → ส่ง task_id/status หรือ error ตามจริง
```

เริ่มในสำเนา workflow จาก Week 3 ที่มี Webhook แล้วเปลี่ยนปลายทางเป็น Week 5 API คง response 202 เมื่อรับ task สำเร็จ ไม่รอ worker ใน request เดียว ใช้ test URL ตามโหมด n8n แล้วทดสอบ schema error, duplicate, API unreachable และ timeout อย่าเปิด production webhook URL สาธารณะเพื่อผ่านโจทย์โดยไม่มี auth

## แผนเก็บ time-saving metrics

เลือก synthetic samples ชุดเดียวกันสำหรับ manual กับ assisted จับเวลา active work ของคนและ correction แยกจาก machine wait เก็บจำนวนเอกสาร, parse failures, evidence corrections, review rate และเวลาเฉลี่ย ระบุว่าใช้ mock หรือ provider จริง ห้ามเอา mock timing ไปสรุปผลประหยัดเวลาของระบบ AI จริง

เกณฑ์พร้อม demo: ผู้เรียนชี้ได้ว่า flow ใดทำงานจริง ส่วนใดเป็น mock ส่วนใดมีเฉพาะแบบฝึก และมีหลักฐานรองรับข้อความที่นำเสนอทุกข้อ
