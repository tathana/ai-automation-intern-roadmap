# 08 — Human Review, Audit และ Side Effects

## ทำไม AI result กับ decision ต้องแยกกัน

AI อาจช่วยสรุปสิ่งที่พบ แต่การตรวจทานของคนเป็นข้อมูลอีกชนิด ถ้าแก้ result เดิมทับทันทีจะตอบไม่ได้ว่า AI เสนออะไร และคนแก้ตรงไหน ตัวอย่างจึงเก็บ result ใน tasks และ decision ใน reviews

```text
AI result ──→ เก็บตามที่ผ่าน validation
    ↓ สร้าง review
คนอ่านหลักฐาน → decision ใหม่ + audit
    └────────→ ไม่เขียนทับ AI result
```

`verified` ใน lab หมายถึงตรวจข้อมูลแล้ว ส่วน `needs_followup` หมายถึงต้องตรวจเพิ่ม ไม่ใช่ approve/reject ผู้สมัคร และกฎธุรกรรมเป็นสัญญาณฝึกตรวจ ไม่ใช่คำตัดสินว่าธุรกรรมนั้นทุจริต

หนึ่ง task มี review row เดียว ถ้าสร้างจาก anomaly ตั้งแต่ intake แล้ว worker ล้มเหลวภายหลัง review reason เดิมจะยังอยู่ ให้ดู result และ audit สำหรับ error ล่าสุดด้วย ไม่ถือว่า reason แรกอธิบายทุกเหตุการณ์ที่ตามมา

## ทำไม decision ต้องมี ID

ถ้าคนกดส่งแล้วเครือข่ายสะดุด เขาอาจกดซ้ำ `decision_id` ช่วยให้การส่ง payload เดิมซ้ำคืนผลเดิมโดยไม่สร้าง decision ใหม่ แต่ถ้าใช้ ID เดิมกับเนื้อหาใหม่ จะคืน 409 เพื่อให้ตรวจเจตนา ไม่ใช้ last write wins โดยไม่บอกใคร

## Auth ตัวอย่างตั้งใจจำกัดมาก

Review endpoints ต้องใช้ bearer token ที่ตั้งใน environment และไม่รับชื่อ reviewer จาก client โดยเชื่อทันที ตัวอย่างบันทึก `local-demo-reviewer` คงที่ จึง **ไม่ใช่ authentication หลายผู้ใช้** และไม่มี role-based access control จริง

Intake และ task endpoints ยังไม่มี auth จึงต้อง bind loopback และใช้ข้อมูลสังเคราะห์เท่านั้น ก่อนใช้ข้อมูลจริงต้องออกแบบ identity, authorization รายข้อมูล, audit access, retention และการป้องกัน transport ให้ครบกับทีม

## Audit log ควรบอกเหตุการณ์ ไม่คัดลอกข้อมูลทั้งหมด

ตัวอย่างบันทึก accepted, claimed, retry_pending, succeeded และ review_decided พร้อมเวลาและ task ID เพื่อไล่เส้นทางได้ แต่ไม่เขียน resume ทั้งฉบับใน console log ฐานข้อมูลยังมี document_text ใน payload จึงยังต้องถือเป็นข้อมูลที่ต้องคุ้มครองเมื่อเปลี่ยนจาก synthetic

## Outbox คืออะไร และตอนนี้ทำถึงไหน

สมมติ DB บันทึกว่าอนุมัติแล้ว แต่การส่ง notification ล้มเหลว ถ้าไม่มีบันทึกว่าจะต้องส่งอะไร ระบบอาจลืมแจ้งเตือน **Transactional outbox** คือบันทึก intent ที่จะส่งใน transaction เดียวกับ decision แล้วให้อีก worker ส่งภายหลัง

```text
decision + outbox row → commit
              ↓ dispatcher ส่งภายนอก
              ↓ บันทึก sent / retry
```

Capstone นี้ยังไม่ส่งอีเมล/ข้อความภายนอกและยังไม่ implement outbox เป็นโจทย์ stretch อย่านำ `print('sent')` มาใช้เป็นหลักฐานว่าปลายทางได้รับแล้ว แม้เพิ่ม outbox ก็ยังอาจส่งซ้ำในช่องว่างระหว่างส่งสำเร็จกับบันทึก sent ต้องมี dedup/idempotency ที่ปลายทางหรือแผนจัดการด้วย

## Lab — เห็น review เปลี่ยน แต่ AI result ไม่ถูกแก้ทับ

```powershell
python learning_walkthrough.py review
```

ควรเห็น:

```text
review_before=pending
review_after=verified
same_decision_on_replay=True
ai_result_unchanged=True
```

จากนั้นมี audit records ให้ดูตามลำดับ สคริปต์จำลองว่าคนตรวจข้อมูลสังเคราะห์แล้วเรียก repository โดยตรง **ไม่ได้ทดสอบ HTTP auth** และไม่ได้แปลว่า application ควรอนุญาตให้ทุกคนเรียก decision ได้ การตรวจ auth อยู่ใน API tests และการทดลองผ่าน HTTP ตาม README

## อ่านการตัดสินใจแบบทีละขั้น

เริ่มจาก `task_id` ที่มี review → อ่าน result/evidence → เขียน note ว่าตรวจอะไร → สร้าง decision_id สำหรับการส่งนี้ → ส่ง → ตรวจ review state และ audit หาก network สะดุดและต้องส่งซ้ำ ใช้ decision_id กับ payload เดิม ไม่สร้าง ID ใหม่ทุกครั้งที่ retry

```text
ผล AI: Python มี quote สนับสนุน
คนตรวจ: อ่าน quote เทียบเอกสารแล้ว
decision: verified + note
     ↓ เก็บคนละช่องทางข้อมูล
ยังย้อนดูผล AI ก่อนคนตรวจได้
```

## Bearer token คือบัตรผ่าน ไม่ใช่ชื่อคน

Header `Authorization: Bearer <token>` ให้ server ตรวจว่าผู้เรียกรู้ token ที่ตั้งไว้หรือไม่ ตัวอย่างนี้ใช้ shared token จึงยังแยกไม่ได้ว่าเป็นคนใดจริง แม้มี reviewer label คงที่ก็ไม่ใช่หลักฐาน identity รายบุคคล ห้ามใส่ token ลง URL เพราะ URL อาจถูกเก็บในประวัติและ logs

เมื่อ HTTP ตอบ 401 ให้ตรวจ header/ค่าที่ตั้ง เมื่อ 503 ให้ตรวจว่า API เปิด review auth แล้วหรือยัง ถ้า 404 ให้ตรวจ task มี review จริงหรือไม่ และ 409 ต้องอ่านว่าตัดสินแล้วหรือ ID ซ้ำ ห้ามแก้ปัญหาด้วยลบ review row เพื่อให้กดได้ใหม่โดยไม่มี audit

## Side effect ที่ต้องระวัง

Side effect คือผลนอกเหนือจากค่าที่ฟังก์ชัน return เช่นเขียน DB, ส่งอีเมล หรือแก้สถานะในระบบอื่น หากฟังก์ชันคำนวณถูกสองครั้งอาจไม่เสียหาย แต่ส่งอีเมลสองฉบับไม่เหมือนหนึ่งฉบับ นี่เป็นเหตุผลให้แยกการคำนวณ, การบันทึก และการส่งภายนอก แทนการเรียกทุกอย่างใน retry loop เดียว
