# 08 — Human Review, Audit และ Side Effects

## ทำไม AI result กับ decision ต้องแยกกัน

AI อาจช่วยสรุปสิ่งที่พบ แต่การตรวจทานของคนเป็นข้อมูลอีกชนิด ถ้าแก้ result เดิมทับทันทีจะตอบไม่ได้ว่า AI เสนออะไร และคนแก้ตรงไหน ตัวอย่างจึงเก็บ result ใน tasks และ decision ใน reviews

```text
AI result ──→ เก็บตามที่ผ่าน validation
    ↓ สร้าง review
คนอ่านหลักฐาน → decision ใหม่ + audit
    └────────→ ไม่เขียนทับ AI result
```

`verified` ใน lab หมายถึงตรวจข้อมูลแล้ว ส่วน `needs_followup` หมายถึงต้องตรวจเพิ่ม ไม่ใช่ approve/reject ผู้สมัคร และกฎธุรกรรมเป็นสัญญาณฝึกตรวจ ไม่ใช่คำตัดสินว่าธุรกรรมนั้นทุจริต

หนึ่ง task มี review row เดียว ถ้าสร้างจาก anomaly ตั้งแต่ intake แล้ว worker ล้มเหลวภายหลัง review reason เดิมจะยังอยู่ ให้ดู result และ audit สำหรับ error ล่าสุดด้วย ไม่ถือว่า reason แรกอธิบายทุกเหตุการณ์ที่ตามมา

## ทำไม decision ต้องมี ID

ถ้าคนกดส่งแล้วเครือข่ายสะดุด เขาอาจกดซ้ำ `decision_id` ช่วยให้การส่ง payload เดิมซ้ำคืนผลเดิมโดยไม่สร้าง decision ใหม่ แต่ถ้าใช้ ID เดิมกับเนื้อหาใหม่ จะคืน 409 เพื่อให้ตรวจเจตนา ไม่ใช้ last write wins โดยไม่บอกใคร

## Auth ตัวอย่างตั้งใจจำกัดมาก

Review endpoints ต้องใช้ bearer token ที่ตั้งใน environment และไม่รับชื่อ reviewer จาก client โดยเชื่อทันที ตัวอย่างบันทึก `local-demo-reviewer` คงที่ จึง **ไม่ใช่ authentication หลายผู้ใช้** และไม่มี role-based access control จริง

Intake และ task endpoints ยังไม่มี auth จึงต้อง bind loopback และใช้ข้อมูลสังเคราะห์เท่านั้น ก่อนใช้ข้อมูลจริงต้องออกแบบ identity, authorization รายข้อมูล, audit access, retention และการป้องกัน transport ให้ครบกับทีม

## Audit log ควรบอกเหตุการณ์ ไม่คัดลอกข้อมูลทั้งหมด

ตัวอย่างบันทึก accepted, claimed, retry_pending, succeeded และ review_decided พร้อมเวลาและ task ID เพื่อไล่เส้นทางได้ แต่ไม่เขียน resume ทั้งฉบับใน console log ฐานข้อมูลยังมี document_text ใน payload จึงยังต้องถือเป็นข้อมูลที่ต้องคุ้มครองเมื่อเปลี่ยนจาก synthetic

## Outbox คืออะไร และตอนนี้ทำถึงไหน

สมมติ DB บันทึกว่าอนุมัติแล้ว แต่การส่ง notification ล้มเหลว ถ้าไม่มีบันทึกว่าจะต้องส่งอะไร ระบบอาจลืมแจ้งเตือน **Transactional outbox** คือบันทึก intent ที่จะส่งใน transaction เดียวกับ decision แล้วให้อีก worker ส่งภายหลัง

```text
decision + outbox row → commit
              ↓ dispatcher ส่งภายนอก
              ↓ บันทึก sent / retry
```

Capstone นี้ยังไม่ส่งอีเมล/ข้อความภายนอกและยังไม่ implement outbox เป็นโจทย์ stretch อย่านำ `print('sent')` มาใช้เป็นหลักฐานว่าปลายทางได้รับแล้ว แม้เพิ่ม outbox ก็ยังอาจส่งซ้ำในช่องว่างระหว่างส่งสำเร็จกับบันทึก sent ต้องมี dedup/idempotency ที่ปลายทางหรือแผนจัดการด้วย
