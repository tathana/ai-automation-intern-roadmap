"""Intentionally broken learning exercise. Use only synthetic local data."""
import sqlite3


class Registry:
    def __init__(self, path):
        self.path=path
        self.seen=set()

    def accept(self, event_id, payload):
        # TODO: durable identity, payload conflict, stable task id.
        if event_id in self.seen:
            return {'task_id':len(self.seen),'duplicate':True}
        self.seen.add(event_id)
        return {'task_id':len(self.seen),'duplicate':False}


def may_finish(current_token, supplied_token, lease_until, now):
    # TODO: token and expiry must both authorize completion.
    return True


def next_state(attempts, temporary):
    # TODO: permanent output errors require review; retry budget is three attempts.
    return 'retry_pending'
