import pytest
from starter import Registry, may_finish, next_state


def test_restart_dedup(tmp_path):
    path=tmp_path/'registry.sqlite3'
    first=Registry(path).accept('E1',{'amount':100})
    repeated=Registry(path).accept('E1',{'amount':100})
    assert repeated=={'task_id':first['task_id'],'duplicate':True}


def test_original_task_id(tmp_path):
    registry=Registry(tmp_path/'registry.sqlite3')
    first=registry.accept('E1',{'amount':100})
    registry.accept('E2',{'amount':200})
    assert registry.accept('E1',{'amount':100})['task_id']==first['task_id']


def test_conflicting_payload(tmp_path):
    registry=Registry(tmp_path/'registry.sqlite3')
    registry.accept('E1',{'amount':100})
    with pytest.raises(ValueError):
        registry.accept('E1',{'amount':200})


@pytest.mark.parametrize('current,supplied,expires,now,expected',[
    ('new','old',30,10,False),('same','same',30,30,False),
    ('same','same',30,29,True), (None,None,30,1,False)])
def test_completion_guard(current,supplied,expires,now,expected):
    assert may_finish(current,supplied,expires,now) is expected


@pytest.mark.parametrize('attempts,temporary,expected',[(1,True,'retry_pending'),(3,True,'failed'),(1,False,'needs_review')])
def test_retry_budget(attempts,temporary,expected):
    assert next_state(attempts,temporary)==expected
