# ReleaseGuard Hints — เปิดตามจุดที่ติด

## Hint 1: ทำไม restart แล้วลืม

`self.seen` อยู่ใน object ใหม่ทุกครั้ง ลองสร้างตาราง events มี id INTEGER PRIMARY KEY, event_id UNIQUE และ payload TEXT จากนั้นอ่าน row เดิมก่อนคืนผล ใช้ canonical JSON เพื่อเทียบข้อมูลโดยไม่ขึ้นกับลำดับ key

## Hint 2: ทำไม len ไม่ใช่ task ID

จำนวนสมาชิกตอนนี้เปลี่ยนได้เมื่อมี event ใหม่ แต่ identity ของ E1 ต้องไม่เปลี่ยน จึงต้องคืน id ที่เก็บไว้กับ E1 ไม่ใช่จำนวน event ทั้งระบบ

## Hint 3: ป้องกัน race อย่างไร

อ่าน/ตัดสินใจ/insert ภายใน transaction เดียวที่จัดลำดับ writer และมี UNIQUE constraint ป้องกันที่ DB ด้วย อย่า commit event แล้วค่อยสร้าง task คนละ transaction ในระบบที่ต้องทำสองอย่างร่วมกัน

## Hint 4: completion ต้องผ่านทุกเงื่อนไข

เขียนเป็นภาษาคนก่อน: มี token ปัจจุบันจริง AND token ตรง AND เวลาปัจจุบันน้อยกว่าเวลาหมดอายุ ค่อยแปลงเป็น Python ใช้ `bool(...)` หากต้องการให้ผลเป็น bool แน่นอน

## Hint 5: ลำดับ retry branch

แยก permanent error ก่อน แล้วดูว่า temporary หมด budget หรือยัง เขียน truth table จาก test inputs จะเห็นสามทาง ไม่ต้องเพิ่ม recursion หรือ while loop ในฟังก์ชันตัดสินสถานะนี้

## หลังผ่าน visible tests

เพิ่มกรณี payload key order ต่างแต่ความหมายเดิม, worker token ว่าง, เวลาหมดอายุพอดี และเปิด Registry ใหม่หลายครั้ง การผ่าน 10 เคสที่ให้มาไม่พิสูจน์การทน concurrent writers หรือ crash ทุกตำแหน่ง ต้องแยกขอบเขตหลักฐานให้ชัด
