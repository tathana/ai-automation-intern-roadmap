# ReleaseGuard — ซ่อมระบบก่อนส่งมอบ

## สถานการณ์

ทีมมีระบบที่ demo รอบแรกดูดี แต่ restart แล้วรับ event ซ้ำได้, task ID ของงานเก่าเปลี่ยน, worker เก่าเขียนผลได้ และ retry ไม่มีวันจบ คุณต้องซ่อม **starter.py** ให้ผ่าน contract โดยไม่แก้ tests เพื่อหลบข้อผิดพลาด

```text
อ่าน contract → รัน red tests → เลือกหนึ่ง defect
    → แก้ → test → ตรวจ regression → เขียน release note
```

## เริ่มต้น

เปิด terminal ใน folder challenge_releaseguard ใช้ Python environment ที่มี pytest:

```powershell
python -m pytest test_acceptance.py -q
```

Starter ตั้งใจให้ tests บางส่วนไม่ผ่าน นี่ไม่ใช่ Capstone reference ที่เสีย แยก folder เพื่อไม่ให้ปนกับชุด tests ที่ควรผ่าน

## ข้อกำหนด

`Registry.accept()` ต้องเก็บ identity ถาวรใน SQLite ตาม path ที่รับ, event ใหม่ได้ ID คงที่, payload เดิมส่งซ้ำได้ duplicate true, payload ต่างใน ID เดิม raise ValueError โดยไม่เขียนทับ

`may_finish()` ต้องตรวจ token ที่ไม่ว่าง ตรงกัน และ lease ยังไม่หมด `next_state()` ให้ retry เฉพาะ temporary error ก่อนครบ 3 attempts; ครบแล้ว failed; permanent output error เป็น needs_review

## ห้ามลัด

ไม่ hardcode E1, ไม่เปลี่ยน expected values, ไม่ใช้ตัวแปร global เป็นฐานข้อมูล และไม่ catch ทุก exception แล้วคืน success เพิ่ม test concurrency หรือ boundary ได้เป็นงานเสริม

## Rubric 100 คะแนน

Durable dedup/conflict 35, stable identity 15, lease fencing 20, bounded retry 15, test เพิ่มพร้อมคำอธิบายและ README 15 คะแนน ต้องไม่มี secret/ข้อมูลจริง หาก tests ผ่านแต่บอกเหตุผลไม่ได้ให้ย้อนอ่าน flow ก่อนนับผ่าน

ส่ง source diff, ผล tests, failure reproduction และ release note สั้น ๆ [Hints แบบเปิดทีละขั้น](HINTS.md) และดู repository ของ Capstone เป็น reference หลังลองเองแล้ว ไม่จำเป็นต้องคัดลอกโครงสร้างทุกบรรทัด
