# 07 — Worker, Retry, Lease และ Crash Recovery

## Worker คือคนทำงานเบื้องหลัง

API รับงานและคืน task ID ส่วน worker วนดูว่ามีงานถึงเวลาทำหรือไม่ หากไม่มีจะพักสั้น ๆ ไม่ใช้ CPU วนเปล่า ถ้ามีจะ claim ก่อนประมวลผล การ claim คือจองสิทธิ์ทำงานชั่วคราว ไม่ใช่ลบงานออกจาก DB

```text
queued → running → succeeded
             ├── output ใช้ไม่ได้ → needs_review
             ├── ชั่วคราวล้มเหลว → retry_pending → running
             └── retry ครบ → failed + review
```

ชื่อสถานะช่วยให้แยก “กำลังรอ” ออกจาก “ล้มเหลวถาวร” ได้ `/tasks/{id}` เป็นจุดอ่านสถานะ อย่าดูเพียง HTTP 202 ของ intake หรือเครื่องหมายสีเขียวใน n8n

## Lease ต่างจาก lock ที่ถือไว้ตลอดอย่างไร

Lease เป็นสิทธิ์ที่มีเวลาหมดอายุ ในตัวอย่าง 30 วินาที ถ้า worker หายไป งานยังอยู่และ worker ใหม่รับต่อหลังหมดเวลาได้ ไม่ต้องเปิด DB transaction ค้างตลอดงาน

```text
เวลา 1: worker A claim → token A, หมดอายุ 31
เวลา 2: A ค้าง
เวลา 32: worker B claim → token B
เวลา 33: A กลับมาเขียนผลด้วย token A → ปฏิเสธ
เวลา 33: B เขียนผลด้วย token B → ยอมรับ
```

การตรวจ token และเวลาตอน update เป็น **fencing** เพื่อกัน attempt เก่าเขียนทับ attempt ใหม่ SQL ต้องตรวจเงื่อนไขใน UPDATE เอง ไม่ใช่ SELECT เช็กก่อนแล้ว UPDATE แบบไม่มีเงื่อนไข เพราะสถานะอาจเปลี่ยนระหว่างสองคำสั่ง

## Retry ไม่ใช่ลองใหม่ทุก error

`TemporaryFailure` ใน mock จำลอง timeout/ปัญหาชั่วคราว จึงรอแล้วลองใหม่ได้ ส่วน malformed JSON หรือ evidence ที่ไม่มีในเอกสารส่งตรวจทาน ไม่วน retry อย่างไร้ขอบเขต ตัวอย่างกำหนดสูงสุด 3 attempts รวมครั้งแรก และ delay 1 แล้ว 2 วินาที

```python
delay = 2 ** (attempts - 1)
```

`**` ตรงนี้คือยกกำลัง ไม่ใช่ unpack dict: attempt 1 ได้ `2 ** 0 = 1`, attempt 2 ได้ `2 ** 1 = 2` งานจริงควรมี max delay, jitter และแยก error ที่ retry ได้ตามสัญญาของ provider

## ขอบเขตที่ต้องรู้ก่อนนำไปใช้จริง

Lab ไม่มี lease heartbeat หากงานใช้เวลานานกว่า 30 วินาที ผลอาจถูกปฏิเสธและงานถูกทำซ้ำ ต้องเพิ่ม renewal/timeout ที่สัมพันธ์กันก่อนใช้ provider ช้า Mock timeout เป็น exception จำลอง ไม่ใช่การวัด network timeout จริง

ระบบนี้ยอมให้การคำนวณเกิดมากกว่าหนึ่งครั้งได้ จึงไม่ควรอ้าง exactly-once end-to-end แม้บันทึกผลใน DB ได้อย่างมีเงื่อนไข การเรียก external API ที่มี side effect ยังต้องมี idempotency ของระบบปลายทางหรือ outbox เพิ่มเติม

ลองรัน test `test_expired_worker_cannot_overwrite` แล้วอ่าน assertion ทีละบรรทัด จะเห็นว่าเราไม่ต้องรอจริง 30 วินาที เพราะส่งเวลาจำลองเข้า Store
