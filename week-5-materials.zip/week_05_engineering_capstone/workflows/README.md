# n8n — Intake Probes สำหรับ Capstone

## เลือกตามตำแหน่ง n8n

- [Transaction — native n8n](native/transaction_intake.json)
- [HR — native n8n](native/resume_intake.json)
- [Transaction — n8n ใน Compose](compose/transaction_intake.json)
- [HR — n8n ใน Compose](compose/resume_intake.json)

Native ใช้ `127.0.0.1:8015` ส่วน Compose ใช้ `api:8015` อย่า import แล้วเปิดใช้งานทั้งหมดโดยไม่เลือก environment ให้ตรง ตัวอย่าง inactive และใช้ Manual Trigger เท่านั้น ไม่มี credential และไม่ส่งข้อมูลจริง

## สิ่งที่ workflow ทำ

```text
Manual Trigger → Seed Request → Intake API → Inspect Accepted
```

Seed สร้างข้อมูลสังเคราะห์ ID คงที่ จึงกดรอบแรกได้ duplicate false และกดซ้ำได้ true ถ้า DB เคยมี ID นี้อยู่แล้ว รอบแรกของวันนี้อาจ true ได้ตามปกติ

Inspect Accepted อ่าน HTTP status และ task ID พร้อม `completed: false` เพราะ workflow นี้ **ตรวจการรับงานเท่านั้น ไม่ได้ poll จนจบ** ใช้ GET `/tasks/{task_id}` หรือ demo.py ติดตามผล หรือเพิ่ม Wait → GET → Switch เป็นแบบฝึกโดยตั้ง max polls/deadline ไม่วนไม่สิ้นสุด

## จุดที่ควรอ่านใน HTTP node

Body ส่งเป็น JSON expression จาก item ปัจจุบัน `fullResponse` ทำให้เห็น statusCode คู่กับ body และ `neverError` ทำให้ HTTP error กลับมาเป็นข้อมูลให้ตรวจได้ จึงต้องตรวจ status เอง ไม่อ่านสีเขียวของ execution แทน business success หากต่อผิด URL network error อาจทำให้ node ล้มเหลวก่อนมี response

## ต่อ review อย่างปลอดภัย

ยังไม่ใส่ token ลง workflow JSON หากต่อ review endpoint ให้ใช้ credential management ของ environment ที่ได้รับอนุมัติ ไม่ paste token ลง Code node หรือ export พร้อมค่าใช้งานจริง และอย่าส่ง decision อัตโนมัติเพียงเพราะ task succeeded
