# 10 — Logs, Metrics และการ Debug ตามเส้นทางงาน

## เริ่มจาก task ID ไม่เริ่มด้วย restart ทุกอย่าง

ถ้า workflow ดูเหมือนสำเร็จแต่ไม่พบผล ให้หา task ID จาก intake response ก่อน แล้วอ่าน `/tasks/{id}` และ `/tasks/{id}/audit` เหตุการณ์จะบอกว่าค้างก่อน claim, ระหว่างประมวลผล หรือรอ review

```text
มี task_id หรือไม่?
  ├─ ไม่มี → ตรวจ request, HTTP status, validation
  └─ มี → queued นาน? → worker ใช้ DB เดียวกันหรือไม่
          running นาน? → lease/exception/worker หยุด
          needs_review? → อ่าน reason ไม่ retry มั่ว
```

## Log ที่ดีต้องตอบคำถามได้

ตัวอย่าง worker เขียนชนิด exception ไม่เขียน payload ทั้งฉบับ แต่ log ขั้นต่ำนี้ยังไม่ใช่ observability เต็มระบบ ถ้าต่อยอดให้เพิ่ม task_id, attempt, duration และ error_code โดยหลีกเลี่ยง token, document_text และข้อมูลระบุตัวบุคคล

```json
{"task_id": 12, "attempt": 2, "stage": "provider", "error_code": "timeout"}
```

นี่เป็นตัวอย่างรูปแบบที่ควรเพิ่ม ไม่ใช่คำกล่าวว่า worker เวอร์ชันนี้มีทุก field แล้ว `task_id` ทำหน้าที่ correlation ระหว่าง request, worker และ audit ส่วน log level ช่วยแยกข้อมูลทั่วไปกับสิ่งที่ต้องตรวจ

## Count กับอายุงานบอกคนละอย่าง

`/summary` มีจำนวน event, จำนวน tasks แยก state และ pending reviews แต่ยังไม่มี latency histogram หรือ oldest queued age ถ้ามี queued 10 งาน อาจปกติเมื่อเพิ่งส่งเข้า หรือผิดปกติเมื่อค้างหลายชั่วโมง ต้องดูอายุร่วมด้วย

```sql
SELECT state, COUNT(*) AS total, MIN(created) AS oldest_created
FROM tasks
GROUP BY state;
```

`MIN(created)` คือเวลาเก่าที่สุด ไม่ใช่จำนวนวินาทีที่รอโดยตัวมันเอง ต้องเทียบกับเวลาปัจจุบัน และไม่ควรสับสนเวลาสร้าง task กับเวลาของ retry รอบล่าสุด

## วัดผลลดเวลางานอย่างซื่อสัตย์

กำหนดงานและจำนวนเอกสารให้เหมือนกันก่อนวัด:

```text
เวลาที่ลดได้ = เวลา manual เดิม
             - (เวลาคนเตรียม input + เวลารอตามนิยาม + เวลาคนตรวจแก้)
```

แยก machine elapsed time กับ human active time เพราะ workflow รัน 10 นาทีไม่ได้แปลว่าคนเสียเวลา 10 นาที และอย่าใช้เวลาของ mock provider อ้างความเร็วของโมเดลจริง เก็บ sample size, วันที่, failure rate, review rate และเงื่อนไขที่วัดในรายงานเสมอ

เมื่อพบ bug ให้บันทึก input สังเคราะห์ที่ทำซ้ำได้, expected/actual, task ID, version และ test ที่เพิ่ม นี่มีประโยชน์ต่อทีมมากกว่าคำว่า “บางครั้งไม่ทำงาน”

## แยก Log, Audit และ Metric ก่อน

**Log** ช่วยอ่านว่า process กำลังทำอะไร/เจอ error อะไร **Audit** เก็บเหตุการณ์ที่ต้องย้อนตรวจของงานหรือ decision ส่วน **Metric** เป็นค่ารวม เช่นจำนวน queued หรืออัตรา failure ไม่ใช่สิ่งเดียวกัน แม้บางระบบสร้าง metrics จาก logs ได้

```text
หนึ่งงานผิดปกติ → task + audit + logs ตาม ID
หลายงานเริ่มค้าง → metrics บอกแนวโน้ม → เจาะบาง task
```

Lab ยังไม่มี dashboard/alerting เต็มระบบ `/summary` เป็นจุดเริ่มอ่าน counts ไม่ใช่ระบบ monitoring ที่แจ้งเตือนให้เอง

## Lab — อ่านภาพรวม แล้วเจาะงานหนึ่งรายการ

หลังเปิด native API/worker ตาม README:

```powershell
Invoke-RestMethod http://127.0.0.1:8015/summary | ConvertTo-Json -Depth 6
```

`ConvertTo-Json` ช่วยให้เห็นข้อมูลซ้อนเป็นข้อความ และ `-Depth 6` เพิ่มระดับข้อมูลที่แสดง ไม่ได้เปลี่ยนข้อมูลใน DB ถ้ามี `queued: 3` หมายถึงตอนอ่านมีสามงานรอ ไม่ได้แปลว่าสามงานนั้น error

หยิบ task ID จาก intake response ของคุณมาใส่แทนเลข 1:

```powershell
Invoke-RestMethod http://127.0.0.1:8015/tasks/1 | ConvertTo-Json -Depth 8
Invoke-RestMethod http://127.0.0.1:8015/tasks/1/audit | ConvertTo-Json -Depth 6
```

หากไม่เปิด API ยังฝึกอ่าน summary สังเคราะห์ได้ด้วย `python learning_walkthrough.py transaction` จะเห็น 3 events, tasks succeeded 3 และ pending reviews 2 จากกฎของตัวอย่างนี้

## ตารางแยกสาเหตุ ไม่แก้ด้วยคำสั่งเดียวทุกปัญหา

| สิ่งที่เห็น | ความหมายที่เป็นไปได้ | ตรวจต่อ |
|---|---|---|
| Connection refused | ไม่มี process รับที่ address/port นั้น | API เปิดหรือยัง, URL ถูกเครื่องหรือไม่ |
| 422 | request ไม่ตรง schema | ชื่อ field/type/value |
| queued + attempts 0 | ยังไม่ถูก claim | worker เปิดไหม, DB เดียวกันไหม |
| retry_pending + attempts 2 | มี failure ชั่วคราวสองรอบ | available / provider reason |
| succeeded + pending review | ประมวลผลแล้ว คนยังไม่ตรวจ | ไม่ต้องส่งงานใหม่เพื่อให้ review หาย |

อย่ารัน `docker compose logs` แล้วเผยแพร่ output ทั้งหมดโดยไม่อ่านก่อน แม้ application ตั้งใจไม่ log ข้อมูลจริง ส่วน library, stack trace หรือ proxy อาจมีข้อมูลอื่น ต้องเลือกเฉพาะส่วนที่จำเป็น

## ตัวอย่างแบบฟอร์มวัดเวลา

เก็บเป็นตารางที่คุณกรอกผลทดลองจริง: sample ID สังเคราะห์, manual active minutes, assisted preparation minutes, correction minutes, machine elapsed seconds และ outcome ใช้หน่วยให้ตรงกันก่อนคำนวณ แยกเอกสารที่อ่านไม่ได้ออกมาเป็น failure ที่รายงาน ไม่ทิ้งมันเพื่อให้ค่าเฉลี่ยดูดี

จุดตรวจ: เล่าปัญหาหนึ่งรายการโดยใช้หลักฐานได้ว่า “รับแล้วแต่ยังไม่ถูก claim” แทนคำว่า “API ไม่ทำงาน” ซึ่งกว้างเกินไป
