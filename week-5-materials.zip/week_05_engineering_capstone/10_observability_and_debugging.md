# 10 — Logs, Metrics และการ Debug ตามเส้นทางงาน

## เริ่มจาก task ID ไม่เริ่มด้วย restart ทุกอย่าง

ถ้า workflow ดูเหมือนสำเร็จแต่ไม่พบผล ให้หา task ID จาก intake response ก่อน แล้วอ่าน `/tasks/{id}` และ `/tasks/{id}/audit` เหตุการณ์จะบอกว่าค้างก่อน claim, ระหว่างประมวลผล หรือรอ review

```text
มี task_id หรือไม่?
  ├─ ไม่มี → ตรวจ request, HTTP status, validation
  └─ มี → queued นาน? → worker ใช้ DB เดียวกันหรือไม่
          running นาน? → lease/exception/worker หยุด
          needs_review? → อ่าน reason ไม่ retry มั่ว
```

## Log ที่ดีต้องตอบคำถามได้

ตัวอย่าง worker เขียนชนิด exception ไม่เขียน payload ทั้งฉบับ แต่ log ขั้นต่ำนี้ยังไม่ใช่ observability เต็มระบบ ถ้าต่อยอดให้เพิ่ม task_id, attempt, duration และ error_code โดยหลีกเลี่ยง token, document_text และข้อมูลระบุตัวบุคคล

```json
{"task_id": 12, "attempt": 2, "stage": "provider", "error_code": "timeout"}
```

นี่เป็นตัวอย่างรูปแบบที่ควรเพิ่ม ไม่ใช่คำกล่าวว่า worker เวอร์ชันนี้มีทุก field แล้ว `task_id` ทำหน้าที่ correlation ระหว่าง request, worker และ audit ส่วน log level ช่วยแยกข้อมูลทั่วไปกับสิ่งที่ต้องตรวจ

## Count กับอายุงานบอกคนละอย่าง

`/summary` มีจำนวน event, จำนวน tasks แยก state และ pending reviews แต่ยังไม่มี latency histogram หรือ oldest queued age ถ้ามี queued 10 งาน อาจปกติเมื่อเพิ่งส่งเข้า หรือผิดปกติเมื่อค้างหลายชั่วโมง ต้องดูอายุร่วมด้วย

```sql
SELECT state, COUNT(*) AS total, MIN(created) AS oldest_created
FROM tasks
GROUP BY state;
```

`MIN(created)` คือเวลาเก่าที่สุด ไม่ใช่จำนวนวินาทีที่รอโดยตัวมันเอง ต้องเทียบกับเวลาปัจจุบัน และไม่ควรสับสนเวลาสร้าง task กับเวลาของ retry รอบล่าสุด

## วัดผลลดเวลางานอย่างซื่อสัตย์

กำหนดงานและจำนวนเอกสารให้เหมือนกันก่อนวัด:

```text
เวลาที่ลดได้ = เวลา manual เดิม
             - (เวลาคนเตรียม input + เวลารอตามนิยาม + เวลาคนตรวจแก้)
```

แยก machine elapsed time กับ human active time เพราะ workflow รัน 10 นาทีไม่ได้แปลว่าคนเสียเวลา 10 นาที และอย่าใช้เวลาของ mock provider อ้างความเร็วของโมเดลจริง เก็บ sample size, วันที่, failure rate, review rate และเงื่อนไขที่วัดในรายงานเสมอ

เมื่อพบ bug ให้บันทึก input สังเคราะห์ที่ทำซ้ำได้, expected/actual, task ID, version และ test ที่เพิ่ม นี่มีประโยชน์ต่อทีมมากกว่าคำว่า “บางครั้งไม่ทำงาน”
