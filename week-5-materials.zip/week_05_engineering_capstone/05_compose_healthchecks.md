# 05 — Compose และ Healthchecks: เปิดครบไม่เท่ากับพร้อมใช้

## Compose ช่วยจัดอะไร

แทนที่จะจำคำสั่งรัน API, worker, network และ volume หลายชุด เราเขียนความสัมพันธ์ใน [compose.yaml](capstone/compose.yaml) ชื่อ service ทำหน้าที่เป็นชื่อเรียกภายใน network ด้วย แต่ Compose ไม่ได้แทน business workflow: ลำดับการวิเคราะห์ resume ยังอยู่ใน service/worker ไม่ใช่ใน YAML

```powershell
docker compose config --quiet
docker compose up --build -d api worker
docker compose ps
docker compose logs --tail 50 api worker
```

`--build` สร้าง image ก่อนเริ่ม, `-d` รันเบื้องหลัง ส่วน `ps` แสดงสถานะ service คำสั่งนี้ต้องรันจาก folder `capstone` ที่มี Compose อยู่ ถ้า Docker Engine ยังไม่เปิด ให้เปิด Docker Desktop และรอพร้อมก่อน ไม่ใช่ติดตั้ง package Python เพิ่มเพื่อแก้ปัญหา daemon

## Running, healthy และ business success

```text
container running
   ↓ process เริ่มแล้ว แต่ DB อาจยังไม่พร้อม
healthcheck ผ่าน
   ↓ API ตอบและ query DB ได้
task succeeded
   ↓ งานหนึ่งผ่านเงื่อนไขการประมวลผล
human decision
     คนตรวจและตัดสินแยกอีกขั้น
```

ตัวอย่าง `/health` query DB ได้จึงตอบ ok แต่ไม่ได้พิสูจน์ว่า worker ยังเดินงานอยู่หรือ provider ภายนอกใช้งานได้ ต้องดู backlog และอายุงานเพิ่ม การมี healthcheck เป็นแค่สัญญาณหนึ่ง

## `depends_on` ไม่ใช่ระบบกู้คืนทั้งหมด

worker ใช้ `condition: service_healthy` เพื่อเริ่มหลัง API healthcheck ผ่าน ช่วยตอน startup แต่ไม่ได้รับประกันว่า API จะไม่ล่มหลังจากนั้น หรือ worker จะกลับมาประมวลผลถูกต้องเสมอ ต้องออกแบบ reconnect/retry และ durable state อยู่ดี [Docker startup order](https://docs.docker.com/compose/how-tos/startup-order/)

`restart: unless-stopped` ช่วยเริ่ม process ใหม่ในสถานการณ์ที่นโยบายครอบคลุม แต่ไม่รู้ว่า “ส่งอีเมลไปแล้วหรือยัง” นั่นเป็นเหตุผลที่บทถัดไปเก็บ task, lease และผลลัพธ์ใน DB

## n8n เป็นทางเลือก ไม่ใช่เงื่อนไขก่อนรันระบบ

Compose มี profile `automation` แยกไว้ ไม่เปิดโดย default ตั้ง `N8N_IMAGE` เป็นเวอร์ชันที่คุณตรวจและอนุมัติก่อนเปิด profile; lab ไม่รับรอง tag ว่าเหมาะเปิด public หาก port 5678 ถูกใช้โดย n8n เดิม อย่าหยุดของเดิมเพื่อรันบทเรียน ให้ใช้ native workflow กับ API host แทนหรือเลือก host port ใหม่ในสำเนา config

ก่อนจบบท ทดลองอ่าน YAML แล้วบอกว่า API กับ worker แชร์อะไร และไม่ได้แชร์อะไร: แชร์ volume/database แต่ไม่ได้แชร์ตัวแปร Python ใน memory เพราะเป็นคนละ process

## อ่าน YAML แบบคนเพิ่งเริ่ม

YAML ใช้การเยื้องบรรทัดบอกความเป็นลูกของข้อมูล ไม่ใช่แค่จัดให้สวย ใช้ spaces ตามไฟล์เดิม ไม่ใช้ tab สลับกัน ส่วน `-` เริ่มสมาชิกใน list:

```yaml
services:
  api:
    build: .
    ports:
      - "127.0.0.1:8015:8015"
```

อ่านว่า services มี service ชื่อ api; api ให้ build จาก directory ปัจจุบัน และมี ports หนึ่งรายการ ถ้าวาง `ports` ผิดระดับ ความหมายก็เปลี่ยนหรือ config ตรวจไม่ผ่านได้ `api` เป็น service name ที่เราเลือก ไม่ใช่ keyword บังคับของ Docker

## เดินตาม startup ของไฟล์เรา

```text
Compose อ่าน config
    ↓ build image สำหรับ api/worker
เปิด API → ตรวจ /health ตามรอบ
    ↓ API healthy
เปิด worker → worker อ่าน DB เดียวกัน
```

API healthcheck ใช้ Python ใน container เรียก `/health` ของตัวเอง ไม่ต้องติดตั้ง curl เพิ่ม `interval: 5s` คือช่วงตรวจ, `timeout: 3s` คือเวลาสูงสุดของการตรวจหนึ่งรอบ, `retries: 10` คือจำนวน failure ต่อเนื่องที่ใช้ตัดสิน unhealthy ส่วน `start_period` ให้ช่วงเริ่มต้นก่อนนับ failures ตามกติกา healthcheck ไม่ใช่การสั่งพัก startup ทุก service 10 วินาทีตายตัว

Container ที่ unhealthy ไม่ได้ถูก restart โดยนโยบาย `unless-stopped` เพียงเพราะสถานะสุขภาพเปลี่ยน นโยบาย restart เน้นการออกของ process; ต้องตรวจสาเหตุ ไม่เพิ่ม retries เพื่อซ่อนปัญหา

## Lab — เปิดระบบและตรวจทีละชั้น

หยุด native API/worker ของ lab ก่อนเพื่อไม่ชน port ไม่หยุด service อื่นของคุณโดยเดา จาก capstone:

```powershell
docker compose config --quiet
docker compose up --build -d api worker
docker compose ps
Invoke-RestMethod http://127.0.0.1:8015/health
```

ขั้นแรกหากผ่านอาจไม่มีข้อความ ให้ตรวจ `$LASTEXITCODE` หลังคำสั่งซึ่งควรเป็น 0 ขั้นสองมีข้อความ build/start ที่เปลี่ยนตามเครื่อง ขั้นสามควรเห็น API running/healthy และ worker running ขั้นสี่ควรได้ `status: ok`, `scope: week5-local-synthetic`, `provider: mock` หากมี service อื่นตอบอยู่ที่ port นี้ scope จะช่วยให้ไม่ทดสอบผิดระบบ

```powershell
python demo.py transaction
docker compose logs --tail 50 worker
```

`demo.py` รันบน host จึงยังต้องมี Python dependencies ตาม README และจะติดตามผล task ให้ ถ้าอยู่ queued ให้ตรวจ worker; ถ้า intake ตอบ 422 ให้ตรวจ input; ถ้า connection refused ให้ตรวจ API/port ก่อน อย่าเริ่มจากลบ volume

## หยุด เริ่มใหม่ และใช้ configuration ใหม่ต่างกัน

| คำสั่ง | ใช้เมื่อ |
|---|---|
| `docker compose stop api worker` | หยุด lab แต่เก็บ containers/data |
| `docker compose start api worker` | เริ่ม containers ที่หยุดไว้ |
| `docker compose restart api worker` | restart process ของ containers เดิม ไม่ rebuild source |
| `docker compose up --build -d api worker` | สร้าง image ใหม่และให้ Compose ปรับ containers ตาม source/config |

ถ้าแก้ `.env` อย่าคาดว่า restart จะรับ config ใหม่เสมอ ใช้เส้นทาง recreate ผ่าน `up` ตาม config ที่ตรวจแล้ว และระวัง environment ใน shell ที่อาจมีค่า override อยู่ [Compose up reference](https://docs.docker.com/reference/cli/docker/compose/up/)

ครั้งแรกยังไม่ต้องเปิด n8n profile ให้ API/worker ผ่านก่อน Review endpoints อาจตอบ 503 หากยังไม่ได้ตั้ง token แต่ไม่ได้หมายความว่า intake API ใช้งานไม่ได้ อ่านขั้นตั้ง token แยกใน README; อย่าแก้ authorize ให้อนุญาตทุกคนเพื่อให้ demo ผ่าน
