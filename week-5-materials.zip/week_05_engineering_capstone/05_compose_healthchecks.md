# 05 — Compose และ Healthchecks: เปิดครบไม่เท่ากับพร้อมใช้

## Compose ช่วยจัดอะไร

แทนที่จะจำคำสั่งรัน API, worker, network และ volume หลายชุด เราเขียนความสัมพันธ์ใน [compose.yaml](capstone/compose.yaml) ชื่อ service ทำหน้าที่เป็นชื่อเรียกภายใน network ด้วย แต่ Compose ไม่ได้แทน business workflow: ลำดับการวิเคราะห์ resume ยังอยู่ใน service/worker ไม่ใช่ใน YAML

```powershell
docker compose config --quiet
docker compose up --build -d api worker
docker compose ps
docker compose logs --tail 50 api worker
```

`--build` สร้าง image ก่อนเริ่ม, `-d` รันเบื้องหลัง ส่วน `ps` แสดงสถานะ service คำสั่งนี้ต้องรันจาก folder `capstone` ที่มี Compose อยู่ ถ้า Docker Engine ยังไม่เปิด ให้เปิด Docker Desktop และรอพร้อมก่อน ไม่ใช่ติดตั้ง package Python เพิ่มเพื่อแก้ปัญหา daemon

## Running, healthy และ business success

```text
container running
   ↓ process เริ่มแล้ว แต่ DB อาจยังไม่พร้อม
healthcheck ผ่าน
   ↓ API ตอบและ query DB ได้
task succeeded
   ↓ งานหนึ่งผ่านเงื่อนไขการประมวลผล
human decision
     คนตรวจและตัดสินแยกอีกขั้น
```

ตัวอย่าง `/health` query DB ได้จึงตอบ ok แต่ไม่ได้พิสูจน์ว่า worker ยังเดินงานอยู่หรือ provider ภายนอกใช้งานได้ ต้องดู backlog และอายุงานเพิ่ม การมี healthcheck เป็นแค่สัญญาณหนึ่ง

## `depends_on` ไม่ใช่ระบบกู้คืนทั้งหมด

worker ใช้ `condition: service_healthy` เพื่อเริ่มหลัง API healthcheck ผ่าน ช่วยตอน startup แต่ไม่ได้รับประกันว่า API จะไม่ล่มหลังจากนั้น หรือ worker จะกลับมาประมวลผลถูกต้องเสมอ ต้องออกแบบ reconnect/retry และ durable state อยู่ดี [Docker startup order](https://docs.docker.com/compose/how-tos/startup-order/)

`restart: unless-stopped` ช่วยเริ่ม process ใหม่ในสถานการณ์ที่นโยบายครอบคลุม แต่ไม่รู้ว่า “ส่งอีเมลไปแล้วหรือยัง” นั่นเป็นเหตุผลที่บทถัดไปเก็บ task, lease และผลลัพธ์ใน DB

## n8n เป็นทางเลือก ไม่ใช่เงื่อนไขก่อนรันระบบ

Compose มี profile `automation` แยกไว้ ไม่เปิดโดย default ตั้ง `N8N_IMAGE` เป็นเวอร์ชันที่คุณตรวจและอนุมัติก่อนเปิด profile; lab ไม่รับรอง tag ว่าเหมาะเปิด public หาก port 5678 ถูกใช้โดย n8n เดิม อย่าหยุดของเดิมเพื่อรันบทเรียน ให้ใช้ native workflow กับ API host แทนหรือเลือก host port ใหม่ในสำเนา config

ก่อนจบบท ทดลองอ่าน YAML แล้วบอกว่า API กับ worker แชร์อะไร และไม่ได้แชร์อะไร: แชร์ volume/database แต่ไม่ได้แชร์ตัวแปร Python ใน memory เพราะเป็นคนละ process
