# 13 — HR Capstone: ช่วยอ่านเอกสารโดยไม่ตัดสินคนแทน HR

## งานที่ช่วยลดเวลา

เป้าหมายคือดึงข้อความและจัดข้ออ้างเกี่ยวกับทักษะพร้อมหลักฐานให้คนตรวจเร็วขึ้น ไม่ใช่จัดอันดับผู้สมัครหรือปฏิเสธคนอัตโนมัติ ตัวอย่างไม่ใช้ชื่อ อายุ เพศ หรือภาพถ่ายในการตัดสิน และใช้เอกสารสังเคราะห์เท่านั้น

```text
ข้อความ / local PDF-DOCX ที่เชื่อถือได้
    ↓ extract text (CLI ถ้าเป็นไฟล์)
POST /resumes → text hash + processing version → task
    ↓ worker mock extraction
claim + exact quote → ตรวจ schema/evidence → human review
```

## เริ่มจากข้อความก่อน

```json
{"candidate_id":"C1","document_text":"Built a Python ETL project.","processing_version":"v1","mode":"normal"}
```

รัน `python demo.py hr` แล้วดู result จะมี skill และ quote ที่พบจริงในข้อความ Mock ใช้ pattern จำกัด เช่นประโยค `Built a Python ... .` จึงไม่ใช่ระบบเข้าใจ resume ทั่วไป หากข้อความจริงใช้สำนวนอื่นแล้วได้ claims ว่าง ไม่ได้แปลว่าผู้สมัครไม่มีทักษะ ต้องดูเอกสารและการออกแบบ extraction เพิ่ม

## Evidence validation ช่วยอะไรและไม่ช่วยอะไร

ตรวจว่า quote อยู่ใน document_text และชื่อ skill อยู่ใน quote พร้อม guard บางกรณี แต่เป็น **lexical validation** ไม่พิสูจน์ว่าผู้สมัครทำงานนั้นจริง หรือประโยคมีบริบทสนับสนุนทักษะนั้นทั้งหมด แม้ quote ตรงก็อาจเป็นการเล่าของคนอื่นหรือการปฏิเสธที่ guard ยังไม่ครอบคลุม จึงส่ง HR tasks เข้า human review เสมอ

```text
JSON ถูกต้อง ≠ ข้อมูลจริง
quote มีในเอกสาร ≠ ตีความถูกครบ
ผ่าน validation ≠ ผ่านการคัดเลือก
```

## เทียบ Job Requirements แบบไม่ตัดสินคน

ส่ง `job_requirements` เช่น `["Python", "Docker"]` และ `job_version: "demo-v2"` เพิ่มใน payload ได้ ก่อนเทียบผล AI ต้องผ่าน Pydantic `ResumeOutput` แล้วจึงตรวจ evidence ผลจับคู่คืน `evidence_found` เมื่อ skill ตรงแบบไม่สนตัวพิมพ์ใหญ่เล็ก พร้อม quote; ถ้าไม่พบจะคืน `not_evidenced` และ evidence ว่าง **ไม่ใช่ unqualified** และไม่มีคะแนนจัดอันดับ

```text
requirements: Python, Docker
claims ที่ผ่าน: Python + quote
       ↓
Python → evidence_found → quote ให้ HR อ่าน
Docker → not_evidenced  → ให้ตรวจเพิ่ม ไม่ปฏิเสธคน
```

ค่าเริ่มต้นคือ Python/SQL และ job version demo-v1 หากเปลี่ยนเกณฑ์แต่ใช้ identity เดิมจะได้ 409 ให้ตั้ง job version ใหม่เพื่อเก็บผลการประเมินแต่ละเกณฑ์แยกกัน การจับคู่รุ่นนี้ไม่รู้ synonyms เช่น py/python หรือระดับประสบการณ์ เป็นเพียง baseline ที่ทดสอบง่าย

## อ่าน PDF/DOCX แบบ local — วิธีเรียก

`python -m course.ingest_file --candidate-id C1 --file path/to/synthetic.pdf` สกัดข้อความก่อนส่ง API รองรับไฟล์หลายรายการสำหรับ candidate เดียวด้วยการใส่ `--file` ซ้ำ ต้องแยกคำสั่งหากเป็นคนละ candidate เพื่อไม่จับข้อมูลผิดคน

มี [Synthetic Resume PDF](capstone/fixtures/synthetic_resume.pdf) และ [Empty PDF](capstone/fixtures/empty_document.pdf) จากชุด Week 4 ให้ทดสอบ parser ใช้ `fixtures/synthetic_resume.pdf` เมื่อรันใน folder capstone ไฟล์ตัวอย่างไม่จำเป็นต้องมีสำนวนตรงกับ mock extractor ทุกประโยค จึงต้องแยก “ดึงข้อความได้” จาก “สกัด claims ได้”

PDF ที่เป็นภาพสแกนต้องมี OCR ซึ่งยังไม่รวมใน lab หากดึงข้อความไม่ได้ CLI จะรายงาน error ไม่ส่งข้อความว่างไป AI DOCX อ่าน paragraph และ table บางรูปแบบ ไม่รับรอง textbox/header หรือการอ่านทุก layout ไฟล์ untrusted ต้องมี sandbox และขีดจำกัดทรัพยากรเพิ่ม ไม่ใช้ parser นี้เป็น upload service สาธารณะ

## File hash กับ text hash อย่าสับสน

CLI แสดง SHA-256 ของ bytes ไฟล์เพื่อช่วยตรวจไฟล์ในเครื่อง แต่ API ปัจจุบันเก็บ key จาก **ข้อความที่สกัด** ไม่ได้เก็บ hash ไฟล์นั้นใน record ดังนั้น version นี้ยังไม่ใช่ end-to-end file provenance หากต้องตรวจกลับถึงไฟล์ต้นทางต้องเพิ่ม source record, file hash, parser version และ access control ก่อน

## ลำดับต่อยอดที่แนะนำ

Core: text intake + evidence + durable review ให้ผ่านก่อน ต่อด้วย local parser smoke tests แล้วจึงทำ manifest ต่อ candidate, file provenance, OCR queue, batch dashboard และ provider ที่อนุมัติ ขั้น batch resume หลักพันยังไม่ได้รับการ load test และไม่ควรใช้จำนวน test fixtures อ้างความพร้อมระดับนั้น

## Lab — อ่านผล extraction โดยไม่เปิด API ก่อน

```powershell
python learning_walkthrough.py hr
python learning_walkthrough.py hr --mode hallucination
```

รอบ normal ใช้ข้อความ `Built a Python ETL project.` กับ requirements Python/Docker จึงควรได้ evidence_found สำหรับ Python และ not_evidenced สำหรับ Docker รอบ hallucination mock จะอ้าง Rust พร้อม quote ที่ไม่มีในเอกสาร ต้องเป็น needs_review และไม่มี validated output ให้ใช้ต่อ

```text
document_text → ข้อความต้นทาง
claim         → สิ่งที่ระบบอ้าง เช่นมีทักษะ Python
quote         → ข้อความหลักฐานที่อ้างถึง
match         → เทียบ claim กับ requirement ที่กำหนด
```

อย่าอ่าน `not_evidenced` ว่า “ทำไม่ได้” เพราะ parser อาจอ่านไม่ครบ, mock ไม่รู้สำนวนอื่น หรือ resume ไม่ได้เขียนทักษะนั้นไว้ การถามคน/ตรวจเพิ่มเป็นอีกขั้นหนึ่ง

## ส่ง request ผ่าน HTTP ด้วยตัวเอง

หลังเปิด API/worker ตาม README ใน terminal client:

```powershell
$resumeBody = @{ candidate_id="C-lesson13-01"; document_text="Built a Python ETL project."; job_requirements=@("Python","Docker"); job_version="learning-v1" } | ConvertTo-Json
$accepted = Invoke-RestMethod http://127.0.0.1:8015/resumes -Method Post -ContentType "application/json" -Body $resumeBody
Invoke-RestMethod "http://127.0.0.1:8015/tasks/$($accepted.task_id)" | ConvertTo-Json -Depth 10
```

`@("Python","Docker")` เป็น array ใน PowerShell ต่างจาก `@{...}` ที่เป็น hashtable API รับ JSON แล้ว Pydantic ตรวจชนิดข้อมูลก่อนบันทึก หากเปลี่ยนเกณฑ์สำหรับข้อความ/คนเดิม ให้เปลี่ยน job_version ตามบทเดิมเพื่อไม่ชน identity ของการประเมินครั้งก่อน

## จากไฟล์ไปข้อความต้องผ่านอีกขั้น

```powershell
python -m course.ingest_file --candidate-id C-file-demo --file fixtures/synthetic_resume.pdf
```

คำสั่งนี้ต้องมี API เปิดอยู่ เพราะ CLI อ่านไฟล์ในเครื่องแล้ว POST ข้อความ ไม่ได้บันทึก DB โดยตรง ควรได้ file_hash และ task_id เมื่อ intake สำเร็จ จากนั้นยังต้องตรวจ task และ review ไม่จบที่การอ่าน PDF ผ่าน

ตัวอย่าง Empty PDF ควรรายงาน local_ingest_error ไม่ควรส่งข้อความว่างไปให้ AI เติมเอง หาก CLI error ให้ตรวจชนิดไฟล์/ขนาด/อ่านข้อความได้หรือไม่ก่อนตรวจ provider และ note ว่า CLI รายงานชนิด exception แบบย่อ จึงต้อง debug เพิ่มอย่างระวังโดยไม่ log resume จริง

## อ่าน JSON ที่ซ้อนกันอย่างไร

เริ่มจาก `state` ก่อน หาก succeeded ค่อยอ่าน `result.claims` และ `result.requirement_matches` ถ้า needs_review/failed ให้ดู reason และไม่สมมติว่ามี claims เสมอ การเรียก `result['claims']` โดยไม่ตรวจ state อาจเกิด KeyError ซึ่งไม่ใช่ปัญหา AI แต่เป็นการอ่าน contract ผิดทาง

จุดตรวจ: ยกตัวอย่างได้หนึ่งกรณีที่ JSON ถูก schema แต่ evidence ผิด และหนึ่งกรณีที่ evidence อยู่จริงแต่ยังต้องให้คนตรวจความหมาย
