# 13 — HR Capstone: ช่วยอ่านเอกสารโดยไม่ตัดสินคนแทน HR

## งานที่ช่วยลดเวลา

เป้าหมายคือดึงข้อความและจัดข้ออ้างเกี่ยวกับทักษะพร้อมหลักฐานให้คนตรวจเร็วขึ้น ไม่ใช่จัดอันดับผู้สมัครหรือปฏิเสธคนอัตโนมัติ ตัวอย่างไม่ใช้ชื่อ อายุ เพศ หรือภาพถ่ายในการตัดสิน และใช้เอกสารสังเคราะห์เท่านั้น

```text
ข้อความ / local PDF-DOCX ที่เชื่อถือได้
    ↓ extract text (CLI ถ้าเป็นไฟล์)
POST /resumes → text hash + processing version → task
    ↓ worker mock extraction
claim + exact quote → ตรวจ schema/evidence → human review
```

## เริ่มจากข้อความก่อน

```json
{"candidate_id":"C1","document_text":"Built a Python ETL project.","processing_version":"v1","mode":"normal"}
```

รัน `python demo.py hr` แล้วดู result จะมี skill และ quote ที่พบจริงในข้อความ Mock ใช้ pattern จำกัด เช่นประโยค `Built a Python ... .` จึงไม่ใช่ระบบเข้าใจ resume ทั่วไป หากข้อความจริงใช้สำนวนอื่นแล้วได้ claims ว่าง ไม่ได้แปลว่าผู้สมัครไม่มีทักษะ ต้องดูเอกสารและการออกแบบ extraction เพิ่ม

## Evidence validation ช่วยอะไรและไม่ช่วยอะไร

ตรวจว่า quote อยู่ใน document_text และชื่อ skill อยู่ใน quote พร้อม guard บางกรณี แต่เป็น **lexical validation** ไม่พิสูจน์ว่าผู้สมัครทำงานนั้นจริง หรือประโยคมีบริบทสนับสนุนทักษะนั้นทั้งหมด แม้ quote ตรงก็อาจเป็นการเล่าของคนอื่นหรือการปฏิเสธที่ guard ยังไม่ครอบคลุม จึงส่ง HR tasks เข้า human review เสมอ

```text
JSON ถูกต้อง ≠ ข้อมูลจริง
quote มีในเอกสาร ≠ ตีความถูกครบ
ผ่าน validation ≠ ผ่านการคัดเลือก
```

## เทียบ Job Requirements แบบไม่ตัดสินคน

ส่ง `job_requirements` เช่น `["Python", "Docker"]` และ `job_version: "demo-v2"` เพิ่มใน payload ได้ ก่อนเทียบผล AI ต้องผ่าน Pydantic `ResumeOutput` แล้วจึงตรวจ evidence ผลจับคู่คืน `evidence_found` เมื่อ skill ตรงแบบไม่สนตัวพิมพ์ใหญ่เล็ก พร้อม quote; ถ้าไม่พบจะคืน `not_evidenced` และ evidence ว่าง **ไม่ใช่ unqualified** และไม่มีคะแนนจัดอันดับ

```text
requirements: Python, Docker
claims ที่ผ่าน: Python + quote
       ↓
Python → evidence_found → quote ให้ HR อ่าน
Docker → not_evidenced  → ให้ตรวจเพิ่ม ไม่ปฏิเสธคน
```

ค่าเริ่มต้นคือ Python/SQL และ job version demo-v1 หากเปลี่ยนเกณฑ์แต่ใช้ identity เดิมจะได้ 409 ให้ตั้ง job version ใหม่เพื่อเก็บผลการประเมินแต่ละเกณฑ์แยกกัน การจับคู่รุ่นนี้ไม่รู้ synonyms เช่น py/python หรือระดับประสบการณ์ เป็นเพียง baseline ที่ทดสอบง่าย

## อ่าน PDF/DOCX แบบ local — วิธีเรียก

`python -m course.ingest_file --candidate-id C1 --file path/to/synthetic.pdf` สกัดข้อความก่อนส่ง API รองรับไฟล์หลายรายการสำหรับ candidate เดียวด้วยการใส่ `--file` ซ้ำ ต้องแยกคำสั่งหากเป็นคนละ candidate เพื่อไม่จับข้อมูลผิดคน

มี [Synthetic Resume PDF](capstone/fixtures/synthetic_resume.pdf) และ [Empty PDF](capstone/fixtures/empty_document.pdf) จากชุด Week 4 ให้ทดสอบ parser ใช้ `fixtures/synthetic_resume.pdf` เมื่อรันใน folder capstone ไฟล์ตัวอย่างไม่จำเป็นต้องมีสำนวนตรงกับ mock extractor ทุกประโยค จึงต้องแยก “ดึงข้อความได้” จาก “สกัด claims ได้”

PDF ที่เป็นภาพสแกนต้องมี OCR ซึ่งยังไม่รวมใน lab หากดึงข้อความไม่ได้ CLI จะรายงาน error ไม่ส่งข้อความว่างไป AI DOCX อ่าน paragraph และ table บางรูปแบบ ไม่รับรอง textbox/header หรือการอ่านทุก layout ไฟล์ untrusted ต้องมี sandbox และขีดจำกัดทรัพยากรเพิ่ม ไม่ใช้ parser นี้เป็น upload service สาธารณะ

## File hash กับ text hash อย่าสับสน

CLI แสดง SHA-256 ของ bytes ไฟล์เพื่อช่วยตรวจไฟล์ในเครื่อง แต่ API ปัจจุบันเก็บ key จาก **ข้อความที่สกัด** ไม่ได้เก็บ hash ไฟล์นั้นใน record ดังนั้น version นี้ยังไม่ใช่ end-to-end file provenance หากต้องตรวจกลับถึงไฟล์ต้นทางต้องเพิ่ม source record, file hash, parser version และ access control ก่อน

## ลำดับต่อยอดที่แนะนำ

Core: text intake + evidence + durable review ให้ผ่านก่อน ต่อด้วย local parser smoke tests แล้วจึงทำ manifest ต่อ candidate, file provenance, OCR queue, batch dashboard และ provider ที่อนุมัติ ขั้น batch resume หลักพันยังไม่ได้รับการ load test และไม่ควรใช้จำนวน test fixtures อ้างความพร้อมระดับนั้น
