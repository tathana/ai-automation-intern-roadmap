# Week 5 — Git, Docker, Clean Code, Documentation และ Capstone

สัปดาห์นี้นำงาน Week 1–4 มาประกอบเป็นระบบที่ **รันซ้ำได้ ตรวจปัญหาได้ และส่งต่อให้คนอื่นได้** ไม่ใช่การแข่งขันเพิ่มเครื่องมือให้ครบทุกชื่อ เป้าหมายคืออธิบายได้ว่าแต่ละส่วนทำหน้าที่อะไร และเมื่อส่วนหนึ่งพัง ข้อมูลจะเป็นอย่างไร

## เรียนแบบไหนจึงไม่หนักเกินไป

อ่านบท 00–02 ก่อน แล้วรัน Capstone แบบ native ตาม README เพื่อเห็นผลโดยยังไม่ต้องเข้าใจ Docker ทั้งหมด จากนั้นเรียนบท 03–08 พร้อมทดลองระบบเดิม สุดท้ายใช้บท 09–14 ทำ release และส่งมอบ บท 15–16 ใช้ทบทวนภาพรวมแบบ visual/easy walkthrough ไม่ต้องพิมพ์ทุกไฟล์ใหม่ แต่ควรแก้โจทย์เล็ก ๆ ด้วยตัวเองและอธิบาย diff ที่เปลี่ยนได้

| วัน | เนื้อหาหลัก | สิ่งที่ต้องได้ |
|---|---|---|
| 1 | 00–02: architecture, clean code, Git | รัน tests ได้ และทำ feature branch หนึ่งงาน |
| 2 | 03–05: Docker และ Compose | แยก host/container ได้ อ่าน config ก่อนสั่งรัน |
| 3 | 06–08: durable state, worker, review | ทดลอง duplicate, retry และ stale worker |
| 4 | 09–11: tests, logs, handoff | มีหลักฐาน failure cases และคู่มือรัน |
| 5 | 12: Transaction Capstone | demo กฎ anomaly และงานตรวจทาน |
| 6 | 13: HR Capstone + ReleaseGuard | ตรวจ evidence และซ่อมระบบที่เสีย |
| 7 | 14: release rehearsal | ให้ผู้อื่นทำตาม README พร้อมบันทึกข้อจำกัด |

ถ้าเวลาจำกัด เลือก Transaction เป็นเส้นหลัก แล้วทำ HR ด้วยข้อมูลข้อความสังเคราะห์ก่อน ส่วน OCR, production auth, external notifications และ distributed queue เป็นงานต่อยอด ไม่ใช่เงื่อนไขที่ต้องทำหมดก่อนเริ่มฝึกงาน

## เส้นทางของระบบตัวอย่าง

```text
n8n / Python client
        ↓ ส่งข้อมูลสังเคราะห์
API → validate → บันทึก event + task ใน SQLite
        ↓ HTTP 202 + task_id
worker → claim งาน → mock AI → validate output
        ↓
ผลลัพธ์ + audit + review queue ในฐานข้อมูล
        ↓
คนอ่านหลักฐาน → บันทึก decision แยกจากผล AI
```

202 หมายถึงรับงานแล้ว ไม่ได้หมายถึงประมวลผลเสร็จ และ `succeeded` ของงาน HR หมายถึงผ่านการประมวลผลทางเทคนิค ไม่ใช่ผู้สมัครผ่านการคัดเลือก

## ชุดลงมือทำ

- [Capstone README และคำสั่งเริ่มต้น](capstone/README.md)
- [Drills 6 ชุด](drills/README.md)
- [ReleaseGuard Challenge](challenge_releaseguard/README.md)
- [Verification และขอบเขตที่ยังไม่ทดสอบ](VERIFICATION.md)
- [เทียบกับ Premium Roadmap เดิมและงานต่อยอด](ROADMAP_COVERAGE.md)

ไฟล์ดาวน์โหลดรวม source, tests, Dockerfile, Compose และ workflow ตัวอย่าง เว็บ Vercel **แสดงหนังสือเท่านั้น** ไม่ได้เปิด API, worker หรือ n8n ให้ใช้งานออนไลน์ ห้ามใส่ข้อมูลผู้สมัครจริงหรือข้อมูลธุรกรรมจริงใน lab นี้

## เส้นทางสำหรับคนเริ่ม Week 5 ครั้งแรก

แต่ละบทมีส่วนลงมือทำเพิ่มจากเนื้อหาเดิม ให้เริ่มจากคำอธิบาย → ทาย output → รัน → ตรวจผล → ลองกรณีผิด อย่าข้ามขั้นเลือก environment และ directory เพราะเป็นสาเหตุของปัญหาหลายอย่างที่ดูคล้าย bug ในโค้ด

1. บท 00 เตรียม Python environment ให้ tests ผ่านก่อน
2. บท 01 ฝึกแยกไฟล์ด้วยตัวอย่างเล็ก ไม่ย้าย Capstone เดิม
3. บท 02 ทำ Git ใน repo ฝึกใหม่; บท 03–05 ค่อยเรียน Docker เมื่อ Engine พร้อม
4. บท 06–08 ใช้ `learning_walkthrough.py` เห็น state/retry/review ใน terminal เดียว
5. บท 09–11 ฝึกอ่าน tests, audit และเขียนคู่มือ
6. บท 12–13 เปลี่ยนจาก walkthrough เป็น HTTP API/worker ตาม README
7. บท 14 ซ้อมส่งมอบพร้อมหลักฐาน ไม่อ้าง mock เป็นระบบ production

ตัวอย่างใหม่สำหรับทดลอง state/retry/lease/review/transaction/HR อยู่ใน [learning_walkthrough.py](capstone/learning_walkthrough.py) ใช้ temporary database ที่ถูกลบเมื่อจบ ไม่ต้องเปิด Docker หรือ server หากยังไม่พร้อม และไม่ใช้ credentials จริง

หาก Docker, durable worker และ handoff ยังดูเป็นหลายเรื่องแยกกัน ให้เปิด [16 — Easy Walkthrough](16_easy_walkthrough.md) เพื่อไล่จาก project structure ไปจนถึง runbook ด้วย request/task เดียว
