# Week 5 — Git, Docker, Clean Code, Documentation และ Capstone

สัปดาห์นี้นำงาน Week 1–4 มาประกอบเป็นระบบที่ **รันซ้ำได้ ตรวจปัญหาได้ และส่งต่อให้คนอื่นได้** ไม่ใช่การแข่งขันเพิ่มเครื่องมือให้ครบทุกชื่อ เป้าหมายคืออธิบายได้ว่าแต่ละส่วนทำหน้าที่อะไร และเมื่อส่วนหนึ่งพัง ข้อมูลจะเป็นอย่างไร

## เรียนแบบไหนจึงไม่หนักเกินไป

อ่านบท 00–02 ก่อน แล้วรัน Capstone แบบ native ตาม README เพื่อเห็นผลโดยยังไม่ต้องเข้าใจ Docker ทั้งหมด จากนั้นเรียนบท 03–08 พร้อมทดลองระบบเดิม สุดท้ายใช้บท 09–14 ทำ release และส่งมอบ ไม่ต้องพิมพ์ทุกไฟล์ใหม่ แต่ควรแก้โจทย์เล็ก ๆ ด้วยตัวเองและอธิบาย diff ที่เปลี่ยนได้

| วัน | เนื้อหาหลัก | สิ่งที่ต้องได้ |
|---|---|---|
| 1 | 00–02: architecture, clean code, Git | รัน tests ได้ และทำ feature branch หนึ่งงาน |
| 2 | 03–05: Docker และ Compose | แยก host/container ได้ อ่าน config ก่อนสั่งรัน |
| 3 | 06–08: durable state, worker, review | ทดลอง duplicate, retry และ stale worker |
| 4 | 09–11: tests, logs, handoff | มีหลักฐาน failure cases และคู่มือรัน |
| 5 | 12: Transaction Capstone | demo กฎ anomaly และงานตรวจทาน |
| 6 | 13: HR Capstone + ReleaseGuard | ตรวจ evidence และซ่อมระบบที่เสีย |
| 7 | 14: release rehearsal | ให้ผู้อื่นทำตาม README พร้อมบันทึกข้อจำกัด |

ถ้าเวลาจำกัด เลือก Transaction เป็นเส้นหลัก แล้วทำ HR ด้วยข้อมูลข้อความสังเคราะห์ก่อน ส่วน OCR, production auth, external notifications และ distributed queue เป็นงานต่อยอด ไม่ใช่เงื่อนไขที่ต้องทำหมดก่อนเริ่มฝึกงาน

## เส้นทางของระบบตัวอย่าง

```text
n8n / Python client
        ↓ ส่งข้อมูลสังเคราะห์
API → validate → บันทึก event + task ใน SQLite
        ↓ HTTP 202 + task_id
worker → claim งาน → mock AI → validate output
        ↓
ผลลัพธ์ + audit + review queue ในฐานข้อมูล
        ↓
คนอ่านหลักฐาน → บันทึก decision แยกจากผล AI
```

202 หมายถึงรับงานแล้ว ไม่ได้หมายถึงประมวลผลเสร็จ และ `succeeded` ของงาน HR หมายถึงผ่านการประมวลผลทางเทคนิค ไม่ใช่ผู้สมัครผ่านการคัดเลือก

## ชุดลงมือทำ

- [Capstone README และคำสั่งเริ่มต้น](capstone/README.md)
- [Drills 6 ชุด](drills/README.md)
- [ReleaseGuard Challenge](challenge_releaseguard/README.md)
- [Verification และขอบเขตที่ยังไม่ทดสอบ](VERIFICATION.md)
- [เทียบกับ Premium Roadmap เดิมและงานต่อยอด](ROADMAP_COVERAGE.md)

ไฟล์ดาวน์โหลดรวม source, tests, Dockerfile, Compose และ workflow ตัวอย่าง เว็บ Vercel **แสดงหนังสือเท่านั้น** ไม่ได้เปิด API, worker หรือ n8n ให้ใช้งานออนไลน์ ห้ามใส่ข้อมูลผู้สมัครจริงหรือข้อมูลธุรกรรมจริงใน lab นี้
