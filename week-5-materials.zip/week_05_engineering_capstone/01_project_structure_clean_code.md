# 01 — Project Structure และ Clean Code ที่ช่วยให้แก้งานง่าย

## แบ่งไฟล์ตามหน้าที่ ไม่ใช่ตามจำนวนบรรทัด

ให้นึกว่า API เป็นจุดรับเรื่อง ไม่ใช่คนที่ต้องทำทุกอย่างเอง `api.py` อ่าน request และคืน response, `models.py` บอกข้อมูลที่ยอมรับ, `repository.py` ติดต่อฐานข้อมูล, `service.py` ประมวลผลงาน ส่วน `worker.py` เรียกงานต่อเนื่อง

```text
api.py ─────→ models.py  ตรวจรูปแบบ input
  ↓
repository.py           เก็บสถานะถาวร
  ↑
service.py ← worker.py  ประมวลผลเบื้องหลัง
```

เปิด [API](capstone/course/api.py) แล้วดูฟังก์ชัน `transaction()` จะเห็นว่าไม่ได้เรียก AI ทันที แต่เรียก `ingest_transaction()` แล้วคืน task ID การย้ายงานหนักออกจาก request ช่วยให้ client ไม่ต้องรอจนงานทั้งหมดเสร็จ แต่เราต้องรับผิดชอบเรื่องสถานะและการติดตามเพิ่มขึ้น

## อ่าน signature ก่อนอ่านเนื้อฟังก์ชัน

```python
def ingest_transaction(self, payload, now):
    ...
```

`self` คือ Store object ที่กำลังใช้งาน, `payload` คือ dict ที่ API ตรวจแล้ว, `now` คือเวลาที่ส่งเข้ามา การรับเวลาเป็น argument ทำให้ test ใช้เวลา 100, 101, 160 ได้โดยไม่ต้องรอจริง วิธีนี้เป็นตัวอย่างของ **dependency injection**: ส่งสิ่งที่ฟังก์ชันต้องพึ่งพาเข้ามา แทนการผูกไว้ภายในทุกจุด

```python
process_one(store, lambda: 101)
```

`lambda: 101` คือฟังก์ชันเล็ก ๆ ที่ไม่รับ argument และคืน 101 เมื่อเรียก จึงใช้แทนนาฬิกาจริงใน test ได้ ไม่ใช่การเปลี่ยนเวลาของเครื่อง

## ชื่อที่ดีช่วยลดคำอธิบาย

`amount_minor` บอกว่าเป็นหน่วยย่อยของเงิน เช่น 100000 สตางค์ = 1000 บาท ไม่ใช่ 100000 บาท ส่วน `duplicate` เป็น boolean ว่างานเคยรับหรือยัง อย่าตั้งชื่อสั้นอย่าง `x`, `v` ในจุดที่คนอ่านต้องเดาความหมาย

โค้ดตัวอย่างใน lab ยังมีส่วนเขียนกระชับเพื่อให้อ่านไฟล์ครบได้ Drill 1 ให้แยก query/constant และเพิ่ม type hints ตามความเหมาะสม โดย tests ต้องผ่านเหมือนเดิม นี่คือ **refactoring**: เปลี่ยนโครงสร้างโดยรักษาพฤติกรรมที่สังเกตได้

## เมื่อใดควรแยกฟังก์ชัน

แยกเมื่อมีหน้าที่ตั้งชื่อได้ชัด ทดสอบแยกได้ หรือถูกใช้ซ้ำ อย่าแยกทุกบรรทัดจนต้องเปิดสิบไฟล์เพื่อเข้าใจการบวกหนึ่งครั้ง เริ่มจาก pure function สำหรับกฎที่รับ input แล้วคืน output โดยไม่เขียน DB; ปล่อย transaction boundary ไว้ใน repository เพื่อไม่ให้ atomicity แตกโดยไม่ตั้งใจ

สรุป: clean code ไม่ใช่โค้ดที่สั้นที่สุด แต่เป็นโค้ดที่ผู้รับช่วงต่ออธิบายได้ว่าเปลี่ยนตรงไหนแล้วกระทบอะไร

## Workshop — จากสคริปต์ไฟล์เดียวสู่โปรเจกต์ที่เป็นระบบ

ส่วนนี้เพิ่มจากคำอธิบายเดิม เพื่อฝึกตอบว่า **“โค้ดชิ้นนี้ควรอยู่ไฟล์ไหน และทำไม?”** ไม่ต้องจำต้นไม้โฟลเดอร์ทั้งหมดก่อนเริ่มเขียน และไม่ต้องย้าย Capstone เดิมตามตัวอย่างนี้ เรามีชุดเล็กแยกให้ลองใน `examples/project_structure/` ภายใน ZIP

### 1. สิ่งนี้เรียกว่าอะไร

**Folder Structure** คือการจัดโฟลเดอร์และไฟล์ ส่วน **Project Structure / Project Layout** รวมการจัด source, tests, configuration และเอกสารด้วย ถ้าคุยถึงหน้าที่และความสัมพันธ์ของส่วนต่าง ๆ เช่น API รับเรื่องแล้วส่งให้ service นั่นเริ่มเป็นเรื่อง **Software Architecture** ซึ่งกว้างกว่าตำแหน่งไฟล์

```text
Layout:       rules.py อยู่ใน demo_app/
Responsibility: rules.py ตรวจเกณฑ์จำนวนเงิน
Architecture: main เรียก rules โดย rules ไม่ต้องรู้จัก main
```

สร้าง folder ชื่อ `services/` ไม่ได้ทำให้โค้ดแยกหน้าที่โดยอัตโนมัติ ถ้าข้างในยังรับ HTTP, query DB และเขียนไฟล์ปนกันทั้งหมด ต้องดูสิ่งที่โค้ดทำจริงประกอบด้วย

### 2. เริ่มเล็กได้: หนึ่งไฟล์ไม่ใช่ความผิด

เมื่อโจทย์ยังเล็ก เช่นอ่านจำนวนเงินแล้วบอกว่าเข้าเกณฑ์ตรวจหรือไม่ เริ่มจากไฟล์เดียวช่วยให้เห็น flow ครบ เปิด [ตัวอย่าง single_file/main.py](examples/project_structure/single_file/main.py):

```python
def needs_review(amount_minor: int) -> bool:
    return amount_minor >= 100_000


def main():
    amounts = [500, 150_000]
    for amount in amounts:
        print(amount, needs_review(amount))


if __name__ == "__main__":
    main()
```

`needs_review()` รับเงินหน่วยสตางค์และคืน boolean ไม่พิมพ์เอง ส่วน `main()` เตรียมตัวอย่าง วน loop แล้วแสดงผล การแยกหน้าที่เริ่มได้ด้วย **ฟังก์ชัน** ก่อนแยกเป็นโฟลเดอร์

```text
amount = 500    → ตรวจ >= 100000 → False → แสดงผล
amount = 150000 → ตรวจ >= 100000 → True  → แสดงผล
```

เกณฑ์นี้เป็นตัวเลขฝึก ไม่ใช่นโยบายธุรกรรมจริง ตัวอย่างสมมติว่า input เป็น integer ที่ถูกต้องแล้ว เพื่อให้โฟกัสเรื่อง layout; type hint ไม่ได้ตรวจ input ขณะรันให้เอง

### 3. เมื่อมีเหตุผล จึงย้ายกฎไปอีก module

สมมติ API, worker และ tests ต่างต้องใช้กฎเดียวกัน การ copy ฟังก์ชันไปสามแห่งทำให้แก้ threshold แล้วตกหล่นได้ เราจึงเก็บกฎไว้จุดเดียว แล้วให้ผู้ใช้กฎ import ไปเรียก

```text
split_package/                  ← project root ของตัวอย่างนี้
├── demo_app/                    ← Python package ของเรา
│   ├── __init__.py              ← เริ่มด้วยไฟล์ว่างได้
│   ├── rules.py                 ← กฎที่ใช้ซ้ำ
│   └── main.py                  ← จุดเริ่มรันตัวอย่าง
└── tests/
    └── test_rules.py            ← ตรวจผลของกฎ
```

ไฟล์ `.py` ที่ import ได้เรียกว่า **module**; กลุ่ม modules ในตัวอย่างนี้จัดเป็น regular **package** ด้วย `__init__.py` ไฟล์นี้ไม่จำเป็นต้องมี logic และไม่ควรแอบเริ่ม worker หรือเชื่อมบริการภายนอกตอน import ส่วน namespace package ที่ไม่มี `__init__.py` เป็นอีกรูปแบบหนึ่ง ยังไม่จำเป็นสำหรับ workshop นี้ [Python modules และ packages](https://docs.python.org/3/tutorial/modules.html)

ใน [rules.py](examples/project_structure/split_package/demo_app/rules.py) เหลือเฉพาะกฎ:

```python
def needs_review(amount_minor: int) -> bool:
    return amount_minor >= 100_000
```

ใน [main.py](examples/project_structure/split_package/demo_app/main.py) เปลี่ยนจากประกาศกฎเองเป็น import:

```python
from demo_app.rules import needs_review


def main():
    amounts = [500, 150_000]
    for amount in amounts:
        print(amount, needs_review(amount))


if __name__ == "__main__":
    main()
```

อ่านบรรทัดแรกว่า “จาก module `rules` ใน package `demo_app` นำชื่อ `needs_review` มาใช้” มันไม่ได้เรียกฟังก์ชันทันที; การเรียกอยู่ที่ `needs_review(amount)` ใน loop

```text
main.py ─── import ──→ rules.py
tests   ─── import ──→ rules.py
                         ↓
                 กฎมีต้นฉบับจุดเดียว
```

### 4. รันจาก folder ไหน และ `-m` คืออะไร

หลังแตก ZIP เปิด terminal ใน `examples/project_structure` แล้วรัน:

```powershell
python single_file/main.py
cd split_package
python -m demo_app.main
python -m pytest tests -q
```

สามคำสั่งท้ายอยู่ใน `split_package` ซึ่งเป็น directory ที่มองเห็น `demo_app/` อยู่ข้างใน ใช้ Python environment ที่มี pytest แล้ว เช่น environment ที่ใช้กับ Capstone หากยังไม่มี ให้ติดตั้ง pytest ใน environment ฝึกก่อน

ทั้ง single-file และ split-package ต้องแสดงผลเหมือนกัน:

```text
500 False
150000 True
```

`python -m demo_app.main` ขอให้ Python ค้นหา module แล้วรันเป็นจุดเริ่มโปรแกรม จึงใช้จุดคั่นชื่อและไม่ใส่ `.py` ส่วน `python demo_app/main.py` เป็นการรันด้วย path ไฟล์โดยตรง ซึ่งทำให้บริบทการค้นหา imports ต่างกัน สำหรับ layout นี้ให้ใช้รูปแบบ `-m` จาก root ตามตัวอย่าง

```text
terminal อยู่ split_package/
           ↓ python -m demo_app.main
เห็น package demo_app → โหลด main → import rules → เรียก main()
```

`if __name__ == "__main__"` ทำให้เรียก `main()` เมื่อ module นี้เป็นจุดเริ่มรัน แต่ไม่เรียกเพียงเพราะไฟล์อื่น import มัน อย่างไรก็ตามคำสั่งระดับบนอื่น ๆ ของ module ยังทำงานตอน import ครั้งแรก ไม่ใช่ว่า import จะไม่รันโค้ดใดเลย

### 5. Absolute import กับ Relative import

ตัวอย่างใช้ **absolute import** ระบุชื่อจาก package:

```python
from demo_app.rules import needs_review
```

ภายใน `demo_app/main.py` จะเขียนแบบ **relative import** ได้เช่นกัน:

```python
from .rules import needs_review
```

จุดหน้า `rules` หมายถึง package ปัจจุบัน ไม่ใช่ folder ที่ terminal ยืนอยู่ เลือกใช้รูปแบบใดรูปแบบหนึ่งในตัวอย่าง ไม่ต้องเพิ่มซ้ำทั้งสองบรรทัด และยังรันด้วย `python -m demo_app.main` เพื่อให้มี package context

หากพบ `ModuleNotFoundError` ให้ตรวจ interpreter, directory ที่รัน และชื่อ package ก่อน ไม่รีบแก้ด้วย `sys.path.append(...)` กระจายทุกไฟล์ เพราะอาจซ่อนปัญหาที่กลับมาเกิดบนเครื่องเพื่อน อย่าตั้งชื่อไฟล์ว่า `json.py`, `typing.py` หรือ `pytest.py` โดยไม่ตั้งใจ เพราะอาจบัง library ที่ต้องการ import

### 6. `app/`, `course/` และ `src/` ต่างกันอย่างไร

ชื่อ `app` หรือ `course` ไม่ใช่คำสงวนของ Python เป็นชื่อ package ที่ผู้เขียนเลือก Capstone ของเราใช้ `course/` ตัวอย่างเล็กใช้ `demo_app/` ไม่ต้องสร้างทั้งสองชื่อในโปรเจกต์เดียวเพียงเพื่อให้ดูครบ

| Layout | ตัวอย่าง | สิ่งที่ต้องรู้ |
|---|---|---|
| Flat layout | `project/demo_app/main.py` | package อยู่ใต้ project root แบบ workshop นี้ |
| Src layout | `project/src/demo_app/main.py` | แยก source ใต้ `src/`; โดยทั่วไปต้องติดตั้ง package ใน environment ก่อนใช้ |

```text
src ไม่ใช่ชื่อที่ใช้ import โดยอัตโนมัติ
project/src/demo_app/rules.py
                     ↓ ตั้งค่า packaging และติดตั้งถูกต้อง
from demo_app.rules import needs_review
```

ใน src layout มักใช้ editable install ระหว่างพัฒนา เช่น `python -m pip install -e .` **หลังจากมี packaging configuration ที่ถูกต้องแล้ว** การสร้าง `src/` เปล่า ๆ แล้วรันคำสั่งนี้ไม่พอ ชุด workshop นี้ยังเป็น flat layout และไม่ได้มี configuration สำหรับขั้นตอนนั้น จึงไม่ต้องย้ายไฟล์หรือลองติดตั้งแบบ editable ตามบทนี้ [Python Packaging: src vs flat layout](https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/)

### 7. ถ้าโปรเจกต์โตขึ้น ค่อยแยกตามหน้าที่

ต้นไม้ต่อไปนี้เป็น **ตัวอย่างการต่อยอด ไม่ใช่ไฟล์ที่มีครบใน Capstone ปัจจุบัน** ไม่ต้องสร้างโฟลเดอร์ว่างทั้งหมดก่อนลงมือ:

```text
project/
├── app/
│   ├── __init__.py
│   ├── main.py                # ประกอบ application / ลงทะเบียน routes
│   ├── api/                   # endpoints แยกตามกลุ่มงาน
│   │   ├── __init__.py
│   │   ├── transactions.py
│   │   └── resumes.py
│   ├── schemas.py             # รูปแบบ input/output ของ API
│   ├── services/              # ขั้นตอนใช้งานและ business logic
│   │   └── __init__.py
│   ├── repositories/          # อ่าน/เขียนฐานข้อมูล
│   │   └── __init__.py
│   └── config.py              # อ่านและตรวจ configuration
├── tests/                     # test code
├── docs/                      # architecture / runbook เมื่อเอกสารเริ่มมาก
├── scripts/                   # คำสั่งช่วยงานเฉพาะ เช่น import ข้อมูลฝึก
├── data/                      # runtime data; ไม่ commit ข้อมูลจริง
├── .env.example
├── .gitignore
└── README.md
```

เริ่มด้วย `api.py` ได้ก่อน พอมี endpoints หลายกลุ่มที่อ่านรวมกันยาก จึงแยกเป็น `api/transactions.py` และ `api/resumes.py` พร้อมให้จุดประกอบ application ลงทะเบียน routes การย้ายไฟล์อย่างเดียวไม่ได้ทำให้ framework รู้จัก endpoint ใหม่เอง และไม่ควรเก็บ `api.py` กับ package `api/` ชื่อเดียวกันคู่กันจนสับสน

ความหมายของชื่อที่พบบ่อย:

- **Schemas:** ข้อมูลที่ยอมรับ/ส่งออก เช่น request ต้องมีจำนวนเงินมากกว่า 0
- **Models:** ความหมายขึ้นกับโปรเจกต์ อาจเป็น Pydantic models, domain objects หรือ ORM models ที่แทนตาราง ต้องดู import และหน้าที่จริง ของเรา `models.py` เป็น Pydantic ไม่ใช่ ORM
- **Services:** กำกับขั้นตอนและกฎ เช่นตรวจผล AI ก่อนบันทึก ไม่ควรต้องรู้รายละเอียด HTTP headers ทุกจุด
- **Repositories:** จัดการการเก็บข้อมูล/query ให้ส่วนอื่นเรียกผ่านหน้าที่ที่ชัดเจน ไม่จำเป็นต้องมี ORM จึงจะใช้ชื่อนี้ได้

สำหรับ Capstone ที่มี worker เส้นทางคือ API → repository เพื่อรับงาน แล้ว worker → service → repository เพื่อทำงาน ไม่ใช่ทุกระบบต้องมี flow API → service → repository แบบ synchronous เสมอไป

### 8. ไฟล์ข้างนอก source มีไว้ทำอะไร

| ตำแหน่ง/ไฟล์ | หน้าที่ | เก็บใน Git หรือไม่ |
|---|---|---|
| `tests/` | ตรวจพฤติกรรม ไม่ใช่เก็บผลรันทุกรอบ | เก็บ test code |
| `fixtures/` | input ตัวอย่างที่ควบคุมได้ | เก็บเฉพาะที่อนุญาต เช่น synthetic |
| `requirements.txt` | รายการ dependency สำหรับ pip | เก็บ |
| `pyproject.toml` | project/build metadata และ/หรือ tool configuration ตามที่กำหนด | เก็บเมื่อโปรเจกต์ใช้; lab นี้ยังไม่ใช้ |
| `README.md` / `RUNBOOK.md` | เริ่มใช้ / รับมือเหตุขัดข้อง | เก็บ |
| `Dockerfile` / `compose.yaml` | build image / จัด services | เก็บ โดยไม่มี secret จริง |
| `.env.example` | ชื่อค่าที่ต้องตั้ง พร้อม placeholder | เก็บ |
| `.env` / `.venv/` | ค่าของเครื่อง / environment ที่สร้างใหม่ได้ | โดยทั่วไปไม่เก็บ |
| `data/`, logs, caches | ข้อมูลขณะระบบรัน | กันออกตามนโยบาย; ไม่รวมข้อมูลจริงใน repo ฝึก |
| `.github/workflows/` | CI configuration บน GitHub | เก็บเมื่อ repo ใช้งาน |

อย่าใช้โฟลเดอร์ `utils/` เป็นที่รวมทุกอย่างที่ยังคิดชื่อไม่ออก ถ้าฟังก์ชันอ่าน CSV ให้ชื่อ module ที่บอกหน้าที่ เช่น `csv_reader.py` จะค้นง่ายกว่า `utils2.py` ส่วน `src/` กับ `scripts/` ก็ไม่เหมือนกัน: source หลักต้องให้ส่วนอื่นใช้ต่อได้ ส่วน scripts เป็น entry point ช่วยงานเฉพาะที่ควรเรียกใช้ logic หลักอีกที

### 9. Project root ไม่เท่ากับ Current Working Directory เสมอ

**Project root** คือ directory หลักที่เรากำหนดให้โปรเจกต์ เช่น `capstone/` ซึ่งมี README และ requirements ส่วน **Current Working Directory (CWD)** คือ directory ที่ process กำลังทำงานอยู่ เปลี่ยนได้ด้วย `cd` ก่อนรัน และ Python ไม่ได้ย้าย CWD ไปตามที่ตั้งไฟล์ `.py` ให้อัตโนมัติ

```python
from pathlib import Path

print(Path.cwd())
print(Path("data/capstone.sqlite3").resolve())
```

ลองจาก terminal สองตำแหน่งจะเห็นว่า relative DB path ชี้คนละไฟล์ได้ นี่คือเหตุผลที่ API กับ worker อาจไม่เห็นงานกันแม้ตั้ง string `data/capstone.sqlite3` เหมือนกัน

```text
CWD A + data/capstone.sqlite3 → ไฟล์ A
CWD B + data/capstone.sqlite3 → ไฟล์ B
```

สำหรับ resource ที่อยู่คู่ source อาจใช้ `Path(__file__).resolve().parent` เป็นฐานใน module ปกติ แต่ไม่ควรเขียน runtime data ลง package โดยอัตโนมัติ เพราะ package อาจติดตั้งในที่เขียนไม่ได้ งานที่ต้องเลือก storage ให้ใช้ config/path ที่ระบุชัดตาม README แทน

### 10. เลี่ยง Circular Import ตั้งแต่เริ่ม

```text
main.py import rules.py
rules.py import main.py
        ↺ พึ่งพากันเป็นวง
```

บางรูปแบบทำให้ module ยังสร้างชื่อไม่ครบตอนอีกไฟล์นำไปใช้ วิธีคิดคือกฎไม่ควรต้อง import จุดเริ่มโปรแกรม ถ้าทั้งสองไฟล์ใช้ข้อมูลชนิดเดียวกัน ให้แยก contract ไป module ที่ทั้งคู่พึ่งพาได้ ไม่แก้ด้วยการย้าย import ไปมาจน error หายแต่ยังอธิบายความสัมพันธ์ไม่ได้

```text
main.py ──→ rules.py
    └─────→ schemas.py ←── rules.py
```

### 11. ลำดับสร้างโปรเจกต์ใหม่แบบไม่เยอะเกินไป

เริ่มจาก README สั้น ๆ บอก input/output และคำสั่งรัน → ทำหนึ่ง happy path ในไฟล์เดียว → แยก pure function ที่ทดสอบได้ → เพิ่ม tests → เมื่อมีผู้ใช้ logic มากกว่าหนึ่งจุดจึงแยก module/package → เพิ่ม API/DB/config ตามโจทย์ → เพิ่ม Docker/CI เมื่อมีขั้นตอนที่ต้องรันซ้ำและส่งต่อ

ไม่จำเป็นต้องรอจนไฟล์ยาวมากจึงแยก และไม่มีจำนวนบรรทัดตายตัว ให้ดูว่า “เปลี่ยนหนึ่งเรื่องแล้วต้องแตะหลายหน้าที่ที่ไม่เกี่ยวกันหรือไม่” กับ “เพื่อนหาโค้ดส่วนนี้เจอหรือไม่” เป็นสัญญาณประกอบ

### 12. Mini Challenge — ลองจัดเองหนึ่งรอบ

ใช้สำเนา `split_package` ไม่แก้ Capstone หลัก เพิ่มกฎ `is_small_amount()` ใน `rules.py` ซึ่งรับ integer หน่วยสตางค์และคืน True เมื่อ `0 < amount_minor < 1_000` เรียกจาก `main.py` แล้วเพิ่ม tests โดย import กฎจาก module ไม่ copy implementation ไปไว้ใน test

```text
input: 0, 500, 1000
expected: False, True, False
```

อ่าน [test_rules.py](examples/project_structure/split_package/tests/test_rules.py) เป็นตัวอย่าง ชุดเดิมตรวจต่ำกว่า threshold, เท่ากับ threshold และสูงกว่า threshold ของ `needs_review()` รวม 3 tests หลังเพิ่มโจทย์ให้มี tests ใหม่ของคุณด้วย

ถือว่าเข้าใจเมื่ออธิบายได้ว่าไฟล์ไหนเป็น entry point, ไฟล์ไหนเป็นกฎ, import เดินทางใด, ต้องรันจาก directory ไหน และทำไมยังไม่ต้องมี `services/` หรือ `repositories/` ในตัวอย่างที่ไม่มี API/DB นี้
