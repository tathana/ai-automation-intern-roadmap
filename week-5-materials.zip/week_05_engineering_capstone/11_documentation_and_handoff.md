# 11 — README, Runbook และการส่งมอบงาน

## README กับ Runbook ต่างกันอย่างไร

README ช่วยคนใหม่เริ่มใช้งานและเข้าใจขอบเขต ส่วน runbook ช่วยคนที่ระบบมีปัญหาตัดสินใจว่าตรวจอะไรต่อ ไม่ต้องคัดลอกทุกบรรทัดจาก source มาใส่เอกสาร แต่ต้องให้คำสั่งที่รันได้จาก folder ที่ระบุ

```text
คนใหม่ → README → setup → sample → expected result
ระบบผิดปกติ → runbook → symptom → check → safe action → verify
```

## README ขั้นต่ำที่ควรส่งพร้อมงาน

บอกปัญหาที่แก้, architecture สั้น ๆ, prerequisites, วิธีตั้ง environment โดยไม่เผย secret, คำสั่งรัน, sample input/output, tests, known limitations และผู้รับผิดชอบ แยกขั้นตอน native กับ Compose เพราะ `localhost` และการโหลด `.env` ไม่เหมือนกัน

ดู [Capstone README](capstone/README.md) และ [Runbook](capstone/RUNBOOK.md) เป็นตัวอย่าง ลองให้คนอื่นอ่านโดยคุณยังไม่ช่วย หากเขาติดตรง path หรือ expected result ให้แก้คู่มือก่อนบอกว่า “เครื่องเขามีปัญหา”

## Security handoff ไม่ใช่แค่เขียนว่าอย่า commit key

ต้องบอกว่า endpoint ใดยังไม่มี auth, ใครเห็นไฟล์ DB ได้, เก็บ document_text ตรงไหน, ลบตาม retention อย่างไร และมี log ที่อาจมีข้อมูลละเอียดหรือไม่ Lab นี้ตั้งใจให้ local-only ไม่มีการออกแบบควบคุมสิทธิ์ข้อมูลผู้สมัครจริง จึงไม่ควรนำไปเปิด public ตรง ๆ

Backup ต้องทดสอบ restore ด้วย ไม่ใช่มีไฟล์สำรองแล้วถือว่าใช้ได้ ขณะ DB มี writer อย่า copy ไฟล์ SQLite แบบสุ่มโดยไม่เข้าใจ journal/WAL ให้ใช้ backup API หรือหยุด writer อย่างมีขั้นตอนใน lab แล้วตรวจสำเนาแยก ไม่ overwrite ฐานข้อมูลต้นฉบับเพื่อ “ลองดู”

## Decision log ช่วยจำเหตุผล

ตัวอย่างสั้น: “เลือก SQLite เพราะเป็น lab เครื่องเดียวและลด setup; เมื่อเพิ่มหลาย host จะย้าย queue/database ตาม requirement ไม่วาง SQLite บน network filesystem เพื่อ scale โดยไม่ทดสอบ” เอกสารนี้เรียกได้ว่า ADR แบบย่อ: context, decision, consequences

## Release note ควรพูดถึงผลต่อผู้ใช้

แทน “refactor service” เขียนว่า “ส่งงานซ้ำด้วย ID เดิมคืน task เดิม; payload ต่างคืน 409; ยังไม่รองรับ OCR” พร้อมวิธีตรวจและขั้นตอน rollback ที่พิจารณาข้อมูลด้วย หากแก้ schema DB การ revert Git อย่างเดียวอาจไม่พอ ต้องมี migration/restore plan ที่ผ่านการทดสอบ
