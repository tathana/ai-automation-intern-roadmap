# 11 — README, Runbook และการส่งมอบงาน

## README กับ Runbook ต่างกันอย่างไร

README ช่วยคนใหม่เริ่มใช้งานและเข้าใจขอบเขต ส่วน runbook ช่วยคนที่ระบบมีปัญหาตัดสินใจว่าตรวจอะไรต่อ ไม่ต้องคัดลอกทุกบรรทัดจาก source มาใส่เอกสาร แต่ต้องให้คำสั่งที่รันได้จาก folder ที่ระบุ

```text
คนใหม่ → README → setup → sample → expected result
ระบบผิดปกติ → runbook → symptom → check → safe action → verify
```

## README ขั้นต่ำที่ควรส่งพร้อมงาน

บอกปัญหาที่แก้, architecture สั้น ๆ, prerequisites, วิธีตั้ง environment โดยไม่เผย secret, คำสั่งรัน, sample input/output, tests, known limitations และผู้รับผิดชอบ แยกขั้นตอน native กับ Compose เพราะ `localhost` และการโหลด `.env` ไม่เหมือนกัน

ดู [Capstone README](capstone/README.md) และ [Runbook](capstone/RUNBOOK.md) เป็นตัวอย่าง ลองให้คนอื่นอ่านโดยคุณยังไม่ช่วย หากเขาติดตรง path หรือ expected result ให้แก้คู่มือก่อนบอกว่า “เครื่องเขามีปัญหา”

## Security handoff ไม่ใช่แค่เขียนว่าอย่า commit key

ต้องบอกว่า endpoint ใดยังไม่มี auth, ใครเห็นไฟล์ DB ได้, เก็บ document_text ตรงไหน, ลบตาม retention อย่างไร และมี log ที่อาจมีข้อมูลละเอียดหรือไม่ Lab นี้ตั้งใจให้ local-only ไม่มีการออกแบบควบคุมสิทธิ์ข้อมูลผู้สมัครจริง จึงไม่ควรนำไปเปิด public ตรง ๆ

Backup ต้องทดสอบ restore ด้วย ไม่ใช่มีไฟล์สำรองแล้วถือว่าใช้ได้ ขณะ DB มี writer อย่า copy ไฟล์ SQLite แบบสุ่มโดยไม่เข้าใจ journal/WAL ให้ใช้ backup API หรือหยุด writer อย่างมีขั้นตอนใน lab แล้วตรวจสำเนาแยก ไม่ overwrite ฐานข้อมูลต้นฉบับเพื่อ “ลองดู”

## Decision log ช่วยจำเหตุผล

ตัวอย่างสั้น: “เลือก SQLite เพราะเป็น lab เครื่องเดียวและลด setup; เมื่อเพิ่มหลาย host จะย้าย queue/database ตาม requirement ไม่วาง SQLite บน network filesystem เพื่อ scale โดยไม่ทดสอบ” เอกสารนี้เรียกได้ว่า ADR แบบย่อ: context, decision, consequences

## Release note ควรพูดถึงผลต่อผู้ใช้

แทน “refactor service” เขียนว่า “ส่งงานซ้ำด้วย ID เดิมคืน task เดิม; payload ต่างคืน 409; ยังไม่รองรับ OCR” พร้อมวิธีตรวจและขั้นตอน rollback ที่พิจารณาข้อมูลด้วย หากแก้ schema DB การ revert Git อย่างเดียวอาจไม่พอ ต้องมี migration/restore plan ที่ผ่านการทดสอบ

## Workshop — เขียน README ให้คนที่ไม่เคยนั่งข้างเรารันได้

เริ่มจากผู้อ่านไม่รู้ว่าเราเปิด terminal ที่ไหน จึงต้องบอก **ก่อนรัน**, **คำสั่ง**, **ผลที่ควรเห็น**, **ถ้าไม่เห็นให้ตรวจอะไร** ตัวอย่างคำว่า “รัน server” อย่างเดียวข้ามรายละเอียดมากเกินไป

```text
ก่อนรัน: อยู่ capstone, ติดตั้ง requirements ใน .venv แล้ว
คำสั่ง: .\.venv\Scripts\python.exe -m uvicorn course.api:app --host 127.0.0.1 --port 8015
ผล: terminal ค้างรอรับ request; เปิด /health ได้
ตรวจต่อ: ถ้า port ชน ให้ดูว่ามี API lab เก่าเปิดอยู่หรือไม่
```

Server ทำงานค้างใน terminal เป็นเรื่องปกติ ไม่ใช่คำสั่งติด จึงเปิดอีก terminal สำหรับ client อย่าให้ผู้อ่านกด Ctrl+C หยุด server เพื่อพิมพ์ request แล้วงงว่าทำไมเชื่อมต่อไม่ได้

## โครง README ที่คัดไปปรับใช้ได้

```text
1. Problem / Scope: ช่วยงานใด และไม่ทำอะไร
2. Prerequisites: Python/Docker และสิทธิ์ที่ต้องมี
3. Setup: folder, environment, dependencies
4. Run: API / worker / client แยก terminal
5. Sample: synthetic input + expected output
6. Tests: คำสั่งและขอบเขต
7. Troubleshooting: อาการ → ตรวจ → วิธีแก้ที่ปลอดภัย
8. Limitations / Security: mock, auth, data handling
9. Stop / Recovery: หยุดอย่างไรและข้อมูลยังอยู่ที่ไหน
```

ให้แทนข้อความด้วยสิ่งที่โปรเจกต์ทำจริง ถ้ายังไม่ทดสอบ Docker อย่าเขียนว่า “Docker verified” เพียงเพราะมี Dockerfile และอย่าระบุ env var ที่ source ไม่เคยอ่าน

## ทดลองส่งมอบแบบไม่แตะข้อมูลเดิม

แตก ZIP ใหม่ไป folder ฝึกแยก ทำตาม README ด้วย environment ใหม่ และใช้ข้อมูลสังเคราะห์ ถ้ามี server เก่าใช้ port อยู่ ให้หยุดเฉพาะ lab ที่คุณรู้จักหรือกำหนด port ใหม่พร้อมแก้ client URL ไม่ stop ทุก Python process ในเครื่อง

จดทุกขั้นตอนที่ต้องถามเจ้าของงานเพิ่ม เช่น “ต้อง cd ไปไหน”, “token มาจากไหน”, “output นี้ถูกไหม” แล้วแก้เอกสารตรงนั้น การใช้ได้บนเครื่องเราอย่างเดียวไม่พอจะพิสูจน์ว่าคนอื่นใช้ต่อได้

## Runbook หนึ่งเรื่องควรมีจุดจบ

ตัวอย่าง queued ค้าง: ตรวจ task → worker → DB path → เปิด worker ที่ถูก config → ตรวจว่า task เปลี่ยน state และ audit มี claimed ถ้ายังไม่เปลี่ยนหลังเงื่อนไขที่ควรพร้อม ให้เก็บหลักฐานและส่งต่อ ไม่วน restart ไม่จำกัดจนต้นเหตุหายจาก logs

จุดตรวจ: คนอื่นเริ่ม, ตรวจผล และหยุด lab ได้จากเอกสาร โดยคุณไม่ต้องบอกค่าลับหรือส่ง DB ของตัวเองให้เขา
