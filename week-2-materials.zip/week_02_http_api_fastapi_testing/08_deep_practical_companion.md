# 08 — Deep Practical Companion

## ไล่ Request จริง

<!-- tutor-rich:## ไล่ Request จริง -->
### คำอธิบายแบบเข้าใจง่าย

> **HTTP request คือซองงานที่มีวิธีทำ ที่อยู่ ข้อมูลกำกับ และข้อมูลข้างใน**

พิจารณา Flow ต่อไปนี้:

```text
Method + Path/Query
  ↓
Headers บอก metadata
  ↓
Body ส่ง payload
  ↓
Server parse และ validate
```

#### จุดที่มักเข้าใจผิด

URL ถูกอย่างเดียวไม่พอ Method, Content-Type และ body ต้องตรง contract ด้วย

```http
POST /api/v1/transactions HTTP/1.1
Content-Type: application/json
Idempotency-Key: tx-001

{"transaction_id":"tx-001","amount_satangs":10000}
```

1. server รับ bytes
2. router เลือก endpoint จาก method+path
3. framework parse JSON; syntax พังหยุดก่อน route
4. Pydantic ตรวจ field/type/boundary; พังตอบ validation error
5. dependency สร้าง testable DB/service
6. service ตรวจ account/rule/idempotency
7. repository ทำ parameterized SQL ใน transaction
8. service คืน domain result
9. route map เป็น response model + status
10. middleware/log บันทึก duration/request ID โดยไม่เผย secret

## จุดสับสนสำคัญ

<!-- tutor-rich:## จุดสับสนสำคัญ -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า จุดสับสนสำคัญ อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

### 400 กับ 422

อย่าท่องอย่างเดียว ให้ยึด API contract ของทีม: malformed transport/JSON และ semantic/schema validation อาจถูก map ต่างกัน FastAPI default มักคืน 422 สำหรับ request validation

### 401 กับ 403

401 คือ credential ไม่มี/ไม่ผ่าน; 403 คือยืนยันตัวตนแล้วแต่ action/resource ไม่ได้รับอนุญาต

### Timeout กับ 500

Timeout เป็นอาการที่ boundary ภายนอก; API เราอาจ map เป็น 502/503/504 ตาม architecture ไม่ควรปล่อย library exception ดิบ และต้องแยกว่าทำ side effect ไปแล้วหรือยัง

### Pydantic ผ่านไม่ได้แปลว่า business ถูก

amount เป็น int บวกได้ แต่ account อาจปิด, currency ไม่รองรับในประเทศนั้น หรือ transaction ID อาจ conflict กับ payload เดิม

### `async` ไม่เท่ากับเร็ว

Async เพิ่ม concurrency สำหรับ waiting I/O แต่ CPU-heavy parsing ยังบล็อก event loop และ blocking library ใน async route ทำให้ request อื่นรอ

## Thin Route Example

<!-- tutor-rich:## Thin Route Example -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Thin Route Example อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

```python
@router.post("/transactions", response_model=TransactionResponse, status_code=201)
def create(body: TransactionCreate, service: TransactionService = Depends(get_service)):
    try:
        result = service.create(body)
    except TransactionConflict as exc:
        raise HTTPException(409, "transaction conflict") from exc
    return TransactionResponse.model_validate(result)
```

Route รู้ HTTP ส่วน service ไม่ควรรู้ `HTTPException` จึง reuse จาก CLI/worker ได้

## Reliable Client Decision Table

<!-- tutor-rich:## Reliable Client Decision Table -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Reliable Client Decision Table อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

| เหตุการณ์ | Retry? | หมายเหตุ |
|---|---|---|
| connect timeout | อาจ | มี backoff/deadline |
| read timeout | อาจ | side effect อาจเกิดแล้ว |
| 400/422 | ไม่ | แก้ request |
| 401/403 | ไม่วน | แก้ credential/permission |
| 429 | ตาม policy | เคารพ Retry-After |
| 503 | อาจ | จำกัดครั้ง+jitter |
| invalid 200 body | ปกติไม่ | schema/provider incident |

## Diagnostic Template

<!-- tutor-rich:## Diagnostic Template -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Diagnostic Template อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

ส่ง method, sanitized URL, sanitized headers, request shape, status, response body ที่ตัด PII, full traceback ฝั่ง local, expected behavior และ minimal reproduction ห้ามส่ง token/cookie/raw resume

## ก่อน Challenge

<!-- tutor-rich:## ก่อน Challenge -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า ก่อน Challenge อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

อธิบายให้ได้: request lifecycle, schema vs business validation, response model ป้องกันอะไร, dependency override ทำให้ test ปลอดภัยอย่างไร, retry POST เสี่ยงอะไร, unique constraint ป้องกัน race อย่างไร และ webhook signature ต้องใช้ raw body เพราะอะไร

