# 12 — Visual Notes: HTTP, FastAPI และ Testing

## Request เดินทางอย่างไร

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Client</div><span class="visual-arrow">DNS/TCP/TLS →</span><div class="visual-box">Host:Port</div><span class="visual-arrow">HTTP →</span><div class="visual-box">Method + Path</div><span class="visual-arrow">schema →</span><div class="visual-box">Use Case</div><span class="visual-arrow">→</span><div class="visual-box">Status + Body</div></div></div>

อาการบอก last known boundary: connection refused ยังไม่ถึง HTTP, 404 ถึง server, 405 พบ path, 422 ถึง validator, 500 เข้า application/dependency

## FastAPI Mock Screen

<div class="visual-board"><div class="visual-grid"><div class="visual-pane"><div class="visual-label">REQUEST</div><p><code>POST /tasks</code></p><p>headers + JSON body</p></div><div class="visual-pane"><div class="visual-label">BOUNDARY</div><p>authentication</p><p>Pydantic validation</p><p>dependency injection</p></div><div class="visual-pane"><div class="visual-label">RESPONSE</div><p><code>202 Accepted</code></p><p><code>{task_id, state}</code></p></div></div></div>

`202` หมายถึงรับเพื่อประมวลผล ไม่ได้แปลว่างานเสร็จ ต้องมี durable task ID/status contract

## Thin Route และ Dependency Direction

<div class="visual-board"><div class="visual-flow"><div class="visual-box">API Route<br><small>HTTP mapping</small></div><span class="visual-arrow">→</span><div class="visual-box">Service<br><small>use case</small></div><span class="visual-arrow">→</span><div class="visual-box">Domain<br><small>rules</small></div></div><div class="visual-flow"><div class="visual-box">DB / Provider Adapter</div><span class="visual-arrow">implements interface defined inward</span></div></div>

## Reliable Client

<div class="visual-board"><div class="visual-flow"><div class="visual-box">build request</div><span class="visual-arrow">→ timeout</span><div class="visual-box">send</div><span class="visual-arrow">→ classify</span><div class="visual-box">2xx / 4xx / 429 / 5xx</div><span class="visual-arrow">→</span><div class="visual-box">parse + validate body</div><span class="visual-arrow">→</span><div class="visual-box">domain result/error</div></div></div>

Retry เฉพาะ transient failure ภายใน budget และต้องคิด idempotency สำหรับ operation ที่มี side effect

## Test Pyramid ตาม Boundary

<div class="visual-board"><div class="visual-lane"><strong>Unit</strong><div class="visual-track">pure rules และ error mapping</div></div><div class="visual-lane"><strong>Integration</strong><div class="visual-track">FastAPI + real test DB / adapter contract</div></div><div class="visual-lane"><strong>End-to-end</strong><div class="visual-track">HTTP request ผ่านระบบถึง observable outcome</div></div></div>

