# Drill 02 — Reliable Client

เขียน client ที่มี timeout และแปลง 404, 429, 503, invalid JSON เป็น error categories ของโปรเจกต์ ใช้ fake transport ทดสอบทุกกรณี ห้าม network จริง อธิบายว่า case ใด retry ได้และเพราะอะไร

