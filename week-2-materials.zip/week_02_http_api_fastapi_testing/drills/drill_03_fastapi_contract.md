# Drill 03 — FastAPI Contract

สร้าง `POST /items` และ `GET /items/{id}` แยก request/response models, forbid unknown fields, ตรวจ boundary, map not found/conflict และยืนยันว่า internal field ไม่ออก response

