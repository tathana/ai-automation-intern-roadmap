# Week 2 Drills

ทำใน repo ทดลองและ commit แยก drill: 01 อ่าน HTTP, 02 reliable client, 03 FastAPI contract, 04 failure tests

