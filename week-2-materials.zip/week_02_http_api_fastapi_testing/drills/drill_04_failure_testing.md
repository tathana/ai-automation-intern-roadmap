# Drill 04 — Failure Testing

เขียน tests สำหรับ duplicate, DB rollback, upstream timeout, malformed upstream 200 response และ unexpected exception ตรวจทั้ง status/error shape/DB side effect/secret leakage

