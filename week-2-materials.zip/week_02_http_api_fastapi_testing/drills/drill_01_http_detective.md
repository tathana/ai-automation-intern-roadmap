# Drill 01 — HTTP Detective

ใช้ curl กับ API ทดลอง 6 requests: GET success, POST success, malformed JSON, missing field, unknown resource และ wrong content type บันทึก method/path/query/headers/body/status และอธิบายว่า failure เกิดก่อนหรือหลัง endpoint

