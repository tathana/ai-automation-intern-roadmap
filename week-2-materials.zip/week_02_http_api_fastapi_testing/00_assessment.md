# 00 — Assessment

ตอบก่อนค้น: request มีส่วนใดบ้าง, JSON text ต่างจาก dict อย่างไร, 401 ต่างจาก 403 อย่างไร, timeout ต่างจาก 500 อย่างไร, ทำไม retry POST อาจซ้ำ, Pydantic แทน business rules ทั้งหมดได้ไหม และ mock ไปเพื่ออะไร

อ่าน request นี้แล้วแยกทุกส่วน:

```http
POST /api/v1/transactions?dry_run=true HTTP/1.1
Content-Type: application/json
Idempotency-Key: req-123

{"transaction_id":"tx-1","amount_satangs":5000}
```

เมื่อจบ Week ต้อง demo success, invalid, duplicate และ upstream timeout พร้อมไล่ flow จาก client ถึง DB และกลับมาเป็น response ได้

## วิธีใช้ Assessment

```text
ตอบจากความเข้าใจก่อน
       ↓
ทำ request จริงด้วย TestClient/curl
       ↓
เทียบ status + body + state ใน repository
       ↓
อธิบาย failure ด้วยศัพท์ transport / HTTP / validation / business
```

ไม่ต้องตอบถูกทั้งหมดก่อนเริ่ม ให้ทำเครื่องหมายคำถามที่ตอบด้วยเหตุผลไม่ได้ แล้วกลับมาตอบใหม่หลังบท 08–10 หลักฐานว่าผ่านคือเขียน endpoint เล็กเองและมี tests อย่างน้อย success, invalid input, not found, conflict และ dependency failure
