# 11 — Sources และ Verification

ตรวจเอกสารทางการล่าสุดสำหรับฉบับ Textbook เมื่อ 12 กันยายน 2026 ชื่อ API/พฤติกรรมของ dependency อาจเปลี่ยนเมื่ออัปเกรด จึงให้ตรวจ release notes และทดสอบใน environment ของทีมอีกครั้ง

## แหล่งอ้างอิงหลัก

- [FastAPI — Request Body](https://fastapi.tiangolo.com/tutorial/body/): Pydantic model เป็น request body, parsing/validation/documentation
- [FastAPI — Nested Models](https://fastapi.tiangolo.com/tutorial/body-nested-models/): typed lists/dicts และ nested request structures
- [FastAPI — Response Model](https://fastapi.tiangolo.com/tutorial/response-model/): output filtering/validation และการแยก input/output models
- [FastAPI — Handling Errors](https://fastapi.tiangolo.com/tutorial/handling-errors/): `HTTPException` และ error responses
- [FastAPI — Dependencies](https://fastapi.tiangolo.com/tutorial/dependencies/): dependency graph/injection สำหรับ database, security และ services
- [FastAPI — Testing](https://fastapi.tiangolo.com/tutorial/testing/): `TestClient`, pytest และการส่ง JSON/headers ใน tests
- [FastAPI — Testing Dependencies with Overrides](https://fastapi.tiangolo.com/advanced/testing-dependencies/): แทน dependency ใน test และ reset override
- [FastAPI — Background Tasks](https://fastapi.tiangolo.com/tutorial/background-tasks/): งานหลัง response; บทนี้เพิ่มข้อควรระวังว่าไม่ใช่ durable queue โดยอัตโนมัติ
- [Pydantic Documentation](https://docs.pydantic.dev/latest/): models, fields, validation errors และ strictness

## สิ่งที่หนังสือพิสูจน์และไม่พิสูจน์

```text
Markdown/HTML examples อ่านและ syntax สมเหตุผล
        ≠ ทุก snippet ถูกรวมเป็น production application เดียว
TestClient ผ่าน
        ≠ proxy/TLS/container/network จริงผ่าน
mock dependency ผ่าน
        ≠ provider หรือ database จริงพร้อมใช้งาน
Pydantic ผ่าน
        ≠ business rule/authorization ถูกต้อง
```

Challenge starter มีส่วนที่ตั้งใจให้ผู้เรียนทำต่อ อย่านับการอ่านเฉลยหรือการรันเฉพาะ health endpoint เป็น Definition of Done ทั้ง Week

## Verification Checklist หลังแก้หนังสือ

- internal Markdown/HTML anchors ไม่ขาด
- code fences ปิดครบและ Python snippets สำคัญ compile/run แยกได้
- ไม่มี secret หรือ endpoint production ในเอกสาร
- ตัวอย่างใช้ synthetic identifiers/data
- HTML ที่เผยแพร่มีบท 09–11 และ flow/code blocks ครบ
- หน้า Week 1/3/4/5 และไฟล์เดิมไม่ถูกเขียนทับ
