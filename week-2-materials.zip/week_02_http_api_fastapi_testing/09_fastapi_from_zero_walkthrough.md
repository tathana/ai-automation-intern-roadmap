# 09 — FastAPI จากไฟล์เปล่า: Code Walkthrough

บทนี้ตั้งใจให้พิมพ์ตามด้วยตัวเองเพื่อเชื่อม Python function, Pydantic model และ HTTP contract เข้าด้วยกัน ใช้ข้อมูล transaction สังเคราะห์และเก็บใน memory เพื่อเน้น flow ก่อน ยังไม่ใช่ production database

## Core: จาก function ธรรมดาเป็น endpoint

function ธรรมดามี caller เป็นโค้ด Python:

```python
def double(value: int) -> int:
    return value * 2

result = double(10)
```

endpoint มี caller ผ่าน HTTP จึงต้องแปลง request เป็น Python values และ Python result กลับเป็น response:

```text
POST /transactions + JSON text
           ↓ HTTP server/FastAPI
Pydantic parse + validate
           ↓ Python object
path operation function
           ↓ service result
response model serialize
           ↓
HTTP status + JSON text
```

## Step 1: สร้าง app และ health endpoint

สร้าง `main.py`:

```python
from fastapi import FastAPI

app = FastAPI(title="Week 2 Transaction Lab")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
```

อ่านทีละบรรทัด:

- `app = FastAPI(...)` สร้าง ASGI application object ที่ server จะโหลด
- `@app.get("/health")` ลงทะเบียนว่า GET path นี้ให้เรียก function ถัดไป
- `def health()` เป็น path operation function
- dict ที่ return ถูก serialize เป็น JSON response; ค่าเริ่มต้นของ success คือ HTTP 200

เปิด server จากโฟลเดอร์ที่มี `main.py`:

```powershell
python -m uvicorn main:app --reload
```

`main:app` แปลว่า import module `main` แล้วหา object `app` หากรันจากโฟลเดอร์ผิดมักได้ import error

Expected:

```http
GET /health HTTP/1.1

HTTP/1.1 200 OK
content-type: application/json

{"status":"ok"}
```

## Step 2: ประกาศ request และ response models

```python
from pydantic import BaseModel, Field


class TransactionCreate(BaseModel):
    transaction_id: str = Field(min_length=1, max_length=80)
    amount_satangs: int = Field(gt=0)
    description: str | None = Field(default=None, max_length=200)


class TransactionCreated(BaseModel):
    transaction_id: str
    amount_satangs: int
    status: str
```

จุดสำคัญ:

- `TransactionCreate` คือ contract ของ input ไม่ใช่ database row ทั้งหมด
- `str | None` บอกว่าชนิดอาจเป็น string หรือ None; `default=None` ทำให้ไม่ส่ง field ก็ได้
- `Field(gt=0)` เป็น structural constraint ที่ตรวจได้ก่อนเข้า route
- response model แยกจาก input เพื่อไม่เผลอคืน internal/secret fields ภายหลัง

ลองทายผล:

```json
{"transaction_id":"T1","amount_satangs":5000}
```

ผ่าน ส่วน amount เป็น 0, field หาย หรือ string ที่แปลงไม่ได้จะถูกปฏิเสธก่อน service ทำงาน โดยทั่วไป FastAPI คืน 422 พร้อมรายละเอียดตำแหน่ง field ตาม validation behavior

## Step 3: เขียน service และ repository แบบเล็ก

เพิ่มโค้ด:

```python
class DuplicateTransaction(Exception):
    pass


class InMemoryTransactionRepository:
    def __init__(self) -> None:
        self._rows: dict[str, TransactionCreated] = {}

    def get(self, transaction_id: str) -> TransactionCreated | None:
        return self._rows.get(transaction_id)

    def add(self, row: TransactionCreated) -> None:
        if row.transaction_id in self._rows:
            raise DuplicateTransaction(row.transaction_id)
        self._rows[row.transaction_id] = row


class TransactionService:
    def __init__(self, repository: InMemoryTransactionRepository) -> None:
        self.repository = repository

    def create(self, request: TransactionCreate) -> TransactionCreated:
        row = TransactionCreated(
            transaction_id=request.transaction_id,
            amount_satangs=request.amount_satangs,
            status="created",
        )
        self.repository.add(row)
        return row
```

flow ของ `create()`:

```text
validated request object
        ↓ ประกอบ output/domain record
TransactionCreated(status="created")
        ↓ repository ตรวจ key และเก็บ
return record หรือ raise DuplicateTransaction
```

business rule “transaction_id ห้ามซ้ำ” อยู่ service/repository boundary ไม่ใช่ Pydantic เพราะต้องดู state ที่มีอยู่แล้ว

## Step 4: เชื่อม route ให้บาง

```python
from fastapi import HTTPException, status

repository = InMemoryTransactionRepository()
service = TransactionService(repository)


@app.post(
    "/transactions",
    response_model=TransactionCreated,
    status_code=status.HTTP_201_CREATED,
)
def create_transaction(request: TransactionCreate) -> TransactionCreated:
    try:
        return service.create(request)
    except DuplicateTransaction as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"code": "duplicate_transaction", "transaction_id": str(exc)},
        ) from exc
```

route รับผิดชอบ HTTP: รับ model, เรียก service, map domain error เป็น 409 และประกาศ response contract ส่วน service ไม่ import `HTTPException` จึงทดสอบโดยไม่ต้องเปิด server ได้

```text
POST valid, new id  → service add สำเร็จ → 201 + TransactionCreated
POST valid, same id → DuplicateTransaction → route map → 409
POST invalid amount → Pydantic/FastAPI reject → 422; service ไม่ถูกเรียก
```

## Step 5: เขียน tests จาก contract

สร้าง `test_main.py`:

```python
from fastapi.testclient import TestClient

from main import app, repository

client = TestClient(app)


def setup_function() -> None:
    repository._rows.clear()  # ใช้เฉพาะ lab; production ใช้ fixture/dependency override


def test_create_transaction() -> None:
    response = client.post(
        "/transactions",
        json={"transaction_id": "T1", "amount_satangs": 5000},
    )

    assert response.status_code == 201
    assert response.json() == {
        "transaction_id": "T1",
        "amount_satangs": 5000,
        "status": "created",
    }


def test_rejects_non_positive_amount() -> None:
    response = client.post(
        "/transactions",
        json={"transaction_id": "T1", "amount_satangs": 0},
    )
    assert response.status_code == 422


def test_duplicate_is_conflict() -> None:
    payload = {"transaction_id": "T1", "amount_satangs": 5000}
    assert client.post("/transactions", json=payload).status_code == 201
    response = client.post("/transactions", json=payload)
    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "duplicate_transaction"
```

`TestClient` เรียก app โดยไม่ต้องเปิด socket จริง จึงเหมาะกับ API tests แต่ยังไม่พิสูจน์ reverse proxy, container network หรือ production database

รัน:

```powershell
python -m pytest -q
```

## Deep Dive: ปรับจาก global memory ไปสู่ dependency injection

global repository ทำให้ตัวอย่างสั้นแต่ test isolation และ lifecycle ไม่ชัด งานจริงควรให้ route ขอ service ผ่าน dependency:

```python
from typing import Annotated
from fastapi import Depends


def get_service() -> TransactionService:
    return service


ServiceDep = Annotated[TransactionService, Depends(get_service)]


@app.post("/transactions", response_model=TransactionCreated, status_code=201)
def create_transaction(request: TransactionCreate, svc: ServiceDep) -> TransactionCreated:
    return svc.create(request)
```

test สามารถ override `get_service` ด้วย fake ที่ควบคุมได้ แล้ว reset override หลัง test นี่คือเหตุผลของ dependency injection: ทำ dependency ชัด, เปลี่ยน implementation และทดสอบ failure ได้ ไม่ใช่เพียง syntax ของ framework

## Debugging Checklist

```text
ModuleNotFoundError → อยู่ project root และ import path ถูกหรือไม่
404                  → method/path/prefix ถูกหรือไม่
405                  → path มี แต่ใช้ method ผิด
422                  → เปิด response.detail ดู loc/type/input
500                  → อ่าน server log/trace id; อย่าส่ง traceback ให้ client
test ผ่าน server พัง → ตรวจ environment, startup, network และ dependency จริง
```

## Mini Challenge

เพิ่ม `GET /transactions/{transaction_id}` ให้คืน 200 เมื่อพบและ 404 เมื่อไม่พบ เขียน tests ก่อน implementation และอย่าคืน `_rows` ทั้ง dict ออกสู่ API
