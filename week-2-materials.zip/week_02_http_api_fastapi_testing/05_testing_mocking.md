# 05 — Testing FastAPI และ Mocking

## Test Pyramid แบบใช้งาน

<!-- tutor-rich:## Test Pyramid แบบใช้งาน -->
### คำอธิบายแบบเข้าใจง่าย

> **มี unit tests จำนวนมากเพื่อ logic, integration tests สำหรับการประกอบ และ end-to-end น้อยแต่ครอบทางสำคัญ**

พิจารณา Flow ต่อไปนี้:

```text
Business rule → unit
Route+DB → integration
ระบบเต็ม → E2E
  ↓
สมดุลความเร็วกับความมั่นใจ
```

#### จุดที่มักเข้าใจผิด

มีแต่ E2E จะช้าและหาต้นเหตุยาก มีแต่ unit จะไม่พิสูจน์ wiring

- unit: pure service/validators เร็วและระบุต้นเหตุง่าย
- integration: route + dependency + test DB
- contract: schema/status/error shape
- end-to-end: จำนวนน้อย ครอบ critical flow

```python
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
```

## Cases

<!-- tutor-rich:## Cases -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Cases อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

ทุก endpoint คิด normal, boundary, invalid, missing, not found, duplicate/conflict, unauthorized, dependency timeout และ unexpected failure ตามความเสี่ยง

## Dependency Override

<!-- tutor-rich:## Dependency Override -->
### คำอธิบายแบบเข้าใจง่าย

> **ระหว่าง test เราสลับ DB/service จริงเป็น test DB/fake ผ่านจุด dependency เดียว**

พิจารณา Flow ต่อไปนี้:

```text
Test เตรียม fake/test DB
  ↓ override dependency
เรียก API ผ่าน TestClient
  ↓ assert response + state
คืน override
```

#### จุดที่มักเข้าใจผิด

ต้อง cleanup override ไม่ให้รั่วไป test ถัดไป

Override DB/service dependency ให้ใช้ isolated temporary DB/fake แล้วคืนค่า override หลัง test ป้องกัน state รั่วระหว่าง tests ห้ามชี้ test ไป production URL/DB

## Mock Boundary

<!-- tutor-rich:## Mock Boundary -->
### คำอธิบายแบบเข้าใจง่าย

> **Mock สิ่งที่อยู่นอกการควบคุม เช่น network เวลา และ email ไม่ mock logic ที่กำลังต้องการพิสูจน์**

พิจารณา Flow ต่อไปนี้:

```text
Code ถึง boundary
  ↓ fake คืน success/timeout/error
Service ใช้ policy
  ↓
Test ตรวจ observable behavior
```

#### จุดที่มักเข้าใจผิด

Mock มากเกินไปทำให้ test ผ่านเพราะเราสั่ง mock ไม่ใช่เพราะระบบถูก

Mock network, clock, random, email หรือ provider ไม่ควร mock pure internal helpers ทุกตัวจน test เพียงยืนยัน implementation calls

## Assertions

<!-- tutor-rich:## Assertions -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Assertions อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

ตรวจ status + body contract + side effect จริง เช่น DB row count ไม่ใช่แค่ “ไม่ exception” สำหรับ error ตรวจว่าไม่มี stack trace/secret หลุด

## Determinism

<!-- tutor-rich:## Determinism -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Determinism อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

ใช้ `tmp_path`, fixed clock, fake provider และ fresh DB; test ต้องผ่านเดี่ยวและผ่านทั้ง suite โดยไม่ขึ้นกับลำดับ

## AI-generated Code

<!-- tutor-rich:## AI-generated Code -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า AI-generated Code อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

เพิ่ม adversarial cases: unknown field, bool ใน integer, empty string, huge body, duplicate key, timeout หลัง side effect, invalid upstream JSON และ malformed auth header

