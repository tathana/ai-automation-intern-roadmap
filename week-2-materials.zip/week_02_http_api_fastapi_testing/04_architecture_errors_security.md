# 04 — Architecture, Errors, Logging และ Security

## Layers

<!-- tutor-rich:## Layers -->
### คำอธิบายแบบเข้าใจง่าย

> **แบ่ง route, service, repository และ client เพื่อให้แต่ละส่วนรับผิดชอบเหตุผลที่เปลี่ยนคนละแบบ**

พิจารณา Flow ต่อไปนี้:

```text
HTTP Route
  ↓ Service/use case
  ↓ Repository หรือ External Client
  ↓ Result
Route map กลับเป็น HTTP
```

#### จุดที่มักเข้าใจผิด

การแยกชั้นไม่ใช่เพิ่มไฟล์ให้ดูใหญ่ แต่ทำให้ test และเปลี่ยน dependency ได้

```text
Route: HTTP mapping
Schema: input/output contract
Service: use case/business rules
Repository: SQL/persistence
Client: external API boundary
```

Route ควร parse dependency, เรียก service และ map result/error ไม่ควรมี SQL และกฎธุรกิจยาว ๆ แยกชั้นเพื่อ test/reuse/change ได้ ไม่ใช่เพื่อสร้างไฟล์เยอะ

## Dependency Injection

<!-- tutor-rich:## Dependency Injection -->
### คำอธิบายแบบเข้าใจง่าย

> **แทนที่ function จะสร้าง DB/client เอง เราส่งสิ่งที่ต้องใช้เข้าไป ทำให้ production ใช้ของจริงและ test ใช้ fake**

พิจารณา Flow ต่อไปนี้:

```text
App สร้าง dependency
  ↓ inject เข้า route/service
ทำงาน
  ↓ lifecycle cleanup
Test override ด้วย fake
```

#### จุดที่มักเข้าใจผิด

DI คือการควบคุมที่มาของ dependency ไม่ใช่แค่ใช้ `Depends` ตาม syntax

FastAPI `Depends` จัด lifecycle ของ DB/auth/service และ override ใน tests ได้ Connection ต้องปิดเสมอและ transaction boundary ต้องอยู่รอบ business operation ไม่ใช่ commit กระจายทุก repository function

## Domain to HTTP Mapping

<!-- tutor-rich:## Domain to HTTP Mapping -->
### คำอธิบายแบบเข้าใจง่าย

> **Service พูดภาษาธุรกิจ ส่วน route แปลผลเป็น HTTP status**

พิจารณา Flow ต่อไปนี้:

```text
Service raise NotFound/Conflict
  ↓ Route/handler แปล
404/409 + safe error body
  ↓
Client เข้าใจ contract
```

#### จุดที่มักเข้าใจผิด

อย่าให้ domain layer raise HTTPException ทุกที่ เพราะจะผูก logic กับ FastAPI

`NotFound → 404`, invalid state/duplicate conflict → `409`, authentication → `401`, authorization → `403`, unexpected → `500` พร้อม request ID อย่าส่ง raw exception/SQL/stack trace ให้ client

## Error Body

<!-- tutor-rich:## Error Body -->
### คำอธิบายแบบเข้าใจง่าย

> **Error body ควรให้ code สำหรับโปรแกรม message สำหรับคน และ request ID สำหรับตาม log**

พิจารณา Flow ต่อไปนี้:

```text
เกิด error
  ↓ สร้าง stable error code
เพิ่ม safe message + request ID
  ↓
ตอบ client; รายละเอียดลึกอยู่ server log
```

#### จุดที่มักเข้าใจผิด

ห้ามส่ง raw traceback, SQL หรือ token เพื่อความสะดวกตอน debug

```json
{"error":{"code":"TRANSACTION_CONFLICT","message":"transaction already exists","request_id":"req-123"}}
```

code ให้โปรแกรมใช้, message ให้คนอ่าน, request ID ใช้ตาม log รายละเอียดภายในอยู่ server log

## Logging

<!-- tutor-rich:## Logging -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Logging อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

Log request start/end, method/path template, status, duration, request ID และ identifiers ที่ไม่อ่อนไหว ห้าม log Authorization, password, token, full resume/PII หรือ raw body โดยไม่จำเป็น

## Authentication/Authorization

<!-- tutor-rich:## Authentication/Authorization -->
### คำอธิบายแบบเข้าใจง่าย

> **Authentication ถามว่าเป็นใคร Authorization ถามว่าคนนี้ทำสิ่งนี้ได้ไหม**

พิจารณา Flow ต่อไปนี้:

```text
Credential
  ↓ verify identity
ไม่ผ่าน → 401
  ↓ ผ่าน
ตรวจ permission
ไม่ผ่าน → 403 / ผ่าน → ทำงาน
```

#### จุดที่มักเข้าใจผิด

มี valid token ไม่ได้แปลว่ามีสิทธิ์ทุก resource

Authentication ตอบ “ใคร” Authorization ตอบ “ทำได้ไหม” การมี valid token ไม่ได้แปลว่าเข้าถึงทุก resource ได้ และ CORS ไม่ใช่ auth

## Configuration

<!-- tutor-rich:## Configuration -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Configuration อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

secret อยู่ environment/secret manager มี `.env.example` เฉพาะชื่อและค่าปลอม validate config ตอน startup และแยก dev/test/prod database

## Health

<!-- tutor-rich:## Health -->
### คำอธิบายแบบเข้าใจง่าย

> **Health endpoint ให้ระบบภายนอกรู้ว่า process ยังอยู่และพร้อมรับงานหรือไม่**

พิจารณา Flow ต่อไปนี้:

```text
Probe เรียก endpoint
  ↓ ตรวจ liveness/readiness
ตอบสถานะสั้น ๆ
  ↓
load balancer ส่งหรือหยุด traffic
```

#### จุดที่มักเข้าใจผิด

อย่าเปิด version/config/secret หรือ query dependency หนักเกินจำเป็นทุก probe

Liveness บอก process ยังทำงาน; readiness บอกพร้อมรับ traffic และ dependency สำคัญพร้อม อย่าให้ health endpoint เปิดข้อมูลระบบลึกเกินจำเป็น

