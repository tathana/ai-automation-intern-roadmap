# Special Challenge — API Sentinel

สร้าง API รับ transaction events และเรียก Risk Provider จำลอง โดยใช้ความรู้ Week 1–2

```text
Client/Webhook → FastAPI → Pydantic → Transaction Service
→ SQLite + Idempotency → Risk Client → Structured Response/Audit
```

อ่าน [Requirements](REQUIREMENTS.md), [Test Cases](TEST_CASES.md), [Hints](HINTS.md) และ [Rubric](GRADING_RUBRIC.md) ก่อนเริ่ม

