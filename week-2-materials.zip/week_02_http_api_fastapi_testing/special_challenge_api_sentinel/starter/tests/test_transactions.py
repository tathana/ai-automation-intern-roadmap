from fastapi.testclient import TestClient

from api_sentinel.main import app


def test_rejects_negative_amount() -> None:
    response = TestClient(app).post(
        "/api/v1/transactions",
        json={"transaction_id": "tx-1", "account_id": "a-1", "amount_satangs": -1, "currency": "THB"},
    )
    assert response.status_code == 422


def test_valid_transaction_is_created() -> None:
    response = TestClient(app).post(
        "/api/v1/transactions",
        json={"transaction_id": "tx-1", "account_id": "a-1", "amount_satangs": 100, "currency": "THB"},
    )
    assert response.status_code == 201

