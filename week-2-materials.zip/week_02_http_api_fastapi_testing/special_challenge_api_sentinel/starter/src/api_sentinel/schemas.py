from pydantic import BaseModel, ConfigDict, Field


class TransactionCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    transaction_id: str = Field(min_length=1, max_length=64)
    account_id: str = Field(min_length=1, max_length=64)
    amount_satangs: int = Field(ge=0)
    currency: str = Field(pattern=r"^[A-Z]{3}$")


class TransactionResponse(BaseModel):
    transaction_id: str
    status: str

