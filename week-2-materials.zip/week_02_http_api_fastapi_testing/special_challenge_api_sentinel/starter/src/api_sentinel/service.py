from .schemas import TransactionCreate, TransactionResponse


class TransactionConflict(Exception):
    pass


class TransactionService:
    def create(self, body: TransactionCreate) -> TransactionResponse:
        """TODO: validate business rules and persist idempotently."""
        raise NotImplementedError

