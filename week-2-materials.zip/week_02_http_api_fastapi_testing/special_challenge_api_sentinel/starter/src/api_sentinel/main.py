from fastapi import FastAPI, HTTPException

from .schemas import TransactionCreate, TransactionResponse
from .service import TransactionConflict, TransactionService

app = FastAPI(title="API Sentinel", version="0.1.0")
service = TransactionService()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/api/v1/transactions", response_model=TransactionResponse, status_code=201)
def create_transaction(body: TransactionCreate) -> TransactionResponse:
    try:
        return service.create(body)
    except TransactionConflict as exc:
        raise HTTPException(status_code=409, detail="transaction conflict") from exc

