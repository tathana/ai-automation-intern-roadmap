"""API Sentinel training project."""

