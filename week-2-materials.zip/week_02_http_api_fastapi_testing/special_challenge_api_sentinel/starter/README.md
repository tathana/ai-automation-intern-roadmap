# API Sentinel Starter

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
pytest -q
uvicorn api_sentinel.main:app --reload
```

Tests เริ่มต้นบางข้อควร fail เพราะ service/repository TODO เป็นส่วนของโจทย์ ห้ามใส่ token จริงใน `.env.example`

