# Grading Rubric — 100

- API contracts/status codes 20
- architecture/separation 15
- persistence/transaction/idempotency 20
- external-client reliability 15
- webhook safety 10
- automated tests 15
- README/logging/security 5

Critical failure: secret ใน repo/log, test ยิง production, SQL interpolation จาก input, duplicate สร้าง financial effect ซ้ำ, หรือ error ตอบ success ต้องแก้ก่อนถือว่าผ่าน

