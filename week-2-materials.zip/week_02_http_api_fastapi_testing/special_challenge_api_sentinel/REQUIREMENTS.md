# API Sentinel — Requirements

## Endpoints

- `GET /health`
- `POST /api/v1/transactions` รับ transaction ID, account ID, amount satangs, currency
- `GET /api/v1/transactions/{id}`
- `GET /api/v1/transactions/summary`
- `POST /webhooks/risk-results`

## Engineering

- Pydantic input/output models; unknown fields policy ชัด
- route/service/repository/client แยกกัน
- parameterized SQL และ transaction
- unique transaction/event ID ป้องกันผลซ้ำ
- risk client มี timeout และ error taxonomy
- webhook ตรวจ signature ผ่าน injectable verifier
- structured errors พร้อม request ID; ไม่เผย secret/traceback
- `.env.example`, README และ pytest

## Failure Policy

แยก invalid request, not found, conflict, provider timeout, rate limit, invalid provider response และ unexpected error ห้ามตอบ success เมื่อ critical persistence ล้ม

