# Progressive Hints

1. เขียน schemas และ contract table ก่อน route
2. ทำ service เป็น pure/use-case logic เท่าที่ทำได้
3. ใช้ repository interface และ test DB
4. ให้ unique constraint ตัดสิน duplicate ไม่พึ่ง SELECT อย่างเดียว
5. wrap provider library exception เป็น project error
6. override dependencies ใน FastAPI tests
7. ทดสอบ side effect จำนวน row ไม่ใช่ status อย่างเดียว

