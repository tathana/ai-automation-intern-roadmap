# Required Test Cases

1. health 200
2. valid transaction 201
3. missing/invalid amount 422
4. unknown field ตาม policy
5. GET missing ID 404
6. duplicate same payload idempotent
7. same ID changed payload 409
8. provider timeout mapped ตาม contract
9. provider invalid JSON/schema
10. DB failure rollback
11. valid webhook signature
12. invalid signature rejected
13. duplicate webhook no duplicate effect
14. response ไม่มี internal/secret field
15. summary ถูกต้องหลังหลายรายการ

