# Week 2 — HTTP, API, FastAPI และ Automated Testing

เล่มนี้เป็น textbook จาก “โปรแกรมของเรา” ไปสู่ “บริการที่ระบบอื่นเรียกได้” เนื้อหาเดิมเก็บศัพท์เทคนิคและคำอธิบายแบบเข้าใจง่ายไว้ ส่วนบท 09–10 เติม code walkthrough ตั้งแต่ไฟล์เปล่าและ architecture งานจริงสำหรับกลับมาเปิดระหว่างฝึกงาน

อ่านสามระดับตามเวลา:

- **Core:** บท 01–07 เข้าใจ HTTP, validation, route/service/repository และ tests
- **Practice:** ทำ drills และพิมพ์โค้ดบท 09 ด้วยตัวเอง อย่าคัดลอกอย่างเดียว
- **Deep Dive/Reference:** บท 08–10 ใช้ debug และออกแบบ service ที่ต่อ Week 3–5

## เป้าหมาย

เปลี่ยน logic จาก Week 1 ให้ระบบอื่นเรียกผ่าน HTTP ได้อย่างมี contract, validation, failure handling และ tests

```text
Client → HTTP → FastAPI → Pydantic → Service → SQLite/External API → Response
```

## บทเรียน

| บท | เนื้อหา |
|---|---|
| 00 | [Assessment](00_assessment.md) |
| 01 | [HTTP และ API Mental Model](01_http_api_foundation.md) |
| 02 | [Reliable API Client](02_reliable_api_client.md) |
| 03 | [FastAPI และ Pydantic](03_fastapi_pydantic.md) |
| 04 | [Architecture, Errors, Logging, Security](04_architecture_errors_security.md) |
| 05 | [Testing และ Mocking](05_testing_mocking.md) |
| 06 | [Webhooks และ Idempotency](06_webhooks_idempotency.md) |
| 07 | [Cheat Sheet](07_cheat_sheet.md) |
| 08 | [Deep Practical Companion](08_deep_practical_companion.md) |
| 09 | [FastAPI จากไฟล์เปล่า: Code Walkthrough](09_fastapi_from_zero_walkthrough.md) |
| 10 | [Real Service Blueprint และ Debugging](10_real_service_blueprint.md) |
| 11 | [Sources และ Verification](11_sources_and_verification.md) |

แบบฝึกอยู่ใน [`drills/`](drills/) และโจทย์ท้ายสัปดาห์อยู่ใน [`special_challenge_api_sentinel/`](special_challenge_api_sentinel/)

## วิธีเรียน

```text
อ่าน contract → วาด request/response → ทดลอง success
→ invalid input → dependency failure → อ่าน log → test → commit
```

## Definition of Done

- [ ] แยก method/path/query/header/body ได้
- [ ] เลือก status code และอธิบายเหตุผลได้
- [ ] external call มี timeout/retry policy
- [ ] route บางและแยก service/repository
- [ ] input/output ใช้ Pydantic models
- [ ] error ไม่เผย secret/traceback
- [ ] tests ไม่ยิง network/production DB จริง
- [ ] webhook ซ้ำไม่สร้างผลกระทบซ้ำ
- [ ] Challenge ผ่านอย่างน้อย 75%
