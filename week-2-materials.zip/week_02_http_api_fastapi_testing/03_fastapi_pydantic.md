# 03 — FastAPI และ Pydantic

```python
from fastapi import FastAPI
from pydantic import BaseModel, ConfigDict, Field

app = FastAPI(title="Transaction API")

class TransactionCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    transaction_id: str = Field(min_length=1, max_length=64)
    amount_satangs: int = Field(ge=0)

class TransactionResponse(BaseModel):
    transaction_id: str
    status: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/transactions", response_model=TransactionResponse, status_code=201)
def create_transaction(body: TransactionCreate):
    return TransactionResponse(transaction_id=body.transaction_id, status="created")
```

## Lifecycle

<!-- tutor-rich:## Lifecycle -->
### คำอธิบายแบบเข้าใจง่าย

> **หนึ่ง request ผ่านหลายด่านก่อนถึง function และอีกหลายด่านก่อนกลับเป็น response**

พิจารณา Flow ต่อไปนี้:

```text
HTTP bytes
  ↓ Route match
Dependencies + Pydantic validation
  ↓ Endpoint/Service/DB
Response validation → HTTP bytes
```

#### จุดที่มักเข้าใจผิด

422 อาจเกิดก่อน endpoint body รัน จึงอย่า debug service ก่อนอ่าน validation detail

```text
ASGI รับ bytes → match route → resolve dependencies → parse/validate
→ endpoint → response validation/serialization → HTTP response
```

422 อาจเกิดก่อน endpoint ทำงาน จึงต้องอ่าน response detail ก่อน debug service

## Sources

<!-- tutor-rich:## Sources -->
### คำอธิบายแบบเข้าใจง่าย

> **FastAPI ต้องรู้ว่าค่าแต่ละตัวมาจาก path, query, header หรือ body**

พิจารณา Flow ต่อไปนี้:

```text
URL path → path parameter
?key=value → query
Headers → metadata/auth
JSON body → Pydantic model
```

#### จุดที่มักเข้าใจผิด

ชื่อเหมือนกันแต่แหล่งต่างกันมี contract และความเสี่ยงต่างกัน

ค่าใน `{item_id}` คือ path parameter, ค่า default ธรรมดาใน GET มักเป็น query, Pydantic model มาจาก JSON body, headers/cookies/dependencies ต้องประกาศชัดเจน

## Required/Nullable/Default

<!-- tutor-rich:## Required/Nullable/Default -->
### คำอธิบายแบบเข้าใจง่าย

> **ไม่ส่ง field, ส่ง null และส่งค่าว่างเป็นสามกรณีคนละความหมาย**

พิจารณา Flow ต่อไปนี้:

```text
Field
  ├─ missing
  ├─ null → None
  └─ empty/zero
  ↓
Pydantic + business contract ตัดสิน
```

#### จุดที่มักเข้าใจผิด

Optional มักถูกใช้กำกวม ต้องเขียน default/type และ test missing กับ null แยกกัน

`name: str` ต้องส่งและห้าม null; `name: str | None` ต้องส่งแต่รับ null ตาม Pydantic version/config; `name: str | None = None` ไม่ส่งได้และ default null ต้อง test missing กับ explicit null แยกกัน

## Schema vs Business Rule

<!-- tutor-rich:## Schema vs Business Rule -->
### คำอธิบายแบบเข้าใจง่าย

> **Pydantic ตรวจรูปร่างและกฎใกล้ field ส่วน Service ตรวจความจริงทางธุรกิจที่ต้องดูข้อมูลอื่น**

พิจารณา Flow ต่อไปนี้:

```text
JSON
  ↓ Schema validation
ข้อมูลมีรูปถูกต้อง
  ↓ Business validation
operation ได้รับอนุญาตและสมเหตุผล
```

#### จุดที่มักเข้าใจผิด

amount เป็นเลขบวกไม่ได้แปลว่า account ยังใช้งานหรือวงเงินพอ

Pydantic ตรวจ shape/type/local constraints ส่วน service ตรวจ rule ที่ต้องใช้ DB/หลาย records เช่น account active หรือ daily limit อย่าใส่ network/DB call ใน validator

## Input/Output Models

<!-- tutor-rich:## Input/Output Models -->
### คำอธิบายแบบเข้าใจง่าย

> **แยก model ที่ client ส่ง กับ model ที่อนุญาตให้ client เห็น เพื่อไม่ปล่อย field ภายในออกไป**

พิจารณา Flow ต่อไปนี้:

```text
Request model
  ↓ Service/Internal model
  ↓ Repository
  ↓ Response model กรอง fields
JSON กลับ client
```

#### จุดที่มักเข้าใจผิด

อย่า return dict/DB row ทั้งก้อนเพราะอาจมี secret หรือ internal note

แยก create/internal/response เพื่อไม่ให้ internal note, credential หรือ DB fields หลุด ควรใช้ response model เป็น outbound contract

## Sync/Async

<!-- tutor-rich:## Sync/Async -->
### คำอธิบายแบบเข้าใจง่าย

> **Async ช่วยให้ worker ไปดูแลงานอื่นระหว่างรอ I/O ไม่ได้ทำให้การคำนวณหนักเร็วขึ้นเอง**

พิจารณา Flow ต่อไปนี้:

```text
async request
  ↓ await I/O
event loop ดูแลงานอื่น
  ↓ I/O พร้อม
กลับมาทำต่อ
```

#### จุดที่มักเข้าใจผิด

เรียก blocking library หรือ time.sleep ใน async route ยังบล็อก event loop

`async def` ช่วยเมื่อรอ async I/O ไม่ทำ CPU work เร็วขึ้น ห้ามเรียก blocking I/O หรือ `time.sleep()` ใน async route โดยไม่เข้าใจ event loop

## Run

<!-- tutor-rich:## Run -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Run อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

```bash
uvicorn app.main:app --reload
```

`app.main` คือ module และ `app` หลัง colon คือ object; reload เหมาะ development

