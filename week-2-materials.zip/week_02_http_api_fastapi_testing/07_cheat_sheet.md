# 07 — Week 2 Cheat Sheet

```bash
uvicorn app.main:app --reload
curl -i http://localhost:8000/health
pytest -q
```

## ก่อนสร้าง Endpoint

<!-- tutor-rich:## ก่อนสร้าง Endpoint -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า ก่อนสร้าง Endpoint อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

กำหนด method/path/auth/input/output/status/side effect/idempotency/failures ก่อนเขียน route

## ก่อน External Call

<!-- tutor-rich:## ก่อน External Call -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า ก่อน External Call อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

กำหนด timeout, accepted statuses, response schema, retryable cases, max retries, backoff และ fake สำหรับ tests

## Debug Order

<!-- tutor-rich:## Debug Order -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Debug Order อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

request URL/method → headers/content type → raw response status/body → Pydantic validation → service → repository/DB → external dependency

## Status

<!-- tutor-rich:## Status -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Status อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

201 created; 400 malformed/general bad request; 401 unauthenticated; 403 forbidden; 404 missing; 409 conflict; 422 validation; 429 rate limit; 500 bug; 502/503/504 upstream/availability/timeout

## หยุดก่อน

<!-- tutor-rich:## หยุดก่อน -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า หยุดก่อน อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

ห้าม log token/body อ่อนไหว, ยิง provider จริงใน unit test, retry ไม่จำกัด, catch `Exception` แล้วตอบ 200, return raw DB model หรือใช้ production DB ใน tests

