# 10 — Real Service Blueprint และ Debugging

บทนี้รวม Week 2 ให้เห็นเป็นบริการที่ต่อเข้ากับ n8n, AI และ worker ในสัปดาห์ถัดไป ใช้ case Resume Intake ด้วย metadata สังเคราะห์ ไม่รับไฟล์/ข้อมูลจริงในตัวอย่าง

## Problem Statement

ระบบรับคำขอสร้างงานอ่าน resume แล้วตอบ task ID เพื่อให้ caller ตรวจสถานะภายหลัง เป้าหมาย Week 2 คือออกแบบ HTTP contract และขอบเขต service ยังไม่ให้ AI อ่านหรือตัดสินผู้สมัคร

```text
Client/n8n
  │ POST /resume-intakes
  │ Idempotency-Key: HR-001
  │ {candidate_id, file_ref, file_hash}
  v
FastAPI → input validation → auth/policy → IntakeService → Repository
  │                                                   ↓ durable task
  └── 202 {task_id, status:"queued", duplicate:false}
```

## Contract ก่อนเขียนโค้ด

Request:

```http
POST /api/v1/resume-intakes HTTP/1.1
Content-Type: application/json
Idempotency-Key: HR-001
Authorization: Bearer <redacted>

{
  "candidate_id": "C-SYNTH-001",
  "file_ref": "fixture://resume/synth-001",
  "file_hash": "sha256-example"
}
```

Responses:

| กรณี | HTTP | body สำคัญ |
|---|---:|---|
| สร้าง task ใหม่ | 202 | task_id, queued, duplicate=false |
| key+payload เดิม | 200 หรือ 202 ตาม contract | task เดิม, duplicate=true |
| key เดิม payload ต่าง | 409 | idempotency_conflict |
| field/type ผิด | 422 | validation details |
| ไม่มี/ไม่ถูกต้อง credential | 401 | generic auth error |
| มีตัวตนแต่ไม่มีสิทธิ์ | 403 | forbidden |
| database ไม่พร้อม | 503 | dependency_unavailable + trace_id |

เลือก behavior duplicate ให้ชัดและ test ตาม contract ไม่จำเป็นต้องเหมือนทุกระบบ

## แยก Layers และความรับผิดชอบ

```text
Router       HTTP parsing/status/header + call service
Schema       shape/type/field constraints
Service      use case + business transitions
Repository   persistence/query/unique constraint/transaction
Client       calls external services with timeout policy
Worker       processes queued task later (Week 5)
```

route ที่ยาวมักเกิดเพราะ validation, SQL, external calls และ error mapping ถูกวางรวมกัน แยกชั้นเพื่อให้แต่ละ failure test ได้ตรง boundary

## Synchronous กับ Asynchronous Contract

แบบ synchronous:

```text
request → อ่านไฟล์ → เรียก AI → validate → save → response
client รอทั้งหมด; timeout/retry ซับซ้อนและ request นาน
```

แบบ asynchronous:

```text
request → validate → persist queued task → 202
                                  ↓ ภายหลัง
                           worker → analyze → result
client → GET /tasks/{id} → queued/processing/succeeded/needs_review/failed
```

ห้ามตอบ 202 ก่อน persist task สำเร็จ และ `BackgroundTasks` ใน process เดียวไม่ได้กลายเป็น durable queue โดยอัตโนมัติ หาก process ตาย งานที่ยังไม่เก็บอย่างทนทานอาจหาย ประเด็น worker/lease/crash recovery อยู่ Week 5

## Error Mapping: จากสาเหตุสู่ response

```text
Pydantic error            → 422 invalid_request
TaskNotFound              → 404 task_not_found
IdempotencyConflict       → 409 idempotency_conflict
DatabaseTemporarilyDown   → 503 dependency_unavailable
unexpected exception      → 500 internal_error + trace_id
```

client ต้องได้ error body ที่เสถียรพอให้เขียน logic แต่ไม่ควรได้ SQL, stack trace, secret หรือ raw resume

ตัวอย่าง error body:

```json
{
  "error": {
    "code": "idempotency_conflict",
    "message": "The key was already used with different input",
    "trace_id": "trace-synthetic-7"
  }
}
```

## End-to-End Debug Map

```text
Client says timeout
   ↓ มี request ใน access log หรือไม่
ไม่มี → DNS/TLS/network/proxy/client timeout
มี   → route เริ่มหรือไม่ + trace_id
          ↓
     validation ผ่านหรือไม่
          ↓
     service เรียก dependency ใด
          ↓
     DB commit สำเร็จหรือ rollback
          ↓
     response ถูกสร้างแต่กลับไม่ถึง clientหรือไม่
```

เมื่อ client timeout หลัง server commit อาจมี task ถูกสร้างแล้ว การ retry ด้วย idempotency key เดิมควรคืน task เดิม ไม่สร้างใหม่

## Observability ที่พอใช้ตามงาน

structured log ต่อ transition:

```json
{
  "event": "resume_intake_created",
  "trace_id": "trace-synthetic-7",
  "task_id": "TASK-7",
  "candidate_ref": "C-SYNTH-001",
  "status": "queued",
  "duration_ms": 24
}
```

ไม่ log raw authorization header, file bytes หรือ resume text Metrics ขั้นต้น: request count/status, latency, validation failures, duplicate/conflict rate และ dependency error rate

## Test Matrix

| ชั้น | Test | ไม่ควรแตะ |
|---|---|---|
| service unit | state/business errors | HTTP/server/real DB |
| repository integration | unique key/transaction | external API |
| API contract | status/body/headers | production DB/network |
| external client | timeout/error translation ด้วย mock transport | provider จริง |
| end-to-end staging | network/config/persistence จริงของ staging | production data |

เขียน negative cases ก่อนต่อ Week 3: missing field, malformed JSON, duplicate same payload, duplicate changed payload, unauthorized, forbidden, DB unavailable และ client replay

## Security Boundary

- authenticate caller ก่อนทำงานที่ต้องมีตัวตน
- authorize ว่า caller เข้าถึง candidate/task นี้ได้
- validate file reference ตาม allowlist/scope ไม่เปิด arbitrary local path หรือ URL
- จำกัด request size/rate และไม่เชื่อ filename/content type เพียงอย่างเดียว
- ใช้ synthetic data ใน lab และตรวจ policy/retention ก่อนข้อมูลจริง

## From Week 2 to Week 5

```text
Week 2 FastAPI contract
       ↓ Week 3 n8n เรียก API และ route outcomes
Week 4 analysis service คืน validated/review result
       ↓ Week 5 durable worker จัดการ queued task/retry/crash
ระบบรวม: API + orchestration + guarded AI + operational reliability
```

## Mini Project: Intake API Design Pack

ส่งมอบโดยยังไม่ต้องมี AI:

1. OpenAPI/contract สำหรับ POST intake และ GET task
2. Pydantic request/response models
3. thin routes + service + repository interface
4. idempotency behavior และ state machine
5. test matrix อย่างน้อย 10 cases
6. run instructions, sample curl และ known limitations

หากอีกคนอ่านแล้วรู้ว่าจะส่งอะไร, ได้สถานะใด, retry อย่างไร และตาม task ที่ไหน งาน Week 2 ของคุณพร้อมต่อ n8n แล้ว
