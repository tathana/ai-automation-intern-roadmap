# 01 — HTTP และ API Mental Model

## Client/Server

<!-- tutor-rich:## Client/Server -->
### คำอธิบายแบบเข้าใจง่าย

> **Client คือฝ่ายเริ่มถาม ส่วน Server คือฝ่ายรอรับและตอบ โปรแกรมเดียวสลับบทบาทได้**

พิจารณา Flow ต่อไปนี้:

```text
n8n เป็น client → FastAPI เป็น server
FastAPI เรียก AI provider
  ↓
FastAPI กลายเป็น client → Provider เป็น server
```

#### จุดที่มักเข้าใจผิด

อย่ายึดว่าโปรแกรมหนึ่งต้องเป็น client หรือ server ตลอด ให้ดูการเชื่อมต่อหนึ่งช่วง

เป็นบทบาท ไม่ใช่ชนิดโปรแกรม: `n8n → FastAPI → AI provider` ทำให้ FastAPI เป็น server ต่อ n8n และเป็น client ต่อ provider

## Request

<!-- tutor-rich:## Request -->
### คำอธิบายแบบเข้าใจง่าย

> **HTTP request คือซองงานที่มีวิธีทำ ที่อยู่ ข้อมูลกำกับ และข้อมูลข้างใน**

พิจารณา Flow ต่อไปนี้:

```text
Method + Path/Query
  ↓
Headers บอก metadata
  ↓
Body ส่ง payload
  ↓
Server parse และ validate
```

#### จุดที่มักเข้าใจผิด

URL ถูกอย่างเดียวไม่พอ Method, Content-Type และ body ต้องตรง contract ด้วย

- method: เจตนา
- path: resource
- query: filter/options
- headers: metadata/auth/media type/request ID
- body: payload bytes ซึ่งอาจเป็น JSON

```text
bytes → decode text → parse JSON → dict/list → validate model
```

แต่ละขั้นล้มต่างกัน อย่าเรียกทุกอย่างว่า “JSON error”

## Methods

<!-- tutor-rich:## Methods -->
### คำอธิบายแบบเข้าใจง่าย

> **HTTP method บอกเจตนา GET อ่าน, POST สร้าง/สั่งงาน, PUT แทนทั้งก้อน, PATCH แก้บางส่วน และ DELETE ลบ**

พิจารณา Flow ต่อไปนี้:

```text
Requirement
  ↓ เลือกเจตนา
HTTP Method
  ↓
กำหนด side effect และ idempotency
```

#### จุดที่มักเข้าใจผิด

Method ไม่ได้ป้องกัน code จากการทำผิดเอง แต่เป็นข้อตกลงที่ client และ server ใช้ร่วมกัน

| Method | ใช้ทั่วไป | Idempotent ตาม semantics |
|---|---|---|
| GET | อ่าน | yes |
| POST | สร้าง/สั่งงาน | ไม่รับประกัน |
| PUT | แทน resource | yes |
| PATCH | แก้บางส่วน | ไม่รับประกัน |
| DELETE | ลบ | yes |

Idempotent หมายถึง intended state หลังทำซ้ำเหมือนทำครั้งเดียว ไม่ได้แปลว่า log/response ทุกครั้งเหมือนกัน

## Status Codes

<!-- tutor-rich:## Status Codes -->
### คำอธิบายแบบเข้าใจง่าย

> **Status code คือคำตอบสั้น ๆ ว่า request จบแบบไหน ก่อนที่ client จะอ่านรายละเอียดใน body**

พิจารณา Flow ต่อไปนี้:

```text
Request
  ↓ Server ประมวลผล
เลือกกลุ่ม 2xx / 4xx / 5xx
  ↓
Client ตัดสิน success, แก้ request หรือ retry
```

#### จุดที่มักเข้าใจผิด

401 คือยังยืนยันตัวตนไม่ได้ ส่วน 403 คือรู้ว่าเป็นใครแต่ไม่มีสิทธิ์; 500 ไม่ควรใช้แทน error ทุกชนิด

`200` สำเร็จ, `201` สร้างแล้ว, `204` ไม่มี body, `400` request ผิด, `401` ยังยืนยันตัวตนไม่ได้, `403` ไม่มีสิทธิ์, `404` ไม่พบ, `409` state conflict, `422` validation ไม่ผ่าน, `429` rate limit, `500` unexpected server bug, `502/503/504` upstream/availability/timeout

Status เป็น contract อย่าตอบ 200 แล้วซ่อน error ทุกชนิดใน body

## Headers

<!-- tutor-rich:## Headers -->
### คำอธิบายแบบเข้าใจง่าย

> **Header คือข้อมูลกำกับ request/response เช่นชนิดข้อมูล token และ request ID ไม่ใช่ business payload หลัก**

พิจารณา Flow ต่อไปนี้:

```text
Client สร้าง body
  + Headers
  ↓
Server อ่าน Content-Type/Auth
  ↓
parse, authenticate และตาม request
```

#### จุดที่มักเข้าใจผิด

Authorization header อาจจำเป็นต่อระบบ แต่ห้ามพิมพ์หรือ log token เต็ม ๆ

`Content-Type` บอกชนิด body ที่ส่ง; `Accept` บอกชนิด response ที่ต้องการ; `Authorization` ห้าม log; request/correlation ID ช่วยตามหนึ่ง request ข้ามระบบ

## Webhook/Polling

<!-- tutor-rich:## Webhook/Polling -->
### คำอธิบายแบบเข้าใจง่าย

> **Webhook คือระบบต้นทางเป็นฝ่ายโทรหาเราเมื่อมีเหตุการณ์ จึงไม่ต้องถามซ้ำ ๆ แบบ polling**

พิจารณา Flow ต่อไปนี้:

```text
Event เกิดที่ provider
  ↓ POST webhook
Verify → Deduplicate → Persist
  ↓
ตอบเร็ว แล้วประมวลผลต่อ
```

#### จุดที่มักเข้าใจผิด

Webhook ส่งซ้ำได้ตามปกติ การได้รับซ้ำไม่ใช่ bug และ handler ต้อง idempotent

Polling คือเราไปถามเป็นระยะ Webhook คือต้นทางเรียกเราเมื่อเกิด event จึงต้องรับมือ duplicate, retry, signature, out-of-order และตอบเร็ว

## Inspect

<!-- tutor-rich:## Inspect -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Inspect อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

```bash
curl -i http://localhost:8000/health
curl -i -X POST http://localhost:8000/items -H "Content-Type: application/json" -d '{"name":"demo"}'
```

ดู status, headers และ body แยกกัน อย่าใส่ token จริงใน command history

