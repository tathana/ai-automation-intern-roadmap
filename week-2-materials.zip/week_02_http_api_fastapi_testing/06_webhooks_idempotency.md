# 06 — Webhooks และ Idempotency

## Webhook Reality

<!-- tutor-rich:## Webhook Reality -->
### คำอธิบายแบบเข้าใจง่าย

> **Webhook คือระบบต้นทางเป็นฝ่ายโทรหาเราเมื่อมีเหตุการณ์ จึงไม่ต้องถามซ้ำ ๆ แบบ polling**

พิจารณา Flow ต่อไปนี้:

```text
Event เกิดที่ provider
  ↓ POST webhook
Verify → Deduplicate → Persist
  ↓
ตอบเร็ว แล้วประมวลผลต่อ
```

#### จุดที่มักเข้าใจผิด

Webhook ส่งซ้ำได้ตามปกติ การได้รับซ้ำไม่ใช่ bug และ handler ต้อง idempotent

Provider อาจ retry เมื่อไม่ได้ 2xx, ส่งซ้ำ, ส่งช้า, out-of-order หรือปลอม request ได้ Endpoint จึงต้อง verify → deduplicate → persist → enqueue/process → acknowledge ตาม contract

## Signature

<!-- tutor-rich:## Signature -->
### คำอธิบายแบบเข้าใจง่าย

> **Signature ช่วยตรวจว่า webhook body มาจากผู้ถือ secret และไม่ถูกแก้ระหว่างทาง**

พิจารณา Flow ต่อไปนี้:

```text
Raw body + timestamp
  ↓ คำนวณ/verify signature
ไม่ผ่าน → reject
ผ่าน → parse และ process
```

#### จุดที่มักเข้าใจผิด

ต้อง verify raw bytes ก่อนเปลี่ยนรูปข้อความและใช้ algorithm ตาม provider

ตรวจ signature จาก raw request bytes ก่อน parse/เปลี่ยน whitespace ใช้ shared secret/public-key scheme ตาม provider, constant-time comparison และ timestamp tolerance ป้องกัน replay ห้ามคิด algorithm เอง

## Idempotency

<!-- tutor-rich:## Idempotency -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Idempotency อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

ใช้ provider event ID หรือ stable idempotency key พร้อม unique constraint:

```sql
CREATE TABLE webhook_events (
  event_id TEXT PRIMARY KEY,
  payload_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  received_at TEXT NOT NULL
);
```

ID เดิม hash เหมือน → คืนผลตาม contract; ID เดิม hash ต่าง → conflict/security signal; ห้าม deduplicate ด้วย timestamp อย่างเดียว

## Race Condition

<!-- tutor-rich:## Race Condition -->
### คำอธิบายแบบเข้าใจง่าย

> **สอง worker อาจตรวจว่าไม่มีข้อมูลพร้อมกันแล้ว insert พร้อมกัน Unique constraint จึงเป็นกรรมการสุดท้าย**

พิจารณา Flow ต่อไปนี้:

```text
Worker A/B: SELECT ไม่พบ
  ↓ ทั้งคู่ INSERT
DB unique constraint
  ↓ หนึ่งสำเร็จ
อีกหนึ่ง duplicate/conflict
```

#### จุดที่มักเข้าใจผิด

check-before-insert อย่างเดียวไม่ปลอดภัยภายใต้ concurrency

“SELECT ก่อน INSERT” สอง worker อาจเห็นว่าไม่มีพร้อมกัน ให้ DB unique constraint เป็น safety net และจัดการ conflict อย่างตั้งใจ

## Fast Acknowledge

<!-- tutor-rich:## Fast Acknowledge -->
### คำอธิบายแบบเข้าใจง่าย

> **Webhook ควรยืนยันรับเร็วแล้วโยนงานยาวไป queue เพื่อลด timeout และการส่งซ้ำ**

พิจารณา Flow ต่อไปนี้:

```text
Verify + persist event
  ↓ enqueue durable work
ตอบ 2xx เร็ว
  ↓ worker ทำ AI/OCR
บันทึก outcome
```

#### จุดที่มักเข้าใจผิด

ตอบก่อน persist/enqueue สำเร็จอาจทำ event หาย

งานยาวควร persist/enqueue แล้วตอบเร็ว หากทำ AI/OCR ก่อนตอบ provider อาจ timeout และ retry เพิ่ม duplicate load แต่ต้องแน่ใจว่า queue handoff ไม่ทำ event หาย

## Status Machine

<!-- tutor-rich:## Status Machine -->
### คำอธิบายแบบเข้าใจง่าย

> **แทน boolean done ใช้สถานะหลายขั้นเพื่อรู้ว่าค้าง ล้มแบบ retry ได้ หรือรอคนตรวจ**

พิจารณา Flow ต่อไปนี้:

```text
received → processing
  ├→ completed
  ├→ failed_retryable → retry
  └→ manual_review
```

#### จุดที่มักเข้าใจผิด

กำหนด transition ที่อนุญาตและ audit ทุกการเปลี่ยน

`received → processing → completed` หรือ `failed_retryable/failed_permanent/manual_review` ช่วย resume หลัง crash และ audit ได้ อย่าใช้ boolean `done` เมื่อสถานการณ์มากกว่าสองแบบ

## Tests

<!-- tutor-rich:## Tests -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Tests อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

valid signature, invalid signature, expired timestamp, duplicate same payload, duplicate changed payload, out-of-order, handler crash และ retry หลัง timeout

