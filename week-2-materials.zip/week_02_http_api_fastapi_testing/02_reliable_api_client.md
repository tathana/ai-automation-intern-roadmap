# 02 — Reliable API Client

## Failure ที่ต้องคิด

<!-- tutor-rich:## Failure ที่ต้องคิด -->
### คำอธิบายแบบเข้าใจง่าย

> **การเรียก API ไม่ได้มีแค่ผ่านกับไม่ผ่าน ต้องแยกว่าเชื่อมไม่ได้ รอนาน status ผิด หรือ body ผิด**

พิจารณา Flow ต่อไปนี้:

```text
เรียก API
  ↓
connect/read timeout หรือ response
  ↓
status check → parse → schema validation
  ↓
result หรือ error category
```

#### จุดที่มักเข้าใจผิด

HTTP 200 ยังมี JSON หรือ schema ที่ผิดได้ อย่าใช้ status อย่างเดียวตัดสิน

DNS/connect error, connect/read timeout, TLS error, 4xx, 5xx, invalid JSON, schema drift, 429 และ response ช้า

```python
import httpx

def fetch_item(item_id: str) -> dict:
    timeout = httpx.Timeout(10.0, connect=3.0)
    with httpx.Client(timeout=timeout) as client:
        response = client.get(f"https://example.invalid/items/{item_id}")
        response.raise_for_status()
        payload = response.json()
    if not isinstance(payload, dict):
        raise ValueError("response must be an object")
    return payload
```

HTTP 200 ไม่รับประกันว่า body ถูก schema ต้อง validate ก่อนใช้

## Retry

<!-- tutor-rich:## Retry -->
### คำอธิบายแบบเข้าใจง่าย

> **Retry คือการลองใหม่เฉพาะความล้มเหลวชั่วคราว ไม่ใช่วนซ้ำทุก error**

พิจารณา Flow ต่อไปนี้:

```text
Failure
  ↓ จำแนก retryable?
ไม่ → report
ใช่ → wait/backoff+jitter
  ↓ จำกัด attempts/deadline
ลองใหม่
```

#### จุดที่มักเข้าใจผิด

Retry POST อาจทำ side effect ซ้ำ ต้องรู้ idempotency ของ operation ก่อน

มัก retry ได้: transient timeout, 429 ตาม `Retry-After`, 502/503/504 บางกรณี มักไม่ retry 400/401/403/404/422 โดยไม่แก้ request

Retry ต้องมี max attempts, exponential backoff, jitter, overall deadline, logging และ idempotency safety ห้าม loop ทันทีไม่จำกัด

## POST Risk

<!-- tutor-rich:## POST Risk -->
### คำอธิบายแบบเข้าใจง่าย

> **Server อาจทำงานสำเร็จแต่ response หาย Client จึงเห็น timeout ทั้งที่ side effect เกิดแล้ว**

พิจารณา Flow ต่อไปนี้:

```text
POST ถึง server
  ↓ สร้างรายการสำเร็จ
Response หาย/timeout
  ↓ Client retry
เสี่ยงสร้างซ้ำถ้าไม่มี idempotency key
```

#### จุดที่มักเข้าใจผิด

Timeout บอกว่าเราไม่ได้รับคำตอบ ไม่ได้พิสูจน์ว่า server ไม่ได้ทำงาน

ถ้า server ทำ side effect สำเร็จแต่ response หาย client จะเห็น timeout การ retry อาจทำซ้ำ ต้องใช้ idempotency key ที่ provider รองรับและเก็บผลเดิม

## Pagination

<!-- tutor-rich:## Pagination -->
### คำอธิบายแบบเข้าใจง่าย

> **API มักส่งข้อมูลทีละหน้า หน้าแรกจึงไม่เท่ากับข้อมูลทั้งหมด**

พิจารณา Flow ต่อไปนี้:

```text
Request page/cursor แรก
  ↓ รับ items + next
เก็บ items
  ↓ มี next? วนต่อ
ไม่มี next → จบ
```

#### จุดที่มักเข้าใจผิด

ต้องมี safety limit และตรวจ cursor ไม่เปลี่ยน เพื่อไม่วนไม่รู้จบ

อ่าน next cursor/page metadata จนจบ พร้อม safety limit อย่าสันนิษฐานว่าหน้าแรกคือข้อมูลทั้งหมด

## Design for Tests

<!-- tutor-rich:## Design for Tests -->
### คำอธิบายแบบเข้าใจง่าย

> **หัวข้อนี้อธิบายว่า Design for Tests อยู่ตรงไหนใน request lifecycle และช่วยให้ระบบถูกต้องอย่างไร**

พิจารณา Flow ต่อไปนี้:

```text
Input/Request
  ↓ ใช้แนวคิดของหัวข้อนี้
State/ข้อมูลถูกตรวจหรือเปลี่ยน
  ↓
Output หรือ error ตาม contract
```

#### จุดที่มักเข้าใจผิด

อย่าจำเฉพาะ syntax ให้ถามว่า input, output, side effect และ failure คืออะไร

Inject client/interface แทนสร้าง client ลึกใน business function เพื่อ fake timeout/status/body ได้โดยไม่ยิงอินเทอร์เน็ต

