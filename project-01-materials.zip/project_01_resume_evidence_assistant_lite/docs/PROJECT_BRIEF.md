# Project Brief — เติมก่อนเขียน Code

วันที่ / version:
Problem และผู้ใช้:
Current process/baseline ที่สมมติสำหรับ lab:
Target outcome:

## Scope

In scope:
Out of scope:
Constraints:
Assumptions + วิธีพิสูจน์:

## Success และ Guardrails

Outcome metric:
Technical evidence:
Must-not-happen:

## Plan

Milestone แรกและ demo date:
Top risks/unknowns:
Decision owner ในโปรเจกต์จำลอง:

Ready when: คุณอธิบาย why/what/not-what/how-proven ได้ภายในสองนาที

