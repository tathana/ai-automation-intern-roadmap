# Architecture Decision Log

## ADR-001 — Text input and mock provider first

Status: proposed  
Context:
Decision:
Alternatives:
Consequences:
Validation/revisit trigger:

## ADR-002 — Persistence and worker boundary

Status: proposed  
Context:
Decision:
Alternatives:
Consequences:
Crash/restart verification:

## ADR-003 — Idempotency scope

Status: proposed  
Business key:
Canonical payload fields:
Same key/same payload behavior:
Same key/different payload behavior:
Retention/limitation:

