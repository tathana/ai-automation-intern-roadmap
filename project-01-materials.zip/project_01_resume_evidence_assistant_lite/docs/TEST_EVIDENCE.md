# Test and Demo Evidence

Commit / environment / Python version / date:

| ID | Command/request | Expected | Actual | Result/evidence |
|---|---|---|---|---|
| TEST-01 | | | | |

## Failure Drill

Scenario:
State before:
Action/failure injected:
Expected transition/log/audit:
Actual:
Recovery steps:
State after:
Limitation/follow-up:

## n8n Evidence

Workflow version/export:
Synthetic execution IDs:
Pinned data removed:
Normal/duplicate/conflict/failure actual results:

