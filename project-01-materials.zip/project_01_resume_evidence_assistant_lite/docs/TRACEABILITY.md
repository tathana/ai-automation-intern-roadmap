# Requirement Traceability

เติมตารางนี้ก่อนเริ่ม implementation แล้วอัปเดตเมื่อ requirement หรือ test เปลี่ยน จุดประสงค์คือพิสูจน์ว่าแต่ละข้อกำหนดมี code boundary และหลักฐานรองรับ ไม่ใช่เพียงบอกว่า “ทำครบแล้ว”

| Requirement ID | Requirement | Code boundary/owner | Test ID | Evidence | Status |
|---|---|---|---|---|---|
| REQ-API-01 | valid intake returns durable task | | TEST-03 | | Planned |
| REQ-IDEM-01 | same event + same payload returns same task | | TEST-05 | | Planned |
| REQ-IDEM-02 | same event + changed payload conflicts | | TEST-06 | | Planned |
| REQ-AI-01 | quoted evidence must exist in source | | TEST-07, TEST-09 | | Planned |
| REQ-AI-02 | absent skill must not be invented | | TEST-08 | | Planned |
| REQ-WRK-01 | retry is bounded and observable | | TEST-10, TEST-11 | | Planned |
| REQ-REV-01 | final decision requires valid human action | | TEST-12, TEST-13 | | Planned |
| REQ-DUR-01 | accepted work survives restart | | TEST-14 | | Planned |
| REQ-SEC-01 | logs do not expose raw resume | | TEST-15 | | Planned |
| REQ-N8N-01 | workflow preserves API truth | | TEST-16 | | Planned |

## วิธีใช้

1. แทน `Code boundary/owner` ด้วย module/function/table/node ที่รับผิดชอบ
2. ใส่ exact command, report path, execution ID หรือ screenshot reference ใน Evidence
3. ใช้สถานะ `Planned`, `Implemented`, `Verified`, `Blocked`
4. ถ้า requirement เปลี่ยน ให้อัปเดต requirement, acceptance test และ implementation พร้อมกัน
5. ก่อน demo ต้องไม่มี critical requirement ที่ยังเป็น `Planned` โดยไม่ระบุ limitation
