# Runbook — Resume Evidence Assistant Lite

Status/environment/commit:
Components and owners:
Known limitations: synthetic text, mock provider, demo reviewer identity

## Setup and configuration

Prerequisites:
Config names (no secret values):
Initialize DB/schema:

## Normal operation

Start API:
Readiness expected:
Run worker once:
Submit/check/review task:
Stop safely:

## Debug and recovery

Find task/audit without exposing resume:
Duplicate/conflict handling:
Provider transient/invalid output:
Task stuck processing:
Safe replay rule:
Reset lab data safely:

## Handoff rehearsal

Recipient/date:
Clean setup result:
Failure drill result:
Questions/docs fixed:

