# 04 — Hint Ladder

เปิดทีละระดับและจดว่าติดเพราะ mental model, syntax, environment หรือ design

## Milestone 1 Hints

### Level 1

เริ่มด้วย `BaseModel` แยก IntakeRequest/Response อย่าใช้ dict ไหลทุก layer ให้ route เรียก service ผ่าน dependency ที่เปลี่ยนเป็น fake ใน test ได้

### Level 2

Pydantic validator สามารถ normalize skills แล้วตรวจค่าซ้ำ ควรตัดสินว่าเก็บ display casing อย่างไรและ hash ใช้รูป normalized แบบใด

### Level 3

ถ้า `422` test ยาก ให้เขียน request JSON จริงผ่าน FastAPI TestClient/HTTPX transport และ inspect error body อย่าเรียก function route ตรงจนข้าม framework validation

## Milestone 2 Hints

### Level 1

วาง unique constraint ที่ DB ไม่ใช่ `SELECT` แล้วหวังว่าไม่มี request พร้อมกัน

### Level 2

ใช้ `json.dumps(..., sort_keys=True, separators=(",", ":"), ensure_ascii=False)` กับ canonical dict แล้ว `hashlib.sha256(bytes).hexdigest()`; เขียน test field order ต่างแต่ logical payload เดิม

### Level 3

เมื่อ insert ชน unique ให้ query task เดิมภายใน error handling แล้วเทียบ payload hash: เท่ากันคือ duplicate ต่างกันคือ conflict ระวัง transaction state หลัง integrity error

## Milestone 3 Hints

### Level 1

Provider คืน raw candidate draft; validator เป็นคนตัดสิน supported อย่าให้ mock providerตั้ง `supported=true` แล้วเชื่อทันที

### Level 2

normalize quote/source สำหรับ comparison อย่างระมัดระวัง เช่น whitespace/case แต่เก็บ quote ต้นฉบับสำหรับแสดง อย่า fuzzy match กว้างจนคำแต่งผ่าน

### Level 3

แยก exception เป็น `TransientProviderError`, `PermanentProviderError`, `InvalidProviderOutput` แล้ว map ไป state/retry policy ที่ test ได้

## Milestone 4 Hints

### Level 1

สร้าง pure function `transition(current, action)` ก่อน repository transaction จะเห็น allowed/invalid cases ชัด

### Level 2

review write, task state update และ audit ควรสำเร็จ/ล้มเหลวร่วมกัน

### Level 3

ถ้าต้องป้องกัน double submit review เพิ่ม review request ID/idempotency rule หรือประกาศว่า second action on final state คืน 409 พร้อม test

## n8n Hints

- ดู Output pane ของ HTTP node ก่อนเขียน Switch path
- ถ้าเปิด Never Error ให้ HTTP failure กลายเป็น data; ต้อง route เอง
- timeout outcome อาจ unknown ใช้ event ID เดิม ไม่สร้างใหม่สุ่ม
- unpin ก่อน whole-flow evidence
- localhost จาก container ไม่ใช่ Windows host

## Debug Card

```text
Expected:
Actual:
Exact command/request:
CWD/interpreter/version:
Small synthetic reproduction:
Last known correct boundary:
First incorrect boundary:
Evidence collected:
One variable to change next:
```

