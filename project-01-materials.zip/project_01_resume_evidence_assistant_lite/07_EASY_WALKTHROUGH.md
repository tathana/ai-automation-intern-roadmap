# 07 — Easy Walkthrough: มองระบบให้ออกก่อนเขียน

บทนี้ไม่เพิ่ม requirement ใหม่ แต่ช่วยแปลโจทย์เดิมให้เป็นภาพในหัว ถ้าเริ่มงงให้กลับมาถามว่า “ตอนนี้ข้อมูลอยู่ตรงไหน ใครเป็นเจ้าของกฎ และมีอะไรถูก commit แล้ว”

## 1. ระบบนี้กำลังช่วยอะไร

สมมติ HR มี Resume จำนวนมาก งานที่เสียเวลาคือเปิดเอกสาร มองหาทักษะ คัดข้อความอ้างอิง และจัดข้อมูลเตรียม review เราจะให้ระบบช่วย “เตรียมหลักฐาน” แต่ไม่ให้ระบบตัดสินว่าควรรับใคร

```text
งานของระบบ: อ่าน → หา → จัดรูป → ตรวจย้อนกลับ → รอคน
งานที่ไม่ทำ: ให้คะแนน → จัดอันดับ → ปฏิเสธ → จ้าง
```

เหตุผลที่แยกแบบนี้ไม่ใช่เพียงเรื่องโค้ด แต่เป็น **scope boundary** และ **decision boundary** ที่ช่วยควบคุมความเสี่ยง

## 2. ทำไม API ไม่เรียก AI แล้วรอเลย

ถ้า API รับ Resume แล้วรอ AI ใน request เดียว จะเกิดปัญหาเมื่อ AI ช้า, network หลุด หรือ client timeout:

```text
แบบรอใน request
Client ─→ API ─→ AI (ช้า/ล่ม)
Client รอนานและไม่รู้ว่างานถูกเก็บหรือยัง

แบบ durable task
Client ─→ API ─→ SQLite commit ─→ ตอบ task ID
                              ↓
                         Worker ทำต่อ
```

`202 Accepted` จึงหมายถึง “รับงานไว้แล้ว” ไม่ใช่ “วิเคราะห์เสร็จแล้ว” ผู้เรียกใช้ `task_id` เพื่อตรวจ state ต่อ

## 3. ไฟล์แต่ละตัวควรรับผิดชอบอะไร

```text
main.py / api.py
  รับ HTTP, map status, ไม่ทำ business logic ยาว

models.py
  บอก shape/type/validation ของข้อมูล

domain.py
  กฎ state/evidence ที่ไม่ควรรู้จัก HTTP หรือ SQL

repository.py
  transaction และคำสั่ง SQLite

service.py
  เรียกลำดับงานระหว่าง domain/repository/provider

provider.py
  adapter ของ Mock AI; ภายหลังเปลี่ยน provider ได้

worker.py
  claim task แล้วสั่ง service ประมวลผล
```

นี่เรียกว่า **separation of concerns** ภาษาง่ายคือ “อย่าให้ไฟล์เดียวเป็นทั้งพนักงานรับเรื่อง คนวิเคราะห์ และคนเฝ้าฐานข้อมูล”

## 4. Intake หนึ่งครั้งเกิดอะไรขึ้น

ตัวอย่าง client ส่ง `HR-DEMO-001`:

```text
POST /intakes
  ↓ Pydantic ตรวจ field/type/limit
สร้าง canonical payload
  ↓ SHA-256
เปิด transaction
  ├─ event ใหม่ → insert task + audit
  ├─ event เดิม/hash เดิม → คืน task เดิม
  └─ event เดิม/hashต่าง → conflict
commit
  ↓
ตอบ 202 + task_id
```

**Canonical payload** คือรูปข้อมูลมาตรฐานก่อน hash เช่นจัด key order แน่นอน เพื่อไม่ให้ JSON ที่ความหมายเท่ากันแต่เรียง key คนละแบบถูกมองว่าต่างกัน

## 5. Worker หนึ่งรอบเกิดอะไรขึ้น

```text
worker --once
  ↓ ขอ task ที่ queued
claim: เปลี่ยนเป็น processing + เพิ่ม attempt
  ↓ commit สิทธิ์ก่อน
เรียก Mock AI นอก transaction
  ↓ parse structured output
ตรวจ quote ทุกชิ้นกับ source
  ↓ transaction ใหม่
บันทึก result/state/audit
```

อย่าเปิด SQLite write transaction ค้างระหว่างเรียก provider เพราะ request ภายนอกอาจช้าและทำให้ writer อื่นรอ

## 6. Hallucination Case ต้องเห็นอะไร

Resume เขียนว่า:

```text
Built Python ETL pipelines.
```

แต่ provider คืน:

```text
skill = Rust
quote = Built a Rust trading engine.
```

Validator ทำหน้าที่ดังนี้:

```text
quote อยู่ใน normalized Resume จริงไหม?
  ├─ อยู่ → supported=true
  └─ ไม่อยู่ → supported=false
                 ↓
          UNSUPPORTED_EVIDENCE
                 ↓
             needs_review
```

จุดสำคัญคือ provider กับ validator ต้องเป็นคนละ boundary ถ้าให้ AI ประกาศเองว่า `supported=true` แล้วระบบเชื่อ ค่า boolean นั้นไม่ได้พิสูจน์อะไร

## 7. Review ไม่ใช่แค่เปลี่ยนข้อความ

การ approve/edit/reject เป็น **state transition** ที่มีผลต่อ business record จึงต้องตรวจ state ปัจจุบันและเขียน review + task + audit ร่วม transaction:

```text
needs_review + approve → approved
needs_review + edit    → edited
needs_review + reject  → rejected
approved + approve     → 409 invalid transition
```

ถ้า request สุดท้ายไม่ถูกต้อง state เดิมต้องไม่เปลี่ยน และไม่ควรมี audit ที่ทำให้ดูเหมือน action สำเร็จ

## 8. n8n อยู่ตรงไหน

n8n ทำหน้าที่รับ event, แปลง shape, เรียก API และ route outcome ไม่ควร copy กฎ evidence/idempotency ไปเขียนซ้ำใน Code node

```text
n8n = คนเดินเอกสารและต่อระบบ
Python service = เจ้าของกฎ
SQLite = หลักฐานสถานะที่ commit แล้ว
Human reviewer = ผู้ตัดสินใจสุดท้าย
```

## 9. ลำดับลงมือวันแรก

1. เติม Project Brief ให้ตอบว่า in/out-of-scope อะไร
2. วาด request/response และ state flow ด้วยมือ
3. สร้าง Pydantic models และ validation tests
4. ทำ `/health`, `/ready`, `/intakes` กับ fake repository
5. เปลี่ยนเป็น SQLite แล้วพิสูจน์ duplicate/conflict/restart
6. หยุดและอธิบาย flow ให้ได้ก่อนเปิด Milestone Worker

## 10. ถ้าติด ให้ถามแบบนี้

แทนที่จะบอก AI ว่า “โค้ดพัง ช่วยแก้” ให้ส่ง:

```text
Expected: duplicate คืน task เดิม
Actual: ได้ task ID ใหม่
Boundary: repository/idempotency
Exact test: pytest tests/integration/test_intake.py -q
Evidence: rows ใน tasks เพิ่มจาก 1 เป็น 2
ขอ: อธิบายสาเหตุและให้ hint ก่อน ยังไม่ขอเฉลยเต็ม
```

นี่ช่วยให้ AI เป็นผู้ช่วยคิดและ review ขณะที่คุณยังเป็นเจ้าของ mental model ของระบบ

## 11. Code Skeleton อ่านอย่างไรโดยยังไม่แจกเฉลย

ตัวอย่าง request model ขั้นต้น:

```python
class IntakeRequest(BaseModel):
    event_id: str = Field(min_length=1, max_length=80)
    candidate_id: str = Field(min_length=1, max_length=80)
    resume_text: str = Field(min_length=1, max_length=20_000)
    required_skills: list[str] = Field(min_length=1, max_length=10)
```

ทีละส่วน:

- `class ... (BaseModel)` สร้าง Pydantic model สำหรับข้อมูลภายนอก
- `event_id: str` เป็น type hint และทำให้ field required เพราะไม่มี default
- `Field(...)` เพิ่มข้อจำกัดที่ type `str` อย่างเดียวบอกไม่ได้
- `list[str]` หมายถึง list ที่สมาชิกทุกตัวต้องเป็น string
- min/max ของ list นับจำนวนสมาชิก ส่วนของ string นับความยาวข้อความ

ยังต้องเพิ่ม validator สำหรับ trim และ duplicate แบบ case-insensitive เพราะ `Field` ไม่รู้ business rule นี้

Service skeleton:

```python
def accept_intake(request: IntakeRequest, repository: TaskRepository) -> IntakeResult:
    canonical = canonicalize(request)
    payload_hash = stable_hash(canonical)
    return repository.create_or_replay(request, payload_hash)
```

อ่าน flow:

```text
validated request
  ↓ canonicalize
รูปมาตรฐาน
  ↓ stable_hash
fingerprint
  ↓ create_or_replay
new / duplicate / conflict
```

Type hints บอก contract ให้คนและเครื่องมืออ่าน แต่ Python ไม่บังคับทุก type ตอน runtime เอง Boundary จึงยังต้องใช้ Pydantic/tests

## 12. `if ... is None` ใน Worker หมายถึงอะไร

```python
task = repository.claim_one()
if task is None:
    return False
```

`None` เป็น sentinel ว่า “ไม่มีงานให้ claim” ส่วน `False` ที่คืนจาก worker function บอก caller ว่ารอบนี้ไม่ได้ทำงาน ไม่ควรใช้ empty dict แทนหลายความหมาย เพราะจะอ่าน contract ยาก

```text
claim_one()
  ├─ Task object → process ต่อ
  └─ None        → จบรอบอย่างปกติ
```

อย่าสับสน `None` กับ exception: ไม่มีงานเป็นสถานะปกติ ส่วน DB เปิดไม่ได้ควรเกิด controlled infrastructure error เพื่อให้ health/log แสดงปัญหา

## ศัพท์ที่ควรพูดกับทีมได้

| ศัพท์ | ความหมายในโปรเจกต์นี้ |
|---|---|
| Contract | รูปและพฤติกรรมที่ผู้เรียกคาดหวังได้ |
| Boundary | จุดแบ่งความรับผิดชอบ/ความน่าเชื่อถือ |
| Durable | process หยุดแล้วสถานะไม่หาย |
| Idempotent | retry เหตุการณ์เดิมแล้วไม่เพิ่ม side effect |
| Canonicalization | ทำข้อมูลให้อยู่รูปมาตรฐานก่อนเทียบ/hash |
| Transaction | หลายการเขียนสำเร็จหรือล้มเหลวร่วมกัน |
| Evidence grounding | claim ต้องตรวจย้อนกลับไป source ได้ |
| Human-in-the-loop | คนตรวจ/ตัดสินใจในจุดเสี่ยง |
| Audit trail | ประวัติว่าใคร/อะไรทำอะไรเมื่อไร |
| Failure mode | รูปแบบที่ระบบอาจล้มเหลวและต้องออกแบบรับมือ |
