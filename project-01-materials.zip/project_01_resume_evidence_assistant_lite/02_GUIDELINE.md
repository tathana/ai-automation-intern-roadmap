# 02 — Implementation Guideline ทีละ Milestone

Guideline บอกลำดับและหลักฐาน ไม่บอก source-code solution ทุกบรรทัด ให้ commit เมื่อ milestone ผ่านและอธิบาย diff ได้

## ภาพจำของลำดับการสร้าง

อย่าเริ่มจาก Docker/n8n พร้อมกันหมด เพราะเวลาพังจะไม่รู้ว่าพังชั้นไหน ให้สร้างเหมือนต่อท่อน้ำทีละช่วง:

```text
contract รับข้อมูลได้
  ↓ เปลี่ยน fake เป็น SQLite
งานอยู่หลัง restart
  ↓ เพิ่ม worker/mock/validator
งานประมวลผลได้
  ↓ เพิ่ม review/audit
วงจรธุรกิจครบ
  ↓ ค่อยครอบด้วย n8n/Docker/docs
รันและส่งต่อได้
```

แต่ละ milestone ต้องมี “หลักฐานว่าผ่าน” ก่อนต่อส่วนถัดไป ไม่ใช่เพียงมีไฟล์เพิ่มขึ้น

## Milestone 0 — Brief และ Repository

1. คัดลอก/เติม `docs/PROJECT_BRIEF.md`
2. เขียน ADR แรกใน `docs/DECISION_LOG.md`: รองรับ PDF text/DOCX/TXT โดยแปลงเป็น text contract เดิม ใช้ Mock AI ก่อน และเลื่อน OCR ไว้รอบถัดไป
3. สร้าง repo และโครงขั้นต่ำ
4. สร้าง `.venv`, `pyproject.toml`, `.gitignore`, `.env.example`
5. commit: `docs: define project scope and acceptance plan`

โครงเริ่มต้นแนะนำ:

```text
src/resume_evidence/
├── main.py
├── models.py
├── domain.py
├── repository.py
├── service.py
├── provider.py
└── worker.py
tests/
├── unit/
├── integration/
└── fixtures/
```

อย่าแยกโฟลเดอร์หลายชั้นก่อนมีหลายไฟล์/หลาย responsibility จริง

## Milestone 1 — Contract First

เส้นทางเริ่มจากไฟล์ให้ทำ F0 ใน [File Intake](08_RESUME_FILE_INTAKE.md) ก่อน และเพิ่ม F1 upload endpoint เมื่อ intake service พร้อม ใช้ service เดียวกันเพื่อรักษา duplicate/transaction behavior

สร้าง Pydantic request/response models, `/health`, `/ready` และ `POST /intakes` ที่ยังใช้ in-memory fake repository ได้ชั่วคราว

หลักฐาน:

- valid request คืน shape/status ที่ตกลง
- missing/blank/duplicate skills ถูก reject อย่างอธิบายได้
- route ไม่ log raw resume
- test schema/error mapping ผ่าน

Commit: `feat: add validated intake contract`

## Milestone 2 — SQLite และ Idempotency

ออกแบบ schema `tasks`, `audit_events` และภายหลัง `reviews` ใช้ unique constraint บน `event_id` และ transaction สำหรับ task + audit

ทำ canonical payload hash ด้วย deterministic serialization เช่น normalized JSON + SHA-256 บันทึกเหตุผลของ fields ที่รวมใน hash

หลักฐาน:

- restart process แล้วยัง GET task ได้
- replay payload เดิมคืน task เดิม
- event ID เดิม payload ต่างคืน 409
- concurrent duplicate อย่างน้อยพิสูจน์ด้วย integration test หรือบันทึก limitation หาก SQLite/test setup ยังไม่ครอบคลุม

Commit: `feat: persist idempotent intake tasks`

## Milestone 3 — Worker และ Evidence Validator

แยก provider interface จาก mock implementation Mock ต้องสร้างสี่ scenario แบบ deterministic

```text
claim queued → mark processing/attempt
→ call mock provider
→ parse schema
→ verify every quote against normalized source
→ persist result + state + audit atomically
```

เริ่ม worker `--once` ก่อน loop ตลอดเวลา สำหรับ `transient` ให้ retry แบบมี budget; จะใช้ `retry_wait` + `next_attempt_at` หรือ simplified requeue ก็ได้แต่ต้องเขียน semantics

หลักฐาน:

- normal สร้าง supported evidence
- hallucination ถูก flag
- invalid JSON ไม่กลายเป็น success
- transient ไม่ retry ไม่สิ้นสุด

Commit: `feat: process tasks with evidence validation`

## Milestone 4 — Human Review และ Audit

สร้าง review endpoint และ transition guard อนุญาตเฉพาะ task `needs_review` การ edit ต้องเก็บ before/after หรือ final evidence อย่างอธิบายได้

หลักฐาน:

- approve/edit/reject paths
- duplicate/invalid review ถูก reject หรือ idempotent ตาม contract
- audit มี actor/action/time โดยไม่เก็บ raw resume

Commit: `feat: add audited human review`

## Milestone 5 — n8n

สร้าง workflow จาก canvas เปล่า:

```text
Webhook → Normalize → POST /intakes → Switch
        ├─ accepted/duplicate → Respond truthful task state
        ├─ conflict → review/error response
        └─ unavailable/timeout → truthful failure
```

ทดสอบ Test URL ก่อน แล้ว production URL เฉพาะ local environment ที่ควบคุม Export workflow แบบ inactive ไม่มี credentials/pinned PII

Commit: `feat: add n8n intake workflow`

## Milestone 6 — Docker และ Delivery

สร้าง Dockerfile แบบไม่ฝัง secrets และ Compose ตาม scope เลือกว่าจะรัน API/worker แยก service หรือเริ่ม native worker พร้อมบันทึก trade-off หาก share SQLite volume ต้องอธิบาย concurrency/locking limitation

เติม README, runbook, test evidence และ demo script ทำ failure drill หนึ่งกรณีจาก clean start

Commit: `docs: add verified runbook and demo evidence`

## AI-assisted Coding Ritual

ก่อนให้ AI ช่วย ส่งเฉพาะ synthetic context และระบุ contract/test หลังรับคำตอบ:

```text
อ่าน diff → อธิบายเอง → ตรวจ API/version → รัน focused test
→ รัน full test → ตรวจ secret/PII/log → commit เล็ก
```
