# 08 — อ่านไฟล์ Resume ก่อนต่อ AI

เริ่มด้วยไฟล์ได้เลย เป้าหมายชิ้นแรกคือ **เลือก Resume สังเคราะห์หนึ่งไฟล์ แล้วเห็นข้อความที่อ่านออกมา** เมื่ออ่านถูกต้องจึงต่อ API, task และ Mock AI เดิม

## ภาพรวมและขอบเขต

Text extraction คือดึงตัวอักษรจากไฟล์ ส่วน AI extraction คืออ่านข้อความแล้วเลือกข้อมูล เช่น skill และ quote เป็นคนละขั้น จึงควรทดลองแยกกัน

```text
PDF / DOCX / TXT + ข้อมูลผู้สมัคร
        ↓ ตรวจชนิด ขนาด และอ่านได้จริง
Document Reader → extracted text
        ↓ validate
Intake service เดิม → SQLite task
        ↓
Worker → Mock AI → ตรวจ evidence กับข้อความต้นทาง
        ↓
HR ตรวจ draft → decision + audit
```

| ไฟล์ | รอบแรกอ่านอะไร | ข้อจำกัด |
|---|---|---|
| PDF | text layer จากไฟล์ไม่เข้ารหัส | PDF สแกนไม่มีข้อความต้องใช้ OCR |
| DOCX | ย่อหน้าและตารางตามลำดับเอกสาร | ยังไม่รับประกัน text box/header/footer |
| TXT | UTF-8 และ UTF-8 BOM | encoding อื่นแจ้งไม่รองรับ |
| DOC, รูปภาพ, ZIP | ยังไม่รองรับ | ปฏิเสธชนิดไฟล์ |

OCR คือการแปลงภาพตัวอักษรเป็นข้อความ ให้เพิ่มภายหลัง PDF ที่มี text layer ก็อาจอ่านลำดับสองคอลัมน์ผิดได้ ต้องเทียบกับต้นฉบับด้วย

กำหนดเพดานแบบฝึกเป็น config: ไฟล์ไม่เกิน 5 MiB, PDF ไม่เกิน 20 หน้า, ข้อความไม่เกิน 50,000 ตัวอักษร ตัวเลขนี้เป็นขอบเขตรอบทดลอง ไม่ใช่มาตรฐานทุกระบบ

## F0 — อ่านไฟล์บนเครื่องก่อน

เพิ่ม `document_reader.py` และ `tests/unit/test_document_reader.py` ใช้ไฟล์สังเคราะห์ ยังไม่ใส่ SQL หรือ AI ใน reader

```text
read_resume(file_bytes, filename)
      ↓ เลือก parser ที่อนุญาต
read_pdf / read_docx / read_txt
      ↓ ตรวจข้อความไม่ว่างและไม่เกินเพดาน
คืน text + source metadata
```

`file_bytes` คือเนื้อไฟล์จริง `filename` ช่วยเลือก parser แต่ไม่พิสูจน์ชนิดไฟล์ ต้องให้ parser อ่านและจัดการ error ด้วย

| Function | Input | Output | หน้าที่ |
|---|---|---|---|
| `read_txt` | bytes | str | decode และตรวจว่าง |
| `read_pdf` | bytes | ข้อความแยกหน้า | รักษาหมายเลขหน้าที่อ่านจริง |
| `read_docx` | bytes | ข้อความตามลำดับเอกสาร | อ่านย่อหน้าและตาราง |
| `read_resume` | bytes, filename | document result | เลือก reader และตรวจ limits ร่วม |

ตัวอย่างเริ่มต้นที่อ่านทีละบรรทัดได้:

```python
def read_txt(content: bytes) -> str:
    text = content.decode("utf-8-sig")
    if not text.strip():
        raise ValueError("NO_EXTRACTABLE_TEXT")
    return text
```

`decode` เปลี่ยน bytes เป็นข้อความ; `utf-8-sig` รองรับ BOM ต้นไฟล์; `strip()` ใช้เช็กว่ามีแต่ช่องว่างหรือไม่ คืนข้อความเดิมไว้ตรวจ evidence ภายหลัง หาก decode ไม่ได้ให้ชั้น service แปลง error เป็นรหัส API

PDF/DOCX ดูตัวอย่าง Document Reader ใน Book 08 ประกอบ และตรวจ library/version ที่เลือกก่อนใช้ **จบด่านนี้เมื่อ:** อ่านทั้งสามชนิดและเทียบข้อความกับต้นฉบับได้

## F1 — ต่อ Upload API

เพิ่ม `POST /intakes/files` รับ `multipart/form-data` ซึ่งแนบไฟล์และ field ข้อความใน request เดียว เมื่ออ่านสำเร็จให้เรียก intake service เดียวกับ `/intakes` เพื่อรักษา transaction และ duplicate behavior เดิม

| Field | ตัวอย่าง | ความหมาย |
|---|---|---|
| `file` | resume-demo.pdf | ไฟล์สังเคราะห์หนึ่งไฟล์ |
| `event_id` | HR-FILE-001 | รหัสการส่ง |
| `candidate_id` | C001 | รหัสผู้สมัคร |
| `required_skills_json` | `["Python", "Docker"]` | JSON array ใน form field ต้อง parse และ validate |
| `mock_scenario` | normal | scenario เดิมของชุดฝึก |

```text
อ่าน upload แบบจำกัด bytes → parse → ตรวจ text
  → สร้าง input model โดย resume_text = extracted_text
  → intake service ตรวจ duplicate และ commit
  → 202 + task_id
```

รอบเล็กอ่านเอกสารก่อนสร้าง task และต้องจำกัด resource การเรียก parser งานหนักไม่ควรบล็อก async event loop; งาน OCR/ไฟล์ใหญ่ค่อยย้าย extraction ไป worker

อย่าใช้ชื่อไฟล์จากผู้ใช้เป็น path เขียน disk หรือรับ URL/path ให้ server เปิดเอง อ่าน bytes ได้เลย ตรวจขนาด DOCX หลังขยายด้วยเพราะภายในเป็น ZIP

## Error ที่ผู้ใช้ควรได้รับ

| กรณี | HTTP | รหัสตัวอย่าง |
|---|---:|---|
| เกินขนาด | 413 | FILE_TOO_LARGE |
| ชนิดไม่รองรับ | 415 | UNSUPPORTED_FILE_TYPE |
| ไฟล์เสีย/เข้ารหัส/encoding ผิด | 422 | DOCUMENT_UNREADABLE |
| ไม่มีข้อความ | 422 | NO_EXTRACTABLE_TEXT |
| เกิน page/text limits | 422 | DOCUMENT_LIMIT_EXCEEDED |
| metadata ผิด | 422 | INVALID_METADATA |
| event เดิมแต่ payload ต่าง | 409 | EVENT_PAYLOAD_CONFLICT |

error ก่อน intake สำเร็จต้องไม่สร้าง task หรือเรียก provider ไม่ส่ง traceback หรือเนื้อหา Resume เต็มกลับผู้ใช้

## Duplicate และหลักฐาน

สำหรับ file intake ใช้ SHA-256 ของ bytes ร่วมกับ candidate ID, skills, mock scenario และชนิด intake ใน canonical payload hash ชื่อไฟล์ไม่ใช่ identity: เปลี่ยนชื่อแต่ bytes/metadata เหมือนเดิมควรคืน task เดิม

event เดิมแต่ bytes/metadata เปลี่ยน → 409; event ใหม่ → งานใหม่ตาม contract แม้ไฟล์เหมือนเดิม บันทึกกติกานี้ใน README

เก็บ extracted text ที่ใช้วิเคราะห์ไว้กับ task เพื่อให้ validator/reviewer อ้าง source เดียวกัน เก็บ page number เฉพาะที่รู้จริงจาก PDF ไม่สร้างเลขหน้า DOCX/TXT ขึ้นเอง การพบ quote พิสูจน์ว่าข้อความมีอยู่ แต่ไม่ได้พิสูจน์ว่า AI ตีความถูกต้อง

## F2 — Test และ Demo

| ID | ทดลอง | ผลที่ต้องเห็น |
|---|---|---|
| FILE-01 | TXT BOM, PDF text, DOCX ย่อหน้า/ตาราง | อ่านข้อความสำคัญได้ |
| FILE-02 | ไฟล์ว่างหรือ PDF ไม่มี text | 422 ไม่มี task/AI call |
| FILE-03 | ไฟล์เสีย/เข้ารหัส/encoding ผิด | error ตาม contract |
| FILE-04 | ชนิดไม่รองรับ/ปลอม extension | ปฏิเสธหรือ parse error |
| FILE-05 | ต่ำกว่า/เท่ากับ/เกิน limits | boundary ตรง config |
| FILE-06 | event/bytes/metadata เดิม เปลี่ยนชื่อไฟล์ | task เดิม ไม่มี audit ซ้ำ |
| FILE-07 | event เดิม เปลี่ยน bytes/metadata | 409 |
| FILE-08 | skills JSON ผิดหรือ metadata หาย | 422 |
| FILE-09 | ชื่อไฟล์มี path traversal | ไม่เขียนตามชื่อผู้ใช้; ไม่มี raw text ใน logs |
| FILE-10 | upload → worker → review → restart | result/audit ยังอยู่ และ tests เดิมผ่าน |

สร้าง fixtures จากข้อความสังเคราะห์เดียวกัน เช่น `Built reporting scripts using Python.` ทั้งสามรูปแบบ เพิ่มไฟล์ว่างและเสียสำหรับทดสอบ ชุดบทนี้เป็น guideline ยังไม่ได้แจก binary fixtures หรือ upload implementation

Demo เริ่มจาก Swagger UI `/docs` เลือกไฟล์ → รับ task ID → รัน worker → เปิดผล → review จากนั้นค่อยต่อ n8n แบบ multipart โดยส่ง binary property และรักษา error routing ของบท 06

## Prompt เริ่มทำกับผู้ช่วย

```text
ช่วยพาทำ F0 ของ Resume Evidence Assistant Lite
เริ่ม read_txt และ unit tests อธิบาย input/output ทีละขั้น
ใช้ synthetic fixture ยังไม่ต่อ API/AI/database
เมื่อผ่านค่อยเพิ่ม PDF และ DOCX ตาม contract บท 08
```

อ่าน [Guideline](02_GUIDELINE.md) ต่อ และใช้ [Acceptance Matrix](03_ACCEPTANCE_TESTS.md) ควบคู่ FILE-01–10 เมื่อต่อระบบครบ
