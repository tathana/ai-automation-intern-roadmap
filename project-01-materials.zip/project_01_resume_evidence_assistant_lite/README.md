# Project 01 — Resume Evidence Assistant Lite

โปรเจกต์ฝึกแบบ end-to-end สำหรับประกอบ Python, FastAPI, SQLite, Worker, n8n, Mock AI, validation, human review, tests, Docker และ documentation เข้าด้วยกัน โดยตั้งใจจำกัดขอบเขตให้เล็กพอทำ vertical slice ได้ภายในหนึ่งวันและขยายต่อได้ในวันที่สอง

> ข้อมูลสังเคราะห์เท่านั้น • Text input เท่านั้น • Mock AI เท่านั้น • ไม่ rank/reject/hire • ไม่มี production authentication

## เริ่มอย่างไร

1. อ่าน [Mission และข้อกำหนด](01_MISSION.md) โดยยังไม่เปิด Hints
2. เติม [Project Brief](docs/PROJECT_BRIEF.md) และ [Decision Log](docs/DECISION_LOG.md)
3. สร้าง repository/virtual environmentตาม [Implementation Guideline](02_GUIDELINE.md)
4. ทำ Milestone 1–3 ให้ flow หลักครบก่อน
5. รัน failure cases แล้วค่อยทำ n8n/Docker/docs
6. เปิด [Hint Ladder](04_HINTS.md) เฉพาะเมื่อบอกได้ว่าติด boundary ใด

ถ้าอ่าน Mission แล้วรู้สึกว่าศัพท์เยอะ ให้เปิด [07 — Easy Walkthrough](07_EASY_WALKTHROUGH.md) ก่อนลงมือ เนื้อหานี้แปลภาพรวมเป็นภาษาง่าย แต่ยังเก็บชื่อศัพท์ที่ต้องใช้คุยกับทีมไว้

## แผนเวลา

| รอบ | เป้าหมาย | ประมาณการสำหรับการฝึก |
|---|---|---:|
| 0 | อ่านโจทย์, brief, diagram, repo | 45–60 นาที |
| 1 | FastAPI intake + schemas | 60–90 นาที |
| 2 | SQLite + idempotency | 90–120 นาที |
| 3 | Worker + mock + evidence validator | 90–120 นาที |
| 4 | Review + audit + failure tests | 60–90 นาที |
| 5 | n8n + Docker + runbook + demo | 90–150 นาที |

เวลาเป็นเพียงกรอบ ถ้าติดให้เก็บหลักฐานและใช้ Debug Card ไม่ต้องเร่งจนข้าม test

## Definition of Done แบบย่อ

```text
synthetic intake → durable task → worker → evidence validation
→ needs_review → human action → audit
```

ต้องพิสูจน์ duplicate, payload conflict, unsupported quote, invalid transition และ restart/recovery อย่างน้อยตาม Acceptance Matrix

## สิ่งที่ให้มา

- Mission, requirements และ architecture constraints
- Guideline ทีละ milestone
- Hint ladder สามระดับ
- Acceptance tests ที่ต้องออกแบบ
- Synthetic input/expected examples
- เอกสารตั้งต้นสำหรับ brief, decisions, test evidence และ runbook
- Grading rubric และ delivery checklist
- Traceability template และ n8n canvas checklist

## เอกสารหลักของชุดฝึก

- [ภาพรวมสถาปัตยกรรมและขอบเขต](00_PROJECT_MAP.md)
- [Mission และ contracts](01_MISSION.md)
- [Guideline ทีละ milestone](02_GUIDELINE.md)
- [Acceptance Matrix](03_ACCEPTANCE_TESTS.md)
- [Hint Ladder](04_HINTS.md)
- [Rubric และการส่งมอบ](05_GRADING_AND_DELIVERY.md)
- [คู่มือสร้าง n8n จาก canvas เปล่า](06_N8N_CANVAS_GUIDE.md)
- [Easy Walkthrough — มองระบบให้ออกก่อนเขียน](07_EASY_WALKTHROUGH.md)
- [Requirement Traceability Template](docs/TRACEABILITY.md)

ชุดนี้ไม่ให้ source-code solution เพราะเป้าหมายคือให้คุณอธิบายการตัดสินใจและเขียนแต่ละ boundary ได้เอง ใช้ AI ช่วยได้ แต่ทุก diff ต้องผ่าน AI Review Checklist
