# 03 — Acceptance Matrix และ Test Design

อย่าเขียน test ทั้งหมดทีเดียวก่อนเข้าใจ feature ให้เพิ่มทีละ milestone แต่ ID/expected behavior ต้องคงที่

Acceptance test คือการแปลงประโยคกว้าง ๆ เช่น “ห้ามสร้างงานซ้ำ” ให้กลายเป็นสิ่งที่พิสูจน์ได้ เช่น ส่ง payload เดิมสองครั้งแล้ว query จำนวน task ต้องยังเป็นหนึ่ง ถ้า test บอกเพียง status code แต่ไม่ตรวจ side effect ก็ยังพิสูจน์ไม่ครบ

| ID | Case | Expected |
|---|---|---|
| TEST-01 | health | `200`, ไม่มี dependency claim เกินจริง |
| TEST-02 | ready + DB/schema พร้อม | `200`; เมื่อ DB ใช้ไม่ได้ต้องไม่คืน ready |
| TEST-03 | valid intake | `202`, durable `task_id`, `queued` |
| TEST-04 | invalid/blank input | `422`, ไม่มี task/audit side effect |
| TEST-05 | duplicate same payload | same task ID, `duplicate=true`, task count ไม่เพิ่ม |
| TEST-06 | same event/different payload | `409 EVENT_PAYLOAD_CONFLICT` |
| TEST-07 | normal mock | supported quote พบใน source |
| TEST-08 | skill absent | `found=false`, `quote=null` โดยไม่ invent |
| TEST-09 | hallucinated quote | unsupported flag; no automatic approval |
| TEST-10 | invalid provider JSON | controlled error/retry/review state, no false success |
| TEST-11 | transient provider failure | bounded attempt; visible state/reason |
| TEST-12 | valid review | final transition + review + audit |
| TEST-13 | invalid transition | `409`; state/audit ไม่เสีย |
| TEST-14 | restart | accepted task/result ยังอ่านได้ |
| TEST-15 | log inspection | ไม่มี raw resume/full provider payload |
| TEST-16 | n8n duplicate/conflict/failure | route และ HTTP response ตรง API truth |

## Unit Tests

- normalize skill uniqueness
- canonical payload/hash
- allowed state transitions
- evidence quote normalization/matching
- error classification และ retry decision

## Integration Tests

- SQLite transaction + unique constraint
- API/Pydantic/error mapping
- worker claim/process/persist
- review + audit
- process/repository restart

## Failure Drill

เลือกอย่างน้อยหนึ่ง:

1. provider transient สองครั้งแล้วสำเร็จ/หมด budget
2. process หยุดหลัง intake commit ก่อน worker
3. worker หยุดหลัง claim แล้วทำ recovery ตาม lease/contract
4. replay event หลังไม่แน่ใจว่า client ได้ response หรือไม่

บันทึก exact commands, task ID, state ก่อน/หลัง, audit events, expected/actual และ limitation

## Evidence Table

| Test/requirement | Command/request | Expected | Actual | Evidence/version | Result |
|---|---|---|---|---|---|
| | | | | | |
