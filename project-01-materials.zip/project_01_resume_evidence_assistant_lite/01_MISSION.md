# 01 — Mission และข้อกำหนด

## แปลโจทย์เป็นภาษาง่ายก่อน

ระบบนี้เหมือน “โต๊ะรับเอกสารที่มีเลขใบงาน” ครับ API รับข้อความ Resume แล้วออกเลข task ให้ แต่ยังไม่รีบวิเคราะห์ใน request เดียว Worker จะมาหยิบ task ไปทำต่อ ตรวจว่าหลักฐานที่ AI อ้างมีอยู่จริง แล้วส่งให้คนตัดสินใจ

```text
HR ส่งข้อความ Resume
  ↓ API ตรวจว่าข้อมูลครบไหม
รับงานลง SQLite + ออก task ID
  ↓ worker หยิบงาน
Mock AI เสนอหลักฐาน
  ↓ validator เช็กกับ Resume ต้นทาง
คน review → approve/edit/reject
```

คำว่า **durable task** ในโจทย์จึงแปลว่า “API รับแล้ว งานต้องยังอยู่แม้ process ถูก restart” ส่วน **human-in-the-loop** แปลว่า “AI ช่วยเตรียมข้อมูล แต่คนยังเป็นผู้ตัดสินใจ”

## Mission

สร้างระบบที่รับ resume text สังเคราะห์พร้อมรายการ skill แล้วสร้าง task แบบ durable ให้ worker ประมวลผลเป็น evidence draft จากนั้นให้คน approve/edit/reject พร้อม audit โดยไม่สร้างหลักฐานที่ไม่มีใน source

## Input Contract

ทางเข้าไฟล์ `POST /intakes/files` รองรับ PDF text, DOCX และ TXT ตาม [File Intake](08_RESUME_FILE_INTAKE.md) และแปลง extracted text เป็น `resume_text` ตาม contract ด้านล่าง `/intakes` เดิมยังใช้ทดสอบแก่นระบบโดยตรงได้

```json
{
  "event_id": "HR-DEMO-001",
  "candidate_id": "C001",
  "resume_text": "Built Python ETL pipelines and automated daily reports.",
  "required_skills": ["Python", "FastAPI", "Docker"],
  "mock_scenario": "normal"
}
```

Rules:

- `event_id`, `candidate_id`, `resume_text` ต้องไม่เป็นข้อความว่าง
- `required_skills` มี 1–10 ค่า; trim; ไม่รับค่าซ้ำแบบ case-insensitive
- `mock_scenario`: `normal`, `hallucination`, `transient`, `invalid_json`
- จำกัดความยาว input ตามค่าที่คุณประกาศและทดสอบ

## Required API

| Method/path | ความหมาย | ผลหลัก |
|---|---|---|
| `GET /health` | process alive | `200` |
| `GET /ready` | DB/schema พร้อม | `200` หรือ truthful `503` |
| `POST /intakes` | validate + persist task | `202`; duplicate เดิมคืน task เดิม; conflict `409` |
| `GET /tasks/{task_id}` | ดู state/result/flags | `200` หรือ `404` |
| `POST /tasks/{task_id}/reviews` | approve/edit/reject | `200`, invalid transition `409` |

Worker ใช้ CLI เช่น:

```powershell
python -m resume_evidence.worker --once
```

`--once` claim ได้สูงสุดหนึ่ง task แล้วจบ เพื่อให้ทดสอบและ debug ง่าย

## Idempotency Contract

ให้นึกถึงการกดปุ่มส่งแล้วอินเทอร์เน็ตค้าง ผู้ใช้ไม่รู้ว่า server รับหรือยังจึงกดซ้ำ ระบบที่ดีต้องไม่สร้างงานสองก้อนจากเหตุการณ์เดียวกัน นี่คือเหตุผลของ `event_id` และ idempotency

```text
event_id ใหม่
  → create task, 202 duplicate=false

event_id เดิม + canonical payload hash เดิม
  → same task_id, duplicate=true, ห้ามสร้าง audit task_created ซ้ำ

event_id เดิม + payload hash ต่าง
  → 409 EVENT_PAYLOAD_CONFLICT
```

กำหนดเองและบันทึกว่า field ใดเข้า canonical hash ห้ามใช้ Python `hash()` เพราะค่าไม่ใช่ stable cross-process contract

## Evidence Contract

Evidence ไม่ได้แปลว่า AI พูดน่าเชื่อ แต่หมายถึงข้อความอ้างอิงที่ตรวจย้อนกลับไปยัง source ได้ ตัวอย่างเช่น ถ้า AI บอกว่าผู้สมัครมี Python แต่ quote ที่คืนมาไม่มีอยู่ใน Resume ระบบต้องติดธง ไม่ใช่พยายามหาเหตุผลให้ AI ถูก

```json
{
  "skill": "Python",
  "found": true,
  "quote": "Built Python ETL pipelines",
  "supported": true,
  "reason": null
}
```

- `found=true` ต้องมี quote ที่พบใน normalized source จริง
- ถ้าไม่มีหลักฐาน: `found=false`, `quote=null`, `supported=true`
- ถ้า provider อ้าง quote ไม่มีจริง: `supported=false`, reason `UNSUPPORTED_EVIDENCE`
- draft ที่มี unsupported evidence ยังต้อง `needs_review` พร้อม flags และห้าม approve จนแก้/ตัด claim ตาม policy ที่คุณประกาศ

## Review Contract

```json
{
  "reviewer_id": "reviewer-demo",
  "action": "approve",
  "reason": "Evidence verified",
  "edited_evidence": null
}
```

`reviewer_id` เป็น demo input ไม่ใช่ authentication จริง ต้องระบุ limitation ใน README

## Must Not

- ไม่ใช้ resume จริงหรือข้อมูลบริษัท
- ไม่เรียก paid/real LLM
- ไม่ auto-rank, auto-reject หรือ auto-hire
- ไม่ log `resume_text` ทั้งฉบับ
- ไม่รับ arbitrary file path/URL
- ไม่ตอบ success หาก transaction ยังไม่ commit
- ไม่ retry validation/permanent error แบบไม่มีขอบเขต
