# 00 — Project Map และภาพปลายทาง

## Business Scenario

HR ต้องอ่าน resume จำนวนมากเพื่อหา evidence ของ skill ที่กำหนด ระบบนี้ช่วยสร้าง draft พร้อม quote ให้คนตรวจ ไม่ได้ตัดสินความเหมาะสมของผู้สมัคร

```text
Client / n8n
  │ POST event_id + candidate_id + resume_text + required_skills
  v
FastAPI Intake ──transaction──> SQLite Task + Audit
  │ 202 task_id                         ▲
  v                                     │ claim/result
Client polls                        Worker --once
                                        │
                                 Mock AI Provider
                                        │ raw output
                                 Schema + Evidence Validator
                                        │
                                  needs_review
                                        │
                                 Human review API
                                        │
                              approved / edited / rejected
```

## Boundary Ownership

| ส่วน | รับผิดชอบ | ไม่ควรรับผิดชอบ |
|---|---|---|
| FastAPI | HTTP/auth-placeholder/schema/status mapping | evidence logic ยาว, provider SDK โดยตรง |
| Service/domain | use case, state rules, evidence validation | HTTP/SQL syntax |
| Repository | transaction, query, unique constraint | business wording |
| Worker | claim, invoke provider, validate, persist outcome | รับ HTTP request |
| Mock provider | คืน scenario ที่ควบคุมได้ | เขียน DB/approve |
| n8n | trigger, normalize, call API, truthful route | source of truth/state machine |

## State Machine

```text
queued → processing → needs_review → approved
            │              ├────────→ approved_with_edits
            │              └────────→ rejected
            ├→ retry_wait → queued
            └→ failed_terminal
```

Transition ทุกเส้นต้องระบุ actor และบันทึก audit ไม่มีเส้นจาก model output ไป `approved`

## Mock กับของจริง

| ในโปรเจกต์ | ถ้าเป็นระบบจริง |
|---|---|
| `resume_text` สังเคราะห์ใน SQLite | document reference ใน approved store + retention/access controls |
| `reviewer_id` ใน body | identity จาก authentication/authorization layer |
| Mock provider | approved provider + secrets + rate limit/cost/privacy |
| manual `worker --once` | supervised worker/queue/concurrency/monitoring |
| SQLite | database choice ตาม volume/concurrency/backup requirements |

