# 06 — n8n Canvas Guideline

บทนี้เป็นแนวทางสร้าง workflow เอง ไม่ใช่ไฟล์เฉลยสำเร็จ จุดประสงค์คือฝึกมองว่า n8n เป็น orchestration layer ที่รับ event, เรียก API และส่งคำตอบตามข้อเท็จจริงของระบบ

## ภาพที่ควรเห็นบน Canvas

```text
[Webhook]
    ↓
[Normalize Input]
    ↓
[POST /intakes]
    ↓
[Switch by HTTP status/body]
    ├── accepted/duplicate ──→ [Respond 202]
    ├── payload conflict  ──→ [Respond 409]
    └── timeout/unavailable ─→ [Respond 502/503]
```

ไม่ต้องนำ worker, evidence validator หรือ database rule ไปเขียนซ้ำใน Code node เพราะ business truth ควรอยู่ใน Python/API และตรวจด้วย automated tests ได้

## สร้างทีละ Node

### 1. Webhook

- Method: `POST`
- Path: ตั้งชื่อสื่อความหมาย เช่น `resume-evidence-intake`
- เริ่มจาก Test URL
- เตรียม synthetic payload จาก `fixtures/intake_normal.json`

Expected: Output pane ต้องเห็น body ที่ส่งเข้ามาจริง ถ้า shape เป็น `items[0].json.body` ให้จด shape นี้ก่อนเขียน expression

### 2. Normalize Input

ใช้ Edit Fields/Set node เพื่อสร้าง contract ที่ API ต้องการเท่านั้น:

```text
Webhook body
    ↓ เลือกเฉพาะ field ที่อนุญาต
event_id, candidate_id, resume_text, required_skills, mock_scenario
    ↓
HTTP Request JSON body
```

อย่าส่ง headers, query หรือ metadata ทั้งก้อนไป API โดยไม่จำเป็น

### 3. HTTP Request

- Method: `POST`
- URL: ใช้ environment/config ที่เหมาะกับวิธีรัน
- Body type: JSON
- Timeout: กำหนดค่า ไม่ปล่อยให้รอไม่สิ้นสุด
- เก็บ full response/status เพื่อใช้ route

เมื่อ n8n อยู่ใน container คำว่า `localhost` หมายถึง container ของ n8n เอง ไม่ใช่ API บน Windows host ใช้ service name ใน Compose network หรือ host address ที่ environment รองรับ

### 4. Switch

route จากค่าที่ node ก่อนหน้าส่งออกจริง ไม่เดาชื่อ fieldจากความจำ โดยต้องแยกอย่างน้อย:

| Outcome | ความหมาย | คำตอบที่ควร truthful |
|---|---|---|
| `202`, duplicate false | รับงานใหม่แล้ว | task ID + queued |
| `202`, duplicate true | เคยรับ event เดิม | task ID เดิม |
| `409` | event เดิมแต่ payload เปลี่ยน | conflict; ห้ามสร้าง event ID ใหม่อัตโนมัติ |
| timeout/network | ไม่รู้ว่า API commit หรือไม่ | แจ้ง unknown/failure; retry ด้วย event ID เดิม |
| validation error | input ไม่ผ่าน contract | ส่ง error ที่อ่านได้; ไม่ retry |

### 5. Respond to Webhook

ให้ HTTP status และ body สอดคล้องกับ API truth ห้ามเปลี่ยน timeout เป็น `200 success` เพียงเพื่อให้ workflow เป็นสีเขียว

## Execution Checklist

- [ ] normal input ผ่านและคืน task ID
- [ ] replay payload เดิมคืน task ID เดิม
- [ ] event เดิม payload ต่างเป็น conflict
- [ ] invalid inputไม่เกิด task
- [ ] API ปิดอยู่แล้ว workflow ไม่อ้างว่าสำเร็จ
- [ ] เปิดดู input/output ของทุก node แล้ว
- [ ] unpin data ก่อนรันหลักฐานทั้ง flow
- [ ] workflow export เป็น inactive
- [ ] export ไม่มี credentials, token, real PII หรือ internal secret URL
- [ ] บันทึก execution ID/เวลา/expected/actual ใน Test Evidence

## ถ้าติด ให้ไล่ Boundary

```text
Webhook รับไม่ได้?
  → ตรวจ method, URL mode, workflow listening

Webhook ได้ แต่ API 422?
  → เทียบ normalized JSON กับ Pydantic contract

API ได้ แต่ Switch ผิดทาง?
  → inspect output schema/status ของ HTTP node

ทุกอย่างผ่าน แต่ retry สร้างซ้ำ?
  → ตรวจ event_id เดิมและ API idempotency test
```

เมื่อ workflow ผ่านแล้ว ให้วาด flow ปัจจุบันจากของจริงหนึ่งครั้ง แล้วเทียบกับภาพต้นบท ถ้าไม่ตรงให้อัปเดต diagram หรือ implementation เพื่อไม่ให้เอกสารโกหก
