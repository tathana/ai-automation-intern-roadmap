# 05 — Grading Rubric และ Delivery Checklist

## Rubric 100 คะแนน

| หมวด | คะแนน | หลักฐาน |
|---|---:|---|
| Requirement/traceability | 10 | brief, REQ→TEST mapping |
| API contracts/validation | 12 | schemas, status/error tests |
| SQLite transaction/idempotency | 15 | duplicate/conflict/restart tests |
| Worker/state/recovery | 15 | state transitions, bounded retry/drill |
| Evidence/AI safety | 15 | hallucination/absence validators |
| Human review/audit | 10 | transition, actor/action/time evidence |
| n8n orchestration | 8 | inactive export, execution evidence, truthful routes |
| Tests/code quality | 7 | focused + full commands, readable boundaries |
| Docker/config/security | 4 | no secrets, health/readiness, limitation |
| Documentation/demo/handoff | 4 | README, runbook, clean-start rehearsal |

## Minimum Pass

- อย่างน้อย 70/100
- ห้ามตก critical gate: duplicate creates side effect, unsupported quote approved, raw resume logged, accepted task lost silently หรือ tests ไม่ reproducible

## Delivery Checklist

- [ ] `git status` clean และ commit history แบ่งตาม milestone
- [ ] README มี prerequisites/setup/run/test/demo/limitations
- [ ] `.env.example` ไม่มี secret
- [ ] schema/state/architecture ตรง code ปัจจุบัน
- [ ] test matrix มี actual evidence ไม่ใช่ช่องว่าง
- [ ] n8n export inactive ไม่มี pinned PII/credentials/internal secret URLs
- [ ] Docker/native commands แสดง expected output
- [ ] failure drill และ safe replay อธิบายได้
- [ ] reviewer/handoff rehearsal ทำจาก clean start
- [ ] ระบุชัดว่า synthetic, mock และไม่ใช่ production system

## Demo 7 นาที

```text
0:00 problem, scope, architecture
1:00 valid intake → task ID
2:00 worker → evidence draft
3:00 unsupported quote ถูกบล็อก
4:00 duplicate/conflict
5:00 human review + audit
6:00 tests, recovery, limitation, next step
```

## Reflection

ตอบหลังจบ:

1. จุดใดที่ตอนแรกคิดว่า n8n ควรทำ แต่ย้ายไป Python/DB เพราะอะไร
2. test ใดพบ bug ที่ demo ปกติไม่พบ
3. state/transaction ใดช่วย recovery
4. ถ้าใช้ resume จริง ต้องเพิ่ม approval/control อะไร
5. ถ้ามีเวลาอีกหนึ่งวัน จะเพิ่มอะไรโดยไม่ทำ scope หลุด

