# 15 — Architecture Gallery: AI Integration ในงานจริง

บทนี้ใช้เป็นแผนที่เชื่อมทฤษฎีกับงาน ไม่ใช่แบบสำเร็จรูปสำหรับนำขึ้น production ทุก case เริ่มด้วย synthetic data และแยก suggestion ออกจาก high-impact decision

## ภาพกลางที่ใช้ร่วมกัน

```text
Source → Ingest/Normalize → Deterministic checks → LLM task
  │                                                ↓
  └────────────── evidence refs ───────> Parse → Schema → Evidence
                                                    ↓
                           usable draft / review / failed / blocked
                                                    ↓
                                 Human/policy-approved side effect
```

## Case 1: HR Resume Evidence Assistant

**ปัญหา:** HR อ่านเอกสารจำนวนมากและต้องกลับไปหาหลักฐานเดิม

```text
Upload reference → parser สร้าง segments+source_id
      ↓
LLM สกัด skill/education claims พร้อม quote
      ↓
Pydantic → quote/source validation → review UI
      ↓
HR ดูต้นฉบับและตัดสินเอง
```

Output ที่เหมาะคือ profile draft + evidence ไม่ใช่ `hire=true` ข้อมูลที่ไม่พบใช้ unknown/empty claims ไม่ตีความว่าไม่มีความสามารถ

Production concerns: parser isolation, file limits, PII minimization, access control, retention, bias/fairness review, versioned evidence และ reviewer audit

## Case 2: Customer Support Ticket Triage

**ปัญหา:** ส่ง ticket ไปทีมผิดและตอบช้า

```text
Ticket → redact/minimize → classify allowed label + evidence
       → confidence/evidence policy
       ├─ strong + low risk → route queue
       └─ ambiguous/high risk → human triage
```

รุ่นแรกให้ AI ช่วย route/draft ไม่ส่งข้อความลูกค้าเอง Metrics: routing precision ราย category, review rate, time-to-first-human และ false urgent downgrade

## Case 3: Incident Report Summarizer

**ปัญหา:** ข้อมูลกระจายจาก metrics, logs และ notes

```text
SQL/monitoring คำนวณ facts → LLM เขียน draft timeline
       ↓                         ↓
source timestamps/IDs       validate numbers/causal wording
       └──────────────→ incident commander review → publish
```

LLM ไม่ควรคำนวณยอดจาก log ยาวหรือประกาศ root cause หากหลักฐานมีเพียง correlation

## Case 4: Transaction Anomaly Explanation

**ปัญหา:** rule engine คืน flags ที่คนอ่านยาก

```text
Transaction facts → deterministic rules → reason codes
                                     ↓
                          LLM แปลงเป็น draft explanation
                                     ↓
                           compare facts/numbers → reviewer
```

โมเดลอธิบายผลของ rule ไม่สร้าง risk decision ใหม่ Side effect เช่น freeze/refund ยังอยู่ในระบบ policy ที่ authenticate/authorize แล้ว

## Case 5: Internal Knowledge Assistant / RAG

**ปัญหา:** พนักงานค้น policy หลายฉบับ

```text
Question → identity/scope → retrieve current authorized chunks
         → answer only from evidence + citations
         → no evidence = say not found / escalate owner
```

ต้องทดสอบ retrieval แยกจาก generation และรองรับ document update/delete/permission changes

## เลือก Architecture จาก Risk

| ผลลัพธ์ | รูปแบบเริ่มต้น |
|---|---|
| อ่าน/สรุปเพื่อช่วยคน | AI draft + citations + human review |
| route งานภายในที่ย้อนกลับได้ | validated classification + fallback queue |
| ส่งข้อความภายนอก | draft → approval → idempotent send |
| เงิน สิทธิ์ การจ้าง หรือข้อมูลอ่อนไหว | deterministic policy + authorized human; AI เป็น evidence assistant |

## Mock → Staging → Production

```text
Deterministic Mock
พิสูจน์ code paths/schema/retry
        ↓
Real model + synthetic evaluation
พิสูจน์คุณภาพบน dataset ที่ระบุ
        ↓
Staging integrations
พิสูจน์ network/credentials/queue/observability
        ↓
Limited production rollout
วัด drift, cost, latency, review capacity, incidents
```

แต่ละลูกศรมีหลักฐานใหม่ ไม่มีขั้นใดอนุมานว่าผ่านเพราะขั้นก่อนสีเขียว

## Design Exercise

เลือกหนึ่ง case แล้วเขียน artifact หกชิ้น:

1. problem statement และสิ่งที่ระบบ **ไม่ทำ**
2. input/output schema พร้อม example
3. architecture flow และ trust boundaries
4. failure policy: retry/review/block
5. evaluation cases อย่างน้อย 10 รายการพร้อม tags
6. production checklist: privacy, authorization, observability, owner, rollback

หากอธิบายได้ว่า LLM อยู่ node ไหน ใครตรวจ output และใครมีสิทธิ์ทำ side effect คุณเริ่มคิดแบบ AI integration engineer แล้ว
