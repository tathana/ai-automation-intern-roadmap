# 11 — Testing และ Evaluation

## สองคำถามที่ต้องแยก

**Software tests:** โค้ดทำตามกฎหรือไม่ เช่น 503 ทำ retry สามครั้ง ส่วน **model evaluation:** คำตอบของโมเดลดีพอสำหรับงานหรือไม่ เช่นสกัดทักษะที่มีหลักฐานได้ครบเพียงใด

```text
Mock tests ผ่าน → โค้ดรับมือ output ตามกรณีที่กำหนดได้
Real-model eval ผ่าน → หลักฐานคุณภาพบนชุดประเมินนั้น
ทั้งคู่ยังไม่รับประกันทุก input ในอนาคต
```

## เขียน test ให้ตรวจสิ่งสำคัญ

```python
def test_missing_evidence_routes_to_review():
    result = analyze(request, MockProvider("hallucination"))
    assert result["status"] == "needs_review"
    assert result["profile"] is None
```

assert ที่สองสำคัญ เพราะบางระบบบอก needs_review แต่ยังแนบข้อมูลที่ไม่ผ่านไว้ในช่อง validated profile แล้ว downstream เผลอใช้ต่อ

## Dataset สำหรับประเมิน

แยก development set ที่ใช้ปรับ prompt กับ held-out set ที่ยังไม่ใช้ปรับ มีภาษาไทย/อังกฤษ, input สั้น/ยาว, missing info, negation, injection และรูปแบบที่ไม่เคยเห็น เก็บ expected labels/evidence ที่ผู้ตรวจยืนยันแล้ว

## Metric ไม่ควรมีแค่เลขเดียว

สำหรับ extraction: precision ของ claims, recall ของข้อมูลที่ควรพบ, unsupported-claim rate และ review rate ถ้าคืน list ว่างทุกครั้งจะไม่มี hallucination แต่ recall ต่ำมาก จึงไม่ควรผ่านเพียงเพราะ false claim เป็นศูนย์

สำหรับ classification ใช้ confusion matrix/ผลรายหมวด สำหรับ summary ใช้ rubric เรื่องข้อเท็จจริง ความครบ และระดับความแน่นอน ไม่จำเป็นต้อง match string เดียวเป๊ะ

## Regression และเวอร์ชัน

เมื่อเปลี่ยน prompt/model/parser ให้รันชุดเดิมเทียบก่อนหลัง เก็บ model identifier, prompt version, schema version และ parser version การลด latency แต่เพิ่ม unsupported claims ต้องเห็นเป็น tradeoff ไม่สรุปว่าดีขึ้นทุกด้าน

ไฟล์ [evaluate.py](lab/evaluate.py) ประเมิน deterministic mock บน fixtures เท่านั้น ผลคะแนนที่ได้ไม่ใช่ผลประเมินโมเดลจริง ให้นำรูปแบบรายงานไปต่อยอดภายหลัง

## ชั้น Practice: Evaluation row หนึ่งแถวควรมีอะไร

```json
{
  "case_id": "negation-001",
  "input_ref": "fixture://resume/negation-001",
  "expected_claims": [],
  "forbidden_claims": ["Docker experience"],
  "tags": ["thai", "negation"],
  "reviewer_note": "ข้อความระบุว่ายังไม่เคยใช้"
}
```

อย่าใส่ expected output เป็นข้อความเดียวทั้งหมดหากงานยอมรับคำตอบได้หลายแบบ แยก assertions ที่สำคัญและ rubric สำหรับคุณภาพภาษา

## อ่าน metric ด้วย confusion matrix

```text
                     Expected claim   Expected no claim
Predicted claim           TP                FP
Predicted no claim        FN                TN
```

precision สนใจว่า claims ที่ระบบให้มาถูกกี่ส่วน; recall สนใจว่าหลักฐานที่ควรพบ ระบบพบกี่ส่วน งาน HR อาจให้ค่าความเสียหายของ false positive/negative ต่างกัน ต้องคุยกับเจ้าของงาน ไม่เลือก threshold จากตัวเลขสวยอย่างเดียว

## ชั้น Deep Dive: Release gate

กำหนด baseline และเพดาน เช่น unsupported-claim rate ห้ามแย่ลง, review rate ไม่พุ่งเกิน capacity, p95 latency/cost อยู่ในงบ และ security cases ต้องผ่าน เมื่อเปลี่ยน model/prompt/parser ให้บันทึก diff และผลราย tag ไม่ดูเฉพาะคะแนนรวม
