# 16 — Visual Notes: LLM, RAG, Agent และ Human Review

## LLM ไม่ได้คืน “ความจริง” โดยอัตโนมัติ

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Prompt + Context</div><span class="visual-arrow">tokens →</span><div class="visual-box">Model</div><span class="visual-arrow">probabilistic →</span><div class="visual-box">Raw Output<br><small>untrusted</small></div><span class="visual-arrow">→</span><div class="visual-box">Validators</div><span class="visual-arrow">→</span><div class="visual-box">Review / Action</div></div></div>

## Structured Extraction

<div class="visual-board"><div class="visual-grid"><div class="visual-pane"><div class="visual-label">SOURCE</div><p>segment/page IDs และ text</p></div><div class="visual-pane"><div class="visual-label">MODEL DRAFT</div><p>field + quote + source ID</p></div><div class="visual-pane"><div class="visual-label">VALIDATED</div><p>schema + quote exists + policy</p></div></div></div>

Schema ผ่านเพียงพิสูจน์รูปทรงข้อมูล ไม่พิสูจน์ว่า quote/claim อยู่ใน source

## RAG สองช่วง

<div class="visual-board"><div class="visual-lane"><strong>Index</strong><div class="visual-track">documents → clean/chunk → embeddings → index + metadata/permissions</div></div><div class="visual-lane"><strong>Query</strong><div class="visual-track">question → retrieve → permission filter → context → answer + citations</div></div><div class="visual-lane"><strong>Evaluate</strong><div class="visual-track">retrieval relevance · groundedness · abstention · permission leakage</div></div></div>

## Agent และ Tool Permission

<div class="visual-board"><div class="visual-flow"><div class="visual-box">Model proposes<br>tool + args</div><span class="visual-arrow">→</span><div class="visual-box">Allowlist + typed validation</div><span class="visual-arrow">→</span><div class="visual-box">Human approval<br><small>high impact</small></div><span class="visual-arrow">→</span><div class="visual-box">Tool executes</div><span class="visual-arrow">→</span><div class="visual-box">Audit + result</div></div></div>

Prompt ไม่ใช่ authorization; model ไม่ควรขยายสิทธิ์หรือเลือก side effect สำคัญเอง

## n8n + AI ในงานจริง

<div class="visual-board"><div class="visual-flow"><div class="visual-box">n8n trigger</div><span class="visual-arrow">→</span><div class="visual-box">FastAPI/Worker</div><span class="visual-arrow">→</span><div class="visual-box">Model Adapter</div><span class="visual-arrow">→</span><div class="visual-box">Evidence Validator</div><span class="visual-arrow">→</span><div class="visual-box">n8n review route</div><span class="visual-arrow">→</span><div class="visual-box">Human</div></div></div>

