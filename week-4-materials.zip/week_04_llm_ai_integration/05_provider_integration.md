# 05 — แยก Provider ออกจาก Business Logic

## ทำไมต้องมีชั้นกลาง

ถ้า FastAPI endpoint มีทั้ง prompt, SDK call, retry และตรวจ Resume อยู่ในฟังก์ชันเดียว การทดสอบหนึ่งเรื่องจะไปเรียกโมเดลจริงโดยไม่จำเป็น แยก provider interface เพื่อเปลี่ยนบริการได้โดยไม่เปลี่ยนกฎตรวจทั้งหมด

```text
API → analyze(request, provider)
                         ├─ MockProvider: tests ฟรีและควบคุมผลได้
                         └─ Real adapter: ทดลองเมื่อพร้อมและมีงบ
```

## Interface คือข้อตกลงว่าจะเรียกอย่างไร

```python
class MockProvider:
    def generate(self, request):
        return '{"skills": [], "education": null}'
```

method นี้คืน string แบบ provider response ยังไม่คืนสถานะสำเร็จของธุรกิจ การแปลงและตรวจอยู่ใน service ส่วน `self` คือ instance ปัจจุบัน ใช้เก็บจำนวนครั้งที่เรียกหรือ scenario สำหรับการทดสอบได้ แต่ไม่ใช่ที่เก็บงานถาวรข้าม process

ใน [lab/provider.py](lab/provider.py) mock แยกสถานการณ์ invalid_json, hallucination, refusal, transient และ timeout ให้ทดลองได้ซ้ำ **mock ไม่เข้าใจภาษาและไม่ใช่ตัวแทนคุณภาพ LLM จริง**

## Real provider เป็นขั้นเลือกทำ

ตัวอย่าง adapter ใน [openai_adapter_example.py](lab/openai_adapter_example.py) แยกจาก API หลัก ไม่ถูก import หรือเรียกโดยอัตโนมัติ ตั้ง model ผ่าน environment ตามโมเดลที่บัญชีมีสิทธิ์และรองรับ structured output ไม่ hardcode ราคา/รุ่นว่าใหม่ที่สุด

ก่อนใช้จริง: ตรวจ SDK version, model capabilities, data policy, timeout และค่าใช้จ่าย ใช้ข้อมูลสังเคราะห์หนึ่งรายการก่อน ห้ามวาง key ใน n8n export, HTML หรือ Git

## Timeout สองระดับ

Timeout ของ SDK คุมการรอ network ส่วน deadline ของงานรวมต้องครอบ retries/validation/queue ด้วย ตั้ง SDK retry และ application retry ให้ไม่ซ้อนโดยไม่ตั้งใจ เช่น SDK 3 ครั้ง × service 3 ครั้ง อาจเป็น 9 requests

lab จำลอง timeout ด้วย exception เพื่อทดสอบ routing ไม่ได้พิสูจน์ timeout ของ network จริง อ่าน Verification เพื่อแยกสิ่งที่ทดสอบแล้วกับสิ่งที่ยังต้องทำเมื่อเชื่อม provider

## ชั้น Core: Adapter แยกภาษาของระบบออกจาก SDK

```text
service.analyze(request)
        ↓ เรียก interface generate(prompt, schema)
Provider adapter
        ↓ แปลงเป็น SDK request ของผู้ให้บริการ
SDK/network/model
        ↓ แปลง response/error กลับเป็นชนิดของเรา
service parse + validate + route
```

business service ไม่ควรรู้ชื่อ field เฉพาะของ SDK ทุกจุด วิธีนี้ทำ mock tests ได้และเปลี่ยน provider โดยไม่รื้อ policy ทั้งระบบ

## ชั้น Practice: Error translation

adapter ควรแยกอย่างน้อย `ProviderTimeout`, `RateLimited`, `AuthenticationFailed`, `InvalidProviderResponse` และ unknown provider error แล้วให้ service ตัดสิน policy ไม่ส่ง stack trace หรือ raw response กลับ client

```text
SDK exception → adapter error → retry policy → public status/reason code
```

ทดสอบแต่ละ error ด้วย mock ที่ deterministic ก่อนเชื่อม key จริง จากนั้นทำ staging probe หนึ่งรายการสังเคราะห์และตรวจ timeout/usage/log redaction

## ชั้น Deep Dive: Configuration ที่ควร version/record

model identifier, prompt version, schema version, sampling parameters, timeout, retry policy และ provider endpoint มีผลต่อผลลัพธ์ เก็บ metadata เหล่านี้กับ analysis record โดยไม่เก็บ secret
