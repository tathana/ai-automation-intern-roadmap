# 06 — Classification, Extraction และ Summarization

## งานสามแบบต้องตรวจคนละอย่าง

| งาน | Input | Output | จุดที่ตรวจ |
|---|---|---|---|
| Classification | ticket | category | label อยู่ในชุดที่อนุญาตและตรงความหมาย |
| Extraction | resume text | claims + evidence | ไม่เติมข้อมูลและไม่อ้างผิดส่วน |
| Summarization | incident notes | summary | ไม่เพิ่มสาเหตุ/ตัวเลขที่ต้นฉบับไม่มี |

ทั้งสามงานคืน JSON ได้ แต่ไม่ควรใช้ schema เดียวกันเพียงเพราะรับข้อความเหมือนกัน

## Classification ต้องมีทางไม่แน่ใจ

ตัวอย่าง labels: `payment`, `account`, `other`, `needs_review` ข้อความ “เข้าไม่ได้หลังตัดเงิน” อาจเกี่ยวสองหมวด ให้กำหนดว่าระบบใช้ single-label หรือ multi-label และมีกติกา tie-break อย่างไร

อย่าดูแค่ accuracy รวม หาก dataset 90% เป็น payment โมเดลที่ตอบ payment ทุกครั้งก็ได้ 90% แต่ไม่ช่วยทีม account เลย ต้องดูผลแยกตามหมวดและ cases ที่พลาด

## Extraction ไม่ใช่เติมช่องให้ครบ

Input: `Built a Python ETL project.`

```json
{"name":"Python","quote":"Built a Python ETL project.","source_id":"p1"}
```

สิ่งที่ไม่ควรเพิ่มคือ years_experience=3 หรือ proficiency=expert เพราะ input ไม่ได้บอก การเก็บ unknown ทำให้ข้อมูลตรงกว่าการเดาให้ schema ดูสมบูรณ์

## Summarization ต้องรักษาระดับความแน่นอน

```text
ต้นฉบับ: ทีมสงสัยว่า latency อาจเกี่ยวกับ deploy
     ↓
ใช้ได้: ทีมกำลังตรวจความเกี่ยวข้องระหว่าง deploy กับ latency
ใช้ไม่ได้: deploy เป็นสาเหตุของ latency แน่นอน
```

ฝึกสรุป anomaly โดยให้ Python/SQL คำนวณจำนวนรายการและยอดก่อน จากนั้น AI สรุปจากตัวเลขที่ส่งให้ ห้ามให้โมเดลเดายอดรวมจากรายการยาวแทนระบบคำนวณ

## Workshop ที่ตรวจเองได้

อ่าน [workshops.py](lab/workshops.py) มี fixtures ทั้งสามงานและตัวตรวจขั้นต่ำ ให้เพิ่ม cases “คำสองความหมาย”, “การปฏิเสธ” และ “ตัวเลขเปลี่ยนใน summary” ส่วนการตัดสินความหมายขั้นสุดท้ายยังใช้ rubric และผู้ตรวจ ไม่ใช้เพียง `assert isinstance(output, dict)`

