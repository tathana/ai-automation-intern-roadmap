# 13 — Embeddings และ RAG Overview

## เมื่อเอกสารเยอะเกินจะส่งทั้งหมด

RAG หรือ Retrieval-Augmented Generation คือค้นส่วนข้อมูลที่เกี่ยวข้องแล้วแนบให้โมเดลสร้างคำตอบ Embedding เป็นตัวแทนข้อมูลแบบ vector ที่ใช้เปรียบเทียบความใกล้กันได้ แต่ความใกล้ไม่เท่ากับข้อเท็จจริงถูกหรือมีสิทธิ์เข้าถึง

```text
เอกสาร → แบ่ง chunks → ทำ embeddings → เก็บ index
คำถาม → ค้น chunks ที่เกี่ยวข้อง → กรองสิทธิ์/แหล่งข้อมูล
                                      ↓
                            LLM ตอบพร้อมอ้างอิง
```

## Chunk คือชิ้นข้อมูล ไม่ใช่ตัดทุก N ตัวอักษรเสมอ

การตัดกลางประโยคหรือแยกหัวข้อจากรายละเอียดอาจทำให้ความหมายหาย Overlap ช่วยบริบทแต่เพิ่มข้อมูลซ้ำ ต้องเลือกจากงานและประเมินผล ไม่ใช้ chunk size เดียวเป็นคำตอบสากล

เก็บ document_id, page/section, version และ access scope กับ chunk ไม่เก็บแต่ข้อความจนย้อนที่มาไม่ได้

## Retrieval failure กับ Generation failure

ถ้าระบบค้นไม่เจอหน้าเงื่อนไขสำคัญ ต่อให้โมเดลสรุปจากสิ่งที่ได้รับอย่างซื่อสัตย์ก็ยังตอบไม่ครบ แยกวัดว่าค้นหลักฐานเจอหรือไม่ และคำตอบใช้หลักฐานถูกหรือไม่

```text
หลักฐานไม่ถูกส่งให้โมเดล → แก้ retrieval
หลักฐานส่งแล้วแต่ตอบผิด → ตรวจ generation/prompt/validation
```

## Week นี้จำเป็นต้องมี vector database ไหม

ไม่จำเป็นสำหรับ resume สั้นหนึ่งไฟล์ เริ่ม direct extraction ก่อน RAG เหมาะเป็นหัวข้อเสริมเมื่อค้นเอกสารหลายฉบับ/คู่มือจำนวนมาก การเพิ่ม vector DB ยังเพิ่มภาระ index freshness, deletion, authorization และ evaluation

Stretch: ใช้เอกสารสมมติ 5 ชิ้น ทำ keyword retrieval baseline ก่อน แล้วเปรียบเทียบกับ embeddings ด้วยชุดคำถามเดียวกัน อย่าสรุปว่า embeddings ดีกว่าเพียงเพราะเป็นเทคนิค AI

## ชั้น Core: RAG มีสอง pipeline

```text
Indexing pipeline
document → parse → chunk → metadata/ACL → embedding/index

Query pipeline
question → retrieve → filter permission/version → assemble context
         → LLM → answer + citations → validation
```

indexing สำเร็จวันนี้ไม่ได้แปลว่าข้อมูลสดตลอด ต้องรองรับ update/delete/re-index และตรวจว่า chunk เก่าหายจริงตาม retention policy

## ชั้น Practice: เริ่มด้วย keyword baseline

สร้างเอกสารสังเคราะห์ห้าชิ้นพร้อม `document_id`, `section`, `version`, `access_scope` แล้วเขียนคำถามสิบข้อ วัด `retrieval_hit@k`: หลักฐานที่ผู้ตรวจระบุอยู่ใน top-k หรือไม่ ก่อนเพิ่ม LLM

หาก retrieval ไม่พบหลักฐานที่ถูกต้อง อย่าให้โมเดลตอบจากความรู้ทั่วไป ให้ตอบว่าไม่พบในแหล่งข้อมูลที่อนุญาต

## ชั้น Deep Dive: Authorization ต้องมาก่อน/หลัง retrieval ตามการออกแบบ

อย่าดึง chunks ที่ผู้ใช้ไม่มีสิทธิ์แล้วหวังให้ prompt ไม่เปิดเผย ควรกรองสิทธิ์ใน data/retrieval layer และตรวจอีกครั้งก่อนแสดง citation การใช้ vector similarity ไม่ได้ทำให้ access control เกิดขึ้นเอง
