# Drills — ลงมือฝึก Week 4

ทุกข้อบันทึก input, expected, actual และสิ่งที่แก้ อย่าใส่ expected ในช่อง actual จนกว่าจะรันแล้ว

## 1. เลือกเครื่องมือให้ถูกงาน

จัดกลุ่มงาน: รวมยอด, อ่าน ticket, ตรวจ email format, สรุป incident, approve refund และอ่าน Resume พร้อมอธิบายเหตุผล

ผ่านเมื่อไม่ใช้ LLM คำนวณเงินแทน Python และไม่ให้ AI อนุมัติ refund เพียงเพราะข้อความลูกค้าบอกว่ามีสิทธิ์

## 2. Prompt Contract

แก้ prompt `Find everything about this candidate` ให้ระบุงาน หลักฐาน unknown และข้อห้าม เพิ่มตัวอย่าง “กำลังเรียน SQL” กับ “ไม่เคยใช้ Docker”

ส่งมอบ prompt_v2 และ test input อย่างน้อย 4 แบบ ไม่ต้องเรียก API จริง แต่อธิบายได้ว่าแต่ละคำสั่งจะตรวจด้วยกฎหรือ rubric ใด

## 3. Structured Output Detective

ลอง `invalid_json`, `invalid_schema` และ `hallucination` ใน demo เปรียบเทียบ reasons และ profile ต้องเป็น null เมื่อไม่ผ่าน

คำถาม: ทำไม hallucination อาจผ่าน Pydantic? แนวตอบคือชนิดข้อมูลถูกแต่ไม่รองรับด้วย source

## 4. Evidence Checker

เพิ่ม test สำหรับ quote ว่าง, source_id ผิด, quote จากอีกหน้า, claim Rust แต่ quote Python และประโยคปฏิเสธ จากนั้นหา counterexample ที่ผ่าน lexical checker แต่ยังผิดความหมาย

ผ่านเมื่อระบุข้อจำกัดได้จริง ไม่สรุปว่าตรวจ substring แล้ว AI ไม่มีทางแต่งเรื่อง

## 5. Failure Lab

ใช้ transient แล้วเก็บ provider.calls=3; timeout ต้องหยุดที่ 3; refusal ต้องไม่ retry ให้แก้ max_attempts=1 แล้วทายผล transient ก่อนรัน

Stretch: เพิ่ม repair policy สูงสุดหนึ่งครั้ง โดยไม่เพิ่มจำนวน calls เกิน budget รวม และห้าม repair หลักฐานที่ไม่มีในเอกสาร

## 6. Tool Permission Lab

ใช้ dispatch lookup T1 ในฐานะ demo-user ต้องผ่าน ส่วน T2, send_email และ approved=true ต้องถูกปฏิเสธ

ผ่านเมื่ออธิบายว่า authenticated_user ต้องมาจากระบบที่ยืนยันตัวตนแล้ว ไม่ใช่ argument ที่โมเดลหรือ client ป้อนเองตามใจ

