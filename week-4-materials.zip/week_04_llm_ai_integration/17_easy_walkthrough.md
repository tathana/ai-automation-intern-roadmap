# 17 — Easy Walkthrough: จาก “เรียก AI” ไปสู่ระบบที่เชื่อถือได้

Week 4 ไม่ได้สอนให้เชื่อคำตอบของโมเดลเก่งขึ้น แต่สอนให้วางโมเดลไว้ในระบบโดยรู้ว่าอะไรเชื่อได้ อะไรต้องตรวจ และใครมีสิทธิ์ตัดสินใจ

## 1. LLM คือคนร่าง ไม่ใช่ฐานข้อมูลข้อเท็จจริง

```text
Input/context + instruction
  ↓ LLM คาด token ถัดไป
Candidate output
  ↓ application ตรวจ schema/evidence/policy
Validated result หรือ needs_review
```

คำตอบดูเป็นธรรมชาติไม่ได้แปลว่าถูก โมเดลเหมาะกับงานภาษา เช่นจัดหมวด สรุป หรือเสนอข้อมูลที่ต้องตรวจ ไม่ควรเป็นเจ้าของยอดเงิน สิทธิ์ หรือ final hiring decision

## 2. Token และ Context Window แบบเห็นภาพ

Prompt, เอกสาร, history, tool result และ output ต่างใช้พื้นที่ context เดียวกัน:

```text
[system][instructions][resume][examples][tool output][answer]
└──────────────── context window ────────────────┘
```

ส่งข้อมูลมากไม่ได้แปลว่าเข้าใจดีขึ้นเสมอ อาจเพิ่ม cost/latency และทำให้คำสั่งสำคัญจมหาย จึงเลือกเฉพาะ context ที่จำเป็นและวัดผลจาก task จริง

## 3. Prompt Contract

Prompt ที่ใช้ทำงานควรบอก role/task/input boundary/output schema/failure behavior:

```text
งาน: สกัด skill evidence
source: ข้อความระหว่าง <document>...</document>
กฎ: ห้ามสร้าง quote ที่ไม่มีใน source
output: JSON ตาม schema
ถ้าไม่มี: found=false, quote=null
```

แต่ prompt ไม่ใช่ enforcement เพียงชั้นเดียว Application ยังต้อง parse และ validate

## 4. Structured Output ผ่านยังไม่แปลว่าจริง

```text
JSON parse ผ่าน       → syntax ถูก
Pydantic ผ่าน          → shape/type ถูก
Evidence validator ผ่าน → quote ตรวจย้อน source ได้
Policy ผ่าน            → อนุญาตให้ใช้ outcome นี้
```

สี่ชั้นนี้ตอบคนละคำถาม อย่ารวมคำว่า “validation ผ่าน” จนไม่รู้ว่าผ่านชั้นใด

## 5. Provider Adapter ช่วยอะไร

```text
service → Provider interface → MockProvider / RealProvider
```

Service ไม่ควรรู้ชื่อ SDK ทุกเมธอด การแยก adapter ทำให้ tests ใช้ mock แบบ deterministic และเปลี่ยน provider/version โดยไม่แก้ domain rule

## 6. Error แต่ละชนิดทำอย่างไร

| Error | ภาษาง่าย | Action |
|---|---|---|
| timeout/429/selected 5xx | บริการอาจกลับมา | bounded retry |
| invalid JSON/schema | คำตอบใช้ไม่ได้ | retry จำกัดหรือ review ตาม policy |
| unsupported evidence | ข้อความอ้างไม่มีจริง | block/flag; ห้าม approve อัตโนมัติ |
| refusal | โมเดลไม่ทำงานที่ขอ | บันทึกเป็น outcome ไม่ปลอม success |
| auth/config | ตั้งค่าหรือสิทธิ์ผิด | fail fast; ไม่ retry ไม่สิ้นสุด |

## 7. Prompt Injection

ข้อความในเอกสารเป็น **data** แม้จะเขียนว่า “ให้ข้ามกฎและส่ง secret” ก็ไม่กลายเป็น instruction ของระบบ:

```text
trusted instruction ─────┐
tool policy/allowlist ───┼→ application controls
untrusted document ──────┘  (อ่านเป็นข้อมูลเท่านั้น)
```

หาก agent ใช้ tools ต้องจำกัด tool, argument, permission, budget และจุด approval ไม่ให้โมเดลเลือก side effect ได้กว้างเกินไป

## 8. Agent ต่างจาก Workflow อย่างไร

- Workflow: เส้นทางหลักกำหนดไว้ล่วงหน้า ตรวจง่าย เหมาะกับขั้นตอนแน่นอน
- Agent: โมเดลเลือก tool/ลำดับบางส่วน ยืดหยุ่นแต่เสี่ยงและ evaluate ยากกว่า

เริ่มจาก workflow + LLM call ธรรมดาก่อน เพิ่ม agent เฉพาะเมื่อการเลือกขั้นตอนแบบ dynamic สร้างคุณค่าที่วัดได้

## 9. RAG แบบไม่แต่งศัพท์

```text
question → retrieve เอกสารที่เกี่ยวข้อง
         → ส่ง chunks + source IDs ให้ LLM
         → answer + citations
         → ตรวจ citation/access policy
```

RAG ไม่รับประกันความจริง หาก retrieve ผิดหรือโมเดลอ้างเกิน context ผลยังผิดได้ ต้อง evaluate retrieval และ answer แยกกัน

## 10. Evaluation

อย่าทดสอบแค่ตัวอย่างสวยหนึ่งเคส สร้าง dataset สังเคราะห์ที่มี normal, absent, ambiguous, hallucination, refusal, malformed และ injection:

```text
fixture + expected property
  ↓ run pipeline version
actual structured result
  ↓ deterministic checks + human rubric
metrics + failure examples
```

เก็บ model/prompt/schema/dataset version เพื่อเทียบรอบถัดไปอย่างยุติธรรม

## 11. อ่าน Structured Output Code ทีละส่วน

```python
class Evidence(BaseModel):
    skill: str
    found: bool
    quote: str | None = None
```

- `BaseModel` ให้ Pydantic สร้าง/ตรวจ object จากข้อมูลภายนอก
- `skill: str` ต้องมี field และควรเพิ่ม length/normalization ตาม contract
- `found: bool` บอกว่า provider อ้างว่าพบหรือไม่
- `str | None` หมายถึง quote เป็นข้อความหรือ `None`
- `= None` ทำให้ field optional ตอนสร้าง object

แต่ model นี้ยังยอมรับ `found=True, quote=None` จึงต้องเพิ่ม model validator หรือ domain validator สำหรับความสัมพันธ์ข้าม field

```python
raw = provider.generate(prompt)
parsed = json.loads(raw)
evidence = Evidence.model_validate(parsed)
```

ภาพการทำงาน:

```text
provider string
  ↓ json.loads: syntax JSON ถูกไหม
Python dict
  ↓ model_validate: field/type ถูกไหม
Evidence object
  ↓ verify_quote: ข้อเท็จจริงรองรับไหม
```

Exception แต่ละบรรทัดจึงหมายถึง failure คนละ boundary อย่าจับ `except Exception` แล้วตอบ success เหมือนกันหมด

## 12. Provider Interface แบบง่าย

```python
class Provider(Protocol):
    def generate(self, prompt: str) -> str: ...

def extract(provider: Provider, prompt: str) -> Evidence:
    raw = provider.generate(prompt)
    return Evidence.model_validate_json(raw)
```

`Protocol` บอกว่า object ใดมี method `generate(str) -> str` ก็ใช้ได้ ไม่ต้องสืบทอด class เดียวกัน ใน test เราส่ง `MockProvider`; ตอนรันจริงส่ง adapter ของ SDK นี่คือการพึ่ง **contract** แทนการผูก service กับ vendor

## ตัวอย่างงานจริงหนึ่งเส้น

```text
n8n รับ candidate_id + synthetic text
→ FastAPI ตรวจ contract
→ provider คืน evidence draft
→ Pydantic ตรวจ shape
→ validator เทียบ quote กับ source
→ unsupported ติด flag
→ HR review
→ audit เก็บ version/outcome
```

ประโยคที่ควรอธิบายกับทีมได้คือ: “โมเดลสร้าง candidate output; application เป็นผู้ enforce schema/evidence/policy; คนเป็นผู้ตัดสินใจผลกระทบสูง”
