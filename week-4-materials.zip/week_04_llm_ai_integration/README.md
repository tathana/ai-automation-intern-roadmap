# Week 4 — LLM และ AI Integration for Automation

Week 3 ช่วยให้เรารับงาน เรียก API และตามสถานะได้ สัปดาห์นี้จะเพิ่มงานอ่านภาษาเข้าไป โดยยังคงให้ Python ตรวจข้อมูลและให้คนตัดสินใจในเรื่องที่มีผลกระทบสูง

เป้าหมายคือเรียก AI แล้ว **ตรวจผล อธิบายข้อจำกัด และจัดการกรณีใช้คำตอบไม่ได้** ไม่ใช่เพียงให้ API ตอบกลับมา

## ลำดับการเรียน

| วัน | อ่าน | ลงมือ |
|---|---|---|
| 1 | 00–04 | เลือกงานให้เหมาะ, prompt contract, schema |
| 2 | 05–07 | mock provider, งานภาษา, evidence validation |
| 3 | 08–10 | failure, tool permissions, prompt injection |
| 4 | 11–12 | tests/evaluation, ต่อ n8n, Challenge |
| 5 | 13–14 และ HR Add-on | RAG overview, เอกสารสังเคราะห์, end-to-end |

ประมาณวันละ 3–5 ชั่วโมงพร้อมทดลอง ถ้าต้องแบ่งเวลาให้ลดส่วน RAG/OCR ขั้นเสริมก่อน ไม่ตัด validation, tests หรือ human review และไม่ต้องรอจำทุกศัพท์ก่อนเริ่ม lab

เริ่ม [00 Assessment](00_assessment.md) แล้วอ่านตามหมายเลข ชุดลงมือมี [Lab](lab/README.md), [Drills 6 ชุด](drills/README.md), [AI Output Guard](challenge/README.md) และ [HR Add-on](hr_intake/README.md)

## ภาพทั้งระบบ

```text
n8n รับงาน → FastAPI ตรวจ input → Provider อ่านภาษา
                                  ↓
                      parse → schema → evidence
                                  ↓
                 ผลที่ตรวจแล้ว / ต้องให้คนตรวจ
```

ชุดฝึกเริ่มด้วย MockProvider ที่คืนคำตอบตามกติกาสังเคราะห์ ไม่มีการเรียก API แบบเสียเงิน ไม่มีการค้นหา API key ในเครื่อง และไม่มีข้อมูลผู้สมัครจริง Model quality ยังต้องประเมินแยกเมื่อเลือกใช้โมเดลจริง

## สิ่งที่ได้เมื่อจบ

อธิบายได้ว่าเหตุใด schema ผ่านแต่ข้อเท็จจริงผิดได้, ทดสอบ refusal/invalid JSON/timeout ได้, ไม่ให้คำสั่งในเอกสารไปควบคุมเครื่องมือ และเตรียมผล Resume พร้อมหลักฐานให้ HR ตรวจ โดยไม่ตัดสิน reject/hire อัตโนมัติ

ดู [Verification](VERIFICATION.md) สำหรับสิ่งที่ทดสอบแล้วจริง และ [Sources](SOURCES.md) สำหรับรายละเอียดที่ต้องตรวจใหม่เมื่อเปลี่ยน SDK หรือโมเดล

