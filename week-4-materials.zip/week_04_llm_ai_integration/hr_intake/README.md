# HR Add-on — AI Resume Structured Extraction

## เริ่มจากเอกสาร ไม่เริ่มจากการให้คะแนนคน

ใช้ [Resume สังเคราะห์](../lab/fixtures/synthetic_resume.pdf) และ [PDF ว่างสำหรับ negative test](../lab/fixtures/empty_document.pdf) เพื่อทดลองสกัดข้อความ จากนั้นให้ mock สร้าง claims พร้อม evidence ตัวอย่างนี้ไม่ใช้ข้อมูลส่วนบุคคลจริงและไม่มี reject/hire endpoint

```text
task_id + candidate_id + file_hash จาก intake
       ↓
extract text → segments พร้อมตำแหน่ง
       ├─ เสีย/ว่าง/เข้ารหัส → review
       ↓
provider extraction → schema/evidence validation
       ↓
เทียบ requirement → แสดงหลักฐานให้ HR ตรวจ
```

## Text-based PDF, Scanned PDF และ DOCX

Text-based PDF อาจสกัด text ได้โดยไม่ OCR แต่ลำดับอ่านอาจผิดในหลายคอลัมน์ Scanned PDF มีภาพของตัวหนังสือ หากไม่มี text layer parser อาจได้ข้อความว่าง ไม่ควรเหมาว่าผู้สมัครไม่มีประสบการณ์

DOCX มี paragraphs/tables และอาจมี textboxes/headers ที่ parser ขั้นพื้นฐานไม่ครอบคลุม เก็บ warnings และทดสอบรูปแบบใหม่ก่อนรับรอง coverage OCR ยังคงเป็น Stretch Goal ตามแผนเดิม

## Schema ขั้นเล็กกับ schema เป้าหมาย

Lab ใช้ skills พร้อม quote/source_id, education=null และ warnings เพื่อเน้น evidence ก่อน Schema เป้าหมายสำหรับงานต่อยอดเพิ่ม education, work_experience, projects, certifications และ languages โดย **ทุก claim สำคัญต้องมี evidence** ไม่เพิ่ม field แล้วให้โมเดลเดาเติม

ตัวอย่าง field:

```json
{"value":"Python","evidence":{"source_id":"p1","quote":"Built a Python ETL project."}}
```

ไม่ทราบให้ null หรือสถานะ missing ตาม contract ส่วน [] ใช้เมื่ออ่านส่วนที่ครอบคลุมแล้วไม่พบรายการที่สกัดได้ อย่าปนกับ parse failure

## Requirement matching

matching.py ให้ข้อเสนอแบบ exact skill name เท่านั้น ยังไม่ตีความ “Python 2 years”, skill synonyms หรือคุณภาพโครงการ

- MATCHED_WITH_EVIDENCE: พบ claim/evidence ตามกฎ lab ยังต้องตรวจบริบท
- NOT_FOUND_IN_RESUME: ไม่พบในผลที่สกัด ไม่ได้พิสูจน์ว่าไม่มีทักษะ
- INSUFFICIENT_EVIDENCE: ใช้ในส่วนต่อยอดเมื่อหลักฐานมีแต่ไม่พอรองรับเงื่อนไข เช่นพบ Python แต่ไม่ทราบจำนวนปี
- NEEDS_HUMAN_REVIEW: ผลวิเคราะห์ใช้ไม่ได้หรือมีข้อสงสัยที่ต้องตรวจ

สถานะ INSUFFICIENT_EVIDENCE เป็นโจทย์ให้เพิ่มใน matcher ขั้นต่อไป ไม่ได้อ้างว่า exact-name matcher ปัจจุบันตรวจเงื่อนไขเชิงประสบการณ์แล้ว

## ข้อมูลที่ต้องเก็บเพื่อ audit

candidate_id, task_id, file_hash ของ bytes, text hash ของ segments, parser/prompt/model/schema versions และเวลาประมวลผล ค่า text hash ใน Week 4 ไม่ใช่ file_hash ของ Week 3 อย่านำมาแทนกัน

เก็บ HR decision แยกจาก AI suggestion เพื่อไม่เขียนทับประวัติเดิม และต้องใช้ reviewer identity จากระบบ login จริง ไม่เชื่อชื่อผู้ตรวจที่โมเดลส่งมา

## แบบฝึกจบ Add-on

รัน PDF สำเร็จ, PDF ว่างไป review, ใช้ภาษาไทย/อังกฤษใน eval fixtures, hallucination ถูกปฏิเสธ และ job criteria ว่างถูกแจ้ง error เพิ่ม fixture ที่มี “กำลังเรียน Python” แล้วอธิบายว่าไม่ควรตีความเป็นประสบการณ์ทำงานหลายปี

การต่อ queued tasks ของ Week 3 แบบอัตโนมัติ, durable results และสิทธิ์ HR เป็นงานรวมระบบ Week 5 ไม่รวมอยู่ใน synchronous demo นี้
