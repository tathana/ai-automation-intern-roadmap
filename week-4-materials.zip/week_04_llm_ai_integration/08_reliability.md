# 08 — Timeout, Retry และ Fallback

## อะไรลองใหม่ได้ อะไรควรหยุด

| เหตุการณ์ | แนวทางใน lab |
|---|---|
| transient provider error | ลองใหม่แบบมีขอบเขต |
| simulated timeout | ลองใหม่ไม่เกินเพดาน แล้ว review |
| invalid JSON/schema | review ไม่เรียกซ้ำไม่จำกัด |
| evidence ไม่พบ | review ไม่ซ่อมด้วยการแต่ง quote |
| refusal | เคารพการปฏิเสธ ไม่เปลี่ยน prompt เพื่อหลบ |
| input เกินขนาด | ตีกลับก่อนเรียก provider |

Fallback อาจเป็น “ยังไม่มีผลที่เชื่อถือได้ ต้องให้คนตรวจ” ไม่จำเป็นต้องเป็นคำตอบสำรองจากโมเดลอีกตัวเสมอ

## อ่าน bounded retry ทีละบรรทัด

```python
for attempt in range(1, 4):
    try:
        return provider.generate(request)
    except TransientProviderError:
        if attempt == 3:
            raise
        sleep(0.01 * (2 ** (attempt - 1)))
```

`range(1,4)` ได้ 1,2,3; `try` ทดลองเรียก; `except` จับเฉพาะชนิดที่ตั้งใจ retry; `raise` ส่ง error เดิมออกเมื่อครบเพดาน เวลา 0.01/0.02 วินาทีเป็นค่าจิ๋วสำหรับ lab ไม่ใช่ rate-limit policy จริง

## การซ่อม output ก็มีต้นทุน

บางระบบส่ง validation errors ให้โมเดลแก้ใหม่ได้ แต่ต้องจำกัด repair attempts แยกจาก network retries และตรวจ evidence ใหม่ทุกครั้ง ห้ามให้ repair step เติมข้อมูลที่ไม่มีในเอกสารเพียงเพื่อให้ครบ required fields

```text
เรียก provider → ตรวจไม่ผ่าน
                    ├─ policy อนุญาต repair 1 ครั้ง → ตรวจใหม่
                    └─ ไม่อนุญาต/เกินเพดาน → review
```

lab นี้เลือก review ทันทีสำหรับ invalid output เพื่อให้เห็นพฤติกรรมแน่นอนก่อน เพิ่ม repair เป็นโจทย์เสริมภายหลัง

## Idempotency กับ AI

request เดิมอาจให้ข้อความต่างเมื่อเรียกโมเดลซ้ำ ดังนั้นควรแยกการเก็บผลวิเคราะห์ตาม document_hash + prompt/model/schema version ออกจาก side effect เช่นสร้าง review task การ retry ไม่ควรสร้าง task ซ้ำเพียงเพราะคำตอบเปลี่ยน

ตัว service ใน Week 4 เป็น synchronous/stateless lab ไม่ได้เพิ่ม durable queue หรือ exactly-once processing ให้ Week 3 อัตโนมัติ การรวมระบบจริงต้องทำใน Week 5 และทดสอบ crash/replay ด้วย

## ชั้น Core: Failure policy ต้องเขียนก่อน retry

```text
timeout/rate limit/5xx → retry แบบจำกัด + backoff ภายใน deadline
invalid JSON/schema    → review หรือ repair แบบจำกัด
unsupported evidence  → review ไม่ retry ด้วย prompt เดิมซ้ำ ๆ
authentication error  → fail fast + alert owner
unsafe request/output  → block/quarantine ตาม policy
```

Retry เหมาะเมื่อสาเหตุอาจหายไปเอง การเรียกโมเดลซ้ำเพราะไม่ชอบคำตอบอาจเพิ่มค่าใช้จ่ายและสร้าง output อีกแบบโดยไม่แก้สาเหตุ

## ชั้น Practice: State ที่ client อ่านแล้วเข้าใจ

| status | retryable | มี validated profile | ขั้นถัดไป |
|---|---:|---:|---|
| validated | no | yes | human use ตาม policy |
| needs_review | no/conditional | no | review queue |
| provider_failed | yes ภายหลัง | no | retry/recovery |
| invalid_request | no | no | caller แก้ input |

ห้ามแนบ profile ที่ไม่ผ่านไว้ใน field เดียวกับ validated profile เพราะ downstream อาจลืมเช็ก status

## ชั้น Deep Dive: Circuit breaker และ backpressure

เมื่อ provider ล้มต่อเนื่อง การ retry ทุกงานพร้อมกันทำให้ปัญหาหนักขึ้น ระบบจริงอาจหยุดเรียกชั่วคราว เปิด circuit, จำกัด concurrency และเก็บงาน durable เพื่อทำภายหลัง พร้อมแสดง backlog/age ให้ทีมเห็น
