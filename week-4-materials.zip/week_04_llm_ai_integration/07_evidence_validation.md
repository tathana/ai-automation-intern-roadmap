# 07 — Hallucination และ Evidence Validation

## Evidence ต้องชี้กลับไปหาข้อมูลได้

แบ่งเอกสารเป็น segments ที่มี ID เช่น p1 สำหรับหน้า 1 หรือ para3 สำหรับย่อหน้าที่ 3 แล้วเก็บต้นฉบับของ segment นั้นไว้

```python
segments = {"p1": "Built a Python ETL project."}
quote = "Built a Python ETL project."
print(quote in segments["p1"])  # True
```

นี่พิสูจน์ว่า quote ปรากฏใน segment ไม่ได้พิสูจน์ว่าผู้สมัครทำงานนั้นจริง หรือ quote รองรับ claim ทุกแบบ

## ตรวจเป็นชั้น

```text
source_id มีจริง?
    ↓
quote ไม่ว่างและอยู่ใน source นั้น?
    ↓
quote เกี่ยวกับ claim และไม่ปฏิเสธมัน?
    ↓
ผู้ตรวจพิจารณาบริบทและความหมาย
```

ตัวอย่าง claim=Python, quote=`I have never used Python.` ผ่าน substring check แต่สรุปว่ามีประสบการณ์ Python ไม่ได้ การตรวจคำปฏิเสธด้วย keyword เป็นเพียง guard ขั้นต้น ไม่ครอบคลุมทุกภาษาและประโยค

## Normalize อย่างระวัง

PDF อาจสกัด newline กลางประโยค จึงอาจ normalize whitespace ทั้ง source และ quote ด้วยกฎเดียวกันก่อนเปรียบเทียบ แต่ต้องเก็บ source ต้นฉบับและตำแหน่งไว้ ห้าม normalize จนเปลี่ยนเลข เครื่องหมายลบ หรือความหมาย

```python
def normalize_space(text):
    return " ".join(text.split())
```

`split()` แยกด้วย whitespace หลายรูปแบบ ส่วน `join()` ประกอบกลับด้วยช่องว่างหนึ่งตัว วิธีนี้ไม่ใช่ OCR correction และไม่แก้คำอ่านผิดโดยอัตโนมัติ

## อย่าใช้ confidence เป็นคำรับรอง

โมเดลบอก confidence=0.99 ไม่ได้หมายความว่าโอกาสถูกจริง 99% หากไม่มี calibration และ evaluation ที่รองรับ ใน lab ทุก HR result ยัง needs_human_review=true แม้ตรวจ quote ผ่าน

## False positive กับ False negative

False positive เช่นระบบบอกพบ Docker ทั้งที่เป็นประโยค “ยังไม่เคยใช้ Docker”; false negative เช่นมีประสบการณ์ในโครงการแต่ระบบหาไม่เจอ ต้องเก็บทั้งสองแบบใน evaluation ไม่ทดสอบเฉพาะ hallucination

เกณฑ์ผ่านบท: อธิบายได้ว่า quote_exists, claim_supported และ candidate_qualified เป็นคนละคำถาม และระบบนี้ไม่ได้ตอบคำถามสุดท้ายแทน HR

## ชั้น Core: ตรวจหลักฐานจากง่ายไปยาก

```text
1 source_id_exists    อ้าง section ที่มีจริงหรือไม่
2 quote_exists        quote ปรากฏใน section หรือไม่
3 span_integrity      quote ไม่ถูกตัด/ต่อจนเปลี่ยนความหมายหรือไม่
4 semantic_support    ข้อความรองรับ claim จริงหรือไม่
5 policy_use          claim นี้ใช้ตัดสินใจแบบใดได้บ้าง
```

ด่าน 1–2 เขียน deterministic tests ได้ง่าย ด่าน 3–4 ต้องมี fixtures/rubric และอาจต้องให้คนตรวจ ด่าน 5 เป็นนโยบายของระบบ ไม่ใช่ความสามารถของโมเดล

## ชั้น Practice: ทดสอบ negation และระดับความเชี่ยวชาญ

| Source | Claim | ผลที่ควรได้ |
|---|---|---|
| “ยังไม่เคยใช้ Docker” | มีประสบการณ์ Docker | reject/review |
| “กำลังเรียน Python” | Python expert | reject |
| “สร้าง ETL ด้วย Python” | เคยใช้ Python ทำ ETL | supported |
| “ทีมใช้ Kubernetes” | ผู้สมัครดูแล Kubernetes | insufficient |

substring check อาจพบคำว่า Docker/Python ทุกกรณี จึงต้องมี semantic cases ใน evaluation

## ชั้น Deep Dive: Evidence lineage

เก็บ `document_id`, `document_hash`, `source_id`, quote/span offsets และ parser version เพื่อย้อนจาก claim ไปยัง snapshot ที่วิเคราะห์ได้ หากเอกสารถูกอัปโหลดใหม่ต้องสร้าง version ใหม่ ไม่ปล่อย claim เดิมชี้ไปข้อความที่เปลี่ยนแล้ว
