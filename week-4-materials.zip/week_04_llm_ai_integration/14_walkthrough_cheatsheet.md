# 14 — End-to-End Walkthrough และ Cheat Sheet

## รันตัวอย่างแรก

ทำ setup ตาม [Lab README](lab/README.md) แล้วรัน:

```powershell
python demo.py
python -m pytest -q
python evaluate.py
```

demo ใช้ segments p1=`Built a Python ETL project.` และ MockProvider normal ผลที่ควรเห็นคือ status=validated, skill Python พร้อม quote และ needs_human_review=true

```text
Request ถูก schema
      ↓
Mock คืน JSON ของ Python claim
      ↓
Pydantic ตรวจชนิด/fields
      ↓
ตรวจ quote ใน p1 และ guard ขั้นต้น
      ↓
validated แต่ยังรอ HR พิจารณาความหมาย
```

## เปลี่ยนทีละตัวแปร

ใช้ hallucination: quote ถูกแต่งจนไม่อยู่ใน source → needs_review/profile=null; ใช้ transient: สองครั้งแรกล้มเหลว ครั้งที่สามได้ผล; ใช้ timeout: ครบสาม attempts แล้ว provider_failed

อย่าแก้ prompt, schema และ provider พร้อมกันเมื่อ debug เพราะจะไม่รู้ว่าสิ่งใดทำให้พฤติกรรมเปลี่ยน

## คำศัพท์หยิบใช้

| คำ | ความหมายในงานนี้ |
|---|---|
| Structured output | ผลลัพธ์มีโครงสร้างที่กำหนด |
| Schema validation | ตรวจรูปร่าง/ชนิด/ข้อจำกัดข้อมูล |
| Evidence validation | ตรวจหลักฐานและความสัมพันธ์กับ claim |
| Refusal | โมเดลปฏิเสธคำขอ ไม่ใช่ JSON พังธรรมดา |
| Fallback | วิธีทำต่อเมื่อใช้ผลหลักไม่ได้ |
| Tool calling | โมเดลเสนอการใช้เครื่องมือให้ application จัดการ |
| Evaluation | ประเมินคุณภาพบนชุดข้อมูลและเกณฑ์ที่ระบุ |
| RAG | ค้นข้อมูลมาเป็นบริบทให้การสร้างคำตอบ |

## ก่อนนำไปเล่าในทีม

พูดว่า “ทดสอบ pipeline กับ mock และ fixtures แล้ว ยังต้องประเมินโมเดลจริง” ดีกว่า “AI แม่น 100%” และบอกข้อจำกัดที่สำคัญ: substring ไม่พิสูจน์ความหมาย, schema ไม่พิสูจน์ความจริง, queued ไม่ใช่ processed และไม่มีการตัดสินผู้สมัครอัตโนมัติ

