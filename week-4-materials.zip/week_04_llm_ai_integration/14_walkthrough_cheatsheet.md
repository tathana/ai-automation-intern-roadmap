# 14 — End-to-End Walkthrough และ Cheat Sheet

## รันตัวอย่างแรก

ทำ setup ตาม [Lab README](lab/README.md) แล้วรัน:

```powershell
python demo.py
python -m pytest -q
python evaluate.py
```

demo ใช้ segments p1=`Built a Python ETL project.` และ MockProvider normal ผลที่ควรเห็นคือ status=validated, skill Python พร้อม quote และ needs_human_review=true

```text
Request ถูก schema
      ↓
Mock คืน JSON ของ Python claim
      ↓
Pydantic ตรวจชนิด/fields
      ↓
ตรวจ quote ใน p1 และ guard ขั้นต้น
      ↓
validated แต่ยังรอ HR พิจารณาความหมาย
```

## เปลี่ยนทีละตัวแปร

ใช้ hallucination: quote ถูกแต่งจนไม่อยู่ใน source → needs_review/profile=null; ใช้ transient: สองครั้งแรกล้มเหลว ครั้งที่สามได้ผล; ใช้ timeout: ครบสาม attempts แล้ว provider_failed

อย่าแก้ prompt, schema และ provider พร้อมกันเมื่อ debug เพราะจะไม่รู้ว่าสิ่งใดทำให้พฤติกรรมเปลี่ยน

## คำศัพท์หยิบใช้

| คำ | ความหมายในงานนี้ |
|---|---|
| Structured output | ผลลัพธ์มีโครงสร้างที่กำหนด |
| Schema validation | ตรวจรูปร่าง/ชนิด/ข้อจำกัดข้อมูล |
| Evidence validation | ตรวจหลักฐานและความสัมพันธ์กับ claim |
| Refusal | โมเดลปฏิเสธคำขอ ไม่ใช่ JSON พังธรรมดา |
| Fallback | วิธีทำต่อเมื่อใช้ผลหลักไม่ได้ |
| Tool calling | โมเดลเสนอการใช้เครื่องมือให้ application จัดการ |
| Evaluation | ประเมินคุณภาพบนชุดข้อมูลและเกณฑ์ที่ระบุ |
| RAG | ค้นข้อมูลมาเป็นบริบทให้การสร้างคำตอบ |

## ก่อนนำไปเล่าในทีม

พูดว่า “ทดสอบ pipeline กับ mock และ fixtures แล้ว ยังต้องประเมินโมเดลจริง” ดีกว่า “AI แม่น 100%” และบอกข้อจำกัดที่สำคัญ: substring ไม่พิสูจน์ความหมาย, schema ไม่พิสูจน์ความจริง, queued ไม่ใช่ processed และไม่มีการตัดสินผู้สมัครอัตโนมัติ

## Debug Ladder ของ AI Integration

```text
1 request ผ่าน input schema หรือไม่
2 prompt/context ที่ประกอบมี source_id ครบหรือไม่
3 provider ตอบหรือเกิด timeout/rate/auth error
4 response parse เป็น JSON ได้หรือไม่
5 Pydantic/schema ผ่านหรือไม่
6 evidence รองรับ claims หรือไม่
7 policy อนุญาตให้ใช้ผลอย่างไร
8 downstream route/status/side effect ถูกหรือไม่
```

แก้จากชั้นแรกที่ผิด ไม่เริ่มด้วยเปลี่ยน prompt ทุกครั้ง

## Definition of Done สำหรับหนึ่ง AI feature

- มี non-AI baseline หรือเหตุผลว่าทำไมต้องใช้ LLM
- prompt/schema/provider ถูกแยกและ versioned
- mock tests ครบ success/failure และ real-model eval แยกชัด
- output ที่ไม่ผ่านไม่ไหลเข้า validated field
- มี budget, timeout, retry ceiling และ human fallback
- privacy/security/authorization ถูก review ตามผลกระทบ
- README บอกสิ่งที่พิสูจน์แล้วและสิ่งที่ยังไม่พิสูจน์
