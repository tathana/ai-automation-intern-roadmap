"""Local-only synchronous mock service. Does not read files or call real AI."""
from fastapi import FastAPI
from provider import MockProvider
from schemas import Request
from service import analyze

app = FastAPI(title="Week 4 Mock AI Lab")


@app.get("/health")
def health():
    return {"status": "ok", "provider": "mock", "scope": "week4-local-synthetic"}


@app.post("/analyze")
def analyze_endpoint(request: Request):
    return analyze(request, MockProvider(request.scenario))
