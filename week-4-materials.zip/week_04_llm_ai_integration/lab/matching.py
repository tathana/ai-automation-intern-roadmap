"""Candidate evidence suggestions only. Never an autonomous hiring decision."""


def match_requirements(result, requirements):
    if not requirements or any(not isinstance(r, str) or not r.strip() for r in requirements):
        raise ValueError("Non-empty requirements required")
    if len({r.casefold().strip() for r in requirements}) != len(requirements):
        raise ValueError("Duplicate requirements")
    output = []
    for requirement in requirements:
        if result["status"] != "validated" or result["profile"] is None:
            output.append({"requirement": requirement, "status": "NEEDS_HUMAN_REVIEW", "evidence": []})
            continue
        claims = [c for c in result["profile"]["skills"] if c["name"].casefold() == requirement.casefold().strip()]
        output.append({"requirement": requirement,
                       "status": "MATCHED_WITH_EVIDENCE" if claims else "NOT_FOUND_IN_RESUME",
                       "evidence": claims})
    return {"candidate_id": result["candidate_id"], "matches": output, "needs_human_review": True,
            "scope": "exact skill name suggestions; no proficiency or suitability decision"}
