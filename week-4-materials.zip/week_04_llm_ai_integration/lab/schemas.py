from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


Scenario = Literal["normal", "invalid_json", "invalid_schema", "hallucination", "refusal", "transient", "timeout", "permanent", "negation"]


class Request(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    candidate_id: str = Field(min_length=1, max_length=80)
    segments: dict[str, str] = Field(min_length=1, max_length=50)
    scenario: Scenario = "normal"

    @field_validator("candidate_id")
    @classmethod
    def nonempty_id(cls, value):
        if not value.strip():
            raise ValueError("candidate_id cannot be blank")
        return value

    @field_validator("segments")
    @classmethod
    def bounded_text(cls, value):
        if any(not k.strip() or len(k) > 80 for k in value):
            raise ValueError("segment IDs must be nonblank and at most 80 characters")
        if not any(v.strip() for v in value.values()):
            raise ValueError("no readable text")
        if sum(len(v) for v in value.values()) > 20_000:
            raise ValueError("lab input limit is 20000 characters, not tokens")
        return value


class Skill(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    name: str = Field(min_length=1, max_length=100)
    quote: str = Field(min_length=1, max_length=1000)
    source_id: str = Field(min_length=1, max_length=80)

    @field_validator("name", "quote", "source_id")
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError("blank value")
        return value


class Profile(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    skills: list[Skill] = Field(max_length=50)
    education: str | None
    warnings: list[str] = Field(max_length=20)
