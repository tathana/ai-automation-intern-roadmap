"""CLI-only parsing of trusted synthetic fixtures. Not an untrusted upload sandbox."""
from pathlib import Path
import zipfile

from docx import Document
from docx.table import Table
from pypdf import PdfReader


class ExtractionError(ValueError):
    pass


def extract_segments(path):
    path = Path(path)
    if path.stat().st_size > 2_000_000:
        raise ExtractionError("file_too_large")
    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            reader = PdfReader(path)
            if reader.is_encrypted:
                raise ExtractionError("encrypted_document")
            if len(reader.pages) > 10:
                raise ExtractionError("too_many_pages")
            segments = {f"p{i+1}": page.extract_text() or "" for i, page in enumerate(reader.pages)}
        elif suffix == ".docx":
            with zipfile.ZipFile(path) as archive:
                if len(archive.infolist()) > 200 or sum(i.file_size for i in archive.infolist()) > 10_000_000:
                    raise ExtractionError("docx_expansion_limit")
            doc = Document(path)
            segments = {}
            for i, block in enumerate(doc.iter_inner_content(), 1):
                text = "\n".join(" | ".join(c.text for c in row.cells) for row in block.rows) if isinstance(block, Table) else block.text
                segments[f"block{i}"] = text
        else:
            raise ExtractionError("unsupported_type")
    except ExtractionError:
        raise
    except Exception as exc:
        raise ExtractionError("unreadable_document") from exc
    if not any(text.strip() for text in segments.values()):
        raise ExtractionError("no_text_requires_review_or_ocr")
    if sum(len(s) for s in segments.values()) > 20_000:
        raise ExtractionError("text_too_large")
    return segments
