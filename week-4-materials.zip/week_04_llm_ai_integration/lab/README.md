# Lab — AI Integration แบบไม่เสียค่า API

API นี้ใช้ MockProvider เท่านั้น ไม่เรียก AI จริง ไม่อ่านไฟล์จาก request และไม่มี endpoint อนุมัติผู้สมัคร ให้เปิดเฉพาะ localhost ห้าม deploy เป็น public service ที่รับ resume จริง

## Setup

เปิด PowerShell ในโฟลเดอร์ lab แล้วรัน:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe demo.py
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe evaluate.py
.\.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8014
```

ถ้าใช้ environment ที่พร้อมแล้ว ใช้ `python` ของ environment นั้นแทน เปิด `http://127.0.0.1:8014/docs` เพื่อทดลอง

```powershell
$w4Payload = @{candidate_id='C1'; segments=@{p1='Built a Python ETL project.'}; scenario='normal'} | ConvertTo-Json -Depth 5
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8014/analyze' -ContentType 'application/json' -Body $w4Payload
```

## อ่านไฟล์ตามหน้าที่

schemas.py กำหนด contract → provider.py จำลองคำตอบ → service.py retry/parse/validate → app.py เปิด endpoint ส่วน extract.py สกัดข้อความ, matching.py เสนอ evidence matching และ tools.py สาธิตขอบเขตสิทธิ์

## Scenarios

| scenario | Expected |
|---|---|
| normal | validated, attempts=1, human review=true |
| invalid_json / invalid_schema | needs_review, attempts=1 |
| hallucination | needs_review, quote_not_found |
| refusal | needs_review, provider_refusal |
| transient | ล้มสองครั้ง แล้ว validated ครั้งที่สาม |
| timeout | provider_failed หลัง 3 attempts |
| permanent | provider_failed โดยไม่ retry |
| negation | ใช้ input `I have never used Python.` แล้วต้อง review |

mock อ่านเฉพาะวลีรูป `Built a Python ... .`, SQL/Docker ในรูปเดียวกัน และวลีไทย `พัฒนาโครงการด้วย SQL สำหรับฝึกงาน` รวมถึง Python/Docker ไม่ใช่ parser สำหรับภาษาทั่วไป เอกสารที่อยู่นอก grammar นี้อาจให้ skills=[] แม้มีทักษะจริง

## เอกสาร

```powershell
python demo.py --file fixtures/synthetic_resume.pdf
python demo.py --file fixtures/empty_document.pdf
```

ไฟล์แรกสกัดได้ ไฟล์ที่สองจงใจไม่มีข้อความและควรเกิด ExtractionError เพื่อส่ง review/OCR ไม่ใช่แกล้งให้โมเดลอ่านไฟล์ว่าง

ตัว parser รองรับ DOCX paragraphs/tables ขั้นพื้นฐานและมี unit test สร้าง fixture ชั่วคราว ไม่มี DOCX ตัวอย่างที่รับรองภาพจัดหน้าในชุดดาวน์โหลด เพราะ runtime นี้ไม่มี bundled LibreOffice สำหรับตรวจเอกสาร ไม่ได้อ้างว่าอ่าน textbox/header ทุกแบบครบ

## ขอบเขต

ไม่มี durable queue, persistence, HR login หรือ live AI evaluation; timeout เป็น exception จำลอง; lexical evidence check ไม่ใช่ semantic entailment ทุก output ยังต้องให้คนตรวจ การเปลี่ยน provider ต้องเพิ่ม live smoke tests และใช้ policy ของบริการจริงแทน backoff ขนาดเล็กของ lab

Real adapter เป็นตัวอย่างเลือกทำ ไม่ได้เปิดใช้งานผ่าน HTTP API การตั้ง `store=False` ไม่ใช่คำรับรองว่าไม่มี retention ใด ๆ ให้ตรวจนโยบาย provider/บัญชีจริงก่อนส่งข้อมูล

