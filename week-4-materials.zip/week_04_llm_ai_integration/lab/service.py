import hashlib
import json
import re
from time import perf_counter, sleep

from pydantic import ValidationError

from provider import ProviderInvalidOutput, ProviderRefusal, ProviderUnavailable, TransientProviderError
from schemas import Profile

VERSIONS = {"provider": "deterministic-mock-v1", "prompt": "extract-v1", "schema": "profile-v1", "validator": "lexical-v1"}


def normalize_space(text):
    return " ".join(text.split())


def evidence_errors(profile, segments):
    reasons = []
    seen = set()
    for skill in profile.skills:
        key = (skill.name.casefold(), skill.source_id, skill.quote)
        if key in seen:
            reasons.append("duplicate_claim")
        seen.add(key)
        source = segments.get(skill.source_id)
        if source is None:
            reasons.append("unknown_source")
            continue
        quote = normalize_space(skill.quote)
        if quote not in normalize_space(source):
            reasons.append("quote_not_found")
        if not re.search(r"(?<!\w)" + re.escape(skill.name) + r"(?!\w)", quote, re.IGNORECASE):
            reasons.append("claim_not_in_quote")
        if any(phrase in quote.casefold() for phrase in ["never used", "no experience", "not experienced", "ไม่เคย", "ไม่มีประสบการณ์"]):
            reasons.append("negation_requires_review")
    # Education has no evidence field in this minimal schema; never accept a made-up value.
    if profile.education is not None:
        reasons.append("education_requires_evidence_schema")
    return sorted(set(reasons))


def analyze(request, provider, *, max_attempts=3, sleep_fn=sleep):
    if not 1 <= max_attempts <= 3:
        raise ValueError("lab allows 1..3 attempts")
    started = perf_counter()
    fingerprint = hashlib.sha256(json.dumps(request.segments, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    base = {"candidate_id": request.candidate_id, "document_text_hash": fingerprint,
            "versions": dict(VERSIONS, provider=getattr(provider, "version", VERSIONS["provider"])),
            "needs_human_review": True, "validation_level": "schema_and_lexical_evidence_only"}
    attempts = 0

    def result(status, reasons, profile=None):
        return {**base, "status": status, "reasons": reasons, "profile": profile,
                "attempts": attempts, "elapsed_ms": round((perf_counter()-started)*1000, 3)}

    for attempts in range(1, max_attempts + 1):
        try:
            raw = provider.generate(request)
            break
        except ProviderRefusal:
            return result("needs_review", ["provider_refusal"])
        except ProviderInvalidOutput:
            return result("needs_review", ["invalid_provider_output"])
        except (TimeoutError, TransientProviderError):
            if attempts == max_attempts:
                return result("provider_failed", ["retry_exhausted"])
            sleep_fn(0.01 * (2 ** (attempts-1)))
        except ProviderUnavailable:
            return result("provider_failed", ["provider_unavailable"])
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return result("needs_review", ["invalid_json"])
    try:
        profile = Profile.model_validate(parsed)
    except ValidationError:
        return result("needs_review", ["invalid_schema"])
    reasons = evidence_errors(profile, request.segments)
    if reasons:
        return result("needs_review", reasons)
    return result("validated", [], profile.model_dump())
