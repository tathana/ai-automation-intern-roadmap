import argparse
import json
from extract import extract_segments
from matching import match_requirements
from provider import MockProvider
from schemas import Request
from service import analyze


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--file")
    parser.add_argument("--scenario", default="normal")
    args = parser.parse_args()
    segments = extract_segments(args.file) if args.file else {"p1": "Built a Python ETL project."}
    request = Request(candidate_id="C1", segments=segments, scenario=args.scenario)
    result = analyze(request, MockProvider(args.scenario))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps(match_requirements(result, ["Python", "Docker"]), ensure_ascii=False, indent=2))
