import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from app import app
from evaluate import evaluate
from extract import ExtractionError, extract_segments
from matching import match_requirements
from provider import MockProvider
from schemas import Profile, Request
from service import analyze, evidence_errors
from tools import dispatch
from workshops import TicketLabel, validate_summary_for_fixture


def request(text="Built a Python ETL project.", scenario="normal"):
    return Request(candidate_id="C1", segments={"p1": text}, scenario=scenario)


@pytest.mark.parametrize("scenario,status,attempts", [
    ("normal", "validated", 1), ("invalid_json", "needs_review", 1),
    ("invalid_schema", "needs_review", 1), ("hallucination", "needs_review", 1),
    ("refusal", "needs_review", 1), ("transient", "validated", 3),
    ("timeout", "provider_failed", 3), ("permanent", "provider_failed", 1),
])
def test_scenarios(scenario, status, attempts):
    provider = MockProvider(scenario)
    waits = []
    result = analyze(request(), provider, sleep_fn=waits.append)
    assert result["status"] == status
    assert result["attempts"] == provider.calls == attempts
    assert result["needs_human_review"] is True
    assert len(waits) == attempts-1
    if status != "validated":
        assert result["profile"] is None
    else:
        assert result["profile"]["skills"][0]["name"] == "Python"


@pytest.mark.parametrize("segments", [{}, {"p1":" "}, {"":"text"}, {"p1":"x"*20001}, {"p1":123}], ids=["empty", "blank", "blank_id", "too_long", "not_text"])
def test_request_bounds(segments):
    with pytest.raises(ValidationError):
        Request(candidate_id="C1", segments=segments)


def test_missing_fields_and_extras():
    with pytest.raises(ValidationError):
        Profile.model_validate({"skills": []})
    with pytest.raises(ValidationError):
        Profile.model_validate({"skills": [], "education": None, "warnings": [], "hire": True})


def test_negation():
    result = analyze(request("I have never used Python."), MockProvider("negation"))
    assert result["status"] == "needs_review"
    assert "negation_requires_review" in result["reasons"]


def test_exact_source_and_claim():
    profile = Profile.model_validate({"skills": [{"name":"Rust", "quote":"Built a Python ETL project.", "source_id":"p2"}], "education":None, "warnings":[]})
    assert evidence_errors(profile, {"p1":"Built a Python ETL project."}) == ["unknown_source"]
    profile.skills[0].source_id = "p1"
    assert "claim_not_in_quote" in evidence_errors(profile, {"p1":"Built a Python ETL project."})


def test_empty_quote_rejected():
    with pytest.raises(ValidationError):
        Profile.model_validate({"skills":[{"name":"Python","quote":" ","source_id":"p1"}], "education":None, "warnings":[]})


def test_unproven_education():
    profile = Profile(skills=[], education="PhD", warnings=[])
    assert evidence_errors(profile, {"p1":"Resume"}) == ["education_requires_evidence_schema"]


def test_duplicate_claim():
    claim = {"name":"Python","quote":"Built a Python ETL project.","source_id":"p1"}
    profile = Profile.model_validate({"skills":[claim,claim],"education":None,"warnings":[]})
    assert "duplicate_claim" in evidence_errors(profile, request().segments)


def test_no_evidence_is_not_no_ability():
    result = analyze(request("Seeking an internship."), MockProvider())
    matches = match_requirements(result, ["Python"])
    assert matches["matches"][0]["status"] == "NOT_FOUND_IN_RESUME"
    assert matches["needs_human_review"]


def test_matching_review_and_bad_criteria():
    result = analyze(request(), MockProvider("hallucination"))
    assert match_requirements(result, ["Python"])["matches"][0]["status"] == "NEEDS_HUMAN_REVIEW"
    for requirements in [[], [""], ["Python", "python"]]:
        with pytest.raises(ValueError):
            match_requirements(result, requirements)


def test_tools_allowed():
    assert dispatch("lookup_ticket", {"ticket_id":"T1"}, authenticated_user="demo-user")["status"] == "open"


@pytest.mark.parametrize("name,args", [("send_email", {}), ("lookup_ticket", {"ticket_id":"T2"})])
def test_tools_forbidden(name, args):
    with pytest.raises(PermissionError):
        dispatch(name, args, authenticated_user="demo-user")


def test_model_cannot_supply_approval():
    with pytest.raises(ValidationError):
        dispatch("lookup_ticket", {"ticket_id":"T1", "approved":True}, authenticated_user="demo-user")


def test_api_business_status():
    with TestClient(app) as client:
        assert client.get("/health").json()["provider"] == "mock"
        response = client.post("/analyze", json=request(scenario="hallucination").model_dump())
        assert response.status_code == 200
        assert response.json()["status"] == "needs_review"
        assert client.post("/analyze", json={"candidate_id":"C1", "segments":{}}).status_code == 422


def test_mock_regression():
    report = evaluate()
    assert report["passed"] == report["total"] == 10


def test_pdf_fixture():
    segments = extract_segments(Path(__file__).parent / "fixtures" / "synthetic_resume.pdf")
    assert "Built a Python ETL project." in segments["p1"]
    result = analyze(Request(candidate_id="PDF1", segments=segments), MockProvider())
    assert result["status"] == "validated"


def test_empty_pdf_fixture():
    with pytest.raises(ExtractionError, match="no_text"):
        extract_segments(Path(__file__).parent / "fixtures" / "empty_document.pdf")


def test_unreadable_pdf(tmp_path):
    path = tmp_path / "corrupt.pdf"
    path.write_bytes(b"not a PDF")
    with pytest.raises(ExtractionError, match="unreadable"):
        extract_segments(path)


def test_docx_parser_with_temporary_fixture(tmp_path):
    # This temporary unit-test document is not a published, visually verified artifact.
    from docx import Document
    doc = Document()
    doc.add_paragraph("Built a Python ETL project.")
    doc.add_table(rows=1, cols=1).cell(0, 0).text = "Built a SQL reporting project."
    path = tmp_path / "parser_fixture.docx"
    doc.save(path)
    segments = extract_segments(path)
    assert "Python" in segments["block1"]
    assert "SQL" in segments["block2"]


def test_classification_and_summary_contracts():
    assert TicketLabel(category="account").category == "account"
    with pytest.raises(ValidationError):
        TicketLabel(category="refund_money_now")
    with pytest.raises(ValueError):
        validate_summary_for_fixture({"summary":"Database failed", "confirmed_root_cause":"database"})


def test_paid_provider_opt_in(monkeypatch):
    from openai_adapter_example import OpenAIAdapter
    monkeypatch.delenv("W4_ALLOW_PAID_API", raising=False)
    with pytest.raises(ValueError, match="disabled"):
        OpenAIAdapter(model="explicit-test-model")


def test_sdk_validation_failure_has_review_path():
    from provider import ProviderInvalidOutput
    class SDKLikeProvider:
        def generate(self, request):
            raise ProviderInvalidOutput("simulated SDK validation error")
    result = analyze(request(), SDKLikeProvider())
    assert result["status"] == "needs_review"
    assert result["reasons"] == ["invalid_provider_output"]
