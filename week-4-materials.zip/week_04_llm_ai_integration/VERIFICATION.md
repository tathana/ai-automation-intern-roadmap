# Verification — ขอบเขตที่ตรวจแล้วจริง

วันที่ตรวจ runtime เดิม: 11 กันยายน 2026  
วันที่ rebuild/ตรวจหนังสือฉบับ Textbook: 12 กันยายน 2026

## Software tests

- lab/test_pipeline.py: 34 tests ผ่าน
- evaluate.py: deterministic mock regression 10/10 cases ผ่าน ไม่ใช่ accuracy ของโมเดลจริง
- ครอบคลุม schema, quote/source, negation guard, refusal, bounded retries, tool permissions, HTTP business status และ requirement matching ขั้นพื้นฐาน
- ทดสอบ PDF ที่อ่านได้, PDF ว่าง, PDF เสีย และ DOCX paragraph/table ด้วย fixture ชั่วคราว
- เวอร์ชันทดสอบ Python environment: FastAPI 0.126.0, Pydantic 2.8.2, pypdf 6.13.1, python-docx 1.2.0

## เอกสารตัวอย่าง

PDF resume สังเคราะห์และ PDF ว่างถูก render และตรวจภาพแล้ว PDF ว่างเป็น negative fixture โดยตั้งใจ ไม่ใช่เอกสารที่สร้างไม่สำเร็จ

ไม่ได้ส่งมอบ DOCX ตัวอย่างที่ตรวจภาพจัดหน้าแล้ว เนื่องจาก bundled runtime ไม่มี LibreOffice สำหรับ render ส่วน parser DOCX มี unit test ผ่าน จึงแยกความสามารถสกัดข้อมูลออกจากการรับรองภาพเอกสาร

## ยังไม่ใช่ผลทดสอบ production

ไม่มีการเรียก paid AI API หรือใช้ key จริง; optional OpenAI adapter ยังไม่ผ่าน live-provider integration test; mock timeout ไม่พิสูจน์ network timeout; mock injection fixture ไม่พิสูจน์ว่าโมเดลจริงต้าน prompt injection ได้

## n8n และหนังสือ

- นำเข้าและรัน workflow ทั้ง 2 ไฟล์ด้วย n8n 1.115.3 ใน user folder/database แยกจากงานเดิม
- normal probe ได้ HTTP 200, business_status=validated, Python claim และ human review=true
- hallucination probe ได้ HTTP 200 แต่ business_status=needs_review และ profile=null ตามที่ต้องการ
- HTML ตรวจ internal anchors และ relative links; ชุดดาวน์โหลดคัดเฉพาะ source/fixtures ไม่รวม caches, .env หรือ database
- ฉบับ Textbook รวม Markdown 25 ไฟล์, 202 anchors, 65 code/flow blocks และ archive 46 ไฟล์; ตรวจ local links, Python syntax และ workflow ไม่มี credentials แล้ว
- ไม่รวมการคลิก UI ทุกส่วนหรือการทดสอบ n8n รุ่นอื่น

ฉบับ Textbook เพิ่ม Core/Practice/Deep Dive, validation pipeline, trust boundaries, n8n UI mock และ architecture gallery โดยไม่เปลี่ยน lab/provider/workflow behavior ที่เคยผ่าน runtime tests

## Challenge ที่ตั้งใจให้ fail

challenge/test_acceptance.py ตรวจแล้ว fail ทั้ง 3 ข้อตามข้อผิดที่ตั้งใจไว้กับ starter เดิม ผู้เรียนเป็นคนซ่อม นี่แยกจาก lab tests ที่ต้องผ่านทั้งหมด
