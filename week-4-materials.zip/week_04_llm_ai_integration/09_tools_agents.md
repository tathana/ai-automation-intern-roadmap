# 09 — Tool Calling และ AI Agent Foundation

## โมเดลเสนอ action โปรแกรมเป็นผู้อนุญาต

Tool calling คือโมเดลคืนชื่อเครื่องมือและ arguments ตามรูปแบบที่ API กำหนด Application ต้อง validate และตัดสินใจว่าจะ execute หรือไม่ แล้วจึงส่งผลกลับให้โมเดลเมื่อ workflow ต้องการ [เอกสาร Function Calling](https://developers.openai.com/api/docs/guides/function-calling)

```text
ผู้ใช้ถาม → โมเดลเสนอ lookup_ticket(ticket_id=T1)
                       ↓
             ตรวจชื่อ tool + arguments + สิทธิ์
                       ↓
                  เรียกฟังก์ชันจริง
                       ↓
             ส่งผลให้โมเดล/ตอบตาม workflow
```

อย่าใช้ `eval()` หรือเลือกฟังก์ชันจากชื่อใดก็ได้ที่โมเดลส่งมา สร้าง allowlist ที่ชัดเจน เช่น `tools = {"lookup_ticket": lookup_ticket}`

## Schema ไม่แทน Authorization

arguments `{"ticket_id":"T2"}` อาจถูก schema แต่ T2 ไม่ได้เป็นของผู้ใช้คนนี้ ต้องตรวจสิทธิ์ด้วย identity จากระบบที่ authenticate แล้ว ไม่ใช้ `approved=true` หรือ user_id ที่โมเดลส่งมาเป็นผู้ตัดสินสิทธิ์

ใน [tools.py](lab/tools.py) อนุญาตเพียง lookup ของข้อมูลสังเคราะห์ และปฏิเสธเครื่องมือชื่ออื่น ไม่มี email, shell, payment หรือ hire action ให้เรียก

## Workflow กับ Agent ต่างกันตรงไหน

Workflow แบบกำหนดลำดับให้โปรแกรมตัดสินขั้นตอนหลัก ส่วน Agent ให้โมเดลช่วยเลือก action/ลำดับตามสถานการณ์มากขึ้น ความยืดหยุ่นนี้เพิ่มสิ่งที่ต้องควบคุม: tool scope, budget, stop condition และผลข้างเคียง

สำหรับ extraction ที่ input/output ชัด เริ่มจาก workflow ตรง ๆ ก่อน ไม่ต้องเพิ่ม Agent เพียงเพราะเป็นงาน AI

## Loop ต้องมีจุดจบ

```text
โมเดลเสนอ tool → ตรวจ → เรียก → ส่งผลกลับ
       ↑                              ↓
       └──── หากยังต้องใช้ข้อมูล ───────┘
หยุดเมื่อได้ final answer / ครบ 3 calls / หมดเวลา / ต้องให้คนอนุมัติ
```

ถ้าโมเดลเสนอ tool หลายตัว ให้ตรวจแต่ละตัวและกำหนดว่าเรียงหรือพร้อมกันได้ ไม่ execute ทุกคำขอโดยไม่คิดว่าอ่าน/เขียนหรือพึ่งพากันหรือไม่

## ชั้น Core: โมเดลเสนอ แต่ application เป็นผู้อนุญาต

```text
LLM output: {tool:"lookup_ticket", arguments:{ticket_id:"T2"}}
                     ↓ parse + schema
allowlist มี tool นี้หรือไม่?
                     ↓ authorization ของผู้ใช้กับ T2
budget/timeout ยังเหลือหรือไม่?
                     ↓ execute ด้วย service identity ที่จำกัด
tool result กลับเป็น untrusted data
                     ↓
LLM รอบถัดไปหรือ final response ที่ตรวจแล้ว
```

อย่าให้ชื่อ tool จากโมเดลกลายเป็น module/function/shell command โดยตรง

## ชั้น Practice: แยก read กับ write tools

รุ่นแรกของ HR assistant อาจมี `lookup_job_requirements` และ `get_candidate_segments` แบบ read-only แต่ไม่มี `reject_candidate` หรือ `send_email` หากต้องเพิ่ม write action ให้สร้าง draft/approval step และ idempotency key แยก

## ชั้น Deep Dive: Agent เป็น state machine ที่มีเพดาน

กำหนด states เช่น `thinking → tool_requested → validated → tool_executed → final/review` พร้อม `max_steps`, deadline, token/tool budget และ stop reasons ทุก transition ต้อง log trace metadata โดยไม่เก็บ sensitive payload เกินจำเป็น
