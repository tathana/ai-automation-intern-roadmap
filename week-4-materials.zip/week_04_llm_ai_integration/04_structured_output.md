# 04 — Structured Output และ Pydantic

## ข้อความ JSON มีสามด่านให้ตรวจ

```text
'{"skills":["Python"]}'
       ↓ JSON parse: อ่านเป็น object ได้ไหม?
       ↓ Schema: field และชนิดตรง contract ไหม?
       ↓ Meaning/evidence: มีหลักฐานรองรับไหม?
```

การบอกโมเดลว่า “ตอบ JSON” เป็นเพียงคำสั่ง ส่วน provider-native structured output ใช้ความสามารถของ API จำกัดรูปแบบตาม schema ที่รองรับ แต่ยังต้องจัดการ refusal/incomplete response และตรวจความหมายเอง [เอกสาร Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)

## อ่านโค้ด schema ทีละส่วน

```python
from pydantic import BaseModel, ConfigDict, Field

class Skill(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    name: str = Field(min_length=1)
    quote: str = Field(min_length=1)
    source_id: str = Field(min_length=1)
```

`class Skill` นิยามรูปข้อมูลหนึ่งทักษะ; `BaseModel` ให้ความสามารถ validate; `extra="forbid"` ไม่รับ field เกิน; `strict=True` ลดการแปลงชนิดอัตโนมัติ; `min_length=1` กัน string ว่าง แต่ยังไม่กันข้อความช่องว่างอย่างเดียวหากเราไม่เพิ่มกฎ

```python
skill = Skill.model_validate({
    "name": "Python",
    "quote": "Built a Python ETL project.",
    "source_id": "p1",
})
print(skill.name)  # Python
```

`model_validate()` รับ object/dict ส่วน `model_validate_json()` รับข้อความ JSON แยกสองอย่างนี้ให้ชัด ไม่ต้อง `json.dumps()` แล้ว `json.loads()` ไปมาทุกครั้ง

## ขาด field, null และ []

กำหนด contract ก่อน: `skills=[]` อาจหมายถึงตรวจข้อความแล้วไม่พบ evidence; `skills=null` อาจหมายถึงยังประเมินไม่ได้; field หายอาจเป็น schema error อย่าใช้ทั้งสามแบบสลับกันโดยไม่มีความหมาย

ใน lab ส่วน profile ใช้ `education=None` แทน “ไม่ทราบ” และ skills=[] แทน “ไม่มี claim ที่สกัดได้จากส่วนที่อ่าน” ไม่ยืนยันว่าเจ้าของเอกสารไม่มีทักษะ

## ทำไม schema ผ่านยังผิด

`{"name":"Rust","quote":"Built a Python ETL project.","source_id":"p1"}` ผ่าน schema ด้านบนได้ เพราะทุกค่าเป็นข้อความ แต่ quote ไม่รองรับ Rust ต้องมี evidence validation ต่อ และแม้คำว่า Rust อยู่ใน quote ก็อาจเป็น “never used Rust” จึงยังต้องตรวจความหมาย

## เมื่อ validation ไม่ผ่าน

จับ `ValidationError` แล้วสร้าง reason code เช่น `invalid_schema` ส่ง review โดยไม่ส่ง raw payload หรือรายละเอียด PII ทั้งหมดลง log ไม่ควรลบ field ที่ผิดทิ้งแล้วประกาศว่าสำเร็จโดยเงียบ ๆ

## ชั้น Core: Structured output มีหลายด่าน

```text
ข้อความจาก provider
      ↓ parse JSON       พัง → invalid_json
Python object
      ↓ schema validate  พัง → invalid_schema
typed model
      ↓ evidence validate พัง → unsupported_claim
validated result
      ↓ business policy  → usable / review / prohibited
```

Pydantic ช่วยตรวจชนิด, required fields และ constraints ที่ประกาศ แต่ไม่รู้ว่า quote อยู่ใน resume จริงหรือ claim เหมาะกับงานหรือไม่

## ชั้น Practice: อ่าน model จากขอบนอกเข้าใน

```python
class SkillClaim(BaseModel):
    name: str
    source_id: str
    quote: str

class CandidateProfile(BaseModel):
    candidate_id: str
    skills: list[SkillClaim] = Field(default_factory=list)
```

`skills` คือ list ที่สมาชิกทุกตัวต้องผ่าน `SkillClaim`; `default_factory=list` สร้าง list ใหม่ต่อ instance และหลีกเลี่ยง mutable default ที่เรียนใน Week 1 ค่า `candidate_id` ควรตรวจเทียบ request ด้วย ไม่เชื่อค่าที่โมเดล echo กลับมาเพียงอย่างเดียว

## ชั้น Deep Dive: Strictness เป็นการตัดสินใจของระบบ

การยอม cast `"22"` เป็น 22 อาจสะดวก แต่ซ่อน output drift ในระบบที่ต้องการ type เคร่ง ให้เลือก strict validation ตามความเสี่ยง เก็บ raw response แบบควบคุมสิทธิ์สำหรับ debug และส่ง downstream เฉพาะ validated representation
