# Sources และการตรวจเวอร์ชัน

ตรวจเอกสาร OpenAI ทางการระหว่าง 10–11 กันยายน 2026 ตัวอย่างในบทเรียนเรียบเรียงสำหรับ lab ไม่ได้รับรองว่า API ทุก provider มี schema หรือ response envelope แบบเดียวกัน

- [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs) — structured response, Pydantic helper และการแยก refusal จากผลที่ parse ได้ ใช้ประกอบบท 04–05
- [Function Calling](https://developers.openai.com/api/docs/guides/function-calling) — การเสนอ tool call, application execution และส่ง tool output กลับ ใช้ประกอบบท 09
- [Model catalog](https://developers.openai.com/api/docs/models) — ตรวจสิทธิ์/ความสามารถของโมเดลก่อนเลือกใช้งานจริง ไม่ระบุโมเดลล่าสุดหรือราคาใน lab
- [Pydantic documentation](https://docs.pydantic.dev/latest/) — อ้างอิงต่อยอด BaseModel, strict mode และ validators
- [pypdf text extraction](https://pypdf.readthedocs.io/en/stable/user/extract-text.html) — อ้างอิงต่อยอดข้อจำกัดการอ่านข้อความจาก PDF
- [OWASP LLM01:2025 Prompt Injection](https://genai.owasp.org/llmrisk/llm01-prompt-injection/) — direct/indirect prompt injection และผลกระทบ ใช้ประกอบบท 10
- [OWASP LLM06:2025 Excessive Agency](https://genai.owasp.org/llmrisk/llm062025-excessive-agency/) — least functionality/permissions/autonomy และ human approval ใช้ประกอบบท 09–10

ลิงก์ Pydantic/pypdf เป็นเอกสารอ่านต่อ ไม่อ้างว่าตรวจทุกหน้าหรือทุกเวอร์ชันแล้ว โค้ดใน lab ตรวจผ่านด้วย tests ตาม Verification รายการอ้างอิงฉบับ Textbook ตรวจทานล่าสุด 12 กันยายน 2026

## สิ่งที่เป็น policy ของแบบฝึก

เพดาน 3 attempts, 20000 characters, 10 PDF pages, localhost port 8014, lexical evidence checks และ human review ทุกผล เป็นขอบเขตที่กำหนดสำหรับฝึก ไม่ใช่มาตรฐานบังคับของ provider หรือบริษัท

การบอก quote_exists ไม่ได้เท่ากับ semantic entailment และการสรุปว่าข้อมูลปรากฏใน Resume ไม่ได้เท่ากับตรวจสอบประสบการณ์บุคคลจากแหล่งภายนอกแล้ว
