# 00 — Assessment และขอบเขต Week 4

## ก่อนเริ่ม ลองตอบห้าข้อนี้

1. HTTP 200 แต่ body มี status=needs_review ควรส่ง notification ว่า AI ทำงานสำเร็จหรือไม่?
2. `list[str]` ตรวจได้หรือไม่ว่าทักษะ Python มีอยู่ใน Resume จริง?
3. ถ้า provider timeout ควร retry ทุกครั้งโดยไม่จำกัดหรือไม่?
4. ข้อมูลหาย, null และ list ว่าง ต่างกันอย่างไร?
5. คำว่า “ignore previous instructions” ใน Resume เป็นคำสั่งของผู้ใช้ระบบหรือข้อมูลในเอกสาร?

แนวตอบ: อ่าน business status ก่อน; type annotation ไม่ตรวจข้อเท็จจริง; ต้องมีเพดานและแยกชนิด error; ความหมายขึ้นกับ contract ที่ต้องระบุ; เป็นข้อมูลที่ไม่น่าเชื่อถือ ไม่ใช่สิทธิ์สั่งระบบ

## เราจะรับผิดชอบอะไรเอง

```text
AI เสนอคำตอบ
     ↓
โปรแกรมตรวจรูปแบบและเงื่อนไขที่ตรวจได้
     ↓
ผู้ตรวจพิจารณาความหมายและผลกระทบ
```

อย่าให้ AI เป็นทั้งผู้ตอบและผู้รับรองว่าตนเองถูกต้อง แม้จะใช้โมเดลอีกตัวช่วยตรวจ ก็ต้องมีชุดประเมินและข้อจำกัด เพราะข้อผิดพลาดอาจสัมพันธ์กัน

## Definition of Done

- รัน lab โดยไม่มี API key ได้
- แยก syntax error, schema error, evidence error และ provider error ได้
- ไม่มีผลสำเร็จปลอมเมื่อไม่ผ่าน validation
- ตรวจ retry count และใช้ mock ทำ failure ซ้ำได้
- บันทึก input reference, prompt/model/schema versions และผลการตรวจ
- อธิบายได้ว่าสิ่งใดยังต้องให้คนตรวจ และสิ่งใดเป็นเพียง mock

เมื่อขอ AI ช่วยเขียนโค้ด ให้ขออธิบาย input/output และ test ที่พิสูจน์พฤติกรรม ไม่ใช่ขอเพียงให้โค้ด “รันผ่าน”

## เส้นทางอ่านแบบ Textbook

```text
Core      → เข้าใจว่า LLM อยู่ตรงไหนและอะไรยังไม่ควรเชื่อ
Practice  → รัน mock, ทาย expected result และอ่าน reason code
Deep Dive → ใช้ออกแบบ provider, eval, security และ production handoff
```

อย่ารออ่านจบทั้งเล่มก่อนรัน lab รอบแรก ให้สลับอ่านกับทดลอง: เปลี่ยน scenario ทีละค่า ดู output แล้วอธิบายว่าผ่าน/ไม่ผ่านด่าน parse, schema, evidence หรือ policy

ชิ้นงานวัดผลคือ code/tests/evaluation report/architecture note ไม่ใช่จำนวน prompt ที่ลองจนได้คำตอบที่ชอบ
