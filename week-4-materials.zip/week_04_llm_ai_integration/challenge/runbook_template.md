# Runbook Template — AI Output Guard

คัดลอกเป็น runbook.md ในผลงาน แล้วเติมผลที่ทดลองจริง ไม่ใส่ secrets หรือข้อความ Resume ทั้งฉบับ

## Environment

- Python/n8n/SDK versions: กรอก
- Provider: mock หรือบริการจริงที่ได้รับอนุญาต
- Prompt/schema/validator versions: กรอก
- Base URL ของ lab: http://127.0.0.1:8014

## Smoke test

เปิด API → GET /health → ส่ง positive fixture → ตรวจ profile/evidence → ส่ง hallucination fixture → ตรวจ needs_review/profile=null

## Failure handling

ระบุว่า invalid_json, invalid_schema, quote_not_found, refusal และ retry_exhausted ถูกส่งให้ใครตรวจ เก็บ reference ใด และใครมีสิทธิ์ replay อย่าเขียนว่า “retry อีกครั้ง” โดยไม่บอกเพดานและ business key

## ข้อจำกัด

เขียนอย่างน้อยหนึ่งกรณีที่ lexical checker ผ่านแต่ความหมายยังผิด พร้อมแนวทางให้คนตรวจ และระบุว่าส่วนใดยังไม่ได้ทดลองกับโมเดลจริง

