# Special Challenge — AI Output Guard

ทีม Ops มี code ที่ `json.loads()` ผ่านแล้วนำคำตอบ AI ไปใช้ทันที จึงเกิด false success และผลที่ไม่มีหลักฐาน งานของคุณคือซ่อม [starter.py](starter.py) โดยไม่แก้ tests เพื่อให้ผ่านง่ายขึ้น

## เริ่มอย่างไร

ติดตั้ง requirements ใน lab ก่อน แล้วจากโฟลเดอร์หลัก Week 4 รัน:

```powershell
python -m pytest challenge/test_acceptance.py -q
```

tests ของ challenge **ตั้งใจ fail ก่อนแก้** แยกจาก lab/test_pipeline.py ที่ควรผ่าน ไม่ใช่ชุดส่งมอบพังโดยไม่รู้ตัว

## สิ่งที่ต้องแก้

JSON syntax → schema → evidence; invalid result ห้ามอยู่ใน validated profile; retry เฉพาะ transient และจำกัด attempts; refusal ส่ง review; ไม่ส่ง raw document ลง log; versions และ human-review flag ต้องอยู่กับผล

## Test matrix เพิ่มเอง

| กรณี | Expected |
|---|---|
| valid claim | validated พร้อม evidence |
| malformed JSON | needs_review |
| schema ผิด | needs_review |
| claim ไม่มีหลักฐาน | needs_review/profile=null |
| transient | retry มีเพดาน |
| timeout ตลอด | provider_failed |
| refusal | review ไม่ bypass |
| คำสั่งแฝง | ไม่มี tool side effect |

ชุด acceptance ที่แนบเป็นเพียงบางข้อ ไม่แทน matrix ทั้งหมด ให้เพิ่มอย่างน้อย 4 tests ที่ starter ยังไม่ครอบคลุม รวมกรณีความหมายไม่ชัดเจน

## เกณฑ์ 100 คะแนน

Schema/contract 20, evidence 25, failure policy 20, tests/evaluation 20, safety/runbook 15 ผ่าน 80 และห้ามมี false success, retry ไม่จบ หรือ credentials ในผลงาน

ส่ง starter ที่แก้แล้ว, test_results.md และ runbook ระบุข้อจำกัด มี reference implementation ใน lab ให้เทียบหลังพยายามเอง แต่ควรอธิบายแต่ละเงื่อนไขได้ ไม่คัดลอกเพียงเพื่อให้สีเขียว

