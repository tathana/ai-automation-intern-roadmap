# AI Output Guard — คำใบ้

1. เริ่มจากใส่ Pydantic ระหว่าง json.loads กับ return แล้วแยก ValidationError จาก JSONDecodeError
2. quote ต้องไม่ว่าง, source_id ต้องมีจริง และต้องอ่านจาก segment เดียวกัน
3. profile ที่ไม่ผ่านอย่าเก็บใน field ที่ downstream เข้าใจว่าตรวจแล้ว
4. ตรวจ retry count ด้วย mock counter ไม่ใช้เวลารันที่ดูนานเป็นหลักฐาน
5. “human review=true” ต้องมีเส้นทางให้คนตรวจจริงเมื่อรวมระบบ ไม่ใช่ flag ที่ไม่มีใครใช้งาน

คิดเพิ่ม: ถ้า quote เป็นความจริงในเอกสาร แต่เป็นคำพูดของผู้สมัครอีกคนที่ถูกแนบเข้ามาผิดไฟล์ ระบบยังอาจจับไม่ทัน ต้องมี identity/file/task mapping จาก Week 3 ช่วยด้วย

