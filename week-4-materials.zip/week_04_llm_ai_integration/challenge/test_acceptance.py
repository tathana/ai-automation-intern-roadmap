import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
from provider import MockProvider
from schemas import Request
from starter import process


def test_invented_claim_must_not_pass():
    req = Request(candidate_id="C1", segments={"p1":"Built a Python ETL project."})
    result = process(req, MockProvider("hallucination"))
    assert result["status"] == "needs_review"
    assert result["profile"] is None


def test_human_review_remains_required():
    req = Request(candidate_id="C1", segments={"p1":"Built a Python ETL project."})
    assert process(req, MockProvider())["needs_human_review"] is True


def test_invalid_json_is_handled():
    req = Request(candidate_id="C1", segments={"p1":"Built a Python ETL project."})
    assert process(req, MockProvider("invalid_json"))["status"] == "needs_review"
