# 12 — เชื่อม FastAPI กลับเข้า n8n

## เริ่มจาก endpoint ที่มี contract

เปิด lab ที่ port 8014 แล้ว import [01_ai_mock_probe.json](workflows/01_ai_mock_probe.json) เป็น workflow ใหม่ จะได้ Manual Trigger → Seed Request → Analyze API → Inspect Result

```json
{"candidate_id":"C1","segments":{"p1":"Built a Python ETL project."},"scenario":"normal"}
```

HTTP Request ส่ง JSON นี้ไป POST `/analyze` แล้วตรวจ full response การตอบ HTTP 200 หมายถึง service ประเมิน request เสร็จ ไม่รับรองว่าผล AI ผ่าน ให้ดู `body.status` และ `body.needs_human_review` ด้วย

## สถานะใน lab

| status | ความหมาย | ทำต่อ |
|---|---|---|
| validated | ผ่านกฎตรวจที่มีใน lab | แสดงหลักฐานให้คนตรวจ ยังไม่ใช่ hiring decision |
| needs_review | refusal/output/evidence ใช้ไม่ได้ | เก็บเหตุผลและส่งคิวคนตรวจ |
| provider_failed | ลองตามเพดานแล้วยังไม่ได้ผล | ติดตาม incident/replay ตาม policy |

Input ไม่ตรง schema ใช้ HTTP 422 ของ FastAPI แยกจากผลประมวลผลข้างต้น Node Inspect Result เป็นเพียงตัวแสดงสถานะ ไม่ใช่ durable review queue

## ต่อจาก Week 3 อย่างไร

```text
Week 3 task_id + candidate_id + file reference
                  ↓ worker ที่คุณประกอบ
             สกัดเป็น segments
                  ↓
           Week 4 POST /analyze
                  ↓
          ตรวจ status แล้วเก็บผล/audit
```

Week 3 queued task ยังไม่มี worker อัตโนมัติ บทนี้เตรียมส่วนวิเคราะห์ให้ต่อได้ ส่วนการหยิบ task, claim งาน, เก็บ result และ replay หลัง crash จะรวมให้ครบใน Week 5 อย่ารายงานว่าทั้งระบบทำงานอัตโนมัติแล้วจากการรัน probe ครั้งเดียว

## Failure drill

เปลี่ยน scenario เป็น hallucination, invalid_json และ timeout ทีละค่า แล้วดู Input/Output ทุก node เก็บ candidate_id กับเหตุผลให้ถูกคน หาก n8n อยู่ Docker ต้องปรับ host ตามบท Week 3 ไม่ใช้ localhost ของ container แทน Windows host

## จำลอง Canvas และสิ่งที่ควรเห็น

```text
[Manual] → [Seed Request] → [Analyze API] → [Inspect Result] → [Switch]
                                                    ├─ validated
                                                    ├─ needs_review
                                                    └─ provider_failed
```

```text
Selected: Analyze API
INPUT                         PARAMETERS               OUTPUT
candidate_id: C1             POST /analyze            statusCode: 200
segments.p1: Built...        JSON = current item      body.status: validated
scenario: normal             timeout: 5000            body.profile: {...}
```

HTTP 200 บอกว่า service ตอบตาม protocol แต่ Switch ต้องอ่าน `body.status` อีกชั้น หาก n8n เปิด Never Error ต้องมี branch สำหรับ non-2xx และ output ที่ไม่มี body รูปร่างปกติ

## Practice: ตารางทดลองสี่รอบ

| scenario | expected status | profile | retry |
|---|---|---|---:|
| normal | validated | มี | 0 |
| hallucination | needs_review | ไม่มี | 0 |
| invalid_json | needs_review | ไม่มี | ตาม lab policy |
| timeout | provider_failed | ไม่มี | ถึงเพดาน |

เก็บ execution ID ของแต่ละรอบ แล้วตรวจว่า node `Inspect Result` ไม่สร้างค่า default ที่ทำให้ failure ดูเป็น validated
