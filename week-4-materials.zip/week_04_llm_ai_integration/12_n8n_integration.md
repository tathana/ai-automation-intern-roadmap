# 12 — เชื่อม FastAPI กลับเข้า n8n

## เริ่มจาก endpoint ที่มี contract

เปิด lab ที่ port 8014 แล้ว import [01_ai_mock_probe.json](workflows/01_ai_mock_probe.json) เป็น workflow ใหม่ จะได้ Manual Trigger → Seed Request → Analyze API → Inspect Result

```json
{"candidate_id":"C1","segments":{"p1":"Built a Python ETL project."},"scenario":"normal"}
```

HTTP Request ส่ง JSON นี้ไป POST `/analyze` แล้วตรวจ full response การตอบ HTTP 200 หมายถึง service ประเมิน request เสร็จ ไม่รับรองว่าผล AI ผ่าน ให้ดู `body.status` และ `body.needs_human_review` ด้วย

## สถานะใน lab

| status | ความหมาย | ทำต่อ |
|---|---|---|
| validated | ผ่านกฎตรวจที่มีใน lab | แสดงหลักฐานให้คนตรวจ ยังไม่ใช่ hiring decision |
| needs_review | refusal/output/evidence ใช้ไม่ได้ | เก็บเหตุผลและส่งคิวคนตรวจ |
| provider_failed | ลองตามเพดานแล้วยังไม่ได้ผล | ติดตาม incident/replay ตาม policy |

Input ไม่ตรง schema ใช้ HTTP 422 ของ FastAPI แยกจากผลประมวลผลข้างต้น Node Inspect Result เป็นเพียงตัวแสดงสถานะ ไม่ใช่ durable review queue

## ต่อจาก Week 3 อย่างไร

```text
Week 3 task_id + candidate_id + file reference
                  ↓ worker ที่คุณประกอบ
             สกัดเป็น segments
                  ↓
           Week 4 POST /analyze
                  ↓
          ตรวจ status แล้วเก็บผล/audit
```

Week 3 queued task ยังไม่มี worker อัตโนมัติ บทนี้เตรียมส่วนวิเคราะห์ให้ต่อได้ ส่วนการหยิบ task, claim งาน, เก็บ result และ replay หลัง crash จะรวมให้ครบใน Week 5 อย่ารายงานว่าทั้งระบบทำงานอัตโนมัติแล้วจากการรัน probe ครั้งเดียว

## Failure drill

เปลี่ยน scenario เป็น hallucination, invalid_json และ timeout ทีละค่า แล้วดู Input/Output ทุก node เก็บ candidate_id กับเหตุผลให้ถูกคน หาก n8n อยู่ Docker ต้องปรับ host ตามบท Week 3 ไม่ใช้ localhost ของ container แทน Windows host

